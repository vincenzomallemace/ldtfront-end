import { AppContexts } from "commons/contexts/AppContexts"
import { Route, Routes } from "react-router-dom"
import { routes } from "routes"
import "./index.css";

export const Federation = () => {

  return (
    <div id="life-quotation-mfe" className="life-quotation-mfe">
      <AppContexts>
        <Routes>
          {routes.map(e => <Route key={e.path} path={`${e.path}`} element={<e.component />} />)}
        </Routes>
      </AppContexts>
    </div>
  )
}

export default Federation