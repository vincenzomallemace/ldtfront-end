import { Loader } from "@aws-amplify/ui-react";
import { CheckCircleIcon, PencilIcon } from "@heroicons/react/solid";
import YogaCard from "commons/components/YogaCard";
import { YogaMessage } from "commons/components/YogaMessage";
import { UserContext } from "commons/contexts/UserProvider";
import useContract from "contracts/hooks/useContract";
import useContractConfirmed from "contracts/hooks/useContractConfirmed";
import { DocumentsUpload } from "documents/components/DocumentsUpload";
import OutputDocuments from "documents/components/OutputDocuments";
import { useContext } from "react";
import { FormattedMessage } from "react-intl";
import DigitalSignatureSwitch from "./DigitalSignatureSwitch";
import useDigitalSwitch from "contracts/hooks/useDigitalSignature";
import { DocumentsCheck } from "documents/components/DocumentCheck";
import { YogaButton } from "commons/components/YogaButton";
import { useEffect, useState } from "react";
import { financialAdvicesService } from "offers/services/FinancialAdvicesService";
import { adviceService } from "commons/services/AdviceService";
import {
  Adviceinformation,
  AdviceData,
  AdviceDocument,
} from "documents/models/AdviceInformation";
import AdviceDocuments from "documents/components/AdviceDocuments";
import {
  ProcessStatus,
  webCollaborationService,
} from "commons/services/WebCollaborationService";
// import { nawService } from "commons/services/NAWService";
import { Contract } from "contracts/models/Contract";
// import { NAWSaveProposalInfo } from "../../documents/models/NAWSaveProposalInfo";
// import useDossierInfo from "documents/hooks/useDossierInfo";
//import {useNavigate} from "react-router-dom";
//import {CTX} from "commons/Configuration";

interface ConfirmIssueContractProps {
  contractId: string;
  processStatus?: string;
  signStatus:(signStatus: boolean) => void;
  onWebCollaborationStart?: (id: string) => void;
  onSaveNAWStart?: (contractCompleted: Contract) => void;
  isBundle?: boolean;
}

export default function ConfirmIssueProposal({
  contractId,
  processStatus,
  signStatus,
  onWebCollaborationStart,
  // onSaveNAWStart
}: ConfirmIssueContractProps) {
  const { policyholder } = useContract(contractId);
  const { contract, contractCompleted, contractError } =
    useContractConfirmed(contractId);
  const { user } = useContext(UserContext);
  const [dossierId, setDossierId] = useState<string>(undefined);
  const [isDossierValid, setIsDossierValid] = useState<boolean>(undefined);

  const [adviceData, setAdviceData] = useState<Adviceinformation>(undefined);
  const [errorAdvice, setErrorAdvice] = useState<boolean>(undefined);

  // custom holo signature handler
  const [adviceChecked, setAdviceChecked] = useState<boolean>(false);
  const [outputChecked, setOutputChecked] = useState<boolean>(false);
  const [inputChecked, setInputChecked] = useState<boolean>(false);

  // const { getInfo } = useDossierInfo();
  const { digitalSignature, handleDigitalSignature, disabled } =
    useDigitalSwitch(contract, policyholder);

  //const navigate = useNavigate();

  useEffect(() => {
    signStatus(digitalSignature)
  }, [digitalSignature])

  function getPolizzaPayload(): AdviceData | undefined {
    if (adviceData) {
      const ndgPatrimonio: number =
        policyholder.parameters["ndg"] &&
        policyholder.parameters["ndg"].value &&
        !isNaN(Number(policyholder.parameters["ndg"].value))
          ? Number(policyholder.parameters["ndg"].value)
          : 0; //TODO Viene valorizzata da Anagrafe
      return {
        ndgOperatore: adviceData.ndgUtente,
        ndgPatrimonio: ndgPatrimonio,
        ndgOrdinante: adviceData.ndgOrdinante,
        matricolaOperatore: adviceData.matricolaUtente,
        codiceModelloPdfGenerico: adviceData.codiceModelloPdfGenerico,
        numeroProtocolloPdfGenerico: adviceData.numeroProtocolloPdfGenerico,
        descrizioneModelloPdfGenerico: adviceData.descrizioneModelloPdfGenerico,
        tipoOperazione: adviceData.ordinePolizza && adviceData.ordinePolizza.length > 0 ? adviceData.ordinePolizza[0].tipoOperazione : "",
        adviceDocument: adviceData.ordinePolizza.map((e: any) => ({
          codiceModelloPdf: e.codiceModelloPdf,
          numeroProtocolloPdf: e.numeroProtocolloPdf,
          descrizioneModelloPdf: e.descrizioneModelloPdf,
        })),
      };
    }
  }

  function getAdviceDocuments(): AdviceDocument[] | undefined {
    if (adviceData && adviceData.ordinePolizza) {
      const polizzaDocuments: AdviceDocument[] = adviceData.ordinePolizza.map(
        (e: any) => ({
          codiceModelloPdf: e.codiceModelloPdf,
          numeroProtocolloPdf: e.numeroProtocolloPdf,
          descrizioneModelloPdf: e.descrizioneModelloPdf,
        })
      );
      return [
        {
          codiceModelloPdf: adviceData.codiceModelloPdfGenerico,
          numeroProtocolloPdf: adviceData.numeroProtocolloPdfGenerico,
          descrizioneModelloPdf: adviceData.descrizioneModelloPdfGenerico,
        },
        ...polizzaDocuments,
      ];
    }
  }

  useEffect(() => {
    getAdviceData();
  }, [policyholder, contract]);

  async function getAdviceData() {
    if (contract && policyholder) {
      try {
        const finantialAdvice = await financialAdvicesService.getByProductId(
          contract.quotationId
        );
        if (finantialAdvice && finantialAdvice.data) {
          const codiceIac =
            finantialAdvice.data.financialOffers &&
            finantialAdvice.data.financialOffers.length > 0
              ? finantialAdvice.data.financialOffers.find(
                  (x) => x.product.productId === contract.quotationId
                ).financialOfferId
              : undefined;
          const ndg =
            policyholder.parameters["ndg"] &&
            policyholder.parameters["ndg"].value
              ? policyholder.parameters["ndg"].value.toString()
              : undefined; //TODO Viene valorizzata da Anagrafe

          const res = await adviceService.getAdviceInformation(ndg, codiceIac);
          if (res && res.data) {
            setAdviceData(res.data);
            setErrorAdvice(false);
          } else {
            setAdviceData(undefined);
            setErrorAdvice(true);
          }
          console.log("PIPPO: " + adviceData);
          console.log("NDG: " + ndg + " IAC: " + codiceIac);
        }
      } catch (e) {
        setErrorAdvice(true);
      }
    }
  }

  function startWebCollaboration(){
    if(digitalSignature){
    webCollaborationService
      .initFirmaAsync(dossierId, contract, getPolizzaPayload(), false)
      .then(() => {
        onWebCollaborationStart &&
          onWebCollaborationStart(dossierId);
      })
      .catch((res) => alert(res.data));
    }
    else{
      webCollaborationService
      .initFirmaAsync(dossierId, contract, getPolizzaPayload(), true)
      .then(() => {
        onWebCollaborationStart &&
          onWebCollaborationStart(dossierId);
      })
      .catch((res) => alert(res.data));
    }
  }

  // async function startlastSaveNAW(){
  //   let dossierInfo = await getInfo(contractId);
  //   const input: NAWSaveProposalInfo = {
  //     contract: contract,
  //     dossierInfo: dossierInfo
  //   }
  //   nawService.lastSaveNAW(input)
  //     .then(() => {
  //       onSaveNAWStart &&
  //       onSaveNAWStart(contractCompleted);
  //     })
  //     .catch((res) => alert(res.data))
  // }

  /*const goToProposalDetail = () => {
    navigate(`${CTX}/offers/${contractId}/detail`);
  };*/

  return (
    <>
      {contract && (
        <>
          {contractCompleted ? (
            <div className="flex flex-col space-y-4 px-4 gap-y-4">
              <YogaCard success uniformPadding>
              <div className="flex justify-between items-center">
                <div
                    className="flex text-title-text text-xl font-bold items-center"
                    data-qa="policyNumberSaved"
                  >
                    <CheckCircleIcon className="w-6 h-6 mr-2 text-success flex-shrink-0" />

                    <FormattedMessage
                      id="proposalCreated"
                      values={{
                        number:
                          (contractCompleted.managementNode
                            ? contractCompleted.managementNode.code + "/"
                            : "") + contractCompleted.policyNumber,
                      }}
                    />
                  </div>
              </div>

              </YogaCard>
              <YogaCard uniformPadding>
                <div className="flex float-right items-center">
                  {/* <div
                    className="flex text-title-text text-xl font-bold items-center"
                    data-qa="policyNumberSaved"
                  >
                    <CheckCircleIcon className="w-6 h-6 mr-2 text-success flex-shrink-0" />

                    <FormattedMessage
                      id="proposalCreated"
                      values={{
                        number:
                          (contractCompleted.managementNode
                            ? contractCompleted.managementNode.code + "/"
                            : "") + contractCompleted.policyNumber,
                      }}
                    />
                  </div> */}
                  <div className="flex items-center" style={{zIndex:1}}>
                    <YogaButton
                      action={() => {
                        if (digitalSignature && dossierId) {
                          console.log("chiamare api web collection");
                          startWebCollaboration()
                          return;
                        }
                        if (
                          !digitalSignature &&
                          dossierId &&
                          adviceChecked &&
                          outputChecked &&
                          inputChecked
                        ) {
                          console.log("firma olografa");
                          // startlastSaveNAW()
                          startWebCollaboration()
                          return;
                        }
                        console.log("chiudi dossier");
                      }}
                      disabled={
                        digitalSignature
                          ? !isDossierValid ||
                            (processStatus &&
                              processStatus !== ProcessStatus.ERROR)
                          : !(
                              !digitalSignature &&
                              dossierId &&
                              adviceChecked &&
                              outputChecked &&
                              inputChecked
                            ) // todo: to implement for other fields, thats just for adivce documents
                      }
                    >
                      <PencilIcon className="w-5 mr-2 -ml-1 flex-shrink-0" />
                      <FormattedMessage
                        id={
                          digitalSignature
                            ? "closeDossierDigitally"
                            : "closeDossier"
                        }
                      />
                    </YogaButton>
                  </div>
                  {/* <YogaButton
                  action={goToContractDetail}
                  data-qa="back-to-contract"
                  position="inner"
                >
                  <SearchIcon className="w-5 mr-2 -ml-1 flex-shrink-0" />
                  {isInsurance ? (
                    <FormattedMessage id="showPolicy" />
                  ) : (
                    <FormattedMessage id="showContract" />
                  )}
                </YogaButton> */}
                </div>

                <DigitalSignatureSwitch
                  digitalSignature={digitalSignature}
                  disabled={disabled}
                  handleDigitalSignature={handleDigitalSignature}
                />
              </YogaCard>
              {policyholder && (
                <div className="grid grid-cols-1 gap-y-6">
                  <AdviceDocuments
                    documents={getAdviceDocuments()}
                    error={errorAdvice}
                    holoSign={!digitalSignature}
                    onChangeCheck={(value: boolean) => {
                      console.log("are advice checked? ", value);
                      setAdviceChecked(value);
                    }}
                  />
                  <div className="col-span-2">
                    <OutputDocuments
                      user={user}
                      setPageDossierId={setDossierId}
                      contractId={contractId}
                      signatureEnabled={policyholder.otpSignatureEnabled}
                      holoSign={!digitalSignature}
                      onChangeCheck={(value: boolean) => {
                        console.log("are output documents checked? ", value);
                        setOutputChecked(value);
                      }}
                    />
                  </div>
                  {digitalSignature ? (
                    <DocumentsUpload
                      setPageDossierId={setDossierId}
                      contractId={contractId}
                      contractNumber={undefined}
                      setIsDossierLoaded={() => {}}
                      setIsDossierValid={setIsDossierValid}
                    />
                  ) : (
                    <DocumentsCheck
                      setPageDossierId={setDossierId}
                      contractId={contractId}
                      contractNumber={undefined}
                      setIsDossierLoaded={() => {}}
                      setIsDossierValid={setIsDossierValid}
                      onChangeCheck={(value: boolean) => {
                        console.log("are input documents checked? ", value);
                        setInputChecked(value);
                      }}
                    />
                  )}
                </div>
              )}
            </div>
          ) : (
            <YogaCard>
              <div className="flex items-center">
                {!contractError ? (
                  <div
                    className="flex text-title-text text-xl font-bold items-center"
                    data-qa="proposal-issuing"
                  >
                    <Loader
                      className="w-6 h-6 mr-2 flex-shrink-0"
                      emptyColor="var(--box-background)"
                      filledColor="var(--title-text)"
                    />
                    <FormattedMessage id="proposalIssuing" />
                  </div>
                ) : (
                  <div className="w-full" data-qa="proposal-issuing-errors">
                    <YogaMessage position="inner" type="error">
                      <FormattedMessage id={contractError.message} />
                    </YogaMessage>
                  </div>
                )}
              </div>
            </YogaCard>
          )}
        </>
      )}
    </>
  );
}
