import { Loader } from "@aws-amplify/ui-react";
import { ArrowCircleRightIcon } from "@heroicons/react/outline";
import { CheckCircleIcon, ExclamationCircleIcon } from "@heroicons/react/solid";
import { YogaButton } from "commons/components/YogaButton";
import YogaCard from "commons/components/YogaCard";
import { ProcessStatus } from "commons/services/WebCollaborationService";
import { FormattedMessage } from "react-intl";

interface WaitProcessingProps {
  processStatus: string;
  contractId: string;
  dossierId: string;
  goToDetails?: () => void;
}

export default function WaitProcessing({ processStatus, /*contractId, dossierId,*/ goToDetails }: WaitProcessingProps) {

  function getText() {
    if (processStatus === ProcessStatus.ERROR) {
      return <FormattedMessage id="errorPageTitle" />;
    }
    if (processStatus === ProcessStatus.END) {
      return <FormattedMessage id="continue" />;
    }
    return <FormattedMessage id="waitWebCollab" />;
  }

  function getImage() {
    if (processStatus === ProcessStatus.ERROR) {
      return (
        <ExclamationCircleIcon className="w-24 h-24 mr-2 flex-shrink-0 text-error" />
      );
    }
    if (processStatus === ProcessStatus.END) {
      return (
        <CheckCircleIcon className="w-24 h-24 mr-2 flex-shrink-0 text-success" />
      );
    }
    return (
      <Loader
        className="w-24 h-24 mr-2 flex-shrink-0"
        emptyColor="var(--box-background)"
        filledColor="var(--title-text)"
        fr={undefined}
      />
    );
  }

  function onClose() {
    goToDetails();
  }

  function getYogaCardBorder(type: string): boolean{
    switch (type){
      case 'success': {
        if(processStatus === ProcessStatus.END)
          return true;
        else
          return false;
      }
      case 'error': {
        if(processStatus === ProcessStatus.ERROR)
          return true;
        else
          return false
      }
      case 'info': {
        if(processStatus === ProcessStatus.RUNNING || processStatus === ProcessStatus.INIT)
          return true;
        else
          return false;
      }
      default: {
        return false;
      }

    }
  }

  return (
      <YogaCard border={getYogaCardBorder('info')} success={getYogaCardBorder('success')} error={getYogaCardBorder('error')} uniformPadding>
        <div style={{display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center"}}>
          <>{getImage()}</>
          <div className="grow text-xl">{getText()}</div>
          <div className="h-24">
            {processStatus === ProcessStatus.ERROR && (
              <YogaButton>
                <ArrowCircleRightIcon className="w-5 h-5" />
                    <div className="hidden lg:block">
                      <FormattedMessage id="goBackSign" />
                    </div>
              </YogaButton>
            )}
            {processStatus === ProcessStatus.END && (
              <YogaButton
              action={onClose}>
              <ArrowCircleRightIcon className="w-5 h-5" />
                    <div className="hidden lg:block">
                      <FormattedMessage id="continue" />
                    </div>
              </YogaButton>
              // <>{endingHTML()}</>
            )}
          </div>
        </div>
      </YogaCard>


  );
}
