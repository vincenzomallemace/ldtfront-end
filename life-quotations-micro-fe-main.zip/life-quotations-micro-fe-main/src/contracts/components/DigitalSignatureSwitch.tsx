import YogaCard from "commons/components/YogaCard";
import { YogaChip } from "commons/components/YogaChip";
import { FormattedMessage } from "react-intl";

import "./DigitalSignatureSwitch.css";
import ToggleSignSwitch from "commons/components/ToggleSignSwitch";

interface DigitalSignatureProps {
  digitalSignature: boolean;
  disabled?: boolean;
  handleDigitalSignature: () => void;
}

export default function DigitalSignatureSwitch({
  digitalSignature,
  disabled,
  handleDigitalSignature,
}: DigitalSignatureProps) {
  return (
    <div>
      <YogaCard inner>
        <div className="flex flex-row items-center justify-between">
          {/* <div className="basis-1/8 font-medium">
            <FormattedMessage id="digitalSignature" />
          </div> */}
          <div
            className="basis-1/8 pt-1"
            onClick={() => handleDigitalSignature()}
          >
            {/* <ToggleSwitch
              small
              disabled={false}
              id="digitalSignature"
              checked={digitalSignature}
              onChange={() => {}}
            /> */}
            <ToggleSignSwitch
              small={false}
              disabled={disabled}
              id="digitalSignature"
              checked={digitalSignature}
              onChange={() => {}}
            />
          </div>
          <div className="basis-3/4 h-full">
            {!digitalSignature ? (
              <YogaChip
                className="bg-draft attention-sign-chip"
                type={"default"}
              >
                <div className="flex flex-row h-full text-body-text items-center">
                  {/* <div className="font-bold mr-4">
                    <FormattedMessage id="attention" />
                  </div> */}
                  <div className="flex grow text-sm tracking-tight">
                    <FormattedMessage id="holoSignDetails" />
                  </div>
                </div>
              </YogaChip>
            ) : (
              <></>
            )}
          </div>
        </div>
      </YogaCard>
    </div>
  );
}
