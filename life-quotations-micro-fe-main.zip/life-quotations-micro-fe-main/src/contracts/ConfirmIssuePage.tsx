//import {UserIcon} from "@heroicons/react/solid";
import { CTX } from "commons/Configuration";
import { StickyBar } from "commons/components/StickyBar";
//import {YogaButton} from "commons/components/YogaButton";
import { Context } from "commons/contexts/Context";
import useNotices from "commons/hooks/useNotices";
import { useContext, useEffect, useState } from "react";
import { FormattedMessage } from "react-intl";
import { useNavigate, useParams } from "react-router-dom";
import useContract from "./hooks/useContract";
import ConfirmIssueProposal from "./components/ConfirmIssueProposal";
import { ProcessStatus, webCollaborationService } from "commons/services/WebCollaborationService";
import WaitProcessing from "./components/WaitProcessing";
import { ProcessNAWStatus, nawService } from "commons/services/NAWService";
import { Contract } from "./models/Contract";
import { YogaMessage } from "commons/components/YogaMessage";
import { NAWSaveProposalInfo } from "../documents/models/NAWSaveProposalInfo";
import useDossierInfo from "documents/hooks/useDossierInfo";

export default function ConfirmIssuePage() {
  const { contractId } = useParams();
  const { contract, policyholder } = useContract(contractId);
  const context = useContext(Context);
  const notices = useNotices();
  const [digitalSignature, setDigitalSignature] = useState<boolean>(false);
  // const [navigateDigitalSignPage, setNavigateDigitalSignPage] = useState<boolean>(false);
  const [signStatus, setSignStatus] = useState<boolean>(undefined);
  const [processStatus, setProcessStatus] = useState<string>(undefined);
  const [nawProcessStatus, setNawProcessStatus] = useState<string>(undefined);
  // const [contractCompleted, setContractCompleted] = useState<Contract>(undefined)
  const [dossierId, setDossierId] = useState<string>(undefined);
  const navigate = useNavigate();
  const [errorMessages, setErrorMessages] = useState<string[]>([]);
  const { getInfo } = useDossierInfo();

  /*
  const goToPartyDetail = () => {
    navigate(`/customers/${policyholder.partyId}`);
  };
  */

  const goToContractDetail = () => {
    // navigate(`${CTX}/offers/${contractId}/${signStatus}/outcome`);
    navigate(`${CTX}/offers/${contractId}/${signStatus}/outcome`);
  };

  function isProcessRunning(): boolean {
    return processStatus === ProcessStatus.INIT || processStatus === ProcessStatus.RUNNING;
  }

  function isNAWProcessRunning(): boolean {
    return nawProcessStatus === ProcessNAWStatus.INIT || nawProcessStatus === ProcessNAWStatus.RUNNING;
  }

  useEffect(() => {
    context.clearLoading();
  }, []);

  // useEffect(() => {
  //   orchestrationSignature();
  // }, [digitalSignature, processStatus]);
  useEffect(() => {
    orchestrationSignature();
  }, [processStatus]);

  useEffect(() => {
    context.clearLoading();

    notices.reload();
  }, []);

  // function orchestrationSignature() {
  //   if (digitalSignature == true && processStatus === ProcessNAWStatus.END) {
  //     setProcessStatus(undefined);
  //     setNawProcessStatus(undefined);
  //     setDigitalSignature(false);
  //     callLastSaveNAW();
  //   }
  // }

  function orchestrationSignature() {
    if (processStatus === ProcessNAWStatus.END) {
      setProcessStatus(undefined);
      setNawProcessStatus(undefined);
      // setDigitalSignature(false);
      callLastSaveNAW();
    }
  }

  async function callLastSaveNAW() {
    let dossierInfo = await getInfo(contractId);
    const input: NAWSaveProposalInfo = {
      contract: contract,
      dossierInfo: dossierInfo
    }
    nawService
      .lastSaveNAW(input)
      .then(() => {
        setDigitalSignature(false);
        setNawProcessStatus(ProcessNAWStatus.INIT);
      })
      .catch((res) => alert(res.data));
  }

  function getStatus() {
    webCollaborationService
      .processAsyncStatus(dossierId)
      .then((res) => {
        setProcessStatus(res.data.state);
      })
      .catch((e) => console.log(e));
  }

  function getNAWStatus() {
    nawService
      .processAsyncStatus(contractId)
      .then((res) => {
        setNawProcessStatus(res.data.processState);
        setErrorMessages(res.data.errori.errors);
      })
      .catch((e) => console.log(e));
  }

  useEffect(() => {
    if (isProcessRunning() && dossierId) {
      getStatus();
      const interval = setInterval(() => getStatus(), 2000);
      return () => {
        clearInterval(interval);
      };
    }
    if (processStatus === ProcessStatus.ERROR) {
      const delay = (ms) => new Promise((res) => setTimeout(res, ms));
      delay(5000).then(() => setProcessStatus(undefined));
    }
  }, [processStatus, dossierId]);

  useEffect(() => {
    if (isNAWProcessRunning() && contractId) {
      getNAWStatus();
      const interval = setInterval(() => getNAWStatus(), 2000);
      return () => {
        clearInterval(interval);
      };
    }
    if (nawProcessStatus === ProcessNAWStatus.ERROR) {
      const delay = (ms) => new Promise((res) => setTimeout(res, ms));
      delay(5000).then(() => setNawProcessStatus(undefined));
    }
  }, [nawProcessStatus, contractId]);

  function getWaitingStatus(): string {
    if (digitalSignature) {
      return processStatus;
    } else {
      return nawProcessStatus;
    }
  }

  function setStatusSwitch(signStatusToggle: boolean) {
    setSignStatus(signStatusToggle);
    console.log(signStatus);
  }

  return (
    <div>
      <>
        <StickyBar
          hasBackButton={false}
          breadcrumb={
            <div className="flex flex-col">
              <div data-qa="confirm-page-title" className="truncate">
                <FormattedMessage id="proposalIssueConfirm" />
              </div>
              <div className="inline-flex flex-wrap gap-x-4 items-center" data-qa="extra-info">
                {/*contract?.quotationNumber && (
                    <span
                      className="text-base font-normal truncate"
                      data-qa="product-quotationNumber"
                    >
                  N. {contract.quotationNumber}
                </span>
                  )*/}
                <span className="text-base font-normal truncate" data-qa="policyholder-title">
                  {policyholder?.surnameOrCompanyName}&nbsp;
                  {policyholder?.name}
                </span>
                <span className="text-base font-normal truncate" data-qa="product-description">
                  {contract?.contractProductName}
                </span>
              </div>
            </div>
          }
        >
          {/* <YogaButton
          action={goToPartyDetail}
          kind="default"
          data-qa="back-to-party"
        >
          <UserIcon className="w-5 mr-2 -ml-1 flex-shrink-0" />
          <FormattedMessage id="backToParty" />
        </YogaButton> */}
        </StickyBar>
        {errorMessages &&
          errorMessages.map((error, index) => {
            return (
              <YogaMessage type="error" position="outer" key={index}>
                <p data-qa={error}>{error}</p>
              </YogaMessage>
            );
          })}

        {processStatus || nawProcessStatus ? (
          // <>{waitingComponent}</>
          <WaitProcessing processStatus={getWaitingStatus()} contractId={contractId} dossierId={dossierId} goToDetails={() => goToContractDetail()} />
        ) : (
          <ConfirmIssueProposal
            contractId={contractId}
            processStatus={processStatus}
            signStatus={(signStatus: boolean) => {
              setStatusSwitch(signStatus);
            }}
            onWebCollaborationStart={(dossierId: string) => {
              setDossierId(dossierId);
              setDigitalSignature(true);
              // setNavigateDigitalSignPage(true);
              setProcessStatus(ProcessStatus.INIT);
            }}
            onSaveNAWStart={(contractCompleted: Contract) => {
              // setContractCompleted(contractCompleted);
              console.log(contractCompleted.contractId);
              setDigitalSignature(false);
              // setNavigateDigitalSignPage(false);
              setNawProcessStatus(ProcessNAWStatus.INIT);
            }}
          />
        )}
      </>
    </div>
  );
}
