import ContractParameter from "./ContractParameter";
import { Money } from "commons/models/YogaModels";
import { InvestmentLine } from "./InvestmentLine";

export default interface ContractCoverage {
  coverageId: string;
  coverageCode: string;
  coverageDescription: string;
  coveragePremium?: Money;
  parameters: { [code: string]: ContractParameter };
  coverageAssociatedValueInstant?: Date;
  coverageValuation?: Money;
  grossSurrenderValue?: Money;
  validityInstantFrom?: Date;
  validityInstantTo?: Date;
  coveragePackage: string[];
  minCoverageAdditionalPremium?: Money;
  maxCoverageAdditionalPremium?: Money;
  maxCumulativeCoverage?: Money;
  actualCumulativeCoverage?: Money;
  investmentLines?: InvestmentLine[];
  coverageOrder?: number;
}
