import { KeyValue, Money } from "commons/models/YogaModels";
import { YogaParam } from "commons/models/YogaParam";
import { ManagementNode } from "commons/models/nodes/ManagementNode";
import { Party } from "customers/models/Party";
import ContractAsset from "./ContractAsset";
import { Beneficiaries } from "customers/models/Beneficiaries";
import AvailableBeneficiary from "commons/models/AvailableBeneficiary";
import { ContractContractualOption } from "offers/models/ContractualOption";
import { PartitionOption } from "offers/models/PartitionOption";

export interface Contract {
  addendum: String;
  hasAddendum: boolean;
  contractId: string;
  assets: KeyValue<ContractAsset>;
  // authorizationContractRoles: AuthorizationContractRoles[];
  channel?: string;
  quotationId?: string;
  contractCompleted: boolean;
  contractProductName: string;
  contractBranch: string;
  contractType: string;
  contractStatus: string;
  contractPremium: Money;
  contractEffectInstant: Date;
  contractExpirationInstant: Date;
  coverageEndInstant: Date;
  contractIssueInstant: Date;
  contractCancellationInstant?: Date;
  nextInstallmentAmount?: Money;
  contractFrequency: string;
  // operation?: Operation;
  parameters?: KeyValue<YogaParam>;
  productCode: string;
  policyType: string;
  policyNumber: string;
  policyholderId: string;
  tacitRenewal: boolean;
  editTacitRenewal: boolean;
  masterPolicyNumber?: string;
  lastUpdateInstant: Date;
  authorizationRequestEndValidityInstant?: Date;
  replacedPolicyNumber?: string;
  /**
   * @deprecated this property should not be used
   */
  paymentStatus?: string;
  productCategory: string;
  questionnaires: KeyValue<string>;
  contractDuration?: number;
  lifeProductCategory?: string;
  parties?: { [role: string]: Party[] };
  managementNode?: ManagementNode;
  quotationNumber?: string;
  messages: KeyValue<string[]>;
  quotationMessages?: KeyValue<string[]>;
  indexable: boolean;
  indexed: boolean;
  agreement?: string;
  // complements?: { [code: string]: ContractComplement };
  completeIssueInCustomerArea?: boolean;
  // substates?: ContractSubstates;
  availablePaymentMethods?: string[];
  availableBeneficiaries?: AvailableBeneficiary[];
  beneficiaries?: Beneficiaries;
  contractualOptions?: KeyValue<ContractContractualOption>;
  partitionOption?: PartitionOption;
}

export enum STATUS {
  ACTIVE_POLICY = "ACTIVE_POLICY",
  SUSPENDED_POLICY = "SUSPENDED_POLICY",
  INCOMPLETE = "INCOMPLETE",
  CANCELED_POLICY = "CANCELED_POLICY",
  TO_AUTHORIZE = "TO_AUTHORIZE",
  AUTHORIZED = "AUTHORIZED",
  REFUSED = "REFUSED",
  EXPIRED = "EXPIRED",
  EXPIRING = "EXPIRING",
  ACTIVE_PROPOSAL = "ACTIVE_PROPOSAL",
  DRAFT = "DRAFT",
  COMPLETED_PROPOSAL = "COMPLETED_PROPOSAL",
  VALID_PROPOSAL = "VALID_PROPOSAL",
}

export const isExpiring = (contract: Contract) => {
  const expirationDate = new Date(contract.contractExpirationInstant);
  expirationDate.setHours(0, 0, 0, 0);
  const now = new Date();
  now.setHours(0, 0, 0, 0);
  const from = new Date(expirationDate);

  from.setDate(expirationDate.getDate() - 5);
  return from < now && now <= expirationDate;
};

export const isExpired = (contract: Contract) => {
  const expirationDate = new Date(contract.contractExpirationInstant);
  expirationDate.setHours(0, 0, 0, 0);
  const now = new Date();
  now.setHours(0, 0, 0, 0);
  return now > expirationDate;
};

export const areContractErrors = (contract?: Contract) =>
  contract &&
  contract.messages &&
  (("failures" in contract.messages && contract.messages["failures"].length > 0) ||
    ("errors" in contract.messages && contract.messages["errors"].length > 0));
