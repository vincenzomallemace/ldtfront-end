// import { FundDetail } from "./FundDetail";

export interface InvestmentLine {
  code: string;
  description: string;
  funds: any[];
  percentage: number;
}
