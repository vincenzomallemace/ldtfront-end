import { Location } from "commons/models/Location";
import { KeyValue, Money } from "commons/models/YogaModels";
import { Party } from "customers/models/Party";
import ContractCoverage from "./ContractCoverage";
import ContractPackage from "./ContractPackage";
import ContractParameter from "./ContractParameter";
import { ContractUnitLinked } from "offers/models/UnitLinked";
import { PremiumComponents } from "models/PremiumComponents";
import { SegregatedFund } from "offers/models/SegregatedFund";

export default interface ContractAsset {
  assetId: string;
  assetCode: string;
  assetDescription: string;
  assetType: string;
  assetPremium?: Money;
  coverages: { [code: string]: ContractCoverage };
  parties: { [role: string]: Party[] };
  location?: Location;
  // motor?: AssetMotor;
  parameters: { [code: string]: ContractParameter };
  packages: ContractPackage[];
  insuredPersonRequired: boolean;
  oneMustBeThePolicyholder: boolean;
  locationRequired: boolean;
  policyHolderIsInsuredPerson?: boolean;
  locationIsPolicyHolderLocation?: boolean;
  label: string;
  order: number;
  assetOrder: number;
  // vehicle?: Vehicle;
  questionnaires: KeyValue<string>;
  unitLinked: KeyValue<ContractUnitLinked>;
  premium: PremiumComponents;
  segregatedFund?: SegregatedFund;
}
