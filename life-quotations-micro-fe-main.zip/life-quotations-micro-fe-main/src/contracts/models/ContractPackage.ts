import { Money } from "commons/models/YogaModels";
import ContractCoverage from "./ContractCoverage";
import ContractParameter from "./ContractParameter";

export default interface ContractPackage {
  packageId: string;
  name: string;
  premium?: Money;
  coverages: { [code: string]: ContractCoverage };
  parameters: { [code: string]: ContractParameter };
}
