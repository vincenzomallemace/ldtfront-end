export default interface ContractParameter {
  tags?: string[];
  key: string;
  value: string;
  type: string;
  currency?: string;
  order: number;
  visible?: boolean;
}
