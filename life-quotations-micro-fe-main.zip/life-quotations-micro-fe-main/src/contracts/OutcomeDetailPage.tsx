//import {UserIcon} from "@heroicons/react/solid";
import { CTX } from "commons/Configuration";
import { StickyBar } from "commons/components/StickyBar";
//import {YogaButton} from "commons/components/YogaButton";
import { Context } from "commons/contexts/Context";
import useNotices from "commons/hooks/useNotices";
import { useContext, useEffect, useState } from "react";
import { FormattedMessage } from "react-intl";
import { useNavigate, useParams } from "react-router-dom";
import useContract from "./hooks/useContract";
import { format, parseISO } from "date-fns";
import { webCollaborationService } from "commons/services/WebCollaborationService";
import { nawService } from "commons/services/NAWService";
import YogaCard from "commons/components/YogaCard";
import { ArrowCircleRightIcon, CalendarIcon, CheckCircleIcon, DocumentTextIcon, ExclamationIcon, PencilIcon } from "@heroicons/react/outline";
import { YogaButton } from "commons/components/YogaButton";
import { YogaMessage } from "commons/components/YogaMessage";
import { SignatureInfo } from "documents/models/SignatureInfo";

export default function OutcomeDetailPage() {
  const { contractId } = useParams();
  const { sign } = useParams();

  const { contract, policyholder } = useContract(contractId);
  const context = useContext(Context);
  const notices = useNotices();
  //const navigate = useNavigate();

  const [errorMessages, setErrorMessages] = useState<string[]>([]);
  const [warningMessages, setWarningMessages] = useState<string[]>([]);
  const [infoMessages, setInfoMessages] = useState<string[]>([]);
  //const [processNAWStatus, setProcessNAWStatus] = useState<string>(undefined);
  // const [contractCompleted, setContractCompleted] = useState<Contract>(undefined)
  // const [dossierId, setDossierId] = useState<string>(undefined);
  const [signInfo, setSignInfo] = useState<SignatureInfo>(undefined);
  const navigate = useNavigate();

  /*
  const goToPartyDetail = () => {
    navigate(`/customers/${policyholder.partyId}`);
  };
  */

  // const goToContractDetail = () => {
  //   navigate(`${CTX}/offers/${contractId}/detail`);
  // };

  useEffect(() => {
    context.clearLoading();
  }, []);

  useEffect(() => {
    //context.setForceRedirect(`${CTX}/offers/${contractId}/outcome`);
    context.clearLoading();
    notices.reload();
  }, []);

  useEffect(() => {
    // if (sign == "true") {
    //   getSignInfo();
    // }
    getSignInfo();
  }, []);

  useEffect(() => {
    getNAWStatus();
  }, []);

  function getSignInfo() {
    // webCollaborationService.signatureInfo("a6f37e25-1acd-4102-a78b-3d636d4667ed")
    webCollaborationService
      .signatureInfo(contractId)
      .then((res) => {
        if (res && res.data) {
          setSignInfo(res.data.signInfo);
        } else {
          setSignInfo(undefined);
        }
      })
      .catch((e) => console.log(e));
  }

  function getNAWStatus() {
    nawService
      .processAsyncStatus(contractId)
      .then((res) => {
        if (res.data && res.data.errori) {
          setErrorMessages(res.data.errori.errors);
          setWarningMessages(res.data.errori.warning);
          setInfoMessages(res.data.errori.info);
        }
      })
      .catch((e) => console.log(e));
  }

  function navigateToHome() {
    var localAdviceID = localStorage.getItem("adviceID");
    navigate(`${CTX}/advices/${localAdviceID}`);
  }

  function formatDate(date: string): string {
    return format(parseISO(date), "dd/MM/yyyy");
  }

  return (
    <div>
      <>
        <StickyBar
          hasBackButton={false}
          breadcrumb={
            <div className="flex flex-col">
              <div data-qa="confirm-page-title" className="truncate">
                <FormattedMessage id="proposalIssueConfirm" />
              </div>
              <div className="inline-flex flex-wrap gap-x-4 items-center" data-qa="extra-info">
                {/*contract?.quotationNumber && (
                    <span
                      className="text-base font-normal truncate"
                      data-qa="product-quotationNumber"
                    >
                  N. {contract.quotationNumber}
                </span>
                  )*/}
                <span className="text-base font-normal truncate" data-qa="policyholder-title">
                  {policyholder?.surnameOrCompanyName}&nbsp;
                  {policyholder?.name}
                </span>
                <span className="text-base font-normal truncate" data-qa="product-description">
                  {contract?.contractProductName}
                </span>
              </div>
            </div>
          }
        >
          <YogaButton
            kind="default"
            form="contractBeneficiaries"
            type="submit"
            data-qa="return-home-button"
            className="flex items-center gap-x-2"
            action={navigateToHome}
          >
            <ArrowCircleRightIcon className="w-5 h-5" />
            <div className="hidden lg:block">
              <FormattedMessage id="returnHome" />
            </div>
          </YogaButton>
        </StickyBar>
        <div className="px-3">
          {errorMessages &&
            errorMessages.map((error, index) => {
              return (
                <YogaMessage type="error" position="outer" key={index}>
                  <p data-qa={error}>{error}</p>
                </YogaMessage>
              );
            })}
          {warningMessages &&
            warningMessages.map((warning, index) => {
              return (
                <YogaMessage type="danger" position="outer" key={index}>
                  <p data-qa={warning}>{warning}</p>
                </YogaMessage>
              );
            })}
          {infoMessages &&
            infoMessages.map((info, index) => {
              return (
                <YogaMessage type="info" position="outer" key={index}>
                  <p data-qa={info}>{info}</p>
                </YogaMessage>
              );
            })}
          <div className="flex flex-col gap-y-8">
            <YogaCard success uniformPadding>
              {contract && (
                <>
                  {sign == "true" ? (
                    <>
                      <div className="flex justify-between items-center">
                        <div className="flex text-title-text text-xl font-bold items-center" data-qa="policyNumberSaved">
                          <CheckCircleIcon className="w-6 h-6 mr-2 text-success flex-shrink-0" />
                          <FormattedMessage
                            id="signCreated"
                            values={{
                              number: (contract.managementNode ? contract.managementNode.code + "/" : "") + contract.policyNumber,
                            }}
                          />
                        </div>
                      </div>
                      <div className="flex justify-between items-center" style={{ paddingTop: "2em" }}>
                        <div className="flex text-title-text text-xl font-bold items-center" data-qa="policyNumberSaved">
                          <DocumentTextIcon className="w-6 h-6 mr-2 text-success flex-shrink-0" />
                          <FormattedMessage id="signProposalId" />
                          {signInfo && <label style={{ marginLeft: "1em", color: "#33D4FF" }}>{signInfo.praticaId}</label>}
                        </div>
                      </div>
                      <div className="flex justify-between items-center" style={{ paddingTop: "2em" }}>
                        <div
                          className="flex text-title-text text-xl font-bold items-center"
                          style={{ alignItems: "start" }}
                          data-qa="policyNumberSaved"
                        >
                          <PencilIcon className="w-6 h-6 mr-2 text-success flex-shrink-0" />
                          <div>
                            <FormattedMessage id="signActor" />
                            <ol>
                              <li>
                                <FormattedMessage id="signPolicyholder" />
                                {contract && contract.parties && contract.parties["POLICYHOLDER"] && contract.parties["POLICYHOLDER"].length > 0 && (
                                  <label
                                    style={{
                                      marginLeft: "1em",
                                      color: "#33D4FF",
                                    }}
                                  >
                                    {contract.parties["POLICYHOLDER"][0].surnameOrCompanyName + " " + contract.parties["POLICYHOLDER"][0].name}
                                  </label>
                                )}
                              </li>
                              {contract &&
                                contract.assets &&
                                contract.assets["person_1"] &&
                                contract.assets["person_1"].policyHolderIsInsuredPerson == false && (
                                  <li>
                                    <FormattedMessage id="signInsuredPerson" />
                                    {contract.assets["person_1"].parties &&
                                      contract.assets["person_1"].parties["INSURED_PERSON"] &&
                                      contract.assets["person_1"].parties["INSURED_PERSON"].length > 0 && (
                                        <label
                                          style={{
                                            marginLeft: "1em",
                                            color: "#33D4FF",
                                          }}
                                        >
                                          {contract.assets["person_1"].parties["INSURED_PERSON"][0].surnameOrCompanyName +
                                            " " +
                                            contract.assets["person_1"].parties["INSURED_PERSON"][0].name}
                                        </label>
                                      )}
                                  </li>
                                )}
                            </ol>
                          </div>
                        </div>
                      </div>
                      <div className="flex justify-between items-center" style={{ paddingTop: "2em" }}>
                        <div className="flex text-title-text text-xl font-bold items-center" data-qa="policyNumberSaved">
                          <CalendarIcon className="w-6 h-6 mr-2 text-success flex-shrink-0" />
                          <FormattedMessage id="signExpirationDate" />
                          {signInfo && <label style={{ marginLeft: "1em", color: "#33D4FF" }}>{formatDate(signInfo.folderExpiration)}</label>}
                        </div>
                      </div>
                      <div className="flex justify-between items-center" style={{ paddingTop: "2em" }}>
                        {contract.assets["person_1"].policyHolderIsInsuredPerson == false && (
                          <div className="flex text-title-text text-xl font-bold items-center" data-qa="policyNumberSaved">
                            <ExclamationIcon className="w-6 h-6 mr-2 text-success flex-shrink-0" />
                            <FormattedMessage id="signWarningMessage" />
                          </div>
                        )}
                      </div>
                    </>
                  ) : (
                    <>
                      <div className="flex justify-between items-center">
                        <div className="flex text-title-text text-xl font-bold items-center" data-qa="policyNumberSaved">
                          <CheckCircleIcon className="w-6 h-6 mr-2 text-success flex-shrink-0" />
                          <FormattedMessage
                            id="proposalCreated"
                            values={{
                              number: (contract.managementNode ? contract.managementNode.code + "/" : "") + contract.policyNumber,
                            }}
                          />
                        </div>
                      </div>
                      <div className="flex justify-between items-center" style={{ paddingTop: "2em" }}>
                        <div className="flex text-title-text text-xl font-bold items-center" data-qa="policyNumberSaved">
                          <DocumentTextIcon className="w-6 h-6 mr-2 text-success flex-shrink-0" />
                          <FormattedMessage id="signProposalId" />
                          {signInfo && <label style={{ marginLeft: "1em", color: "#33D4FF" }}>{signInfo.praticaId}</label>}
                        </div>
                      </div>
                      <div className="row" style={{ paddingTop: "2em" }}>
                        <div className="col-12" style={{ fontWeight: "bold" }}>
                          <FormattedMessage id="outcomeDetailMessage1"/>
                          {/* Inviare i documenti via corriere a: */}
                        </div>
                        <div
                          className="col-12"
                          style={{
                            paddingInline: "1em",
                            paddingTop: "1em",
                            lineHeight: "30px",
                          }}
                        >
                          <p>Integra Document Management s.r.l.</p>
                          <p>Strada Padana Superiore, 2/B</p>
                          <p>20063 Cernusco Sul Naviglio (MI), Italy</p>
                          <p>C.A. Nadia Ceriotti</p>
                        </div>
                        <div className="col-12" style={{ fontWeight: "bold" }}>
                          <FormattedMessage id="outcomeDetailMessage2"/>
                          {/* Aggiungendo al pacchetto documentale il frontespizio da stampare sulla WebCollaboration */}
                        </div>
                      </div>
                    </>
                  )}
                </>
              )}
            </YogaCard>
          </div>
        </div>
      </>
    </div>
  );
}
