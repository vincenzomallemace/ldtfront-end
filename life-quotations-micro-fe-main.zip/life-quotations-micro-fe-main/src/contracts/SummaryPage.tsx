import { ArrowCircleRightIcon } from "@heroicons/react/solid";
import { CTX } from "commons/Configuration";
import { groupKeyValueParamsByTag, orderQuestionByTag } from "commons/Utils";
import { Accordion } from "commons/components/Accordion";
import { AnswerBox } from "commons/components/AnswerBox";
import ContractualOptionBox from "commons/components/ContractualOptionBox";
import ErrorPage from "commons/components/ErrorPage";
import Messages from "commons/components/Messages";
import ParameterBox from "commons/components/ParameterBox";
import { CompleteParty, PartyBox } from "commons/components/PartyBox";
import { PaymentBox } from "commons/components/PaymentBox";
import { StickyBar } from "commons/components/StickyBar";
import { YogaButton } from "commons/components/YogaButton";
import YogaCard from "commons/components/YogaCard";
import { Context } from "commons/contexts/Context";
import { contractService } from "commons/services/ContractService";
import { questionnaireService } from "commons/services/QuestionnaireService";
import FundsTable from "offers/components/FundsTable";
import { PremiumDropDown } from "offers/components/PremiumDropDown";
import useContractPayments from "payments/hooks/useContractPayments";
import { QUESTIONNAIRE_TYPE, QuestionnaireModel } from "questionnaires/models/QuestionnaireModel";
import { useContext, useEffect, useMemo, useState } from "react";
import { FormattedDate, FormattedMessage, useIntl } from "react-intl";
import { useNavigate, useParams } from "react-router-dom";
import { RoleType } from "./enums/RoleType";
import useContract from "./hooks/useContract";
import { YogaChip } from "commons/components/YogaChip";
// import FormattedMoney from "commons/components/FormattedMoney";

export default function SummaryPage() {
  const { contractId } = useParams();
  const { changeLoading } = useContext(Context);
  const navigate = useNavigate();
  const intl = useIntl();

  const { contract, contractError, policyholder } = useContract(contractId);

  const { payments, setContract: setContractPayments } = useContractPayments();

  const [dueDiligenceQuestionnaire, setDueDiligenceQuestionnaire] = useState<QuestionnaireModel>();

  async function emit() {
    changeLoading(1);
    await contractService.complete(contract.contractId).then(() => navigate(`${CTX}/offers/${contract.contractId}/confirm`));
    changeLoading(-1);
  }

  const unitLinked = useMemo(() => {
    if (contract) return Object.values(Object.values(contract.assets)[0].unitLinked)[0];
  }, [contract]);

  const investmentLine = useMemo(() => {
    if (unitLinked) return Object.values(unitLinked.investmentLines)[0];
  }, [unitLinked]);

  const technicalData = useMemo(() => {
    if (contract && Object.keys(contract.parameters)?.length > 0) return groupKeyValueParamsByTag(contract.parameters);
    else return undefined;
  }, [contract]);

  const insuredPerson = useMemo(() => {
    let party: CompleteParty;
    if (contract) {
      party = contract.assets["person_1"].parties[RoleType.INSURED_PERSON][0] as CompleteParty;
      if (party.taxId === policyholder.taxId) {
        party = policyholder as CompleteParty;
      }
    }
    return party;
  }, [contract]);

  useEffect(() => {
    const fetchData = async (questId: string) => {
      const result = await questionnaireService.get(questId);
      if (!result.data) {
        setDueDiligenceQuestionnaire(undefined);
      } else {
        setDueDiligenceQuestionnaire(result.data);
      }
    };
    if (contract && contract.questionnaires && QUESTIONNAIRE_TYPE.DUE_DILIGENCE in contract.questionnaires)
      fetchData(contract.questionnaires[QUESTIONNAIRE_TYPE.DUE_DILIGENCE]).catch(() => setDueDiligenceQuestionnaire(undefined));
  }, [contract]);

  useEffect(() => {
    if (contract) setContractPayments(contract);
  }, [contract]);

  return (
    <>
      {contractError ? (
        <ErrorPage />
      ) : (
        <>
          {contract && policyholder && unitLinked && payments && (
            <>
              <StickyBar
                breadcrumb={
                  <div className="flex flex-col">
                    <div data-qa="summary-page-title" className="truncate">
                      <FormattedMessage id="proposalSummary" />
                    </div>
                    <div className="inline-flex flex-wrap gap-x-4 items-center" data-qa="extra-info">
                      {/*contract.quotationNumber && (
                    <span
                      className="text-base font-normal truncate"
                      data-qa="product-quotationNumber"
                    >
                      N. {contract.quotationNumber}
                    </span>
                  )*/}
                      <span className="text-base font-normal truncate" data-qa="policyholder-title">
                        {policyholder?.surnameOrCompanyName}&nbsp;
                        {policyholder?.name}
                      </span>
                      <span className="text-base font-normal truncate" data-qa="product-description">
                        {contract.contractProductName}
                      </span>
                    </div>
                  </div>
                }
              >
                <YogaButton kind="success" data-qa="emit-button" action={emit}>
                  <ArrowCircleRightIcon className="w-5 mr-2 -ml-1" />
                  <FormattedMessage id="issueProposal" />
                </YogaButton>
              </StickyBar>
              <div className="px-3">
                <Messages messages={contract.messages} entity="contract" />
              </div>
              <div className="px-3 flex flex-col gap-y-8">
                
                <YogaCard uniformPadding className="flex flex-col gap-4">
                  <div className="grid grid-cols-[1fr_max-content] items-center">
                    <div
                      data-qa="proposal-status-data-container"
                      className="flex flex-row gap-x-4 bg-body-text text-box-background rounded-lg w-full py-1 px-4 hidden"
                    >
                      <div className="flex flex-col lg:flex-row lg:gap-2 items-start lg:items-center w-1/3" data-qa="issue-date">
                        <span data-qa="issue-date-label" className="hidden">
                          <FormattedMessage id="issueDate" />
                        </span>
                        <span data-qa="issue-date-label" className="hidden">
                          <FormattedMessage id="issue" />
                        </span>
                        <span className="hidden font-bold leading-[1.4rem]" data-qa="issue-date-value">
                          <FormattedDate value={contract.contractIssueInstant} year="numeric" month="2-digit" day="2-digit" />
                        </span>
                      </div>

                      <div className="flex flex-col lg:flex-row lg:gap-2 items-start lg:items-center w-1/3" data-qa="effective-date">
                        <span data-qa="effective-date-label" className="hidden">
                          <FormattedMessage id="effectiveDate" />
                        </span>
                        <span data-qa="effective-date-label" className="hidden">
                          <FormattedMessage id="effect" />
                        </span>
                        <span className="hidden font-bold leading-[1.4rem]" data-qa="effective-date-value">
                          <FormattedDate value={contract.contractEffectInstant} year="numeric" month="2-digit" day="2-digit" />
                        </span>
                      </div>

                      <div className="flex flex-col lg:flex-row lg:gap-2 items-start lg:items-center w-1/3" data-qa="investment-date">
                        <span data-qa="investment-date-label" className="hidden">
                          <FormattedMessage id="investmentDate" />
                        </span>
                        <span data-qa="investment-date-label" className="hidden">
                          <FormattedMessage id="investment" />
                        </span>
                        <span className="hidden font-bold leading-[1.4rem]" data-qa="investment-date-value">
                          <FormattedDate value={unitLinked.investmentInstant} year="numeric" month="2-digit" day="2-digit" />
                        </span>
                      </div>
                    </div>
                    <div
                      className="h-full px-4 py-1 bg-success text-white rounded-lg border border-success flex items-center relative overflow-hidden"
                      data-qa="proposal-status"
                    >
                      <div className="bubbles" />
                      <span data-qa="proposal-status-label">
                        <FormattedMessage id="COMPLETE_PROPOSAL" />
                      </span>
                    </div>
                  </div>
                </YogaCard>
                <Accordion
                  open
                  name="parties-accordion"
                  data-qa="parties-accordion"
                  className="flex flex-col border-collapse bg-body-text text-white overflow-hidden w-full rounded-2xl border-2 border-body-text"
                  titleContainerClasses="px-4 py-3.5"
                  accordionTitle={
                    <h4 data-qa="parties-label">
                      <FormattedMessage id="parties" />
                    </h4>
                  }
                >
                  <div className="mx-3 mb-3.5 grid grid-cols-2 lg:grid-cols-3 text-body-text gap-4" data-qa="parties-container">
                    <PartyBox party={policyholder as CompleteParty} type={RoleType.POLICYHOLDER} openSections />
                    <PartyBox party={insuredPerson} type={RoleType.INSURED_PERSON} openSections />
                    {contract.beneficiaries?.partyData?.length > 0 ? (
                      contract.beneficiaries.partyData.map((beneficiary, index) => (
                        <PartyBox key={index} party={beneficiary as CompleteParty} type={RoleType.BENEFICIARY} openSections />
                      ))
                    ) : (
                      <PartyBox label={contract.beneficiaries.description} type={RoleType.BENEFICIARY} openSections />
                    )}
                    {contract.beneficiaries?.thirdReferent && (
                      <PartyBox party={contract.beneficiaries.thirdReferent as CompleteParty} type={RoleType.THIRD_REFERENT} openSections />
                    )}
                    {RoleType.THIRD_PARTY in contract.parties && (
                      <PartyBox party={contract.parties[RoleType.THIRD_PARTY][0] as CompleteParty} type={RoleType.THIRD_PARTY} openSections />
                    )}
                  </div>
                </Accordion>
               
                {/* <div className="flex flex-col-reverse lg:flex-row items-stretch gap-x-4 h-full">
                  <div
                    data-qa="proposal-status-data-container"
                    className="flex flex-row bg-body-text text-box-background rounded-b-2xl lg:rounded-lg w-full lg:w-3/4 py-1 px-4"
                  >
                    <div className="flex flex-col items-start w-full" data-qa="issue-date">
                      <span data-qa="issue-date-label" className="hidden lg:block">
                        <FormattedMessage id="issueDate" />
                      </span>
                      <span data-qa="issue-date-label" className="lg:hidden">
                        <FormattedMessage id="issue" />
                      </span>
                      <span className="font-bold" data-qa="issue-date-value">
                        <FormattedDate value={contract.contractIssueInstant} year="numeric" month="2-digit" day="2-digit" />
                      </span>
                    </div>

                    <div className="flex flex-col items-start w-full" data-qa="effective-date">
                      <span data-qa="effective-date-label" className="hidden lg:block">
                        <FormattedMessage id="effectiveDate" />
                      </span>
                      <span data-qa="effective-date-label" className="lg:hidden">
                        <FormattedMessage id="effect" />
                      </span>
                      <span className="font-bold" data-qa="effective-date-value">
                        <FormattedDate value={contract.contractEffectInstant} year="numeric" month="2-digit" day="2-digit" />
                      </span>
                    </div>

                    <div className="flex flex-col items-start w-full" data-qa="investment-date">
                      <span data-qa="investment-date-label" className="hidden lg:block">
                        <FormattedMessage id="investmentDate" />
                      </span>
                      <span data-qa="investment-date-label" className="lg:hidden">
                        <FormattedMessage id="investment" />
                      </span>
                      <span className="font-bold" data-qa="investment-date-value">
                        <FormattedDate value={unitLinked.investmentInstant} year="numeric" month="2-digit" day="2-digit" />
                      </span>
                    </div>

                    <div className="flex flex-col items-end lg:items-start w-max lg:w-full" data-qa="total-premium">
                      <span data-qa="total-premium-label" className="w-max">
                        <FormattedMessage id="totalPremium" />
                      </span>
                      <span className="font-bold" data-qa="investment-date-value">
                        <FormattedMoney money={contract.assets["person_1"].premium.uniqueOrAnnual.gross} />
                      </span>
                    </div>
                  </div>
                  <div
                    className="px-4 py-1 bg-success text-white rounded-t-2xl lg:rounded-lg border border-success flex items-center relative overflow-hidden w-full lg:w-1/4"
                    data-qa="proposal-status"
                  >
                    <div className="bubbles" />
                    <span data-qa="proposal-status-label">
                      <FormattedMessage id="COMPLETE_PROPOSAL" />
                    </span>
                  </div>
                </div> */}
                {(contract.agreement || Object.keys(contract.parameters)?.length > 0) && (
                  <Accordion
                    open
                    arrowColor="text-box-background"
                    name="technical-data-container"
                    data-qa="technical-data-container"
                    className="flex flex-col border-collapse bg-body-text text-white overflow-hidden w-full rounded-2xl"
                    titleContainerClasses="px-4 py-3.5"
                    accordionTitle={
                      <h4 data-qa="technical-data-label">
                        <FormattedMessage id="technicalData" />
                      </h4>
                    }
                  >
                    <div className="mx-3 mb-3.5">
                      <div className="p-4 bg-white text-body-text rounded-lg flex flex-col gap-y-4">
                        {/*<div className="grid grid-cols-2 lg:grid-cols-3 gap-4" data-qa="static-data-container">
                          <ParameterBox label="agreement" value={contract.agreement}/>
                        </div>*/}

                        {technicalData &&
                          Object.entries(technicalData).map(([tag, params]) => {
                            return (
                              <div key={`${tag}-section`} data-qa={`${tag}-section`}>
                                {tag !== "noTags" && (
                                  <h4 data-qa={`${tag}-label`} className="mb-2 leading-none">
                                    <FormattedMessage id={tag} />
                                  </h4>
                                )}
                                <div className="grid grid-cols-2 lg:grid-cols-3 gap-4" data-qa={`${tag}-params`}>
                                  {params.map((param: any) => (
                                    <ParameterBox
                                      key={param.key}
                                      label={param.key}
                                      value={param.value as any}
                                      type={param.type}
                                      currency={param.currency || "EUR"}
                                    />
                                  ))}
                                </div>
                              </div>
                            );
                          })}
                      </div>
                    </div>
                  </Accordion>
                )}
                <YogaCard className="bg-body-text border-body-text flex flex-col gap-y-4 text-white" data-qa="partition-card">
                  {(!contract.partitionOption || contract.partitionOption?.unitLinkedInvestment > 0) && (
                    <YogaCard inner data-qa="unit-linked-card" className="bg-body-text border-body-text">
                      <div className="flex justify-between items-center gap-x-4 mb-2">
                        <div className="flex gap-x-2 items-center">
                          <h3 data-qa="investmentLine-label" className="mb-0">
                          <FormattedMessage id="fundsList" />
                            {/* {intl.formatMessage(
                              { id: "investmentLineName" },
                              { line: intl.formatMessage({ id: investmentLine.name }).toLowerCase() }
                            )} */}
                          </h3>
                          {contract.partitionOption?.unitLinkedInvestment > 0 && contract.partitionOption?.segregatedInvestment > 0 && (
                            <YogaChip type="default" style="solid" size="small" data-qa="unit-linked-percentage-chip">
                              {contract.partitionOption.unitLinkedInvestment}%
                            </YogaChip>
                          )}
                        </div>

                        <PremiumDropDown premium={unitLinked.premium.uniqueOrAnnual} entity="unit-linked" />
                      </div>
                      {investmentLine.funds?.length > 0 && (
                        <Accordion
                          open
                          name="investment-line"
                          data-qa="funds-container"
                          //className="flex flex-col border-collapse bg-body-text text-white overflow-hidden w-full rounded-2xl border-2 border-body-text"
                          className="flex flex-col border-collapse bg-box-background overflow-hidden w-full rounded-lg border-2 border-background"
                          titleContainerClasses="px-4 py-3.5"
                          accordionTitle={
                            <h4 data-qa="fund-detail-label" className="text-body-text">
                              {/* <FormattedMessage id="fundsList" /> */}
                              <FormattedMessage id={intl.formatMessage({ id: investmentLine.name })} />
                            </h4>
                          }
                        >
                          <FundsTable funds={investmentLine.funds} investmentLine={investmentLine.code} />
                        </Accordion>
                      )}
                    </YogaCard>
                  )}
                  {contract.partitionOption?.segregatedInvestment > 0 && (
                    <YogaCard inner className="w-full flex items-center justify-between gap-x-4" data-qa="segregated-fund-card">
                      <div className="flex gap-x-2 items-center">
                        <h3 className="mb-0" data-qa="segregated-fund-card-title">
                          <FormattedMessage id="segregatedFund" />
                        </h3>
                        {contract.partitionOption?.unitLinkedInvestment > 0 && (
                          <YogaChip type="default" style="solid" size="small" data-qa="segregated-fund-percentage-chip">
                            {contract.partitionOption.segregatedInvestment}%
                          </YogaChip>
                        )}
                      </div>

                      {contract.assets["person_1"]?.segregatedFund?.premium?.uniqueOrAnnual && (
                        <PremiumDropDown premium={contract.assets["person_1"].segregatedFund.premium.uniqueOrAnnual} entity="segregated-fund" />
                      )}
                    </YogaCard>
                  )}
                </YogaCard>
                {Object.keys(contract.contractualOptions)?.length > 0 && (
                  <Accordion
                    open
                    arrowColor="text-box-background"
                    name="contractual-options-container"
                    data-qa="contractual-options-container"
                    className="flex flex-col bg-body-text text-white overflow-hidden w-full rounded-2xl"
                    titleContainerClasses="p-4"
                    accordionTitle={
                      <h3 data-qa="contractual-options-label" className="mb-0">
                        <FormattedMessage id="contractualOptions" />
                      </h3>
                    }
                  >
                    <div className="text-body-text flex flex-col gap-y-4 mx-4 mb-4">
                      {Object.values(contract.contractualOptions)
                        .filter((opt) => opt.visible)
                        .sort((a, b) => (a.name > b.name ? 1 : -1))
                        .map((opt) => (
                          <ContractualOptionBox contractualOption={opt} open key={opt.code} />
                        ))}
                    </div>
                  </Accordion>
                )}

                <Accordion
                  open
                  arrowColor="text-box-background"
                  name="parties-accordion"
                  data-qa="parties-accordion"
                  className="flex flex-col bg-body-text text-white overflow-hidden w-full rounded-2xl"
                  titleContainerClasses="p-4"
                  accordionTitle={
                    <h3 data-qa="parties-label" className="mb-0">
                      <FormattedMessage id="parties" />
                    </h3>
                  }
                >
                  <div className="mx-4 mb-4 grid grid-cols-2 lg:grid-cols-3 text-body-text gap-4" data-qa="parties-container">
                    <PartyBox party={policyholder as CompleteParty} type={RoleType.POLICYHOLDER} openSections />
                    <PartyBox party={insuredPerson} type={RoleType.INSURED_PERSON} openSections />
                    {contract.beneficiaries?.partyData?.length > 0 ? (
                      contract.beneficiaries.partyData.map((beneficiary, index) => (
                        <PartyBox key={index} party={beneficiary as CompleteParty} type={RoleType.BENEFICIARY} openSections />
                      ))
                    ) : (
                      <PartyBox label={contract.beneficiaries.description} type={RoleType.BENEFICIARY} openSections />
                    )}
                    {contract.beneficiaries?.thirdReferent && (
                      <PartyBox party={contract.beneficiaries.thirdReferent as CompleteParty} type={RoleType.THIRD_REFERENT} openSections />
                    )}
                    {RoleType.THIRD_PARTY in contract.parties && (
                      <PartyBox party={contract.parties[RoleType.THIRD_PARTY][0] as CompleteParty} type={RoleType.THIRD_PARTY} openSections />
                    )}
                  </div>
                </Accordion>
                <Accordion
                  open
                  arrowColor="text-box-background"
                  name="payments-accordion"
                  data-qa="payments-accordion"
                  className="flex flex-col border-collapse bg-body-text text-white overflow-hidden w-full rounded-2xl border-2 border-body-text"
                  titleContainerClasses="px-4 py-3.5"
                  accordionTitle={
                    <h4 data-qa="payments-label">
                      <FormattedMessage id="payment" />
                    </h4>
                  }
                >
                  <div className="mx-3 mb-3.5 grid grid-cols-1 lg:grid-cols-2 text-body-text gap-4" data-qa="parties-and-payments-container">
                    <PartyBox party={contract.parties[RoleType.PAYER][0] as CompleteParty} type={RoleType.PAYER} openSections />
                    <PaymentBox
                      payer={contract.parties[RoleType.PAYER][0] as CompleteParty}
                      payment={payments[0]}
                      productCode={contract.productCode}
                    />
                  </div>
                </Accordion>

                {dueDiligenceQuestionnaire && (
                  <Accordion
                    open
                    arrowColor="text-box-background"
                    name="due-diligence-questionnaire-container"
                    data-qa="due-diligence-questionnaire-container"
                    className="flex flex-col border-collapse bg-body-text text-white overflow-hidden w-full rounded-2xl border-2 border-body-text"
                    titleContainerClasses="px-4 py-3.5"
                    accordionTitle={
                      <h4 data-qa="due-diligence-questionnaire-label">
                        <FormattedMessage id="dueDiligenceQuestionnaire" />
                      </h4>
                    }
                  >
                    <div className="mx-3 mb-3.5">
                      <div className="flex flex-col gap-y-4">
                        {Object.entries(orderQuestionByTag(dueDiligenceQuestionnaire.questions)).map(([tag, questions]) => {
                          return (
                            <div key={`${tag}-section`} data-qa={`${tag}-section`} className="flex flex-col gap-y-2">
                              {tag !== "noTag" && (
                                <h4 data-qa={`${tag}-label`} className="leading-none">
                                  <FormattedMessage id={tag} />
                                </h4>
                              )}
                              {questions.map((question) => (
                                <AnswerBox key={question.questionId} question={question} />
                              ))}
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  </Accordion>
                )}
              </div>
            </>
          )}
        </>
      )}
    </>
  );
}
