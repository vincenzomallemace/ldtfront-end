import { ArrowCircleRightIcon, IdentificationIcon, PlusCircleIcon, SaveIcon, TrashIcon, UserIcon } from "@heroicons/react/outline";
import { MenuIcon } from "@heroicons/react/solid";
import { config, CTX } from "commons/Configuration";
import { geoValidationError, getBirthPlace, getMobilePhoneAndPrefix, paramsToMap, setMobilePhoneAndPrefix } from "commons/FormUtils";
import Messages from "commons/components/Messages";
import { StickyBar } from "commons/components/StickyBar";
import { YogaButton } from "commons/components/YogaButton";
import YogaCard from "commons/components/YogaCard";
import { YogaScrollToFieldError } from "commons/components/YogaScrollToFieldError";
import { Context } from "commons/contexts/Context";
import { FormikInput } from "commons/formik/FormikInput";
import { FormikInputNumeric } from "commons/formik/FormikInputNumeric";
import { FormikSelect } from "commons/formik/FormikSelect";
import { FormikTabSwitch } from "commons/formik/FormikTabSwitch";
import { ConfirmModal } from "commons/modals/ConfirmModal";
import AvailableBeneficiary from "commons/models/AvailableBeneficiary";
import { CodeAndDescription } from "commons/models/CodeAndDescription";
import { Geo } from "commons/models/Geo";
import { getLocationSchema, Location } from "commons/models/Location";
import { KeyValue, Money } from "commons/models/YogaModels";
import { YogaParam } from "commons/models/YogaParam";
import { ManagementNode } from "commons/models/nodes/ManagementNode";
import { partyService } from "commons/services/PartyService";
import useContract from "contracts/hooks/useContract";
import { Beneficiaries, BeneficiaryPartyData, ThirdReferentData } from "customers/models/Beneficiaries";
import { isForeign, Party } from "customers/models/Party";
import { Field, FieldArray, FieldProps, Form, Formik, FormikProps } from "formik";
import { isValidIBAN } from "ibantools";
import { useContext, useEffect, useMemo, useRef, useState } from "react";
import { FormattedMessage, useIntl } from "react-intl";
import { formatPhoneNumberIntl, isValidPhoneNumber } from "react-phone-number-input";
import { useNavigate, useParams } from "react-router-dom";
import * as Yup from "yup";
import BeneficiaryForm from "./form/BeneficiaryForm";
import ThirdReferentForm from "./form/ThirdReferentForm";
import { YogaMessage } from "commons/components/YogaMessage";
import { scrollToTop } from "commons/Utils";
import ErrorPage from "commons/components/ErrorPage";
import usePartyParameters from "customers/hooks/usePartyParameters";
import { RoleType } from "contracts/enums/RoleType";

interface BeneficiaryPageFormValues {
  typeSwitch: string;
  beneficiaries: BeneficiariesForm;
}

interface BeneficiariesForm extends CodeAndDescription {
  partyData?: BeneficiaryFormPartyData[];
  thirdReferent?: ThirdReferentData;
}

export interface BeneficiaryFormPartyData {
  legalEntity: string;
  name?: string;
  surnameOrCompanyName: string;
  birthDate?: Date;
  birthPlace?: string;
  birthPlaceCode?: string;
  birthCountry?: string;
  birthCountryCode?: string;
  birthCountyCode?: string;
  parentalRelationship?: CodeAndDescription;
  birthPlaceComplete?: Geo;
  birthCountryComplete?: Geo;
  foreign?: boolean;
  unverified: boolean;
  taxId?: string;
  vatNumber?: string;
  companyType?: string;
  gender?: string;
  iban?: string;
  email?: string;
  mobilePhoneNumber?: string;
  mobilePhoneNumberPrefix?: string;
  location?: Location;
  managementNodes?: ManagementNode[];
  partyId?: string;
  legacyData?: Map<string, any>;
  atecoCode?: string;
  employeesNumber?: number;
  revenue?: Money;
  percentage?: number;
  irrevocable?: boolean;
  parameters?: KeyValue<YogaParam>;
  domicileIsNotResidence: boolean;
  domicile: Location;
}

export default function BeneficiariesPage() {
  const { productId } = useParams<string>();
  const { contract, contractError, policyholder, addBeneficiaries, saveDraft } = useContract(productId, true);
  const intl = useIntl();
  const navigate = useNavigate();
  const { changeLoading } = useContext(Context);

  const [indexOfBeneficiary, setIndexOfBeneficiary] = useState<number>();
  const [beneficiaryModalOpen, setBeneficiaryModalOpen] = useState<boolean>(false);
  const [thirdReferentModalOpen, setThirdReferentModalOpen] = useState<boolean>(false);

  const [typeSwitchValues, setTypeSwitchValues] = useState<string[]>([]);
  const [beneficiaryType, setBeneficiaryType] = useState<AvailableBeneficiary>();

  const formRef = useRef<FormikProps<BeneficiaryPageFormValues>>(null);
  const [initialValues, setInitialValues] = useState<BeneficiaryPageFormValues>();

  const [first, setFirst] = useState<boolean>(true);
  const [isOpenButtons, setIsOpenButtons] = useState<boolean>(false);

  const [taxIdChecks, setTaxIdChecks] = useState<string[]>(undefined);

  const { updateParams: updateThirdReferentParameters, defaultParams: defaultThirdReferentParameters } = usePartyParameters(
    RoleType.THIRD_REFERENT,
    contract?.productCode,
    contract?.quotationId,
    contract?.contractBranch
  );

  const { updateParams: updateBeneficiaryParameters, defaultParams: defaultBeneficiaryParameters } = usePartyParameters(
    RoleType.BENEFICIARY,
    contract?.productCode,
    contract?.quotationId,
    contract?.contractBranch
  );

  const requiredMessage = intl.formatMessage({ id: "required" });
  const requiredGeo = geoValidationError(intl);
  //const selectLocationMessage = intl.formatMessage({id: "selectLocation"});
  const invalidPhoneMessage = intl.formatMessage({ id: "invalidPhoneNumber" });
  const vatNumberLengthMessage = intl.formatMessage({ id: "lengthError" }, { number: "11" });
  const taxCodeLengthMessage = intl.formatMessage({ id: "lengthError" }, { number: "16" });

  const validationSchema = Yup.object({
    beneficiaries: Yup.object({
      code: Yup.string().ensure().required(requiredMessage),
      partyData: Yup.array().when("code", {
        is: "otherParty",
        then: Yup.array(
          Yup.object({
            legalEntity: Yup.string().required(requiredMessage),
            name: Yup.string()
              .ensure()
              .when("legalEntity", {
                is: "physical",
                then: Yup.string().required(requiredMessage),
              }),
            surnameOrCompanyName: Yup.string().ensure().required(requiredMessage),
            birthDate: Yup.date().when("legalEntity", {
              is: "physical",
              then: Yup.date().required(requiredMessage),
              otherwise: Yup.date().nullable(),
            }),
            birthPlace: Yup.string()
              .ensure()
              .when(["legalEntity", "foreign"], {
                is: (legalEntity, foreign) => legalEntity === "physical" && !foreign,
                then: Yup.string().required(requiredGeo),
              }),
            birthCountry: Yup.string()
              .ensure()
              .when(["legalEntity", "foreign"], {
                is: (legalEntity, foreign) => legalEntity === "physical" && foreign,
                then: Yup.string().required(requiredGeo),
              }),
            parentalRelationship: Yup.object({
              code: Yup.string().ensure(),
            })
              .nullable()
              .test("requireParentalRelationship", requiredMessage, (value) => {
                if (beneficiaryType && beneficiaryType.availableParentalRelationships && beneficiaryType.availableParentalRelationships.length > 0)
                  return value ? !!value.code : false;
                else return true;
              }),
            taxId: Yup.string().when(["unverified"], {
              is: true,
              then: (schema) => schema.nullable(),
              otherwise: (schema) =>
                schema.when(["legalEntity", "companyType"], {
                  is: (legalEntity, companyType) =>
                    legalEntity === "legal" && companyType !== "Ditta Individuale" && companyType !== "Impresa familiare",
                  then: Yup.string().test("len11", vatNumberLengthMessage, (val) => val?.length === 11),
                  otherwise: Yup.string()
                    .test("len16", taxCodeLengthMessage, (val) => val?.length === 16)
                    .test(
                      "notEqualThirdReferent",
                      intl.formatMessage({
                        id: "beneficiaryInsertedAsThirdReferent",
                      }),
                      (value, context) => {
                        if (formRef.current?.values.beneficiaries.thirdReferent) {
                          const insertedThirdReferent = formRef.current?.values.beneficiaries.thirdReferent;
                          if (insertedThirdReferent.taxId === value) {
                            return new Yup.ValidationError(
                              intl.formatMessage({
                                id: "beneficiaryInsertedAsThirdReferent",
                              }),
                              "notEqualThirdReferent",
                              `${context.path}`
                            );
                          }
                        }
                        return true;
                      }
                    ),
                }),
            }),
            companyType: Yup.string().when(["unverified", "legalEntity"], {
              is: (unverified, legalEntity) => !unverified && legalEntity === "legal",
              then: Yup.string().required(requiredMessage),
              otherwise: Yup.string().nullable(),
            }),
            vatNumber: Yup.string().when(["unverified", "legalEntity"], {
              is: (unverified, legalEntity) => !unverified && legalEntity === "legal",
              then: Yup.string().test("len11", vatNumberLengthMessage, (val) => val?.length === 11),
              otherwise: Yup.string().nullable(),
            }),

            gender: Yup.string().when(["unverified", "legalEntity"], {
              is: (unverified, legalEntity) => unverified || legalEntity === "legal",
              then: Yup.string().nullable(),
              otherwise: Yup.string().required(requiredMessage),
            }) /*
            email: Yup.string()
              .nullable()
              .email(intl.formatMessage({ id: "invalidEmail" })),*/,
            mobilePhoneNumber: Yup.string()
              .nullable()
              .test("phoneValid", invalidPhoneMessage, (val) => {
                if (val) return isValidPhoneNumber(val);
                return true;
              }),
            location: Yup.object().when("unverified", {
              is: false,
              then: () => getLocationSchema(intl),
              otherwise: (schema) => schema.nullable(),
            }),
            domicile: Yup.object().when(["unverified", "domicileIsNotResidence"], {
              is: (unverified, domicileIsNotResidence) => !unverified && domicileIsNotResidence,
              then: () => getLocationSchema(intl),
              otherwise: (schema) => schema.nullable(),
            }),
            iban: Yup.string()
              .nullable()
              .test("iban", intl.formatMessage({ id: "ibanFormatError" }), (v) => !v || isValidIBAN(v)),
            percentage: Yup.number()
              .test("empoweredMaxCheck", intl.formatMessage({ id: "beneficiaryPercentageMaxError" }), (value) => {
                if (value)
                  if (formRef.current.values.beneficiaries.partyData.length > 1) return value <= 99;
                  else return value <= 100;
                return true;
              })
              // .max(
              //   100,
              //   intl.formatMessage({ id: "beneficiaryPercentageMaxError" })
              // )
              .min(1, intl.formatMessage({ id: "beneficiaryPercentageMinError" }))
              .required(requiredMessage),
            irrevocable: Yup.boolean().when("unverified", {
              is: true,
              then: (schema) => schema.isFalse(),
              otherwise: (schema) => schema.nullable(),
            }),
          })
        )
          .min(1, intl.formatMessage({ id: "otherPartyBeneficiaryLeastOneError" }))
          .test("percentagesSumError", intl.formatMessage({ id: "percentageMessageError" }), (value) => {
            // https://stackoverflow.com/questions/68777401/yup-how-to-create-multiple-errors-using-a-single-test-function

            if (value && value.length) {
              const sum = value.reduce((sum, benef) => {
                if (benef.percentage) sum += benef.percentage;
                return sum;
              }, 0);

              if (sum != 100) {
                // if (sum > 100)
                //   setPercentageSumErrorMessage(
                //     intl.formatMessage({ id: "percentageOver100MessageError" }, { sum })
                //   );
                // if (sum < 100) {
                //   setPercentageSumErrorMessage(
                //     intl.formatMessage({ id: "percentageUnder100MessageError" }, { sum })
                //   );
                // }
                return new Yup.ValidationError(
                  intl.formatMessage({ id: "percentageMessageError" }, { sum }),
                  "percentagesSumError",
                  `beneficiaries.percentageSum`
                );
              }
            }
            return true;
          })
          .test("beneficiaryUniqueness", intl.formatMessage({ id: "beneficiaryUniquenessError" }), (value, context) => {
            const errors = [];
            value.forEach((benef, index, array) => {
              if (benef.taxId || benef.vatNumber) {
                const hasDuplicate = array
                  .slice(0, index)
                  .some((others) =>
                    others.legalEntity === "legal" && benef.legalEntity === "legal"
                      ? others.vatNumber === benef.vatNumber
                      : others.taxId === benef.taxId
                  );
                if (hasDuplicate) {
                  errors.push(
                    new Yup.ValidationError(
                      intl.formatMessage({
                        id: "beneficiaryUniquenessError",
                      }),
                      "beneficiaryUniquenessError",
                      benef.legalEntity === "legal" ? `${context.path}[${index}].vatNumber` : `${context.path}[${index}].taxId`
                    )
                  );
                }
              }
            });

            if (errors.length) {
              return new Yup.ValidationError(errors);
            } else {
              return true;
            }
          })
          .required(),
        otherwise: Yup.array().nullable(),
      }),
      thirdReferent: Yup.object({
        taxId: Yup.string().when("unverified", {
          is: false,
          then: Yup.string().test("len16", taxCodeLengthMessage, (val) => val?.length === 16),
          otherwise: Yup.string().nullable(),
        }),
        name: Yup.string().ensure().required(requiredMessage),
        surnameOrCompanyName: Yup.string().ensure().required(requiredMessage),
        mobilePhoneNumber: Yup.string()
          .nullable()
          .test("phoneValid", invalidPhoneMessage, (val) => {
            if (val) return isValidPhoneNumber(val);
            return true;
          }),
        /*.test("phoneValid", invalidPhoneMessage, (val) => val == null || val == "" || isValidPhoneNumber(val ?? ""))
        .ensure()
        .required(requiredMessage),*/
        contactAddress: Yup.object().when(["unverified", "domicileIsNotResidence"], {
          is: (unverified, domicileIsNotResidence) => unverified || domicileIsNotResidence,
          then: getLocationSchema(intl),
          otherwise: Yup.object({
            label: Yup.string().nullable(),
          }),
        }),
        birthDate: Yup.date().when("unverified", {
          is: false,
          then: Yup.date().required(requiredMessage),
          otherwise: Yup.date().nullable(),
        }),
        birthPlace: Yup.string()
          .ensure()
          .when(["unverified", "foreign"], {
            is: (unverified, foreign) => unverified === false && !foreign,
            then: Yup.string().required(requiredGeo),
          }),
        birthCountry: Yup.string()
          .ensure()
          .when(["unverified", "foreign"], {
            is: (unverified, foreign) => unverified === false && foreign,
            then: Yup.string().required(requiredGeo),
          }),
        gender: Yup.string().when("unverified", {
          is: false,
          then: Yup.string().required(requiredMessage),
          otherwise: Yup.string().nullable(),
        }),
        location: Yup.object().when("unverified", {
          is: false,
          then: getLocationSchema(intl),
          otherwise: Yup.object({
            label: Yup.string().nullable(),
          }),
        }),
        /*email: Yup.string()
          .nullable()
          .email(intl.formatMessage({ id: "invalidEmail" })),*/
        iban: Yup.string()
          .nullable()
          .test("iban", intl.formatMessage({ id: "ibanFormatError" }), (v) => !v || isValidIBAN(v)),
      })
        .test("thirdReferentUniquenessError", intl.formatMessage({ id: "thirdReferentUniquenessError" }), (value, context) => {
          if (value?.taxId) {
            const errors = [];
            const beneficiaries = context.parent.partyData;
            beneficiaries?.forEach((benef) => {
              if (benef.taxId && benef.taxId === value.taxId) {
                errors.push(
                  new Yup.ValidationError(
                    intl.formatMessage({
                      id: "thirdReferentUniquenessError",
                    }),
                    "thirdReferentUniquenessError",
                    `${context.path}.taxId`
                  )
                );
              }
            });

            if (errors.length) {
              return new Yup.ValidationError(errors);
            }
          }
          return true;
        })
        .nullable(),
    }),
  });

  /*useEffect(() => {
    scrollToContractMessages();
  }, [contract?.messages]);*/

  useEffect(() => {
    if (contract) {
      if (contract.beneficiaries) {
        setBeneficiaryType(contract.availableBeneficiaries?.find((ab) => ab.code === contract.beneficiaries!!.code));
      }
      let initialValues: BeneficiaryPageFormValues = {
        typeSwitch: contract.beneficiaries?.code === "otherParty" ? "enterNominatives" : "selectFromList",
        beneficiaries: convertBeneficiariesForInitialValues(contract.beneficiaries),
      };
      setInitialValues(initialValues);
    }
  }, [contract]);

  const availableBeneficiariesValues = useMemo(() => {
    if (contract) {
      let valuesForTypeSwitch: string[] = [];
      if (contract.availableBeneficiaries.filter((availableBenef) => availableBenef.code !== "otherParty").length > 0) {
        valuesForTypeSwitch.push("selectFromList");
      }

      if (contract.availableBeneficiaries.some((availableBenef) => availableBenef.partyDataRequired)) valuesForTypeSwitch.push("enterNominatives");

      setTypeSwitchValues(valuesForTypeSwitch);
      return contract.availableBeneficiaries
        ?.filter((availableBenef) => !availableBenef.partyDataRequired)
        .map((e) => {
          return {
            label: e.description,
            value: e.code,
          };
        });
    }
    return [];
  }, [contract]);

  function convertBeneficiariesForInitialValues(beneficiaries?: Beneficiaries): BeneficiariesForm {
    const initialBenef = Object.assign({}, beneficiaries);
    if (!initialBenef.code) {
      initialBenef.code = "";
    }
    if (!initialBenef.thirdReferent) {
      Object.assign(initialBenef, { thirdReferent: null });
    }

    if (initialBenef.thirdReferent) {
      const [phone, phonePrefix] = getMobilePhoneAndPrefix(
        initialBenef.thirdReferent.mobilePhoneNumber,
        initialBenef.thirdReferent.mobilePhoneNumberPrefix
      );
      const birthData = getBirthPlace(initialBenef.thirdReferent);

      Object.assign(initialBenef.thirdReferent, {
        mobilePhoneNumber: phonePrefix + phone,
        mobilePhoneNumberPrefix: phonePrefix,
        foreign: isForeign(initialBenef.thirdReferent),
        ...birthData,
      });

      if (!initialBenef.thirdReferent.location) {
        initialBenef.thirdReferent.location = { label: "" }; /*, countryCode: ""};*/
      }
    }

    const convertedBeneficiary: any[] = initialBenef["partyData"]?.map((beneficiary) => {
      if (!beneficiary.unverified && beneficiary.mobilePhoneNumber) {
        const [phone, phonePrefix] = getMobilePhoneAndPrefix(beneficiary.mobilePhoneNumber, beneficiary.mobilePhoneNumberPrefix);
        beneficiary.mobilePhoneNumber = phonePrefix + phone;
        beneficiary.mobilePhoneNumberPrefix = phonePrefix;
      }
      return {
        ...beneficiary,
        legalEntity: beneficiary.legalEntity ? "legal" : "physical",
        foreign: isForeign(beneficiary),
        ...getBirthPlace(beneficiary),
      };
    });

    initialBenef["partyData"] = convertedBeneficiary;
    return initialBenef as unknown as BeneficiariesForm;
  }

  function changePartyDataRequired(values: any) {
    if (first) {
      setFirst(false);
      return;
    }
    if (values.typeSwitch === "selectFromList") {
      formRef.current?.setFieldError("beneficiaries.partyData", undefined);
      setIsOpenButtons(false);
      setBeneficiaryType(undefined);
      values.beneficiaries = {
        code: "",
        description: "",
        partyData: undefined,
        thirdReferent: values.beneficiaries?.thirdReferent,
      };
    }
    if (values.typeSwitch === "enterNominatives") {
      formRef.current?.setFieldError("beneficiaries.code", undefined);
      setIsOpenButtons(false);
      const selected = contract?.availableBeneficiaries?.find((e) => e.code === "otherParty");
      setBeneficiaryType(selected);
      values.beneficiaries = {
        code: selected.code,
        description: selected.description,
        partyData: [
          {
            legalEntity: "physical",
            unverified: false,
            taxId: "",
            gender: "",
            vatNumber: "",
            companyType: "",
            surnameOrCompanyName: "",
            foreign: false,
            name: "",
            birthCountry: undefined,
            birthCountryCode: undefined,
            birthPlace: undefined,
            birthDate: undefined,
            parentalRelationship: { code: "" },
            percentage: undefined,
            parameters: {},
          },
        ],
        thirdReferent: values.beneficiaries?.thirdReferent,
      };
    }
  }

  function getBeneficiaryData(beneficiary: BeneficiaryFormPartyData) {
    let mobilePhoneNumber: string;
    let mobilePhoneNumberPrefix: string;
    if (beneficiary.mobilePhoneNumber) {
      const prefix = formatPhoneNumberIntl(beneficiary.mobilePhoneNumber).split(" ")[0];
      mobilePhoneNumber = beneficiary.mobilePhoneNumber.replace(prefix, "");
      mobilePhoneNumberPrefix = prefix.replace("+", "00");
    }
    let updateNodes: ManagementNode[] = beneficiary.managementNodes ? beneficiary.managementNodes : [];
    if (updateNodes.filter((node) => node?.code === contract.managementNode?.code).length === 0) {
      updateNodes.push(contract.managementNode);
    }
    beneficiary.managementNodes = updateNodes;

    return {
      legalEntity: beneficiary.legalEntity === "legal",
      birthCountryCode: beneficiary.birthCountryCode,
      birthPlace: beneficiary.birthPlaceComplete ? (beneficiary.birthPlaceComplete.name as string) ?? undefined : undefined,
      location: beneficiary.unverified ? undefined : beneficiary.location.label == null ? null : beneficiary.location,
      parentalRelationship: beneficiary.parentalRelationship || null,
      mobilePhoneNumberPrefix: mobilePhoneNumberPrefix || "",
      mobilePhoneNumber: mobilePhoneNumber || "",
      managementNodes: updateNodes,
      domicile: !beneficiary.domicileIsNotResidence
        ? beneficiary.location?.label !== null
          ? beneficiary.location
          : null
        : beneficiary.domicile.label !== null
        ? beneficiary.domicile
        : null,
    };
  }

  function getBeneficiariesFromForm(beneficiariesForm: BeneficiariesForm): Beneficiaries {
    const result: Beneficiaries = {
      code: beneficiaryType.code,
      description: beneficiaryType.description,
    };
    let thirdReferent = beneficiariesForm.thirdReferent;

    if (beneficiariesForm.thirdReferent) {
      if (beneficiariesForm.thirdReferent?.unverified) {
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        const { location, ...thirdReferentValue } = beneficiariesForm.thirdReferent;
        thirdReferent = thirdReferentValue;
      } else {
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        const { contactAddress, ...thirdReferentValue } = beneficiariesForm.thirdReferent;
        thirdReferent = thirdReferentValue;
        if (thirdReferent.domicileIsNotResidence) {
          thirdReferent.contactAddress = contactAddress;
        }
      }

      if (thirdReferent.mobilePhoneNumber) {
        const prefix = formatPhoneNumberIntl(thirdReferent.mobilePhoneNumber).split(" ")[0];
        thirdReferent.mobilePhoneNumber = thirdReferent.mobilePhoneNumber.replace(prefix, "");
        thirdReferent.mobilePhoneNumberPrefix = prefix.replace("+", "00");
      }

      let updateNodes: ManagementNode[] = thirdReferent.managementNodes ? thirdReferent.managementNodes : [];
      if (updateNodes.filter((node) => node?.code === contract.managementNode?.code).length === 0) {
        updateNodes.push(contract.managementNode);
      }
      thirdReferent.managementNodes = updateNodes;
    }
    result.partyData = beneficiariesForm.partyData?.map((beneficiary) => Object.assign({}, { ...beneficiary }, getBeneficiaryData(beneficiary)));
    result.thirdReferent = thirdReferent;
    return result;
  }

  async function checkTaxId(party: BeneficiaryPartyData | ThirdReferentData) {
    let result = await partyService.checkTaxId(party as Party, true);
    return result.data;
  }

  async function submit(values: BeneficiaryPageFormValues) {
    changeLoading(1);

    const beneficiariesData = getBeneficiariesFromForm(values.beneficiaries);
    beneficiariesData.description = beneficiaryType?.description;

    const taxIdErrors = [];
    for (let index = 0; index < beneficiariesData.partyData?.length; index++) {
      const beneficiary = beneficiariesData.partyData[index];
      if (!beneficiary.unverified && !beneficiary.legalEntity) {
        const taxIdValid = await checkTaxId(beneficiary);
        if (!taxIdValid) {
          taxIdErrors.push(`beneficiaries.partyData.${index}`);
        }
      }
    }
    const thirdReferent = beneficiariesData.thirdReferent;
    if (thirdReferent && !thirdReferent?.unverified) {
      thirdReferent.birthCountyCode = thirdReferent.birthPlaceComplete
        ? (thirdReferent.birthPlaceComplete.countyCode as string) ?? undefined
        : undefined;
      thirdReferent.birthPlace = thirdReferent.birthPlaceComplete ? (thirdReferent.birthPlaceComplete.name as string) ?? undefined : undefined;

      const taxIdValid = await checkTaxId(beneficiariesData.thirdReferent);
      if (!taxIdValid) {
        taxIdErrors.push(`beneficiaries.thirdReferent`);
      }
    }
    setTaxIdChecks(taxIdErrors);

    if (taxIdErrors.length > 0) {
      changeLoading(-1);
      const element = document.getElementById(taxIdErrors[0]);
      element?.scrollIntoView({
        behavior: "smooth",
        block: "center",
      });
    } else {
      try {
        addBeneficiaries(contract.contractId, beneficiariesData).then(async (areErrors) => {
          if (!areErrors) {
            navigate(`${CTX}/offers/${contract.quotationId}/thirdParty`);
          } else scrollToTop();
        });
      } catch (e: any) {
        console.error(e);
      } finally {
        changeLoading(-1);
      }
    }
  }

  function thereIsThirdReferent(values: any) {
    return values.beneficiaries.thirdReferent != undefined;
  }

  function toggleButtons() {
    setIsOpenButtons(!isOpenButtons);
  }

  function addBeneficiary(values: any) {
    setIsOpenButtons(false);
    const newCount = values.beneficiaries?.partyData?.push({
      unverified: false,
      legalEntity: "physical",
      surnameOrCompanyName: "",
      name: "",
      birthPlace: "",
      birthDate: undefined,
      parentalRelationship: { code: "" },
      percentage: "",
      parameters: paramsToMap(defaultBeneficiaryParameters),
    });
    formRef.current?.setFieldValue("beneficiaries.partyData", values.beneficiaries?.partyData);

    setTimeout(() => {
      const element = document.getElementById(`beneficiaries.partyData.${newCount - 1}`);

      element?.scrollIntoView({
        behavior: "smooth",
        block: "center",
      });
    }, 500);
  }

  function addThirdReferent() {
    setIsOpenButtons(false);
    formRef.current!!.setFieldValue("beneficiaries.thirdReferent", {
      unverified: false,
      taxId: "",
      gender: "",
      name: "",
      birthPlace: "",
      birthDate: undefined,
      surnameOrCompanyName: "",
      mobilePhoneNumber: "",
      contactAddress: { label: "" },
      location: { label: "" },
      domicileIsNotResidence: false,
    } as ThirdReferentData);

    setTimeout(() => {
      const element = document.getElementById(`beneficiaries.thirdReferent`);
      element?.scrollIntoView({
        behavior: "smooth",
        block: "center",
      });
    }, 500);
  }

  /*function toggleUnverifiedThirdReferent(partialValues: any) {
    formRef.current!!.setFieldValue(
      "beneficiaries.thirdReferent",
      {
        unverified: partialValues["beneficiaries.thirdReferent.unverified"],
        taxId: "",
        surnameOrCompanyName: "",
        name: "",
        birthDate: undefined,
        birthPlace: "",
        birthCountry: "",
        birthCountryCode: "",
        gender: "",
        email: "",
        mobilePhoneNumber: "",
        iban: "",
        contactAddress: {label: null},
        location: {label: null},
      },
      false
    );
  }*/

  /*function toggleUnverifiedBeneficiary(partialValues: any) {
    const beneficiaryAtIndex = Object.keys(partialValues)[0];
    const previousValue = formRef.current!!.getFieldMeta(beneficiaryAtIndex).value as Partial<BeneficiaryFormPartyData>;
    formRef.current!!.setFieldValue(
      beneficiaryAtIndex,
      Object.assign({}, previousValue, {
        unverified: partialValues[beneficiaryAtIndex],
        taxId: "",
        surnameOrCompanyName: "",
        name: "",
        birthDate: undefined,
        birthPlace: "",
        birthCountry: "",
        birthCountryCode: "",
        gender: "",
        email: "",
        mobilePhoneNumber: "",
        iban: "",
        location: {label: null},
        parentalRelationship: "",
        vatNumber: "",
        companyType: "",
        atecoCode: "",
        employeesNumber: "",
        revenue: undefined,
        irrevocable: partialValues[beneficiaryAtIndex] ? false : previousValue.irrevocable,
      }),
      false
    );
  }*/

  // function recalcFirstBeneficiaryPercentage(
  //   beneficiaries: BeneficiaryFormPartyData[]
  // ) {
  //   const sum = beneficiaries.reduce((sum, benef, index) => {
  //     if (benef.percentage && index > 0) {
  //       sum += benef.percentage;
  //     }
  //     return sum;
  //   }, 0);
  //   if (sum <= 99) {
  //     beneficiaries[0].percentage = 100 - sum;
  //   }
  // }

  const buttonRef = useRef(null);
  const buttonsContainerRef = useRef(null);
  const handleDocumentClick = (event: MouseEvent) => {
    if (
      buttonRef.current &&
      !buttonRef.current.contains(event.target as Node) &&
      buttonsContainerRef.current &&
      !buttonsContainerRef.current.contains(event.target as Node)
    ) {
      setIsOpenButtons(false);
    }
  };
  useEffect(() => {
    if (isOpenButtons) {
      document.addEventListener("click", handleDocumentClick);
    } else {
      document.removeEventListener("click", handleDocumentClick);
    }
  }, [isOpenButtons]);

  function updateAndSaveDraft(values: BeneficiaryPageFormValues) {
    const beneficiariesForm = values.beneficiaries;
    const resultBenef: Beneficiaries = {
      code: beneficiaryType?.code || "",
      description: beneficiaryType?.description || "",
    };

    let thirdReferent = beneficiariesForm.thirdReferent;

    if (thirdReferent) {
      if (thirdReferent.unverified) {
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        const { location, ...thirdReferentValue } = beneficiariesForm.thirdReferent;
        thirdReferent = thirdReferentValue;
      } else {
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        const { contactAddress, ...thirdReferentValue } = beneficiariesForm.thirdReferent;
        thirdReferent = thirdReferentValue;
        if (thirdReferent.domicileIsNotResidence) {
          thirdReferent.contactAddress = contactAddress;
        }
        if (thirdReferent.location.label == null) {
          thirdReferent.location = null;
        }
      }
      thirdReferent.birthCountyCode = thirdReferent.birthPlaceComplete
        ? (thirdReferent.birthPlaceComplete.countyCode as string) ?? undefined
        : undefined;
      thirdReferent.birthPlace = thirdReferent.birthPlaceComplete ? (thirdReferent.birthPlaceComplete.name as string) ?? undefined : undefined;

      let [number, numberPrefix] = setMobilePhoneAndPrefix(thirdReferent.mobilePhoneNumber);
      thirdReferent.mobilePhoneNumber = number;
      thirdReferent.mobilePhoneNumberPrefix = numberPrefix;
    }
    resultBenef.thirdReferent = thirdReferent;

    resultBenef.partyData = beneficiariesForm.partyData?.map((beneficiary) => Object.assign({ ...beneficiary }, getBeneficiaryData(beneficiary)));

    contract.beneficiaries = Object.assign({}, resultBenef);

    saveDraft(contract);
  }

  return (
    <>
      {contractError ? (
        <ErrorPage />
      ) : (
        <>
          {initialValues && policyholder && (
            <Formik initialValues={initialValues} innerRef={formRef} onSubmit={submit} validationSchema={validationSchema}>
              {({ values, setFieldValue, submitCount, errors }) => (
                <>
                  <StickyBar
                    //backFunction={() => saveDraft()}
                    breadcrumb={
                      <div className="flex flex-col truncate">
                        <div data-qa="beneficiaries-page-title" className="truncate">
                          <FormattedMessage id="beneficiariesAndThirdReferent" />
                        </div>

                        <div className="inline-flex flex-wrap gap-x-4 items-center" data-qa="extra-info">
                          {/*contract.quotationNumber && (
                            <span className="text-base font-normal truncate" data-qa="product-quotationNumber">
                              N. {contract.quotationNumber}
                            </span>
                          )*/}
                          <span className="text-base font-normal truncate" data-qa="policyholder-title">
                            {policyholder?.surnameOrCompanyName}&nbsp;
                            {policyholder?.name}
                          </span>
                          <span className="text-base font-normal truncate" data-qa="product-description">
                            {contract.contractProductName}
                          </span>
                        </div>
                      </div>
                    }
                  >
                    <div className="self-end text-right flex-1 flex gap-x-4">
                      {values.typeSwitch === "enterNominatives" && (
                        <div className="relative">
                          <div ref={buttonRef}>
                            <YogaButton action={() => toggleButtons()} data-qa="add-buttons" position="outer">
                              <MenuIcon className="w-5 mr-2 -ml-1" />
                              <span className="uppercase">
                                <FormattedMessage id="add" />
                              </span>
                            </YogaButton>
                          </div>

                          {isOpenButtons && (
                            <div className="absolute z-100 mt-2 right-0" ref={buttonsContainerRef}>
                              <div
                                data-qa="add-buttons-container"
                                className="flex flex-grow flex-col gap-1 p-1 bg-white border-primary border-2 rounded-lg shadow"
                              >
                                <YogaButton
                                  text-size="base"
                                  uppercase={false}
                                  position="inner-most"
                                  data-qa={`add-beneficiary-button`}
                                  action={() => addBeneficiary(values)}
                                >
                                  <div className="flex gap-4 items-center justify-between w-full">
                                    <span className="text-base">
                                      <FormattedMessage id="beneficiary" />
                                    </span>
                                    <UserIcon className="w-6 h-6" />
                                  </div>
                                </YogaButton>
                                <YogaButton
                                  text-size="base"
                                  uppercase={false}
                                  position="inner-most"
                                  disabled={!!values.beneficiaries?.thirdReferent}
                                  data-qa={`add-third-referent-button`}
                                  action={addThirdReferent}
                                >
                                  <div className="flex gap-4 items-center justify-between w-full">
                                    <span className="text-base">
                                      <FormattedMessage id="thirdReferent" />
                                    </span>
                                    <IdentificationIcon className="w-6 h-6" />
                                  </div>
                                </YogaButton>
                              </div>
                            </div>
                          )}
                        </div>
                      )}
                      <div className={values.typeSwitch === "enterNominatives" ? "hidden" : "block"}>
                        <YogaButton
                          kind="default"
                          data-qa="add-third-referent-button"
                          outline={true}
                          disabled={!!values.beneficiaries?.thirdReferent}
                          action={addThirdReferent}
                          className="flex items-center gap-x-2"
                        >
                          <PlusCircleIcon className="w-5 h-5 shrink-0" />
                          <p className="hidden lg:block">
                            <FormattedMessage id="addThirdReferent" />
                          </p>
                          <p className="lg:hidden">
                            <FormattedMessage id="thirdRef" />
                          </p>
                        </YogaButton>
                      </div>

                      {config.SAVE_DRAFT_LIFE_PROPOSAL && (
                        <YogaButton
                          kind="default"
                          type="button"
                          outline
                          className="flex gap-2 items-center"
                          data-qa="save-draft-button"
                          action={() => updateAndSaveDraft(values)}
                        >
                          <SaveIcon className="w-5 lg:-ml-1 shrink-0" />
                          <span className="hidden lg:block">
                            <FormattedMessage id="saveDraft" />
                          </span>
                        </YogaButton>
                      )}
                      <YogaButton
                        kind="default"
                        form="contractBeneficiaries"
                        type="submit"
                        data-qa="continue-button"
                        className="flex items-center gap-x-2"
                      >
                        <ArrowCircleRightIcon className="w-5 h-5" />
                        <div className="hidden lg:block">
                          <FormattedMessage id="continue" />
                        </div>
                      </YogaButton>
                    </div>
                  </StickyBar>

                  <div className="px-3 scroll-mt-24">
                    <Messages messages={contract.messages} entity="contract" />

                    {submitCount > 0 && errors?.beneficiaries && errors.beneficiaries["percentageSum"] && (
                      <div id="beneficiaries.percentageSum" className="mb-8">
                        <YogaMessage data-qa="percentageMessageError" type="error" position="outer">
                          {errors.beneficiaries["percentageSum"]}
                        </YogaMessage>
                      </div>
                    )}
                    <Form id="contractBeneficiaries">
                      <YogaCard uniformPadding data-qa="contract-beneficiaries-card" className="bg-body-text text-box-background border-body-text">
                        <div className="flex flex-row items-center gap-x-4 justify-between lg:justify-normal">
                          <span className="text-xl font-bold">
                            <FormattedMessage id="deathBeneficiaries" />
                          </span>
                          <Field
                            name="typeSwitch"
                            component={FormikTabSwitch}
                            content={{
                              name: "typeSwitch",
                              type: "TABSWITCH",
                              mandatory: true,
                              availableValues: typeSwitchValues,
                            }}
                            onFieldChange={() => {
                              changePartyDataRequired(values);
                            }}
                          />
                        </div>
                        {beneficiaryType?.code !== "otherParty" && (
                          <div className="w-full mt-4 bg-white p-4 rounded-lg">
                            <span className="w-1/2 lg:w-1/3 flex text-card-text-premium items-center">
                              <Field
                                key="beneficiaries.code"
                                name="beneficiaries.code"
                                component={FormikSelect}
                                onFieldChange={() => {
                                  const selected = contract?.availableBeneficiaries?.find((e) => e.code === values?.beneficiaries?.code);
                                  setBeneficiaryType(selected);
                                }}
                                mandatory
                                dataQa="parentalRelationship"
                                content={{
                                  updateOnChange: true,
                                  name: "beneficiaries.code",
                                  placeholder: intl.formatMessage({
                                    id: "selectBeneficiaries",
                                  }),
                                  availableValues: availableBeneficiariesValues,
                                }}
                              />
                            </span>
                          </div>
                        )}
                        {beneficiaryType?.code === "otherParty" && (
                          <FieldArray
                            name="beneficiaries.partyData"
                            render={() => (
                              <div data-qa="beneficiaries.partyData-container" className="flex flex-col gap-y-4 mt-4">
                                {beneficiaryType?.partyDataRequired &&
                                  values.beneficiaries?.partyData?.map((ben, index, array) => (
                                    <div
                                      key={`beneficiary-${index}`}
                                      id={`beneficiaries.partyData.${index}`}
                                      data-qa={`beneficiary-${index}`}
                                      className="bg-box-background rounded-lg text-body-text"
                                    >
                                      <div className="grid grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-6 p-4 border-b-2 border-background box-border">
                                        <div className="flex gap-x-4 lg:gap-x-2 items-center">
                                          <UserIcon className="w-6 h-6 shrink-0" strokeWidth={2.5} />
                                          <p className="text-xl font-bold">
                                            <FormattedMessage id="beneficiary" />
                                          </p>
                                          <div className="relative overflow-visible whitespace-nowrap hidden lg:block w-full">
                                            <Field name={`beneficiaries.partyData.${index}.percentage`}>
                                              {(fieldProps: FieldProps) => (
                                                <>
                                                  <FormikInputNumeric
                                                    {...fieldProps}
                                                    data-qa={`beneficiaries.partyData.${index}.percentage`}
                                                    content={{
                                                      name: `beneficiaries.partyData.${index}.percentage`,
                                                      placeholder: intl.formatMessage({
                                                        id: "benefitPercentage",
                                                      }),
                                                      type: "NUMBER",
                                                      mandatory: true,
                                                      max: array?.length > 1 ? 99 : 100,
                                                      min: 1,
                                                    }}
                                                    percentage
                                                    notShowErrorMessage
                                                    className="w-full"
                                                  />
                                                  {fieldProps.meta.touched && fieldProps.meta.error && (
                                                    <span className="absolute text-base text-error">{fieldProps.meta.error}</span>
                                                  )}
                                                </>
                                              )}
                                            </Field>
                                          </div>
                                        </div>
                                        <div className="pt-6 lg:p-0 flex-1 col-span-2 lg:col-span-1 flex flex-row gap-x-8 items-center order-last lg:order-none">
                                          <div className="flex-1">
                                            {/* beneficiaries light
                                            <Field
                                              key={`beneficiaries.partyData.${index}.unverified`}
                                              name={`beneficiaries.partyData.${index}.unverified`}
                                              component={FormikInput}
                                              content={{
                                                label: "noPartyData",
                                                type: "SWITCH",
                                                name: `beneficiaries.partyData.${index}.unverified`,
                                                updateOnChange: true,
                                              }}
                                              fieldName={`beneficiaries.partyData[${index}]`}
                                              onPartialUpdate={toggleUnverifiedBeneficiary}
                                              small
                                            />
                                            */}
                                          </div>
                                          <div className="flex-1  block lg:hidden" style={{ display: "none" }}>
                                            <Field
                                              key={`beneficiaries.partyData.${index}.irrevocable`}
                                              name={`beneficiaries.partyData.${index}.irrevocable`}
                                              component={FormikInput}
                                              content={{
                                                label: "irrevocableBeneficiary",
                                                type: "SWITCH",
                                                name: `beneficiaries.partyData.${index}.irrevocable`,
                                              }}
                                              disabled={values.beneficiaries.partyData[index].unverified}
                                              small
                                            />
                                          </div>
                                        </div>

                                        <div className="flex flex-row items-center justify-between w-full">
                                          <div className="hidden lg:block lg:flex-1 w-full grow" style={{ display: "none" }}>
                                            <Field
                                              key={`beneficiaries.partyData.${index}.irrevocable`}
                                              name={`beneficiaries.partyData.${index}.irrevocable`}
                                              component={FormikInput}
                                              content={{
                                                label: "irrevocableBeneficiary",
                                                type: "SWITCH",
                                                name: `beneficiaries.partyData.${index}.irrevocable`,
                                              }}
                                              disabled={values.beneficiaries.partyData[index].unverified}
                                              small
                                            />
                                          </div>
                                          <div className="flex items-center w-full gap-x-2 justify-end">
                                            <div className="relative overflow-visible whitespace-nowrap lg:hidden w-full">
                                              <Field name={`beneficiaries.partyData.${index}.percentage`}>
                                                {(fieldProps: FieldProps) => (
                                                  <>
                                                    <FormikInputNumeric
                                                      {...fieldProps}
                                                      data-qa={`beneficiaries.partyData.${index}.percentage`}
                                                      content={{
                                                        name: `beneficiaries.partyData.${index}.percentage`,
                                                        placeholder: intl.formatMessage({
                                                          id: "benefitPercentage",
                                                        }),
                                                        type: "NUMBER",
                                                        mandatory: true,
                                                        max: array?.length > 1 ? 99 : 100,
                                                        min: 1,
                                                      }}
                                                      percentage
                                                      notShowErrorMessage
                                                      className="w-full"
                                                    />
                                                    {fieldProps.meta.touched && fieldProps.meta.error && (
                                                      <span className="absolute text-base text-error">{fieldProps.meta.error}</span>
                                                    )}
                                                  </>
                                                )}
                                              </Field>
                                            </div>
                                            <YogaButton
                                              data-qa={`remove-beneficiary-${index}`}
                                              action={() => {
                                                setIndexOfBeneficiary(index);
                                                setBeneficiaryModalOpen(true);
                                              }}
                                              className="border-none px-0 py-0"
                                              type="button"
                                              outline
                                              disabled={array.length === 1}
                                            >
                                              <TrashIcon className={`w-10 h-10 ${array.length === 1 ? "text-action-disabled" : "text-error"}`} />
                                            </YogaButton>
                                          </div>
                                        </div>
                                      </div>
                                      <Field name={`beneficiaries.partyData.${index}`}>
                                        {(fieldProps: FieldProps) => (
                                          <BeneficiaryForm
                                            {...fieldProps}
                                            beneficiary={beneficiaryType}
                                            contract={contract}
                                            taxIdChecks={taxIdChecks}
                                            setTaxIdChecks={setTaxIdChecks}
                                            defaultParams={defaultBeneficiaryParameters}
                                            updatePartyParams={updateBeneficiaryParameters}
                                          />
                                        )}
                                      </Field>
                                    </div>
                                  ))}
                                {values.beneficiaries.partyData && beneficiaryModalOpen && (
                                  <ConfirmModal
                                    isOpen={beneficiaryModalOpen && indexOfBeneficiary !== null}
                                    onClose={() => {
                                      setBeneficiaryModalOpen(false);
                                      setIndexOfBeneficiary(null);
                                    }}
                                    onConfirm={() => {
                                      setBeneficiaryModalOpen(false);

                                      values.beneficiaries?.partyData.splice(indexOfBeneficiary, 1);
                                      // remove<BeneficiaryFormPartyData>(
                                      //   indexOfBeneficiary
                                      // );
                                      setIndexOfBeneficiary(null);
                                    }}
                                    title="deleteBeneficiary"
                                    dataQa="delete-beneficiary-modal"
                                  >
                                    <div>
                                      <FormattedMessage id="deleteBeneficiaryMessage" />
                                      {
                                        //this part manages the parentheses and the name and surname print on the sceen
                                        values.beneficiaries?.partyData[indexOfBeneficiary].surnameOrCompanyName ||
                                        values.beneficiaries?.partyData[indexOfBeneficiary].name
                                          ? ` (${
                                              (values.beneficiaries?.partyData[indexOfBeneficiary].name
                                                ? values.beneficiaries?.partyData[indexOfBeneficiary].name
                                                : "") +
                                              (values.beneficiaries?.partyData[indexOfBeneficiary].surnameOrCompanyName &&
                                              values.beneficiaries?.partyData[indexOfBeneficiary].name
                                                ? " "
                                                : "") +
                                              (values.beneficiaries?.partyData[indexOfBeneficiary].surnameOrCompanyName
                                                ? values.beneficiaries?.partyData[indexOfBeneficiary].surnameOrCompanyName
                                                : "")
                                            })?`
                                          : "?"
                                      }
                                    </div>
                                  </ConfirmModal>
                                )}
                              </div>
                            )}
                          />
                        )}
                      </YogaCard>

                      {thereIsThirdReferent(values) && (
                        <div data-qa="thirdReferent-card" className="bg-box-background rounded-2xl shadow-lg mt-8" id="beneficiaries.thirdReferent">
                          <div className="flex flex-row items-center gap-x-8 p-4 border-b-2 border-background box-border justify-between">
                            <div className="w-1/3 flex space-x-2 items-center">
                              <IdentificationIcon className="w-6 h-6 shrink-0" />
                              <p className="text-xl font-bold">
                                <FormattedMessage id="thirdReferent" />
                              </p>
                            </div>
                            <div className="w-1/3">
                              {/* beneficiaries light
                              <Field
                                key={`beneficiaries.thirdReferent.unverified`}
                                name={`beneficiaries.thirdReferent.unverified`}
                                component={FormikInput}
                                content={{
                                  label: "noPartyData",
                                  type: "SWITCH",
                                  name: `beneficiaries.thirdReferent.unverified`,
                                  updateOnChange: true,
                                }}
                                // className="justify-center"
                                fieldName={`beneficiaries.thirdReferent.unverified`}
                                onPartialUpdate={toggleUnverifiedThirdReferent}
                                small
                              /> */}
                            </div>
                            <div className="w-1/3 text-right">
                              <YogaButton
                                data-qa={`remove-third-referent`}
                                action={() => setThirdReferentModalOpen(true)}
                                className="border-none px-0 py-0"
                                type="button"
                                outline
                              >
                                <TrashIcon className=" w-10 h-10 text-error " />
                              </YogaButton>
                            </div>
                            <ConfirmModal
                              isOpen={thirdReferentModalOpen}
                              onClose={() => setThirdReferentModalOpen(false)}
                              onConfirm={() => {
                                setThirdReferentModalOpen(false);
                                setFieldValue("beneficiaries.thirdReferent", null);
                              }}
                              title="deleteThirdReferent"
                              dataQa="delete-third-referent-modal"
                            >
                              <div>
                                <FormattedMessage id="deleteThirdReferentMessage" />
                              </div>
                            </ConfirmModal>
                          </div>
                          <Field name={`beneficiaries.thirdReferent`}>
                            {(fieldProps: FieldProps) => (
                              <ThirdReferentForm
                                {...fieldProps}
                                taxIdChecks={taxIdChecks}
                                setTaxIdChecks={setTaxIdChecks}
                                contract={contract}
                                defaultParams={defaultThirdReferentParameters}
                                updatePartyParams={updateThirdReferentParameters}
                              />
                            )}
                          </Field>
                        </div>
                      )}
                      <YogaScrollToFieldError />
                    </Form>
                  </div>
                </>
              )}
            </Formik>
          )}
        </>
      )}
    </>
  );
}
