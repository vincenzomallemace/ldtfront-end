import { ArrowCircleRightIcon, SaveIcon } from "@heroicons/react/outline";
import { config, CTX } from "commons/Configuration";
import { getISODate } from "commons/DateUtils";
import { getBirthPlace, getMobilePhoneAndPrefix, paramsToMap } from "commons/FormUtils";
import Messages from "commons/components/Messages";
import { StickyBar } from "commons/components/StickyBar";
import { YogaButton } from "commons/components/YogaButton";
import { Context } from "commons/contexts/Context";
import { ManagementNode } from "commons/models/nodes/ManagementNode";
import { contractService } from "commons/services/ContractService";
import { partyService } from "commons/services/PartyService";
import { Party } from "customers/models/Party";
import { Profile } from "customers/models/Profile";
import { Form, Formik } from "formik";
import { Subscriber } from "models/FinancialAdvice";
import useFinancialAdvice from "offers/hooks/useFinancialAdvice";
import { useContext, useEffect, useState } from "react";
import { FormattedMessage, useIntl } from "react-intl";
import { formatPhoneNumberIntl } from "react-phone-number-input";
import { useNavigate, useParams } from "react-router-dom";
import { toast } from "react-toastify";
import { RoleType } from "./enums/RoleType";
import ThirdPartyForm, { ThirdParty, ThirdPartyPresence } from "./form/ThirdPartyForm";
import useContract from "./hooks/useContract";
import { Contract } from "./models/Contract";
import { scrollToTop } from "commons/Utils";
import ErrorPage from "commons/components/ErrorPage";
import { getThirdPartyValidationSchema } from "customers/models/ThirdParty";
import usePartyParameters from "customers/hooks/usePartyParameters";

export default function ThirdPartyPage() {
  const { productId } = useParams<string>();
  const { contract, contractError, policyholder, setContract, addThirdParty } = useContract(productId, true);
  const { financialAdvice } = useFinancialAdvice(productId, true);

  return (
    <>
      {contractError ? (
        <ErrorPage />
      ) : (
        <>
          {contract && policyholder && financialAdvice && (
            <ThirdPartyFormik
              contract={contract}
              setContract={setContract}
              policyholder={policyholder}
              subscriber={financialAdvice.subscriber}
              addThirdParty={addThirdParty}
            />
          )}
        </>
      )}
    </>
  );
}

function ThirdPartyFormik({
  contract,
  setContract,
  policyholder,
  subscriber,
  addThirdParty,
}: {
  contract: Contract;
  setContract: any;
  policyholder: Party;
  subscriber: Subscriber;
  addThirdParty: (contractId: string, party: Party) => Promise<boolean>;
}) {
  const intl = useIntl();
  const navigate = useNavigate();
  const { changeLoading } = useContext(Context);

  const [initialValues, setInitialValues] = useState(undefined);
  const validationSchema = getThirdPartyValidationSchema(policyholder.taxId, intl);

  const [mandatoryThirdParty, setMandatoryThirdParty] = useState(false);
  const [subscriberSetted, setSubscriberSetted] = useState(false);
  const [subscriberParty, setSubscriberParty] = useState<Party>(undefined);

  const [taxIdError, setTaxIdError] = useState(false);

  const { updateParams: updateThirdPartyParameters, defaultParams: defaultThirdPartyParameters } = usePartyParameters(
    RoleType.THIRD_PARTY,
    contract.productCode,
    contract.quotationId,
    contract.contractBranch
  );

  /*useEffect(() => {
    scrollToContractMessages();
  }, [contract?.messages]);*/

  useEffect(() => {
    const fetchParty = async () => {
      changeLoading(1);
      if (subscriber.taxId && subscriber.relationWithContractHolder === RoleType.THIRD_PARTY && subscriber.taxId !== policyholder.taxId) {
        const result = await partyService.getPartyByTaxId(subscriber.taxId, false);
        const party = result.data;
        setSubscriberParty(party);
      }
    };

    fetchParty()
      .catch(() => {
        setSubscriberParty(undefined);
      })
      .finally(() => {
        changeLoading(-1);
        setSubscriberSetted(true);
      });
  }, []);

  useEffect(() => {
    if (contract && policyholder && subscriberSetted) {
      let initValues;
      if (subscriberParty && !(RoleType.THIRD_PARTY in contract.parties)) {
        let [number, numberPrefix] = getMobilePhoneAndPrefix(subscriberParty.mobilePhoneNumber, subscriberParty.mobilePhoneNumberPrefix);
        initValues = {
          presence: ThirdPartyPresence.PRESENT,
          ...subscriberParty,
          birthPlace: subscriberParty.birthPlace
            ? subscriberParty.birthCountyCode
              ? `${subscriberParty.birthPlace} (${subscriberParty.birthCountyCode})`
              : subscriberParty.birthPlace
            : "",
          birthPlaceComplete: {
            geoId: "",
            name: subscriberParty.birthPlace ?? "",
            countyCode: subscriberParty.birthCountyCode ?? "",
          },
          birthCountry: subscriberParty.birthCountry || "",
          birthCountryCode: subscriberParty.birthCountryCode ?? "",
          location: subscriberParty.location || { label: "" },
          mobilePhoneNumber: number ? numberPrefix + number : "",
          domicile: !subscriberParty.domicileIsNotResidence
            ? { label: "" }
            : subscriberParty.domicile?.label !== subscriberParty.location?.label && subscriberParty.domicile?.label !== null
            ? subscriberParty.domicile
            : { label: "" },
        };
        setMandatoryThirdParty(true);
      } else if (RoleType.THIRD_PARTY in contract.parties) {
        const thirdParty = contract.parties[RoleType.THIRD_PARTY][0];
        let [number, numberPrefix] = getMobilePhoneAndPrefix(thirdParty.mobilePhoneNumber, thirdParty.mobilePhoneNumberPrefix);
        const birthData = getBirthPlace(thirdParty);
        initValues = {
          presence: ThirdPartyPresence.PRESENT,
          ...thirdParty,
          partyId: thirdParty.partyId,
          birthPlace: birthData.birthPlace,
          birthPlaceComplete: birthData.birthPlaceComplete,
          location: thirdParty.location || { label: "" },
          mobilePhoneNumber: number ? numberPrefix + number : "",
          domicile: !thirdParty.domicileIsNotResidence
            ? { label: "" }
            : thirdParty.domicile?.label !== thirdParty.location?.label && thirdParty.domicile?.label !== null
            ? thirdParty.domicile
            : { label: "" },
        };
        setMandatoryThirdParty(!!subscriberParty);
      } else {
        initValues = {
          presence: ThirdPartyPresence.ABSENT,
          partyId: "",
          taxId: "",
          name: "",
          surnameOrCompanyName: "",
          birthDate: "",
          birthPlace: "",
          birthCountry: "",
          birthCountryCode: "",
          mobilePhoneNumber: "",
          gender: "",
          email: "",
          iban: "",
          location: { label: "" },
          domicileIsNotResidence: false,
          domicile: { label: "" },
          parameters: paramsToMap(defaultThirdPartyParameters),
        };
      }
      setInitialValues(initValues);
    }
  }, [contract, policyholder, subscriberSetted]);

  function buildThirdParty(values: ThirdParty) {
    let mobilePhoneNumber: string;
    let mobilePhoneNumberPrefix: string;
    if (values.mobilePhoneNumber) {
      const prefix = formatPhoneNumberIntl(values.mobilePhoneNumber).split(" ")[0];
      mobilePhoneNumber = values.mobilePhoneNumber.replace(prefix, "");
      mobilePhoneNumberPrefix = prefix.replace("+", "00");
    }
    let updateNodes: ManagementNode[] = values.managementNodes ? values.managementNodes : [];

    if (updateNodes.filter((node) => node?.code === contract.managementNode?.code).length === 0) {
      updateNodes.push(contract.managementNode);
    }
    const profile = values.profile as Profile;
    if (profile) {
      profile.email = values.email as string;
    }
    const birthData = getBirthPlace(values);
    let thirdParty: Party = {
      partyId: values.partyId,
      taxId: values.taxId as string,
      surnameOrCompanyName: values.surnameOrCompanyName as string,
      name: values.name as string,
      legalEntity: false,
      birthDate: (values.birthDate as Date) ? new Date(getISODate(values.birthDate as Date)) : undefined,
      birthCountry: birthData.birthCountry,
      birthCountryCode: birthData.birthCountryCode,
      birthPlace: birthData.birthPlaceComplete.name,
      birthPlaceCode: birthData.birthPlaceCode,
      birthCountyCode: birthData.birthCountyCode,
      gender: values.gender as string,
      mobilePhoneNumber: mobilePhoneNumber,
      mobilePhoneNumberPrefix: mobilePhoneNumberPrefix,
      email: values.email as string,
      profile: profile,
      iban: values.iban,
      bankAccounts: values.bankAccounts,
      customerReference: values.customerReference,
      managementNodes: updateNodes,
      questionnaireCode: values.questionnaireCode,
      questionnaire: values.questionnaire,
      tags: values.tags,
      legacyData: values.legacyData,
      consents: values.consents,
      lastConsentsUpdateInstant: values.lastConsentsUpdateInstant,
      otpSignatureEnabled: values.otpSignatureEnabled,
      linkedParties: values.linkedParties,
      parameters: values.parameters ?? {},
      location: values.location?.label === null ? null : values.location,
      domicileIsNotResidence: values.domicileIsNotResidence,
      domicile: !values.domicileIsNotResidence
        ? values.location?.label !== null
          ? values.location
          : null
        : values.domicile.label !== null
        ? values.domicile
        : null,
    };

    return thirdParty as Party;
  }

  async function checkTaxId(party: Party) {
    let result = await partyService.checkTaxId(party, true);
    return result.data;
  }

  async function submit(values: ThirdParty) {
    changeLoading(1);
    try {
      if (values.presence == ThirdPartyPresence.PRESENT) {
        const thirdParty = buildThirdParty(values);
        const taxIdValid = await checkTaxId(thirdParty);
        if (!taxIdValid) {
          setTaxIdError(true);
        } else {
          addThirdParty(contract.contractId, thirdParty).then((areThereErrors) => {
            if (!areThereErrors) {
              navigate(`${CTX}/offers/${contract.quotationId}/signatureAndPayment`);
            } else scrollToTop();
          });
        }
      } else {
        if (RoleType.THIRD_PARTY in contract.parties && contract.parties[RoleType.THIRD_PARTY]?.length > 0) {
          const partyToRemove = contract?.parties[RoleType.THIRD_PARTY][0];
          await contractService.removePartyByRoleAndId(contract.contractId, RoleType.THIRD_PARTY, partyToRemove.partyId);
        }
        navigate(`${CTX}/offers/${contract.quotationId}/signatureAndPayment`);
      }
    } catch (e) {
      console.error(e);
    } finally {
      changeLoading(-1);
    }
  }

  async function saveDraft(formValues: ThirdParty) {
    changeLoading(1);

    let draftContract: Contract = Object.assign(contract);
    if (formValues.presence == ThirdPartyPresence.PRESENT) {
      if (formValues.taxId.length === 16) {
        const thirdParty = buildThirdParty(formValues);
        await contractService
          .addPartyByRole(draftContract.contractId, RoleType.THIRD_PARTY, thirdParty)
          .then((response) => (draftContract = response.data));
      }
    } else {
      if (RoleType.THIRD_PARTY in draftContract.parties) {
        const partyIdToRemove = draftContract.parties[RoleType.THIRD_PARTY][0]?.partyId;
        await contractService
          .removePartyByRoleAndId(draftContract.contractId, RoleType.THIRD_PARTY, partyIdToRemove)
          .then((response) => (draftContract = response.data));
      }
    }

    contractService
      .updateContractDraft(contract.contractId, draftContract)
      .then((response) => {
        setContract(response.data);
        toast.success(
          intl.formatMessage(
            {
              id: "proposalDrafted",
            },
            { number: response.data.quotationNumber }
          )
        );
      })
      .catch((e) => {
        console.error(e);
        toast.error(
          intl.formatMessage(
            {
              id: "proposalDraftedErrorWithNumber",
            },
            { number: contract.quotationNumber }
          )
        );
      })
      .finally(() => changeLoading(-1));
  }

  return (
    <>
      {initialValues && (
        <>
          <Formik initialValues={initialValues} validationSchema={validationSchema} onSubmit={submit}>
            {({ values }) => (
              <Form id="thirdPartyForm">
                <StickyBar
                  //backFunction={() => saveDraft}
                  breadcrumb={
                    <div className="flex flex-col truncate">
                      <div data-qa="thirdParty-page-title" className="truncate">
                        <FormattedMessage id="thirdParty" />
                      </div>
                      <div className="inline-flex flex-wrap gap-x-4 items-center" data-qa="extra-info">
                        {/*contract.quotationNumber && (
                          <span className="text-base font-normal truncate" data-qa="product-quotationNumber">
                            N. {contract.quotationNumber}
                          </span>
                        )*/}
                        <span className="text-base font-normal truncate" data-qa="policyholder-title">
                          {policyholder?.surnameOrCompanyName}&nbsp;
                          {policyholder?.name}
                        </span>
                        <span className="text-base font-normal truncate" data-qa="product-description">
                          {contract.contractProductName}
                        </span>
                      </div>
                    </div>
                  }
                >
                  <div className="self-end text-right flex-1 flex gap-x-4">
                    {config.SAVE_DRAFT_LIFE_PROPOSAL && (
                      <YogaButton
                        kind="default"
                        type="button"
                        outline
                        className="flex gap-2 items-center"
                        data-qa="save-draft-button"
                        action={() => saveDraft(values)}
                      >
                        <SaveIcon className="w-5 lg:-ml-1 shrink-0" />
                        <FormattedMessage id="saveDraft" />
                      </YogaButton>
                    )}
                    <YogaButton
                      kind="default"
                      form="thirdPartyForm"
                      type="submit"
                      data-qa="continue-button"
                      className="flex items-center gap-x-2"
                      //action={() => saveDraft()
                    >
                      <ArrowCircleRightIcon className="w-5 h-5" />
                      <div className="hidden lg:block">
                        <FormattedMessage id="continue" />
                      </div>
                    </YogaButton>
                  </div>
                </StickyBar>
                <div className="px-3">
                  <Messages messages={contract.messages} entity="contract" />
                  {defaultThirdPartyParameters && (
                    <ThirdPartyForm
                      contract={contract}
                      policyholder={policyholder}
                      taxIdError={taxIdError}
                      setTaxIdError={setTaxIdError}
                      mandatoryThirdParty={mandatoryThirdParty}
                      updatePartyParams={updateThirdPartyParameters}
                      defaultParams={defaultThirdPartyParameters}
                    />
                  )}
                </div>
              </Form>
            )}
          </Formik>
        </>
      )}
    </>
  );
}
