import { getBirthPlace, getMobilePhoneAndPrefix, paramsToMap } from "commons/FormUtils";
//import { Accordion } from "commons/components/Accordion";
import YogaLoader from "commons/components/Loader";
import YogaCard from "commons/components/YogaCard";
import { YogaMessage } from "commons/components/YogaMessage";
import { YogaScrollToFieldError } from "commons/components/YogaScrollToFieldError";
import { FormikInput } from "commons/formik/FormikInput";
import { FormikTabSwitch } from "commons/formik/FormikTabSwitch";
import { Geo } from "commons/models/Geo";
import { KeyValue } from "commons/models/YogaModels";
import { YogaParam, YogaParamValueType } from "commons/models/YogaParam";
import { partyService } from "commons/services/PartyService";
import { RoleType } from "contracts/enums/RoleType";
import { Contract } from "contracts/models/Contract";
import PartyFromAnotherNodeModal from "customers/components/PartyFromAnotherNodeModal";
import { PartyParametersForm } from "customers/forms/PartyParametersForm";
import { Party } from "customers/models/Party";
import { thirdPartyFormFields } from "customers/models/ThirdParty";
import { Field, getIn, useFormikContext } from "formik";
import { useEffect, useState } from "react";
import { FormattedMessage, useIntl } from "react-intl";
import { getDate, initialPartiesFromContract, initialPartyParametersFromContract, validateParameters } from "commons/formik/Utils";

export interface ThirdParty extends Party {
  presence: string;
  birthPlaceComplete?: Geo;
}

export enum ThirdPartyPresence {
  ABSENT = "absent",
  PRESENT = "present",
}

interface ThirdPartyFormProps {
  contract: Contract;
  policyholder: Party;
  mandatoryThirdParty: boolean;
  taxIdError: boolean;
  setTaxIdError: any;
  updatePartyParams: (partyId: string, newVals: KeyValue<YogaParam>) => Promise<YogaParam[]>;
  defaultParams: YogaParam[];
}

export default function ThirdPartyForm({
  contract,
  policyholder,
  mandatoryThirdParty,
  taxIdError,
  setTaxIdError,
  updatePartyParams,
  defaultParams,
}: ThirdPartyFormProps) {
  const intl = useIntl();
  const { setFieldTouched, setFieldValue, validateForm, values } = useFormikContext<ThirdParty>();

  //const [domicileOpen, setDomicileOpen] = useState<boolean>(initialValues.domicileIsNotResidence);

  const [updatePartyMessage, setUpdatePartyMessage] = useState(false);

  const [canRetrieve, setCanRetrieve] = useState(true);

  const [partyToRetrieve, setPartyToRetrieve] = useState(null);
  const [notVisibleNodeModal, setNotVisibleNodeModal] = useState(false);
  const [retrievedParty, setRetrievedParty] = useState<Party>();
  const [isRetrieving, setIsRetrieving] = useState(false);

  const [partiesById, setPartiesById] = useState<KeyValue<Party>>(initialPartiesFromContract(contract, RoleType.THIRD_PARTY));
  const [partyParams, setPartyParams] = useState<YogaParam[]>();
  const [partyParamsById, setPartyParamsById] = useState<KeyValue<YogaParam[]>>(
    initialPartyParametersFromContract(contract, RoleType.THIRD_PARTY, defaultParams)
  );

  useEffect(() => {
    // Sets default parameters if there is not a party
    if (retrievedParty == undefined) {
      setPartyParams(defaultParams);
      setFieldValue("parameters", paramsToMap(defaultParams), false);
      setUpdatePartyMessage(values.surnameOrCompanyName?.length > 0);
    }
  }, [retrievedParty, defaultParams]);

  async function retrieveParty(id: string) {
    if (isRetrieving) {
      return;
    }
    setIsRetrieving(true);
    await partyService
      .getPartyByTaxId(id, false)
      .then((result) => {
        const party = result.data;
        const notVisible = result.headers["x-not-visible-on-node"];
        if (notVisible === "true") {
          setPartyToRetrieve(party);
          setNotVisibleNodeModal(true);
        } else {
          confirmRetrievedParty(party);
        }
      })
      .catch(() => {
        emptyValues();
      })
      .finally(() => {
        setIsRetrieving(false);
      });
  }

  async function confirmRetrievedParty(party: Party) {
    if (values.taxId?.toUpperCase() === party.taxId.toUpperCase() && values.taxId !== party.taxId) {
      setCanRetrieve(false);
    }
    // It loads a party from the entity
    if (party.partyId in partiesById) {
      party = partiesById[party.partyId];
    }
    setPartiesById({ ...partiesById, [party.partyId]: party });

    let [number, numberPrefix] = getMobilePhoneAndPrefix(party.mobilePhoneNumber, party.mobilePhoneNumberPrefix);
    setFieldValue("taxId", party.taxId, false);
    setFieldValue("name", party.name, false);
    setFieldValue("surnameOrCompanyName", party.surnameOrCompanyName, false);
    setFieldValue("gender", party.gender, false);
    setFieldValue("birthDate", party.birthDate, false);

    const birthData = getBirthPlace(party);
    setFieldValue("birthCountry", birthData.birthCountry, false);
    setFieldValue("birthCountryCode", birthData.birthCountryCode, false);
    setFieldValue("birthPlace", birthData.birthPlace, false);
    setFieldValue("birthPlaceCode", birthData.birthPlaceCode, false);
    setFieldValue("birthCountyCode", birthData.birthCountyCode, false);
    setFieldValue("birthPlaceComplete", birthData.birthPlaceComplete, false);

    setFieldValue("email", party.email, false);
    setFieldValue("mobilePhoneNumber", number ? numberPrefix + number : "", false);
    setFieldValue("location", party.location || { label: "" }, false);

    setFieldValue("managementNodes", party.managementNodes, false);
    setFieldValue("partyId", party.partyId, false);
    setFieldValue("legacyData", party.legacyData, false);

    setFieldValue("iban", party.iban, false);
    setFieldValue("customerReference", party.customerReference, false);
    setFieldValue("questionnaireCode", party.questionnaireCode, false);
    setFieldValue("questionnaire", party.questionnaire, false);
    setFieldValue("tags", party.tags, false);
    setFieldValue("consents", party.consents, false);
    setFieldValue("lastConsentsUpdateInstant", party.lastConsentsUpdateInstant, false);
    setFieldValue("otpSignatureEnabled", party.otpSignatureEnabled, false);
    setFieldValue("linkedParties", party.linkedParties, false);
    setFieldValue("bankAccounts", party.bankAccounts ?? [], false);

    setFieldValue("domicileIsNotResidence", party.domicileIsNotResidence, false);
    setFieldValue(
      "domicile",
      !party.domicileIsNotResidence
        ? { label: "" }
        : party.domicile?.label !== party.location?.label && party.domicile?.label !== null
        ? party.domicile
        : { label: "" },
      false
    );
    //setDomicileOpen(party.domicileIsNotResidence);

    if (defaultParams?.length > 0) {
      let params: YogaParam[] = [];
      if (partyParamsById[party.partyId]) {
        params = partyParamsById[party.partyId];
      } else {
        params = await updatePartyParams(party.partyId, party.parameters);
        setPartyParamsById({ ...partyParamsById, [party.partyId]: params });
      }

      setFieldValue("parameters", paramsToMap(params), false);
      setPartyParams(params);
    }

    validateForm();
    setUpdatePartyMessage(!!party.surnameOrCompanyName);
    setRetrievedParty(party);
  }

  async function emptyValues() {
    setFieldValue("taxId", "", false);
    setFieldValue("name", "", false);
    setFieldValue("surnameOrCompanyName", "", false);
    setFieldValue("gender", "", false);
    setFieldValue("birthDate", undefined, false);
    setFieldValue("birthCountryCode", "", false);
    setFieldValue("birthCountry", "", false);
    setFieldValue("birthPlace", "", false);
    setFieldValue("birthPlaceComplete", undefined, false);
    setFieldValue("email", "", false);
    setFieldValue("mobilePhoneNumber", "", false);
    setFieldValue("location", { label: "" }, false);
    setFieldValue("managementNodes", [], false);
    setFieldValue("partyId", undefined, false);
    setFieldValue("legacyData", undefined, false);
    setFieldValue("iban", "", false);
    setFieldValue("customerReference", "", false);
    setFieldValue("questionnaireCode", "", false);
    setFieldValue("questionnaire", "", false);
    setFieldValue("tags", [], false);
    setFieldValue("consents", undefined, false);
    setFieldValue("lastConsentsUpdateInstant", undefined, false);
    setFieldValue("otpSignatureEnabled", false, false);
    setFieldValue("linkedParties", undefined, false);
    setFieldValue("bankAccounts", [], false);
    setFieldValue("domicileIsNotResidence", false, false);
    setFieldValue("domicile", { label: "" }, false);

    setFieldValue("parameters", paramsToMap(defaultParams), false);
    setPartyParams(defaultParams);

    setTaxIdError(false);
    setUpdatePartyMessage(false);
    //setDomicileOpen(false);
  }

  async function onPartialUpdate(values: KeyValue<YogaParamValueType>, updateOnChange: boolean) {
    if (updateOnChange) {
      let field = Object.keys(values).length ? Object.keys(values)[0] : "";
      if (field == "taxId" && !values.taxId) {
        emptyValues();
      }
    }
  }

  useEffect(() => {
    if (values.taxId?.length === 16) {
      if (values.taxId.toUpperCase() == policyholder.taxId.toUpperCase()) {
        setFieldTouched("taxId", true, true);
        return;
      }
      if (canRetrieve) {
        retrieveParty(values.taxId);
      } else {
        setCanRetrieve(true);
      }
    }
  }, [values.taxId]);

  // useEffect(() => {
  //   if (!value.domicileIsNotResidence) {
  //     setFieldValue("domicile", { label: null }, false);
  //   }
  // }, [value.domicileIsNotResidence]);

  const onUpdateThirdPartyParameters = async (values) => {
    if (defaultParams?.length > 0 && values?.partyId) {
      const newVals = getIn(values, "parameters");
      const updated = await updatePartyParams(retrievedParty.partyId, newVals);
      setPartyParamsById({ ...partyParamsById, [retrievedParty.partyId]: updated });
      setPartyParams(updated);
      setFieldValue("parameters", paramsToMap(updated), false);
    }
  };

  const validateThirdPartyParameters = (editedValues) => {
    if (values.presence === ThirdPartyPresence.PRESENT) return validateParameters(partyParams, editedValues, intl);
  };

  return (
    <YogaCard data-qa="third-party-form-card">
      <div className="flex flex-row items-center justify-between">
        <h4 className="text-title-text">
          <FormattedMessage id="thirdParty" />
        </h4>
        <Field
          name=""
          component={FormikTabSwitch}
          disabled={mandatoryThirdParty}
          content={{
            name: "presence",
            type: "TABSWITCH",
            mandatory: true,
            availableValues: [ThirdPartyPresence.ABSENT, ThirdPartyPresence.PRESENT],
          }}
        />
      </div>

      <YogaLoader loading={isRetrieving} />
      {values.presence == ThirdPartyPresence.PRESENT && (
        <div data-qa="messages-container" className="flex flex-col gap-y-4 pt-4">
          <YogaMessage type="info" position="inner" id="insertDataMessagePhysical">
            <p data-qa="insertDataMessagePhysical">
              <FormattedMessage id="insertDataMessagePhysical" />
            </p>
          </YogaMessage>
          {updatePartyMessage && (
            <YogaMessage type="warning" position="inner" id="third-party-updatePartyMessage">
              <p data-qa="updatePartyMessage">
                <FormattedMessage id="updatePartyMessage" />
              </p>
            </YogaMessage>
          )}
          {taxIdError && (
            <YogaMessage type="error" position="inner" id="third-party-taxIdInconsistent">
              <p data-qa="taxCodeInconsistent">
                <FormattedMessage id="taxCodeInconsistent" />
              </p>
            </YogaMessage>
          )}
        </div>
      )}
      <div className={values.presence === ThirdPartyPresence.ABSENT ? "hidden" : ""}>
        <div className="grid grid-cols-2 lg:grid-cols-3 gap-y-4 gap-x-8 items-start pt-4">
          {thirdPartyFormFields.map((formField) => (
            <Field
              key={`${formField.name}`}
              name={`${formField.name}`}
              disabled={
                (formField.name !== "taxId" && values.taxId?.length !== 16) ||
                isRetrieving == true ||
                formField.disabled ||
                (formField.name === "email" && retrievedParty?.profile) ||
                (formField.name !== "taxId" && values.taxId?.length == 16 && values.taxId?.toUpperCase() == policyholder.taxId.toUpperCase()) ||
                (formField.name === "taxId" && mandatoryThirdParty)
              }
              component={FormikInput}
              maxLength={formField.name === "taxId" ? 16 : undefined}
              hidden={
                (formField.name === "birthCountry" && values?.taxId?.charAt(11).toUpperCase() !== "Z") ||
                (formField.name === "birthPlace" && values?.taxId?.charAt(11).toUpperCase() === "Z")
              }
              content={getDate(
                {
                  ...formField,
                  name: `${formField.name}`,
                },
                values.birthDate
              )}
              noValidate={formField.name === "taxId"}
              onPartialUpdate={onPartialUpdate}
              fieldName={formField.name}
            />
          ))}
        </div>
        {/*<Accordion
          name="domicile-data"
          open={domicileOpen}
          className="flex flex-col gap-2 w-full pt-4"
          accordionTitle={
            <div className="inline-flex items-center w-full">
              <h4 className="text-title-text whitespace-nowrap">
                <FormattedMessage id="domicileData" />
              </h4>
              <span className="middle-border-accordion"></span>
            </div>
          }
          key="domicile-section"
        >*/}
        <div className="grid grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-4">
          <Field
            name="domicileIsNotResidence"
            component={FormikInput}
            label="domicileDataLabel"
            disabled={
              values.taxId?.length !== 16 ||
              isRetrieving == true ||
              (values.taxId?.length == 16 && values.taxId?.toUpperCase() == policyholder.taxId.toUpperCase())
            }
            content={{
              name: "domicileIsNotResidence",
              label: "domicileDataLabelPhysical",
              type: "BOOLEAN",
            }}
          />
          {values.domicileIsNotResidence && (
            <Field
              name="domicile"
              component={FormikInput}
              disabled={
                values.taxId?.length !== 16 ||
                isRetrieving == true ||
                (values.taxId?.length == 16 && values.taxId?.toUpperCase() == policyholder.taxId.toUpperCase())
              }
              content={{
                name: "domicile",
                type: "LOCATION",
                label: "domicile",
                className: "col-span-2",
              }}
            />
          )}
        </div>
        {/*</Accordion>*/}
        {partyParams && partyParams.length > 0 && (
          <div className="pt-4">
            <Field name="parameters" validate={validateThirdPartyParameters}>
              {(fieldProps) => (
                <PartyParametersForm
                  {...fieldProps}
                  disabled={values.taxId?.length !== 16 || values.taxId == policyholder.taxId}
                  partyParameters={partyParams}
                  updateParameters={onUpdateThirdPartyParameters}
                />
              )}
            </Field>
          </div>
        )}
      </div>
      <YogaScrollToFieldError />
      <PartyFromAnotherNodeModal
        isOpen={notVisibleNodeModal}
        onClose={() => {
          setFieldValue("taxId", "", false);
          setNotVisibleNodeModal(false);
        }}
        onConfirm={() => {
          confirmRetrievedParty(partyToRetrieve);
          setNotVisibleNodeModal(false);
        }}
        partyToRetrieve={partyToRetrieve}
        newManagementNodes={[contract?.managementNode]}
      />
    </YogaCard>
  );
}
