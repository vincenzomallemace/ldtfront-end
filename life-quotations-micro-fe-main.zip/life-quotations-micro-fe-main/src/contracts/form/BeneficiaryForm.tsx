import { Field, FieldProps, getIn } from "formik";

import { useEffect, useState } from "react";
import { FormikInput } from "commons/formik/FormikInput";
import AvailableBeneficiary from "commons/models/AvailableBeneficiary";
import { BeneficiaryFormPartyData } from "contracts/BeneficiariesPage";
import {
  beneficiaryLegalPartyDataFormParams,
  beneficiaryLegalUnverifiedPartyDataFormParams,
  beneficiaryNaturalPartyDataFormParams,
  beneficiaryNaturalUnverifiedPartyDataFormParams,
} from "customers/models/Beneficiaries";
import { FormikCodeAndDescriptionSelect } from "commons/formik/FormikCodeAndDescriptionSelect";
import classNames from "classnames";
import { YogaMessage } from "commons/components/YogaMessage";
import { FormattedMessage, useIntl } from "react-intl";
import { isForeign, Party } from "customers/models/Party";
import YogaLoader from "commons/components/Loader";
import PartyFromAnotherNodeModal from "customers/components/PartyFromAnotherNodeModal";
import { Contract } from "contracts/models/Contract";
import { getBirthPlace, getMobilePhoneAndPrefix, paramsToMap } from "commons/FormUtils";
import { partyService } from "commons/services/PartyService";
import { KeyValue } from "commons/models/YogaModels";
import { YogaParam, YogaParamValueType } from "commons/models/YogaParam";
import { RoleType } from "contracts/enums/RoleType";
import { PartyParametersForm } from "customers/forms/PartyParametersForm";
import { getDate, initialPartisFromBeneficiaries, initialPartyParametersFromBeneficiaries, validateParameters } from "commons/formik/Utils";
// import { Accordion } from "commons/components/Accordion";

interface BeneficiaryFormProps extends FieldProps<BeneficiaryFormPartyData> {
  beneficiary: AvailableBeneficiary;
  contract: Contract;
  taxIdChecks?: string[];
  setTaxIdChecks?: (value: string[]) => any;
  updatePartyParams: (partyId: string, newVals: KeyValue<YogaParam>) => Promise<YogaParam[]>;
  defaultParams: YogaParam[];
}

const BeneficiaryForm = ({
  beneficiary,
  contract,
  taxIdChecks,
  setTaxIdChecks,
  field: { name, value },
  form,
  updatePartyParams,
  defaultParams,
}: BeneficiaryFormProps) => {
  const [prevLegalEntity, setPrevLegalEntity] = useState<string>(value.legalEntity);
  const intl = useIntl();

  //const [domicileOpen, setDomicileOpen] = useState(false);
  const [canRetrieve, setCanRetrieve] = useState(true);
  const [updatePartyMessage, setUpdatePartyMessage] = useState(false);
  const [partyToRetrieve, setPartyToRetrieve] = useState(null);
  const [notVisibleNodeModal, setNotVisibleNodeModal] = useState(false);
  const [retrievedParty, setRetrievedParty] = useState<Party>();
  const [isRetrieving, setIsRetrieving] = useState(false);

  const [partiesById, setPartiesById] = useState<KeyValue<Party>>(initialPartisFromBeneficiaries(contract, RoleType.BENEFICIARY));
  const [partyParams, setPartyParams] = useState<YogaParam[]>();
  const [partyParamsById, setPartyParamsById] = useState<KeyValue<YogaParam[]>>(
    initialPartyParametersFromBeneficiaries(contract, RoleType.BENEFICIARY, defaultParams)
  );

  useEffect(() => {
    // Sets default parameters if there is not a party
    if (retrievedParty == undefined) {
      setPartyParams(defaultParams);
    }
  }, [retrievedParty, defaultParams]);

  // useEffect(() => {
  //   const birthPlaceComplete: Geo = getIn(
  //     form.values,
  //     `${name}.birthPlaceComplete`
  //   );
  //   if (birthPlaceComplete) {
  //     value.foreign = false;
  //     value.birthCountry = "ITALIA";
  //     value.birthCountryCode = "ITA";
  //     value.birthCountyCode = birthPlaceComplete.countyCode;
  //     value.birthPlaceCode = birthPlaceComplete.istatCode;
  //   }
  // }, [value.birthPlace]);

  useEffect(() => {
    setPrevLegalEntity(value.legalEntity);

    if (value.legalEntity == "legal" && prevLegalEntity == "physical") {
      //reset beneficiary data for physical person in case of legal entity
      value.taxId = "";
      value.name = "";
      value.surnameOrCompanyName = "";
      value.foreign = false;
      value.birthCountry = "";
      value.birthCountryCode = "";
      value.birthCountyCode = "";
      value.birthPlace = "";
      value.birthPlaceCode = "";
      value.birthDate = undefined;
      value.parentalRelationship = null;
    } else if (value.legalEntity == "physical" && prevLegalEntity == "legal") {
      value.vatNumber = "";
      value.taxId = "";
      value.surnameOrCompanyName = "";
      value.parentalRelationship = null;
    }
  }, [value.legalEntity]);

  useEffect(() => {
    if (value.taxId && value.taxId.length === 16 && value.legalEntity === "physical") {
      form.setFieldTouched(`${name}.taxId`, true);
      form.validateForm().then((errors) => {
        if (!getIn(errors, `${name}.taxId`)) {
          if (canRetrieve) {
            retrieveParty(value?.taxId, false);
          } else {
            setCanRetrieve(true);
          }
        }
      });
    }
  }, [value?.taxId]);

  useEffect(() => {
    if (value?.vatNumber && value?.vatNumber?.length === 11 && value.legalEntity === "legal") {
      form.setFieldTouched(`${name}.vatNumber`, true);
      form.validateForm().then((errors) => {
        if (!getIn(errors, `${name}.vatNumber`)) {
          if (canRetrieve) {
            retrieveParty(value?.vatNumber, true);
          } else {
            setCanRetrieve(true);
          }
        }
      });
    }
  }, [value?.vatNumber]);

  useEffect(() => {
    if (
      value?.vatNumber &&
      value?.vatNumber?.length === 11 &&
      value?.companyType !== "" &&
      value?.companyType !== "Ditta Individuale" &&
      value?.companyType !== "Impresa familiare" &&
      value?.taxId === "" &&
      form.dirty
    ) {
      value.taxId = value?.vatNumber;
    }
  }, [value?.vatNumber, value?.companyType]);

  useEffect(() => {
    if (value.unverified) {
      setUpdatePartyMessage(false);
      value.domicileIsNotResidence = false;
      value.domicile = { label: "" };
    }
  }, [value.unverified]);

  async function confirmRetrievedParty(party: Party) {
    value.unverified = false;
    if (value.taxId.toUpperCase() === party.taxId.toUpperCase() && value.taxId !== party.taxId) {
      setCanRetrieve(false);
    }
    // It loads a party from the entity
    if (party.partyId in partiesById) {
      party = partiesById[party.partyId];
    }
    setPartiesById({ ...partiesById, [party.partyId]: party });

    let [number, numberPrefix] = getMobilePhoneAndPrefix(party.mobilePhoneNumber, party.mobilePhoneNumberPrefix);
    value.taxId = party.taxId;
    value.name = party.name;
    value.surnameOrCompanyName = party.surnameOrCompanyName;
    value.gender = party.gender;
    value.birthDate = party.birthDate;
    value.foreign = isForeign(party);

    const birthData = getBirthPlace(party);
    value.birthCountry = birthData.birthCountry;
    value.birthCountryCode = birthData.birthCountryCode;
    value.birthPlace = birthData.birthPlace;
    value.birthPlaceCode = birthData.birthPlaceCode;
    value.birthCountyCode = birthData.birthCountyCode;
    value.birthPlaceComplete = birthData.birthPlaceComplete;

    value.email = party.email || "";
    value.mobilePhoneNumber = number ? numberPrefix + number : "";
    value.location = party.location ?? { label: "", countryCode: "" };

    value.managementNodes = party.managementNodes;
    value.partyId = party.partyId;

    value.legacyData = party.legacyData;

    value.iban = party.iban ?? "";

    value.companyType = party.companyType ?? "";
    value.vatNumber = party.vatNumber ?? "";
    value.atecoCode = party.atecoCode ?? "";
    value.employeesNumber = party.employeesNumber;
    value.revenue = party.revenue;

    value.domicileIsNotResidence = party.domicileIsNotResidence;
    value.domicile = !party.domicileIsNotResidence
      ? { label: "" }
      : party.domicile?.label !== party.location?.label && party.domicile?.label !== null
      ? party.domicile
      : { label: "" };

    if (defaultParams?.length > 0) {
      let params: YogaParam[];
      if (partyParamsById[party.partyId]) {
        params = partyParamsById[party.partyId];
      } else {
        params = await updatePartyParams(party.partyId, party.parameters);
        setPartyParamsById({ ...partyParamsById, [party.partyId]: params });
      }

      Object.assign(value.parameters, paramsToMap(params));
      setPartyParams(params);
    }

    form.validateForm();
    setUpdatePartyMessage(!!party.surnameOrCompanyName);
    //setDomicileOpen(party.domicileIsNotResidence);
    setRetrievedParty(party);
  }

  function onPartialUpdate(values: KeyValue<YogaParamValueType>, updateOnChange: boolean) {
    if (updateOnChange) {
      let field = Object.keys(values).length ? Object.keys(values)[0] : "";
      if (
        (field == `${name}.taxId` && !value?.taxId && value.legalEntity == "physical") ||
        (field == `${name}.vatNumber` && !value?.vatNumber && value.legalEntity === "legal")
      ) {
        emptyFieldValue();

        if (taxIdChecks?.includes(name)) {
          let newTaxIdChecks: string[] = [...taxIdChecks];
          newTaxIdChecks.splice(newTaxIdChecks.indexOf(name), 1);
          setTaxIdChecks(newTaxIdChecks);
        }
        setUpdatePartyMessage(false);
      }
    }
  }

  async function retrieveParty(id: string, legalEntity: boolean) {
    if (isRetrieving) {
      return;
    }
    setIsRetrieving(true);
    try {
      let result;
      if (legalEntity) {
        result = await partyService.getPartyByVatNumber(id);
      } else {
        result = await partyService.getPartyByTaxId(id, false);
      }
      const party = result.data;
      const notVisible = result.headers["x-not-visible-on-node"];
      if (notVisible === "true") {
        setPartyToRetrieve(party);
        setNotVisibleNodeModal(true);
      } else {
        confirmRetrievedParty(party);
      }
    } catch {
      if (legalEntity) value.vatNumber = id;
      else value.taxId = id;
      emptyFieldValue();
      setUpdatePartyMessage(false);
    } finally {
      setIsRetrieving(false);
    }
  }

  const emptyFieldValue = async () => {
    value.taxId = "";
    value.name = "";
    value.surnameOrCompanyName = "";
    value.birthDate = undefined;
    value.birthCountryCode = "";
    value.birthCountry = "";
    value.birthPlace = "";
    value.gender = "";
    value.email = "";
    value.mobilePhoneNumber = "";
    value.location = { label: "", countryCode: "ITA" };
    value.managementNodes = null;
    value.partyId = value.taxId;
    value.legacyData = null;
    value.iban = "";
    value.unverified = false;
    value.companyType = "";
    value.atecoCode = "";
    value.employeesNumber = undefined;
    value.revenue = undefined;
    value.foreign = false;
    value.parentalRelationship = null;
    value.domicileIsNotResidence = false;
    value.domicile = { label: "" };

    Object.assign(value.parameters, paramsToMap(defaultParams));
    setPartyParams(defaultParams);
  };

  const validateBeneficiaryParameters = (editedValues) => {
    return validateParameters(partyParams, editedValues, intl);
  };

  const onUpdateBeneficiaryParameters = async (values) => {
    const partyId = retrievedParty?.partyId;
    if (defaultParams?.length > 0 && partyId) {
      const newVals = getIn(values, `${name}.parameters`);
      const helpers = form.getFieldHelpers(`${name}.parameters`);
      const updated = await updatePartyParams(partyId, newVals);
      setPartyParamsById({ ...partyParamsById, [partyId]: updated });
      setPartyParams(updated);
      helpers.setValue(paramsToMap(updated), false);
    }
  };

  useEffect(() => {
    if (!value.domicileIsNotResidence) {
      form.setFieldValue(`${name}.domicile`, { label: "" }, false);
    }
  }, [value.domicileIsNotResidence]);

  const fieldDisabled =
    (!value.unverified &&
      ((value.legalEntity === "physical" && value.taxId?.length !== 16) || (value.legalEntity === "legal" && value.vatNumber?.length !== 11))) ||
    isRetrieving == true;

  return (
    <>
      <YogaLoader loading={isRetrieving} />
      {!value.unverified && (
        <div data-qa="messages-container" className="flex flex-col gap-y-4 px-4 pt-4">
          <YogaMessage type="info" position="inner" id="insertDataMessage">
            <p data-qa="insertDataMessage">
              <FormattedMessage id="insertDataMessage" />
            </p>
          </YogaMessage>

          {updatePartyMessage && (
            <YogaMessage type="warning" position="inner" id={`${name}-updatePartyMessage`}>
              <p data-qa="updatePartyMessage">
                <FormattedMessage id="updatePartyMessage" />
              </p>
            </YogaMessage>
          )}

          {taxIdChecks?.includes(name) && (
            <YogaMessage type="error" position="inner" id={`${name}-taxIdInconsistent`}>
              <p data-qa="taxCodeInconsistent">
                <FormattedMessage id="taxCodeInconsistent" />
              </p>
            </YogaMessage>
          )}
        </div>
      )}
      <div className="grid grid-cols-2 lg:grid-cols-3 gap-y-4 gap-x-8 items-start p-4">
        {/*<div>
          <Field
            key={`${name}.legalEntity`}
            name={`${name}.legalEntity`}
            component={FormikInput}
            label="partyType"
            content={{
              name: `${name}.legalEntity`,
              label: "partyType",
              availableValues: ["physical", "legal"],
              type: "LIST",
            }}
          />
        </div>*/}

        {value.unverified ? (
          <>
            {value.legalEntity === "legal" ? (
              <>
                {beneficiaryLegalUnverifiedPartyDataFormParams.map((formParam) => (
                  <div key={`${name}.${formParam.name}`} className={formParam.className}>
                    <Field
                      key={`${name}.${formParam.name}`}
                      name={formParam.name === "birthPlace" ? name : `${name}.${formParam.name}`}
                      component={FormikInput}
                      content={{
                        ...formParam,
                        name: `${name}.${formParam.name}`,
                      }}
                    />
                  </div>
                ))}
              </>
            ) : (
              <>
                {beneficiaryNaturalUnverifiedPartyDataFormParams.map((formParam) => (
                  <div key={`${name}.${formParam.name}`} className={formParam.className}>
                    <Field
                      key={`${name}.${formParam.name}`}
                      name={formParam.name === "birthPlace" ? name : `${name}.${formParam.name}`}
                      component={FormikInput}
                      content={getDate(
                        {
                          ...formParam,
                          name: `${name}.${formParam.name}`,
                        },
                        value?.birthDate
                      )}
                    />
                  </div>
                ))}
              </>
            )}
          </>
        ) : (
          <>
            {value.legalEntity === "legal" ? (
              <>
                {beneficiaryLegalPartyDataFormParams.map((formParam) => (
                  <div key={`${name}.${formParam.name}`} className={formParam.className}>
                    <Field
                      key={`${name}.${formParam.name}`}
                      name={formParam.name === "birthPlace" ? name : `${name}.${formParam.name}`}
                      disabled={
                        (formParam.name !== "vatNumber" && formParam.name !== "legalEntity" && value?.vatNumber?.length !== 11) ||
                        isRetrieving == true ||
                        formParam.disabled ||
                        (formParam.name === "email" && retrievedParty?.profile)
                      }
                      maxLength={
                        formParam.name === "vatNumber" ||
                        (formParam.name === "taxId" && value.companyType !== "Ditta Individuale" && value.companyType !== "Impresa familiare")
                          ? 11
                          : formParam.name === "taxId"
                          ? 16
                          : undefined
                      }
                      currency={value.revenue?.currency || "EUR"}
                      component={FormikInput}
                      content={{
                        ...formParam,
                        name: `${name}.${formParam.name}`,
                      }}
                      onPartialUpdate={onPartialUpdate}
                      fieldName={formParam.name === "birthPlace" ? name : `${name}.${formParam.name}`}
                    />
                  </div>
                ))}
              </>
            ) : (
              <>
                {beneficiaryNaturalPartyDataFormParams.map((formParam) => (
                  <div key={`${name}.${formParam.name}`} className={formParam.className}>
                    <Field
                      key={`${name}.${formParam.name}`}
                      name={formParam.name === "birthPlace" ? name : `${name}.${formParam.name}`}
                      hidden={
                        (formParam.name === "birthCountry" && value?.taxId?.charAt(11).toUpperCase() !== "Z") ||
                        (formParam.name === "birthPlace" && value?.taxId?.charAt(11).toUpperCase() === "Z")
                      }
                      disabled={
                        (formParam.name !== "taxId" && formParam.name !== "legalEntity" && value?.taxId?.length !== 16) ||
                        isRetrieving == true ||
                        formParam.disabled ||
                        (formParam.name === "email" && retrievedParty?.profile)
                      }
                      maxLength={formParam.name === "taxId" ? 16 : undefined}
                      component={FormikInput}
                      content={getDate(
                        {
                          ...formParam,
                          name: `${name}.${formParam.name}`,
                        },
                        value?.birthDate
                      )}
                      onPartialUpdate={onPartialUpdate}
                      fieldName={formParam.name === "birthPlace" ? name : `${name}.${formParam.name}`}
                      foreignIsVisible={false}
                    />
                  </div>
                ))}
              </>
            )}
          </>
        )}

        {/*<div
          className={classNames(
            "order-last",
            value.legalEntity === "physical" &&
            value.unverified &&
            "col-span-2 lg:col-span-1 pt-0.5"
          )}
        >
          <Field
            key={`${name}.parentalRelationship`}
            name={`${name}.parentalRelationship`}
            component={FormikCodeAndDescriptionSelect}
            label="parentalRelationship"
            options={beneficiary.availableParentalRelationships}
            disabled={
              !value.unverified &&
              ((value.legalEntity === "physical" && value?.taxId?.length !== 16) ||
                (value.legalEntity === "legal" && value?.vatNumber?.length !== 11) ||
                isRetrieving == true)
            }
            hidden={!beneficiary.availableParentalRelationships || beneficiary.availableParentalRelationships.length == 0}
          />
        </div>
      </div>*/}

        {!value.unverified && (
          /*<Accordion
            name={`${name}-domicileData`}
            open={domicileOpen}
            className="flex flex-col gap-2 w-full px-4"
            accordionTitle={
              <div className="inline-flex items-center w-full">
                <h4 className="text-title-text whitespace-nowrap">
                  <FormattedMessage id="domicileData" />
                </h4>
                <span className="middle-border-accordion"></span>
              </div>
            }
            key="domicile-section"
          >*/
          <>
            <div className="order-last">
              <Field
                name={`${name}.domicileIsNotResidence`}
                component={FormikInput}
                label="domicileDataLabel"
                disabled={
                  (!value.unverified &&
                    ((value.legalEntity === "physical" && value?.taxId?.length !== 16) ||
                      (value.legalEntity === "legal" && value?.vatNumber?.length !== 11))) ||
                  isRetrieving == true
                }
                content={{
                  name: `${name}.domicileIsNotResidence`,
                  label: value.legalEntity == "legal" ? "domicileDataLabelLegal" : "domicileDataLabelPhysical",
                  type: "BOOLEAN",
                }}
              />
            </div>
            {value.domicileIsNotResidence && (
              <div className="order-last col-span-2">
                <Field
                  name={`${name}.domicile`}
                  component={FormikInput}
                  disabled={
                    (!value.unverified &&
                      ((value.legalEntity === "physical" && value?.taxId?.length !== 16) ||
                        (value.legalEntity === "legal" && value?.vatNumber?.length !== 11))) ||
                    isRetrieving == true
                  }
                  content={{
                    name: `${name}.domicile`,
                    type: "LOCATION",
                    label: "domicile",
                  }}
                />
              </div>
            )}
          </>
          /*</Accordion>*/
        )}

        <div className={classNames("order-last", value.legalEntity === "physical" && value.unverified && "col-span-2 lg:col-span-1 pt-0.5")}>
          <Field
            key={`${name}.parentalRelationship`}
            name={`${name}.parentalRelationship`}
            component={FormikCodeAndDescriptionSelect}
            label="parentalRelationship"
            options={beneficiary.availableParentalRelationships}
            disabled={
              !value.unverified &&
              ((value.legalEntity === "physical" && value?.taxId?.length !== 16) ||
                (value.legalEntity === "legal" && value?.vatNumber?.length !== 11) ||
                isRetrieving == true)
            }
            hidden={!beneficiary.availableParentalRelationships || beneficiary.availableParentalRelationships.length == 0}
          />
        </div>
      </div>
      {!value.unverified && partyParams && partyParams.length > 0 && (
        <Field name={`${name}.parameters`} validate={validateBeneficiaryParameters}>
          {(fieldProps) => (
            <PartyParametersForm
              {...fieldProps}
              partyParameters={partyParams}
              updateParameters={onUpdateBeneficiaryParameters}
              disabled={fieldDisabled}
              className="mt-2 px-4 mb-4"
            />
          )}
        </Field>
      )}

      <PartyFromAnotherNodeModal
        isOpen={notVisibleNodeModal}
        onClose={() => {
          value.taxId = "";
          setNotVisibleNodeModal(false);
        }}
        onConfirm={() => {
          confirmRetrievedParty(partyToRetrieve);
          setNotVisibleNodeModal(false);
        }}
        partyToRetrieve={partyToRetrieve}
        newManagementNodes={[contract?.managementNode]}
      />
    </>
  );
};

export default BeneficiaryForm;
