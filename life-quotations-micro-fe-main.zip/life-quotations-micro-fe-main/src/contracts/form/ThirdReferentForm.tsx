import { getBirthPlace, getMobilePhoneAndPrefix, paramsToMap } from "commons/FormUtils";
//import { Accordion } from "commons/components/Accordion";
import YogaLoader from "commons/components/Loader";
import { YogaMessage } from "commons/components/YogaMessage";
import { FormikInput } from "commons/formik/FormikInput";
import { KeyValue } from "commons/models/YogaModels";
import { YogaParam, YogaParamValueType } from "commons/models/YogaParam";
import { partyService } from "commons/services/PartyService";
import { RoleType } from "contracts/enums/RoleType";
import { Contract } from "contracts/models/Contract";
import PartyFromAnotherNodeModal from "customers/components/PartyFromAnotherNodeModal";
import { PartyParametersForm } from "customers/forms/PartyParametersForm";
import { ThirdReferentData, thirdReferentFormParams, unverifiedThirdReferentFormParams } from "customers/models/Beneficiaries";
import { Party, isForeign } from "customers/models/Party";
import { Field, FieldProps, getIn } from "formik";
import { useEffect, useState } from "react";
import { FormattedMessage, useIntl } from "react-intl";
import { getDate, initialPartisFromBeneficiaries, initialPartyParametersFromBeneficiaries, validateParameters } from "commons/formik/Utils";

interface ThirdReferentProps extends FieldProps<ThirdReferentData> {
  taxIdChecks?: string[];
  setTaxIdChecks?: (value: string[]) => any;
  contract: Contract;
  updatePartyParams: (partyId: string, newVals: KeyValue<YogaParam>) => Promise<YogaParam[]>;
  defaultParams: YogaParam[];
}

const ThirdReferentForm = ({
  field: { name, value },
  form,
  taxIdChecks,
  setTaxIdChecks,
  contract,
  updatePartyParams,
  defaultParams,
}: ThirdReferentProps) => {
  const intl = useIntl();
  const [canRetrieve, setCanRetrieve] = useState(true);
  const [updatePartyMessage, setUpdatePartyMessage] = useState(false);
  const [partyToRetrieve, setPartyToRetrieve] = useState(null);
  const [notVisibleNodeModal, setNotVisibleNodeModal] = useState(false);
  const [retrievedParty, setRetrievedParty] = useState<Party>();
  const [isRetrieving, setIsRetrieving] = useState(false);
  //const [domicileOpen, setDomicileOpen] = useState(false);

  const [partiesById, setPartiesById] = useState<KeyValue<Party>>(initialPartisFromBeneficiaries(contract, RoleType.THIRD_REFERENT));
  const [partyParams, setPartyParams] = useState<YogaParam[]>();
  const [partyParamsById, setPartyParamsById] = useState<KeyValue<YogaParam[]>>(
    initialPartyParametersFromBeneficiaries(contract, RoleType.THIRD_REFERENT, defaultParams)
  );

  useEffect(() => {
    if (value.unverified) {
      setUpdatePartyMessage(false);
    }
  }, [value.unverified]);

  useEffect(() => {
    // Sets default parameters if there is not a party
    if (retrievedParty == undefined) {
      setPartyParams(defaultParams);
    }
  }, [retrievedParty, defaultParams]);

  const validateThirdReferentParameters = (editedValues) => {
    return validateParameters(partyParams, editedValues, intl);
  };

  const onUpdateThirdReferentParameters = async (values) => {
    const partyId = retrievedParty?.partyId;
    if (defaultParams?.length > 0 && partyId) {
      const newVals = getIn(values, `${name}.parameters`);
      const helpers = form.getFieldHelpers(`${name}.parameters`);
      const updated = await updatePartyParams(partyId, newVals);
      setPartyParamsById({ ...partyParamsById, [partyId]: updated });
      setPartyParams(updated);
      helpers.setValue(paramsToMap(updated), false);
    }
  };

  async function retrieveParty(id: string) {
    if (isRetrieving) {
      return;
    }
    setIsRetrieving(true);
    await partyService
      .getPartyByTaxId(id, false)
      .then((result) => {
        const party = result.data;
        const notVisible = result.headers["x-not-visible-on-node"];
        if (notVisible === "true") {
          setPartyToRetrieve(party);
          setNotVisibleNodeModal(true);
        } else {
          confirmRetrievedParty(party);
        }
      })
      .catch(() => {
        emptyFieldValue();
        setUpdatePartyMessage(false);
      })
      .finally(() => {
        setIsRetrieving(false);
      });
  }

  async function confirmRetrievedParty(party: Party) {
    if (value.taxId.toUpperCase() === party.taxId.toUpperCase() && value.taxId !== party.taxId) {
      setCanRetrieve(false);
    }
    // It loads a party from the entity
    if (party.partyId in partiesById) {
      party = partiesById[party.partyId];
    }
    setPartiesById({ ...partiesById, [party.partyId]: party });

    let [number, numberPrefix] = getMobilePhoneAndPrefix(party.mobilePhoneNumber, party.mobilePhoneNumberPrefix);
    value.taxId = party.taxId;
    value.name = party.name;
    value.surnameOrCompanyName = party.surnameOrCompanyName;
    value.gender = party.gender;
    value.birthDate = party.birthDate;
    value.foreign = isForeign(party);

    const birthData = getBirthPlace(party);
    value.birthCountry = birthData.birthCountry;
    value.birthCountryCode = birthData.birthCountryCode;
    value.birthPlace = birthData.birthPlace;
    value.birthPlaceCode = birthData.birthPlaceCode;
    value.birthCountyCode = birthData.birthCountyCode;
    value.birthPlaceComplete = birthData.birthPlaceComplete;

    value.email = party.email || "";
    value.mobilePhoneNumber = number ? numberPrefix + number : "";
    value.location = party.location || { label: "", countryCode: "" };

    value.managementNodes = party.managementNodes;
    value.partyId = party.partyId;

    value.legacyData = party.legacyData;

    value.iban = party.iban ?? "";
    value.unverified = false;

    value.contactAddress = (party as ThirdReferentData).contactAddress ?? { label: "", countryCode: "" };
    value.domicileIsNotResidence = party.domicileIsNotResidence;
    /*if (party.domicileIsNotResidence) {
      setDomicileOpen(true);
    }*/

    if (defaultParams?.length > 0) {
      let params: YogaParam[];
      if (partyParamsById[party.partyId]) {
        params = partyParamsById[party.partyId];
      } else {
        params = await updatePartyParams(party.partyId, party.parameters);
        setPartyParamsById({ ...partyParamsById, [party.partyId]: params });
      }

      Object.assign(value.parameters, paramsToMap(params));
      setPartyParams(params);
    }

    form.validateForm();
    setUpdatePartyMessage(!!party.surnameOrCompanyName);
    setRetrievedParty(party);
  }

  function onPartialUpdate(values: KeyValue<YogaParamValueType>, updateOnChange: boolean) {
    if (updateOnChange) {
      let field = Object.keys(values).length ? Object.keys(values)[0] : "";
      if (field === "taxId" && !values[field]) {
        emptyFieldValue();
        if (taxIdChecks?.includes(name)) {
          let newTaxIdChecks: string[] = [...taxIdChecks];
          newTaxIdChecks.splice(newTaxIdChecks.indexOf(name), 1);
          setTaxIdChecks(newTaxIdChecks);
        }
        setUpdatePartyMessage(false);
      }
    }
  }

  const emptyFieldValue = async () => {
    value.taxId = "";
    value.name = "";
    value.surnameOrCompanyName = "";
    value.birthDate = undefined;
    value.birthCountryCode = "";
    value.birthCountry = "";
    value.birthCountyCode = "";
    value.birthPlace = "";
    value.gender = "";
    value.email = "";
    value.mobilePhoneNumber = "";
    value.location = { label: "" };
    value.managementNodes = null;
    value.partyId = value.taxId;
    value.legacyData = null;
    value.iban = "";
    value.unverified = false;
    value.foreign = false;
    value.domicileIsNotResidence = false;
    value.contactAddress = { label: "" };

    const paramsMap = paramsToMap(defaultParams);

    // TODO Check whether direct assignment is possible and if so, remove the assignment
    if (value.parameters == undefined) value.parameters = paramsMap;
    else Object.assign(value.parameters, paramsMap);

    setPartyParams(defaultParams);
  };

  // useEffect(() => {
  //   const birthPlaceComplete: Geo = getIn(
  //     form.values,
  //     `${name}.birthPlaceComplete`
  //   );
  //   if (birthPlaceComplete) {
  //     value.birthCountry = "ITALIA";
  //     value.birthCountryCode = "ITA";
  //     value.birthCountyCode = birthPlaceComplete.countyCode;
  //     value.birthPlaceCode = birthPlaceComplete.istatCode;
  //     value.foreign = false;
  //   }
  // }, [value.birthPlace]);

  useEffect(() => {
    if (value.taxId?.length === 16) {
      form.setFieldTouched(`${name}.taxId`, true);
      form.validateForm().then((errors) => {
        if (!getIn(errors, `${name}.taxId`)) {
          if (canRetrieve) {
            retrieveParty(value?.taxId);
          } else {
            setCanRetrieve(true);
          }
        }
      });
    }
  }, [value?.taxId]);

  const disabledParameters = (!value.unverified && value.taxId?.length !== 16) || isRetrieving == true;

  return (
    <>
      <YogaLoader loading={isRetrieving} />
      {!value.unverified && (
        <div data-qa="messages-container" className="flex flex-col gap-y-4 px-4 pt-4">
          <YogaMessage type="info" position="inner" id="insertDataMessagePhysical">
            <p data-qa="insertDataMessagePhysical">
              <FormattedMessage id="insertDataMessagePhysical" />
            </p>
          </YogaMessage>

          {updatePartyMessage && (
            <YogaMessage type="warning" position="inner" id={`${name}-updatePartyMessage`}>
              <p data-qa="updatePartyMessage">
                <FormattedMessage id="updatePartyMessage" />
              </p>
            </YogaMessage>
          )}

          {taxIdChecks?.includes(name) && (
            <YogaMessage type="error" position="inner" id={`${name}-taxIdInconsistent`}>
              <p data-qa="taxCodeInconsistent">
                <FormattedMessage id="taxCodeInconsistent" />
              </p>
            </YogaMessage>
          )}
        </div>
      )}
      {value.unverified ? (
        <div className="grid grid-cols-2 lg:grid-cols-3 gap-y-4 gap-x-8 items-start p-4">
          {unverifiedThirdReferentFormParams.map((formParam) => (
            <div key={`${name}.${formParam.name}`} className={formParam.className}>
              <Field
                key={`${name}.${formParam.name}`}
                name={formParam.name === "birthPlace" ? name : `${name}.${formParam.name}`}
                component={FormikInput}
                content={{
                  ...formParam,
                  name: `${name}.${formParam.name}`,
                }}
              />
            </div>
          ))}
        </div>
      ) : (
        <>
          <div className="grid grid-cols-2 lg:grid-cols-3 gap-y-4 gap-x-8 items-start p-4">
            {thirdReferentFormParams.map((formParam) => (
              <div key={`${name}.${formParam.name}`} className={formParam.className}>
                <Field
                  key={`${name}.${formParam.name}`}
                  name={formParam.name === "birthPlace" ? name : `${name}.${formParam.name}`}
                  disabled={
                    (formParam.name !== "taxId" && value?.taxId?.length !== 16) ||
                    isRetrieving == true ||
                    formParam.disabled ||
                    (formParam.name === "email" && retrievedParty?.profile)
                  }
                  component={FormikInput}
                  content={getDate(
                    {
                      ...formParam,
                      name: `${name}.${formParam.name}`,
                    },
                    value?.birthDate
                  )}
                  onPartialUpdate={onPartialUpdate}
                  fieldName={formParam.name}
                  foreignIsVisible={false}
                />
              </div>
            ))}
          </div>
          <div className="px-4 pb-4 w-full">
            {/*<Accordion
              name="domicile-data"
              open={domicileOpen}
              className="flex flex-col gap-2 w-full"
              titleContainerClasses=""
              accordionTitle={
                <div className="inline-flex items-center w-full">
                  <h4 className="text-title-text whitespace-nowrap">
                    <FormattedMessage id="domicileData" />
                  </h4>
                  <span className="middle-border-accordion"></span>
                </div>
              }
              key="domicile-section"
            >*/}
            <div className="grid grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-4">
              <div data-qa={`domicile-values-form`}>
                <Field
                  key={`${name}.domicileIsNotResidence`}
                  name={`${name}.domicileIsNotResidence`}
                  component={FormikInput}
                  label="domicileDataLabel"
                  content={{
                    name: `${name}.domicileIsNotResidence`,
                    label: "domicileDataLabelPhysical",
                    type: "BOOLEAN",
                  }}
                  disabled={value?.taxId?.length !== 16 || isRetrieving == true}
                />
              </div>
              {value.domicileIsNotResidence && (
                <div className="lg:col-span-2">
                  <Field
                    name={`${name}.contactAddress`}
                    key={`${name}.contactAddress`}
                    component={FormikInput}
                    disabled={value?.taxId?.length !== 16 || isRetrieving}
                    content={{
                      name: `${name}.contactAddress`,
                      type: "LOCATION",
                      label: "domicile",
                    }}
                  />
                </div>
              )}
            </div>
            {/*</Accordion>*/}
          </div>

          {partyParams && partyParams.length > 0 && (
            <Field name={`${name}.parameters`} validate={validateThirdReferentParameters}>
              {(fieldProps) => (
                <PartyParametersForm
                  {...fieldProps}
                  partyParameters={partyParams}
                  updateParameters={onUpdateThirdReferentParameters}
                  disabled={disabledParameters}
                  className="mt-2 px-4 pb-4"
                />
              )}
            </Field>
          )}
        </>
      )}
      <PartyFromAnotherNodeModal
        isOpen={notVisibleNodeModal}
        onClose={() => {
          value.taxId = "";
          setNotVisibleNodeModal(false);
        }}
        onConfirm={() => {
          confirmRetrievedParty(partyToRetrieve);
          setNotVisibleNodeModal(false);
        }}
        partyToRetrieve={partyToRetrieve}
        newManagementNodes={[contract?.managementNode]}
      />
    </>
  );
};

export default ThirdReferentForm;
