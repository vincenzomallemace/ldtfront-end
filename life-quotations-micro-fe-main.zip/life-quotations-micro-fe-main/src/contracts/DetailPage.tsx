import { Tab } from "@headlessui/react";
import { IdentificationIcon, UserIcon } from "@heroicons/react/outline";
import { SearchIcon } from "@heroicons/react/solid";
import classNames from "classnames";
import { EMPTY, groupKeyValueParamsByTag } from "commons/Utils";
import { Accordion } from "commons/components/Accordion";
import ParameterBox from "commons/components/ParameterBox";
import ParametersDetail from "commons/components/ParametersDetail";
import { CompleteParty, PartyBox, ThirdReferentInfo } from "commons/components/PartyBox";
import { QuestionnaireBox } from "commons/components/QuestionnaireBox";
import { StickyBar } from "commons/components/StickyBar";
import YogaCard from "commons/components/YogaCard";
import { YogaModal } from "commons/components/YogaModal";
import YogaSkeleton from "commons/components/YogaSkeleton";
import useContractDossier from "commons/hooks/useContractDossier";
import { questionnaireService } from "commons/services/QuestionnaireService";
import DocumentsDetail from "documents/components/DocumentsDetail";
import FundsTable from "offers/components/FundsTable";
import { PremiumDropDown } from "offers/components/PremiumDropDown";
import { QUESTIONNAIRE_TYPE, QuestionnaireModel } from "questionnaires/models/QuestionnaireModel";
import { useEffect, useMemo, useState } from "react";
import { FormattedDate, FormattedMessage, useIntl } from "react-intl";
import { useParams } from "react-router-dom";
import { RoleType } from "./enums/RoleType";
import useContract from "./hooks/useContract";
import ContractualOptionBox from "commons/components/ContractualOptionBox";
import { YogaChip } from "commons/components/YogaChip";
// import FormattedMoney from "commons/components/FormattedMoney";

export default function DetailPage() {
  const { contractId } = useParams();
  const { contract, policyholder } = useContract(contractId);

  const { dossier, dossierError, setStartPolling, documents, isPollingTerminated } = useContractDossier(contractId, true);

  useEffect(() => {
    setStartPolling(true);
  }, []);

  const intl = useIntl();

  const [trasitionOn, setTransitionOn] = useState<boolean>(false);
  const [otherDataVisible, setOtherDataVisible] = useState<boolean>(false);
  const [dueDiligenceQuestionnaire, setDueDiligenceQuestionnaire] = useState<QuestionnaireModel>();
  const [openThirdReferentDetailModal, setOpenThirdReferentDetailModal] = useState<boolean>(false);

  const unitLinked = useMemo(() => {
    if (contract) return Object.values(Object.values(contract.assets)[0].unitLinked)[0];
  }, [contract]);

  const investmentLine = useMemo(() => {
    if (unitLinked) return Object.values(unitLinked.investmentLines)[0];
  }, [unitLinked]);

  const technicalData = useMemo(() => {
    if (contract && Object.keys(contract.parameters)?.length > 0) return groupKeyValueParamsByTag(contract.parameters);
    else return undefined;
  }, [contract]);

  const contractualOptions = useMemo(() => {
    if (contract) {
      if (Object.keys(contract.contractualOptions)?.length > 0) return Object.values(contract.contractualOptions).filter((opt) => opt.visible);
    }
  }, [contract]);

  const insuredPerson = useMemo(() => {
    let party: CompleteParty;
    if (contract) {
      party = contract.assets["person_1"].parties[RoleType.INSURED_PERSON][0] as CompleteParty;
      if (party.taxId === policyholder.taxId) {
        party = policyholder as CompleteParty;
      }
    }
    return party;
  }, [contract]);

  useEffect(() => {
    const fetchData = async (questId: string) => {
      const result = await questionnaireService.get(questId);
      if (!result.data) {
        setDueDiligenceQuestionnaire(undefined);
      } else {
        setDueDiligenceQuestionnaire(result.data);
      }
    };
    if (contract && contract.questionnaires && QUESTIONNAIRE_TYPE.DUE_DILIGENCE in contract.questionnaires)
      fetchData(contract.questionnaires[QUESTIONNAIRE_TYPE.DUE_DILIGENCE]).catch(() => setDueDiligenceQuestionnaire(undefined));
  }, [contract]);

  useEffect(() => {
    if (contract) {
      setTimeout(() => {
        setTransitionOn(true);
      }, 300);
    }
  }, [contract]);

  return (
    <>
      {contract && policyholder && unitLinked ? (
        <>
          <StickyBar
            showStepper={false}
            breadcrumb={
              <div className="flex flex-col">
                <div data-qa="detail-page-title" className="truncate">
                  <FormattedMessage
                    id="proposalNumber"
                    values={{
                      number: (contract.managementNode ? contract.managementNode.code + "/" : "") + contract.policyNumber,
                    }}
                  />
                </div>
                <div className="flex flex-row gap-x-4 items-center text-base font-normal truncate">
                  <span data-qa="policyholder-title">
                    {policyholder?.surnameOrCompanyName}&nbsp;
                    {policyholder?.name}
                  </span>
                  <span data-qa="contract-product-name">{contract.contractProductName}</span>
                </div>
              </div>
            }
          />
          <div className="px-3">
            <div className="flex flex-col mb-8">
              <YogaCard className="z-40">
                
                <div className="grid grid-cols-[1fr_max-content] items-center">
                  <div
                    data-qa="proposal-status-data-container"
                    className="flex flex-row gap-x-4 bg-body-text text-box-background rounded-lg py-1 px-4 col-span-2 hidden"
                  >
                    <div className="flex flex-col lg:flex-row lg:gap-2 items-start lg:items-center w-1/3" data-qa="issue-date">
                      <span data-qa="issue-date-label" className="hidden lg:block">
                        <FormattedMessage id="issueDate" />
                      </span>
                      <span data-qa="issue-date-label" className="lg:hidden">
                        <FormattedMessage id="issue" />
                      </span>
                      <span className="font-bold leading-[1.4rem]" data-qa="issue-date-value">
                        <FormattedDate value={contract.contractIssueInstant} year="numeric" month="2-digit" day="2-digit" />
                      </span>
                    </div>

                    <div className="flex flex-col lg:flex-row lg:gap-2 items-start lg:items-center w-1/3" data-qa="effective-date">
                      <span data-qa="effective-date-label" className="hidden lg:block">
                        <FormattedMessage id="effectiveDate" />
                      </span>
                      <span data-qa="effective-date-label" className="lg:hidden">
                        <FormattedMessage id="effect" />
                      </span>
                      <span className="font-bold leading-[1.4rem]" data-qa="effective-date-value">
                        <FormattedDate value={contract.contractEffectInstant} year="numeric" month="2-digit" day="2-digit" />
                      </span>
                    </div>

                    <div className="flex flex-col lg:flex-row lg:gap-2 items-start lg:items-center w-1/3" data-qa="investment-date">
                      <span data-qa="investment-date-label" className="hidden lg:block">
                        <FormattedMessage id="investmentDate" />
                      </span>
                      <span data-qa="investment-date-label" className="lg:hidden">
                        <FormattedMessage id="investment" />
                      </span>
                      <span className="font-bold leading-[1.4rem]" data-qa="investment-date-value">
                        <FormattedDate value={unitLinked.investmentInstant} year="numeric" month="2-digit" day="2-digit" />
                      </span>
                    </div>
                  </div>
                  <div
                    className="h-full px-4 py-1 bg-success border border-success text-white rounded-lg flex items-center relative overflow-hidden"
                    data-qa="proposal-status"
                  >
                    <div className="bubbles" />
                    <span data-qa="proposal-status-label">
                      <FormattedMessage id="COMPLETE_PROPOSAL" />
                    </span>
                  </div>
                </div>
               
                {/* <div className="flex flex-col-reverse lg:flex-row items-stretch gap-x-4 gap-y-4 h-full">
                  <div
                    data-qa="proposal-status-data-container"
                    className="flex flex-row bg-body-text text-box-background rounded-lg w-full lg:w-3/4 py-1 px-4"
                  >
                    <div className="flex flex-col items-start w-full" data-qa="issue-date">
                      <span data-qa="issue-date-label" className="hidden lg:block">
                        <FormattedMessage id="issueDate" />
                      </span>
                      <span data-qa="issue-date-label" className="lg:hidden">
                        <FormattedMessage id="issue" />
                      </span>
                      <span className="font-bold" data-qa="issue-date-value">
                        <FormattedDate value={contract.contractIssueInstant} year="numeric" month="2-digit" day="2-digit" />
                      </span>
                    </div>

                    <div className="flex flex-col items-start w-full" data-qa="effective-date">
                      <span data-qa="effective-date-label" className="hidden lg:block">
                        <FormattedMessage id="effectiveDate" />
                      </span>
                      <span data-qa="effective-date-label" className="lg:hidden">
                        <FormattedMessage id="effect" />
                      </span>
                      <span className="font-bold" data-qa="effective-date-value">
                        <FormattedDate value={contract.contractEffectInstant} year="numeric" month="2-digit" day="2-digit" />
                      </span>
                    </div>

                    <div className="flex flex-col items-start w-full" data-qa="investment-date">
                      <span data-qa="investment-date-label" className="hidden lg:block">
                        <FormattedMessage id="investmentDate" />
                      </span>
                      <span data-qa="investment-date-label" className="lg:hidden">
                        <FormattedMessage id="investment" />
                      </span>
                      <span className="font-bold" data-qa="investment-date-value">
                        <FormattedDate value={unitLinked.investmentInstant} year="numeric" month="2-digit" day="2-digit" />
                      </span>
                    </div>

                    <div className="flex flex-col items-end lg:items-start w-max lg:w-full" data-qa="total-premium">
                      <span data-qa="total-premium-label" className="w-max">
                        <FormattedMessage id="totalPremium" />
                      </span>
                      <span className="font-bold" data-qa="investment-date-value">
                        <FormattedMoney money={contract.assets["person_1"].premium.uniqueOrAnnual.gross} />
                      </span>
                    </div>
                  </div>
                  <div
                    className="px-4 py-1 bg-success text-white rounded-lg border border-success flex items-center relative overflow-hidden w-full lg:w-1/4"
                    data-qa="proposal-status"
                  >
                    <div className="bubbles" />
                    <span data-qa="proposal-status-label">
                      <FormattedMessage id="COMPLETE_PROPOSAL" />
                    </span>
                  </div>
                </div> */}
                <div data-qa="parties-container" className="grid grid-cols-1 lg:grid-cols-3 gap-4 mt-4">
                  <PartyBox party={contract.parties[RoleType.POLICYHOLDER][0] as CompleteParty} type={RoleType.POLICYHOLDER} border="background" />
                  <PartyBox party={insuredPerson} type={RoleType.INSURED_PERSON} border="background" />
                  {RoleType.THIRD_PARTY in contract.parties && (
                    <PartyBox party={contract.parties[RoleType.THIRD_PARTY][0] as CompleteParty} type={RoleType.THIRD_PARTY} border="background" />
                  )}
                </div>
              </YogaCard>
              <div
                className={classNames(
                  "z-30 flex flex-col ",
                  otherDataVisible ? "mt-4 px-0" : `-mt-[104px] px-4`,
                  trasitionOn ? "transition-all duration-300 ease-out" : ""
                )}
              >
                <YogaCard id="other-data-card" className={classNames("z-30 min-h-[104px]", otherDataVisible ? "shadow-lg" : "shadow-none")}>
                  {otherDataVisible && (technicalData || contract.agreement || dueDiligenceQuestionnaire) && (
                    <div data-qa="other-data-container">
                      <h4 data-qa="technical-data-label" className="leading-none">
                        <FormattedMessage id="technicalData" />
                      </h4>
                      {(technicalData || contract.agreement) && (
                        <div className="mt-2 bg-white text-body-text rounded-lg flex flex-col gap-y-4">
                          {/*<div className="grid grid-cols-2 lg:grid-cols-3 gap-4" data-qa="static-data-container">
                            <ParameterBox label="agreement" value={contract.agreement} />
                          </div>*/}
                          {technicalData &&
                            Object.entries(technicalData).map(([tag, params]) => (
                              <div key={`${tag}-section`} data-qa={`${tag}-section`}>
                                {tag !== "noTags" && (
                                  <h4 data-qa={`${tag}-label`} className="mb-2 leading-none">
                                    <FormattedMessage id={tag} />
                                  </h4>
                                )}
                                <div className="grid grid-cols-2 lg:grid-cols-3 gap-4" data-qa={`${tag}-params`}>
                                  {params.map((param: any) => (
                                    <ParameterBox
                                      key={param.key}
                                      label={param.key}
                                      value={param.value as any}
                                      type={param.type}
                                      currency={param.currency || "EUR"}
                                    />
                                  ))}
                                </div>
                              </div>
                            ))}
                        </div>
                      )}
                      {dueDiligenceQuestionnaire && (
                        <div data-qa="due-diligence-questionnaire" className="mt-4">
                          <h4 data-qa="due-diligence-questionaire-data-title" className="leading-none">
                            <FormattedMessage id="questionnaires" />
                          </h4>
                          <div className="grid grid-cols-2 lg:grid-cols-3 gap-4 mt-2">
                            <QuestionnaireBox questionnaire={dueDiligenceQuestionnaire} />
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </YogaCard>

                <div
                  onClick={() => {
                    setOtherDataVisible(!otherDataVisible);
                  }}
                  data-qa="show-other-data-card"
                  className="z-20 mx-auto text-center cursor-pointer w-fit min-w-[33%] border-box-background border-4 py-1 rounded-b-2xl shadow-lg px-3 border-solid ring-0 bg-box-background text-primary font-bold"
                >
                  {otherDataVisible ? (
                    <FormattedMessage id="hideOtherData" />
                  ) : (
                    <>
                      <FormattedMessage id="showOtherData" />
                    </>
                  )}
                </div>
              </div>
            </div>
            <Tab.Group>
              <Tab.List className="inline-flex w-full gap-2 mb-4">
                <Tab
                  data-qa="summary-tab"
                  className="ui-not-selected:bg-white ui-selected:bg-primary ui-not-selected:text-primary ui-selected:text-white border-2 border-primary items-center justify-center px-4 py-2 rounded-lg uppercase w-1/3"
                >
                  <FormattedMessage id="summary" />
                </Tab>
                <Tab
                  data-qa="beneficiaries-tab"
                  className="ui-not-selected:bg-white ui-selected:bg-primary ui-not-selected:text-primary ui-selected:text-white border-2 border-primary items-center justify-center px-4 py-2 rounded-lg uppercase w-1/3"
                >
                  <FormattedMessage id="beneficiaries" />
                </Tab>
                <Tab
                  data-qa="documents-tab"
                  className="ui-not-selected:bg-white ui-selected:bg-primary ui-not-selected:text-primary ui-selected:text-white border-2 border-primary items-center justify-center px-4 py-2 rounded-lg uppercase w-1/3"
                >
                  <FormattedMessage id="documents" />
                </Tab>
              </Tab.List>
              <Tab.Panels>
                <Tab.Panel className="flex flex-col gap-y-4">
                  <YogaCard className="bg-body-text border-body-text flex flex-col gap-y-4" data-qa="partition-card">
                    {(!contract.partitionOption || contract.partitionOption?.unitLinkedInvestment > 0) && (
                      <YogaCard inner data-qa="unit-linked-card">
                        <div className="flex justify-between items-center gap-x-4">
                          <div className="flex gap-x-2 items-center">
                            <h3 data-qa="investmentLine-label" className="mb-0">
                              {intl.formatMessage(
                                { id: "investmentLineName" },
                                { line: intl.formatMessage({ id: investmentLine.name }).toLowerCase() }
                              )}
                            </h3>
                            {contract.partitionOption?.unitLinkedInvestment > 0 && contract.partitionOption?.segregatedInvestment > 0 && (
                              <YogaChip type="default" style="solid" size="small" data-qa="unit-linked-percentage-chip">
                                {contract.partitionOption.unitLinkedInvestment}%
                              </YogaChip>
                            )}
                          </div>

                          <PremiumDropDown premium={unitLinked.premium.uniqueOrAnnual} entity="unit-linked" />
                        </div>
                        {investmentLine.funds?.length > 0 && (
                          <Accordion
                            open
                            name="investment-line"
                            data-qa="funds-container"
                            className="flex flex-col border-collapse bg-box-background overflow-hidden w-full rounded-lg border-2 border-background mt-4"
                            titleContainerClasses="px-4 py-3.5"
                            accordionTitle={
                              <h4 data-qa="fund-detail-label">
                                <FormattedMessage id="fundsList" />
                              </h4>
                            }
                          >
                            <FundsTable funds={investmentLine.funds} investmentLine={investmentLine.name} />
                          </Accordion>
                        )}
                      </YogaCard>
                    )}
                    {contract.partitionOption?.segregatedInvestment > 0 && (
                      <YogaCard inner className="w-full flex items-center justify-between" data-qa="segregated-fund-card">
                        <div className="flex gap-x-2 items-center">
                          <h3 className="mb-0" data-qa="segregated-fund-card-title">
                            <FormattedMessage id="segregatedFund" />
                          </h3>
                          {contract.partitionOption?.unitLinkedInvestment > 0 && (
                            <YogaChip type="default" style="solid" size="small" data-qa="segregated-fund-percentage-chip">
                              {contract.partitionOption.segregatedInvestment}%
                            </YogaChip>
                          )}
                        </div>

                        {contract.assets["person_1"]?.segregatedFund?.premium?.uniqueOrAnnual && (
                          <PremiumDropDown premium={contract.assets["person_1"].segregatedFund.premium.uniqueOrAnnual} entity="segregated-fund" />
                        )}
                      </YogaCard>
                    )}
                  </YogaCard>
                  {contractualOptions && contractualOptions.length > 0 && (
                    <YogaCard className="bg-body-text border-body-text flex flex-col gap-y-4" data-qa="contractual-options-card">
                      <h3 data-qa="contractual-options-card-title" className="text-box-background mb-0">
                        <FormattedMessage id="contractualOptions" />
                      </h3>
                      {contractualOptions
                        .sort((a, b) => (a.name > b.name ? 1 : -1))
                        .map((opt) => (
                          <ContractualOptionBox contractualOption={opt} key={opt.code} />
                        ))}
                    </YogaCard>
                  )}
                </Tab.Panel>
                <Tab.Panel>
                  {!contract.beneficiaries ? (
                    <YogaCard className="bg-body-text border-body-text">
                      <YogaCard inner data-qa="investmentLine-card">
                        <div className="flex items-center">
                          <FormattedMessage id="notBeneficiariesToShow" />
                        </div>
                      </YogaCard>
                    </YogaCard>
                  ) : (
                    <>
                      <YogaCard className="bg-body-text border-body-text">
                        {contract.beneficiaries?.partyData?.length > 0 ? (
                          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                            {contract.beneficiaries.partyData.map((beneficiary, index) => (
                              <PartyBox key={index} party={beneficiary as CompleteParty} type={RoleType.BENEFICIARY} />
                            ))}
                          </div>
                        ) : (
                          <div
                            className={`flex flex-row items-center gap-x-2 bg-box-background p-3.5 rounded-lg truncate border-2 border-white`}
                            data-qa="beneficiaries-box"
                          >
                            <UserIcon className="w-8 h-8 shrink-0" />
                            <span className="font-bold leading-none" data-qa="beneficiaries-code-label">
                              <FormattedMessage id={contract.beneficiaries.description} />
                            </span>
                          </div>
                        )}
                      </YogaCard>
                      {contract.beneficiaries?.thirdReferent && (
                        <YogaCard className="bg-body-text border-body-text mt-4">
                          <h4 className="text-box-background pb-2 leading-none">
                            <FormattedMessage id="thirdReferent" />
                          </h4>

                          <div
                            className={`flex flex-row items-center gap-x-2 bg-box-background p-3.5 rounded-lg truncate border-2 border-white`}
                            data-qa="third-referent-box"
                          >
                            <IdentificationIcon className="w-8 h-8 shrink-0" />

                            <span className="font-bold leading-none" data-qa={`third-referent-title`}>{`${
                              contract.beneficiaries.thirdReferent.surnameOrCompanyName
                            } ${contract.beneficiaries.thirdReferent.name || EMPTY}`}</span>
                            {contract.beneficiaries.thirdReferent.taxId && (
                              <span className="text-xs font-bold text-action-disabled leading-none truncate mt-0.5" data-qa="party-taxId">
                                {contract.beneficiaries.thirdReferent.taxId}
                              </span>
                            )}
                            <button
                              type="button"
                              data-qa="party-box-detail-btn"
                              className="text-white bg-primary hover:bg-hover-primary rounded-full p-1"
                              onClick={() => setOpenThirdReferentDetailModal(true)}
                            >
                              <SearchIcon className="w-4 h-4 shrink-0" />
                            </button>

                            <YogaModal
                              isOpen={openThirdReferentDetailModal}
                              onClose={() => setOpenThirdReferentDetailModal(false)}
                              title={RoleType.THIRD_REFERENT}
                              className="w-4/5"
                            >
                              <div
                                className="flex flex-row items-center gap-x-2 bg-box-background p-3.5 rounded-lg truncate border-2 border-background mb-4"
                                data-qa="party-box"
                              >
                                <IdentificationIcon className="w-8 h-8 shrink-0" />

                                <div className="flex flex-row gap-x-2 items-center truncate">
                                  {contract.beneficiaries.thirdReferent?.surnameOrCompanyName && (
                                    <>
                                      <span
                                        className="font-bold"
                                        data-qa={`party-${contract.beneficiaries.thirdReferent.surnameOrCompanyName}-title`}
                                      >
                                        {contract.beneficiaries.thirdReferent.surnameOrCompanyName} {contract.beneficiaries.thirdReferent.name}
                                      </span>
                                      {contract.beneficiaries.thirdReferent.taxId && (
                                        <span className="text-xs font-bold text-action-disabled truncate mt-0.5" data-qa="party-taxId">
                                          {contract.beneficiaries.thirdReferent.taxId}
                                        </span>
                                      )}
                                    </>
                                  )}
                                </div>
                              </div>

                              <div className="grid grid-cols-2 lg:grid-cols-3 gap-4 mb-4">
                                <ThirdReferentInfo thirdReferent={contract.beneficiaries.thirdReferent as CompleteParty} />
                              </div>

                              {contract.beneficiaries.thirdReferent.parameters && (
                                <ParametersDetail parameters={contract.beneficiaries.thirdReferent.parameters} />
                              )}
                            </YogaModal>
                          </div>
                        </YogaCard>
                      )}
                    </>
                  )}
                </Tab.Panel>
                <Tab.Panel>
                  <DocumentsDetail dossier={dossier} documents={documents} isPollingTerminated={isPollingTerminated} dossierError={dossierError} />
                </Tab.Panel>
              </Tab.Panels>
            </Tab.Group>
          </div>
        </>
      ) : (
        <>
          <StickyBar
            breadcrumb={
              <div className="flex flex-col">
                <div className="h-7">
                  <YogaSkeleton position="outer" className="h-7 w-48 rounded-lg" />
                </div>
                <div className="h-6">
                  <YogaSkeleton position="outer" className="h-6 w-96 rounded-lg" />
                </div>
              </div>
            }
          />
          <div className="px-3">
            <div className="flex flex-col mb-8">
              <YogaCard className="z-40">
                <div className="grid grid-cols-3 gap-4 items-center">
                  <span className="col-span-2">
                    <YogaSkeleton position="inner" className="h-8 rounded-lg" />
                  </span>
                  <div>
                    <YogaSkeleton position="inner" className="h-8 rounded-lg" />
                  </div>
                </div>
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mt-4">
                  <YogaSkeleton position="inner" className="h-20 rounded-lg" />
                  <YogaSkeleton position="inner" className="h-20 rounded-lg" />
                  <YogaSkeleton position="inner" className="h-20 rounded-lg" />
                </div>
              </YogaCard>
              <div className="z-20 -mt-[1.5px] mx-auto w-fit min-w-[33%] border-box-background border-4 py-1 rounded-b-2xl shadow-lg px-3 border-solid ring-0 bg-box-background">
                <YogaSkeleton position="inner" className="h-6 rounded-lg" />
              </div>
            </div>
            <div className="grid grid-cols-3 gap-2 items-center">
              <YogaSkeleton position="outer" className="h-11 rounded-lg" />
              <YogaSkeleton position="outer" className="h-11 rounded-lg" />
              <YogaSkeleton position="outer" className="h-11 rounded-lg" />
            </div>
            <div className="mt-4">
              <YogaSkeleton position="outer" className="h-40 rounded-2xl" />
            </div>
          </div>
        </>
      )}
    </>
  );
}
