import { useEffect, useState } from "react";
import { contractService } from "commons/services/ContractService";
import { Contract, STATUS } from "contracts/models/Contract";
import useInterval from "commons/hooks/useInterval";
import { Party } from "customers/models/Party";

export default function useContractConfirmed(contractId: string) {
  const [contractCompleted, setContractCompleted] = useState<Contract>();
  const [contract, setContract] = useState<Contract>();
  const [policyholder, setPolicyholder] = useState<Party>();
  const [contractError, setContractError] = useState<Error | undefined>();
  const [isPollingContract, setPollingContract] = useState<boolean>(false);

  let counterRetries = 0;
  const maxRetries = 12;
  const delay = 5000;

  useEffect(() => {
    const fetchData = async () => {
      let result: any;
      if (contractId) {
        result = await contractService.get(contractId);
      }
      const contractConfirmed = result.data;
      setContract(contractConfirmed);
      setPolicyholder(contractConfirmed.parties["POLICYHOLDER"][0]);
      if (contractConfirmed.contractStatus === STATUS.VALID_PROPOSAL || contractConfirmed.contractStatus === STATUS.COMPLETED_PROPOSAL) {
        setContractCompleted(contractConfirmed);
        setPollingContract(false);
      } else {
        setPollingContract(true);
      }
    };

    fetchData().catch((e) => {
      setContractError(e);
    });
  }, []);

  useInterval(
    async () => {
      if (counterRetries > maxRetries) {
        setPollingContract(false);
        setContractError({ name: "errorOccurred", message: "errorOccurred" });
        return;
      }
      try {
        const documents = await contractService.get(contractId);
        const data = documents.data;
        if (data.contractStatus === STATUS.VALID_PROPOSAL || data.contractStatus === STATUS.COMPLETED_PROPOSAL) {
          setPollingContract(false);
          setContractCompleted(data);
        }
      } catch (e) {
        // @ts-ignore
        setContractError(e.response?.data?.message);
      } finally {
        counterRetries++;
      }
    },
    // Delay in milliseconds or null to stop it
    isPollingContract ? delay : null
  );

  return {
    contract,
    contractCompleted,
    policyholder,
    contractError,
  };
}
