import { areContractErrors, Contract, isExpired, isExpiring, STATUS } from "contracts/models/Contract";
import { useContext, useEffect, useState } from "react";
import { Context } from "commons/contexts/Context";
import { contractService } from "commons/services/ContractService";
import { Party } from "customers/models/Party";
import { Beneficiaries } from "customers/models/Beneficiaries";
import { toast } from "react-toastify";
import { useIntl } from "react-intl";

const useContract = (id: string, fromQuotation: boolean = false) => {
  const context = useContext(Context);
  const intl = useIntl();

  const [contract, setContract] = useState<Contract>();
  const [contractError, setContractError] = useState<boolean>(false);
  const [policyholder, setPolicyholder] = useState<Party>();

  useEffect(() => {
    const fetchData = async () => {
      context.changeLoading(1);
      let result: any;
      if (id) {
        result = fromQuotation ? await contractService.getByQuotationId(id) : await contractService.get(id);
      }
      const data = result.data as any;
      setPolicyholder(data.parties["POLICYHOLDER"][0]);
      if (data.contractStatus === STATUS.ACTIVE_POLICY) {
        if (isExpired(data)) {
          data.contractStatus = STATUS.EXPIRED;
        }
        if (isExpiring(data)) {
          data.contractStatus = STATUS.EXPIRING;
        }
      }
      if (
        data.contractCompleted === true &&
        data.contractStatus !== STATUS.AUTHORIZED // ||
        //data.contractStatus === STATUS.VALID_PROPOSAL ||
        //data.contractStatus === STATUS.COMPLETED_PROPOSAL
      ) {
        setContractError(true);
      } else {
        setContract(data);
      }
    };

    fetchData()
      .catch(() => {
        setContractError(true);
      })
      .finally(() => {
        context.changeLoading(-1);
      });
  }, []);

  function addBeneficiaries(contractId: string, beneficiaries: Beneficiaries): Promise<boolean> {
    return new Promise((resolve, reject) => {
      if (contract.contractId === contractId) {
        context.changeLoading(1);
        contractService
          .addBeneficiaries(contract.contractId, beneficiaries)
          .then((response) => {
            setContract(response.data);
            resolve(areContractErrors(response.data));
          })
          .finally(() => context.changeLoading(-1))
          .catch((e) => reject(e));
      } else {
        resolve(true);
      }
    });
  }

  function addThirdParty(contractId: string, thirdParty: Party): Promise<boolean> {
    return new Promise((resolve, reject) => {
      if (contract.contractId === contractId) {
        context.changeLoading(1);
        contractService
          .addThirdParty(contract.contractId, thirdParty)
          .then((response) => {
            setContract(response.data);
            resolve(areContractErrors(response.data));
          })
          .finally(() => context.changeLoading(-1))
          .catch((e) => reject(e));
      } else {
        resolve(true);
      }
    });
  }

  function saveDraft(updatedContract: Contract) {
    context.changeLoading(1);
    contractService
      .updateContractDraft(contract.contractId, updatedContract)
      .then((response) => {
        const quotationNumber = response.data.quotationNumber;
        setContract(response.data);
        toast.success(
          intl.formatMessage(
            {
              id: "proposalDrafted",
            },
            { number: quotationNumber }
          )
        );
      })
      .catch((e) => {
        console.error(e);
        toast.error(
          intl.formatMessage(
            {
              id: "proposalDraftedErrorWithNumber",
            },
            { number: contract.quotationNumber }
          )
        );
      })
      .finally(() => context.changeLoading(-1));
  }

  return {
    contract,
    setContract,
    contractError,
    policyholder,
    addBeneficiaries,
    addThirdParty,
    saveDraft,
  };
};

export default useContract;
