import { RoleType } from "contracts/enums/RoleType";
import { Contract } from "contracts/models/Contract";
import { Party } from "customers/models/Party";
import { useEffect, useState } from "react";

export default function useDigitalSwitch(
  contract: Contract,
  policyholder: Party
) {
  const [digitalSignature, setDigitalSignature] = useState<boolean>(false);
  const [disabled, setDisabled] = useState<boolean>(false);

  function handleDigitalSignature() {
    if (disabled) {
      return;
    }
    setDigitalSignature(!digitalSignature);
  }

  useEffect(() => {
    if (contract && policyholder) {
      const policyHolderIsInsuredPerson: boolean = Object.values(
        contract.assets
      ).every((e) => e.policyHolderIsInsuredPerson ?? true);

      const tasseEstero: string = Object.values(policyholder.parameters)
        .find((e) => e.code === "tasseEstero")
        .value.toString();

      const thirdReferent = Object.entries(contract.parties).filter(
        (e) => e[0] === RoleType.THIRD_PARTY
      );

      const beneficiariesCode: string = contract.beneficiaries?.code ?? "";

      const irrevocable: boolean =
        contract.beneficiaries.partyData?.some((e) => e.irrevocable) ?? false;

      const multicanalita: boolean = policyholder.otpSignatureEnabled ?? true;

      const defaultValue: boolean =
        policyHolderIsInsuredPerson &&
        tasseEstero !== "true" &&
        thirdReferent.length === 0 &&
        multicanalita &&
        (beneficiariesCode !== "otherParty" ||
          (beneficiariesCode === "otherParty" && !irrevocable));

      setDigitalSignature(defaultValue);
      setDisabled(!defaultValue);
    }
  }, [contract, policyholder]);

  return {
    digitalSignature,
    handleDigitalSignature,
    disabled,
  };
}
