/**
 * Return a component representing the chosen icon from https://fonts.google.com/icons.
 * Available styles: round (default), outlined.
 * (If more needs to be added, import corresponding stylesheet in index.html)
 */
export const materialIcon = (name: string, style: string = "round", size: string = "text-2xl") =>
  function YogaIcon() {
    return (
      <span className={`material-icons-${style}`}>
        <span className={`material-icons ${size} flex items-center leading-none`}>{name}</span>
      </span>
    );
  };

export const RISK_ICONS_LARGE: { [key: string]: any } = {
  "professional-mistakes": materialIcon("engineering", "round", "text-5xl"),
  "data-breaches": materialIcon("storage", "round", "text-5xl"),
  "legal-disputes": materialIcon("gavel", "round", "text-5xl"),
  injury: materialIcon("personal_injury", "round", "text-5xl"),
  disease: materialIcon("coronavirus", "round", "text-5xl"),
  fire: materialIcon("local_fire_department", "outlined", "text-5xl"),
  theft: materialIcon("lock_open", "round", "text-5xl"),
  "catastrophic-events": materialIcon("flood", "round", "text-5xl"),
  "other-damages": materialIcon("pending", "outlined", "text-5xl"),
  default: materialIcon("pending", "outlined", "text-5xl"),
};
