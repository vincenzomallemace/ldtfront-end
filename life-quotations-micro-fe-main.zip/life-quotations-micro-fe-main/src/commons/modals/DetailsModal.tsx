import React, { Fragment, PropsWithChildren } from "react";
import { Dialog, Transition } from "@headlessui/react";
import { XIcon } from "@heroicons/react/outline";
import { FormattedMessage } from "react-intl";
import { EMPTY } from "commons/Utils";

interface DetailsModalProps extends PropsWithChildren<any> {
  isOpen: boolean;
  onClose: () => void;
  title?: string;
}

export function DetailsModal({
  isOpen,
  onClose,
  title,
  children,
}: DetailsModalProps) {
  return (
    <Transition appear show={isOpen} as={Fragment}>
      <Dialog
        as="div"
        className="life-quotation-mfe fixed inset-0 z-60"
        onClose={onClose}
        data-qa="add-asset-modal"
      >
        {/* Use the overlay to style a dim backdrop for your dialog */}
        <Dialog.Overlay className="fixed inset-0 bg-modal-background bg-opacity-50" />
        {/*dialog__wrapper*/}
        <div className="min-h-screen px-4 text-center flex items-center justify-center">
          <Transition.Child
            as={Fragment}
            enter="ease-out duration-300"
            enterFrom="opacity-0"
            enterTo="opacity-100"
            leave="ease-in duration-200"
            leaveFrom="opacity-100"
            leaveTo="opacity-0"
          >
            <Dialog.Overlay className="fixed inset-0" />
          </Transition.Child>

          {/* This element is to trick the browser into centering the modal contents. */}
          <span
            className="inline-block h-screen align-middle"
            aria-hidden="true"
          >
            &#8203;
          </span>

          <Transition.Child
            as={Fragment}
            enter="ease-out duration-300"
            enterFrom="opacity-0 scale-95"
            enterTo="opacity-100 scale-100"
            leave="ease-in duration-200"
            leaveFrom="opacity-100 scale-100"
            leaveTo="opacity-0 scale-95"
          >
            <div className="text-left transition-all transform bg-white shadow-xl rounded-2xl w-2/3 lg:w-1/2 details-dialog">
              <Dialog.Title
                as="div"
                className="pt-8 px-8 flex justify-between text-xl font-bold text-title-text shrink-0"
              >
                <span className="max-w-max truncate" data-qa="modal-title">
                  <FormattedMessage id={title || EMPTY} />
                </span>
                <span>
                  <button onClick={onClose} data-qa="modal-close-button">
                    <XIcon className="w-8 cursor-pointer" />
                  </button>
                </span>
              </Dialog.Title>
              {/*dialog__body*/}
              <div
                className="px-8 overflow-auto text-body-text "
                data-qa="modal-body"
              >
                {children}
              </div>
              {/*dialog__footer*/}
              <div className=" p-4 flex items-center justify-end shrink-0" />
            </div>
          </Transition.Child>
        </div>
      </Dialog>
    </Transition>
  );
}
