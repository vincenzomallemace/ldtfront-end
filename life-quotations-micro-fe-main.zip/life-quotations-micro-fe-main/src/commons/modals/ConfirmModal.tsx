import { Dialog, Transition } from "@headlessui/react";
import { XIcon } from "@heroicons/react/outline";
import classNames from "classnames";
import { EMPTY } from "commons/Utils";
import { YogaButton } from "commons/components/YogaButton";
import { Fragment, PropsWithChildren } from "react";
import { FormattedMessage } from "react-intl";

interface ConfirmModalProps extends PropsWithChildren<any> {
  isOpen: boolean;
  onClose: () => void;
  onConfirm?: () => void;
  showCancelButton?: boolean;
  confirmLabel?: string;
  largeModal?: boolean;
  title?: string;
  dataQa?: string;
  element?: string;
  className?: string;
  closeClickOutside?: boolean;
}

export function ConfirmModal({
  isOpen,
  onClose,
  onConfirm,
  showCancelButton = true,
  confirmLabel = "confirm",
  largeModal = false,
  title,
  children,
  dataQa,
  element,
  className,
  closeClickOutside = true,
}: ConfirmModalProps) {
  return (
    <Transition appear show={isOpen} as={Fragment}>
      <Dialog
        data-qa={dataQa}
        as="div"
        className="life-quotation-mfe fixed inset-0 z-60"
        onClose={closeClickOutside ? onClose : () => {}}
      >
        {/* Use the overlay to style a dim backdrop for your dialog */}
        <Dialog.Overlay className="fixed inset-0 bg-modal-background bg-opacity-50" />
        <div
          className={classNames(
            "min-h-screen px-4 text-center flex items-start justify-center",
            largeModal && "h-full"
          )}
        >
          <Transition.Child
            as={Fragment}
            enter="ease-out duration-300"
            enterFrom="opacity-0"
            enterTo="opacity-100"
            leave="ease-in duration-200"
            leaveFrom="opacity-100"
            leaveTo="opacity-0"
          >
            <Dialog.Overlay className="fixed inset-0" />
          </Transition.Child>

          {/* This element is to trick the browser into centering the modal contents. */}
          <span
            className="inline-block h-screen align-middle"
            aria-hidden="true"
          >
            &#8203;
          </span>
          <Transition.Child
            as={Fragment}
            enter="ease-out duration-300"
            enterFrom="opacity-0 scale-95"
            enterTo="opacity-100 scale-100"
            leave="ease-in duration-200"
            leaveFrom="opacity-100 scale-100"
            leaveTo="opacity-0 scale-95"
          >
            <div
              className={classNames(
                className ||
                  "" +
                    " text-left transition-all transform bg-white shadow-xl rounded-2xl confirm-dialog ",
                largeModal
                  ? "h-5/6 w-5/6 self-center"
                  : "lg:w-2/5 max-w-lg lg:max-w-2xl w-2/3"
              )}
            >
              <Dialog.Title
                as="div"
                className="mb-4 pt-8 px-8 flex justify-between text-xl font-bold text-title-text"
              >
                <span data-qa="modal-title">
                  {title && (
                    <FormattedMessage
                      id={title}
                      values={{
                        element: element || EMPTY,
                      }}
                    />
                  )}
                </span>
                <span>
                  <button data-qa="modal-close-button" onClick={onClose}>
                    <XIcon className="w-8 cursor-pointer" />
                  </button>
                </span>
              </Dialog.Title>
              {/*dialog__body*/}
              <div
                data-qa="modal-body"
                className={classNames(
                  "px-8 overflow-auto text-body-text",
                  largeModal && "h-full"
                )}
              >
                {children}
              </div>
              {/*dialog__footer*/}
              {showCancelButton || onConfirm ? (
                <div className="p-8 flex items-center justify-end shrink-0">
                  {showCancelButton && (
                    <YogaButton
                      type="button"
                      outline
                      action={onClose}
                      data-qa="modal-cancel-button"
                    >
                      <FormattedMessage id="cancel" />
                    </YogaButton>
                  )}
                  {onConfirm && (
                    <YogaButton
                      type="button"
                      action={onConfirm}
                      data-qa="modal-confirm-button"
                      className="ml-4"
                    >
                      <FormattedMessage id={confirmLabel} />
                    </YogaButton>
                  )}
                </div>
              ) : (
                <div className="p-4"></div>
              )}
            </div>
          </Transition.Child>
        </div>
      </Dialog>
    </Transition>
  );
}
