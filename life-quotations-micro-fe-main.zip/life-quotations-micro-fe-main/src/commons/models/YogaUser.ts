import { ManagementNode } from "./nodes/ManagementNode";

export interface YogaUser {
  email: string;
  familyName: string;
  givenName: string;
  groups: string[];
  lastUpdateInstant: Date;
  name: string;
  rootManagementNodes: ManagementNode[];
  username: string;
}
