export type KeyValue<T> = Record<string, T>;

export interface ParentYuidEntity {
  parentYuid?: string;
}

export interface YuidEntity {
  yuid: string;
}

export interface OrderedEntity {
  order: number;
}

export interface Money {
  amount: number;
  currency: string;
}

export class CodeAndDescription {
  code: string;
  description?: string = "";
}
