import { Context } from "commons/contexts/Context";
import { useContext, useState } from "react";
import { ManagementNode } from "./ManagementNode";
import { EntityNode } from "./EntityNode";
import { searchService } from "commons/services/SearchService";

export default function useSearchNodes() {
  const context = useContext(Context);
  const [nodes, setNodes] = useState<ManagementNode[]>([]);

  function search(query: string, size: number = undefined) {
    context.changeLoading(1);
    return searchService
      .search("sales-networks", query, null, size)
      .then((result) => {
        let data: ManagementNode[] = (result.data as EntityNode[]).map((e) => {
          return { id: e.nodeId, code: e.code, description: e.description, childrenCount: -1 };
        });
        setNodes(data);
      })
      .finally(() => context.changeLoading(-1));
  }

  function clear() {
    setNodes([]);
  }

  return {
    nodes,
    search,
    clear,
  };
}
