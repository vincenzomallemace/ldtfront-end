export interface EntityNode {
  nodeId: string;
  code: string;
  description: string;
  parent?: string;
  abstract: boolean;
}
