export interface ManagementNode {
  id: string;
  code: string;
  description?: string;
  childrenCount?: number;
}
