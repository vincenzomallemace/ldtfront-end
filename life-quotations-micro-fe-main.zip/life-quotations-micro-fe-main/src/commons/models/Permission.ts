export interface Permission {
  description: string;
  code: string;
  category: string;
}
