import { IntlShape } from "react-intl";
import * as Yup from "yup";
import { config } from "commons/Configuration";

export interface Location {
  label: string;
  cityCode?: string;
  city?: string;
  countryCode?: string;
  country?: string;
  county?: string;
  countyAbbreviation?: string;
  district?: string;
  postalCode?: string;
  state?: string;
  street?: string;
  houseNumber?: string;
  manuallySet?: boolean;
}

export const getLocationSchema = (intl: IntlShape) => {
  const requiredMessage = intl.formatMessage({ id: "required" });
  const selectLocationMessage = intl.formatMessage({ id: "selectLocation" });
  const missingLocationMessage = intl.formatMessage({ id: "missingLocation" });
  const incompleteLocationMessage = intl.formatMessage({
    id: "incompleteLocation",
  });

  function validateLocation(l: Location, foreign: boolean = false) {
    if (!foreign) {
      return (
        l &&
        l.country &&
        l.country != "" &&
        l.county != "" &&
        l.city != "" &&
        l.postalCode != "" &&
        l.district != "" &&
        l.street != "" &&
        l.houseNumber != ""
      );
    } else {
      return l && l.country && l.country != "" && l.county != "" && l.city != "" && l.street != "" && l.houseNumber != "";
    }
  }

  //Condizionare lo schema sul valore di countyAbbreviation. Se è EE allora attivare lo schema estero

  return config.GEOLOCATION == "disabled"
    ? Yup.object().when("countyAbbreviation", {
        is: (countyAbbreviation: string) => countyAbbreviation === "EE",
        then: Yup.object().shape({
          country: Yup.string().ensure().required(requiredMessage),
          county: Yup.string().ensure().required(requiredMessage),
          city: Yup.string().ensure().required(requiredMessage),
          postalCode: Yup.string().ensure().required(requiredMessage),
          district: Yup.string().ensure().required(requiredMessage),
          street: Yup.string().ensure().required(requiredMessage),
          houseNumber: Yup.string().ensure().required(requiredMessage),
          label: Yup.string()
            .ensure()
            .required(missingLocationMessage)
            .test("address", incompleteLocationMessage, (v, c) => validateLocation(c.parent)),
        }),
        otherwise: Yup.object().shape({
          country: Yup.string().ensure().required(requiredMessage),
          county: Yup.string().ensure().required(requiredMessage),
          city: Yup.string().ensure().required(requiredMessage),
          street: Yup.string().ensure().required(requiredMessage),
          houseNumber: Yup.string().ensure().required(requiredMessage),
          label: Yup.string()
            .ensure()
            .required(missingLocationMessage)
            .test("address", incompleteLocationMessage, (v, c) => validateLocation(c.parent, true)),
        }),
      })
    : Yup.object().shape({
        label: Yup.string().ensure().required(selectLocationMessage),
      });
};
