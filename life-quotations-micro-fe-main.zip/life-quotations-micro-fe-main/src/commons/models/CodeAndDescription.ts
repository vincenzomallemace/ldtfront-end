export interface CodeAndDescription {
  code: string;
  description?: string;
}
