interface UserAttributes {
  email: string;
  email_verified: boolean;
  family_name: string;
  given_name: string;
  name: string;
  sub: string;
}

export interface User {
  attributes: UserAttributes;
  id: string;
  username: string;
}
