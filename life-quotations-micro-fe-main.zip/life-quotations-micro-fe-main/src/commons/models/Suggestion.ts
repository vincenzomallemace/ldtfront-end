import { Location } from "commons/models/Location";

export interface Suggestion {
  id: string;
  title: string;
  address: {
    countryName?: string;
    countryCode?: string;
    state?: string;
    stateCode?: string;
    county?: string;
    countyCode?: string;
    city?: string;
    cityCode?: string;
    district?: string;
    street?: string;
    streets?: string[];
    postalCode?: string;
    houseNumber?: string;
    resultType?: string;
    label?: string;
  };
  manuallySet?: boolean;
}

export function suggestionToLocation(suggestion: Suggestion): Location {
  return {
    label: suggestion.title || "",
    cityCode: suggestion.address.cityCode || "",
    city: suggestion.address.city || "",
    countryCode: suggestion.address.countryCode || "",
    country: suggestion.address.countryName || "",
    county: suggestion.address.county || "",
    countyAbbreviation: suggestion.address.countyCode || "",
    district: suggestion.address.district || "",
    postalCode: suggestion.address.postalCode || "",
    state: suggestion.address.state || "",
    street: suggestion.address.street || "",
    houseNumber: suggestion.address.houseNumber || "",
    manuallySet: suggestion.manuallySet,
  };
}

export const mandatoryLocationParams = ["city", "county", "street"];
