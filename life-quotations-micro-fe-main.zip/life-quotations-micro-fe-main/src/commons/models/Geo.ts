export interface Geo {
  iso?: string;
  geoId: string;
  name: string;
  countyCode?: string;
  county?: string;
  istatCode?: string;
  cap?: string[];
}

export enum GeoType {
  CITY = "CITY",
  COUNTRY = "COUNTRY",
}
