import { OrderedEntity, YuidEntity } from "commons/models/YogaModels";
import { SearchList } from "questionnaires/models/SearchList";
import { CodeAndDescription } from "./CodeAndDescription";

export type YogaParamType =
  | "STRING"
  | "NUMBER"
  | "LIST"
  | "DYNAMIC_LIST"
  | "BOOLEAN"
  | "SWITCH"
  | "DATE"
  | "PHONE"
  | "AMOUNT"
  | "CHECKMARK"
  | "TEXTAREA"
  | "SEARCHLIST"
  | "COUNTRY"
  | "CITY"
  | "LOCATION"
  | "BIRTHPLACE"
  | "MULTIPLE_CHOICE"
  | "LOCATION_DYNAMIC_LIST";

export type YogaParamValidationFormatType = "IBAN" | "PHONE_NUMBER" | "EMAIL" | "TAX_ID";

export type YogaParamValueType = string | boolean | number | Date | undefined;

interface ParamValidations {
  min?: number;
  max?: number;
  regExp?: string;
  minSelected?: number;
  maxSelected?: number;
  format?: YogaParamValidationFormatType;
}

interface DynamicListParam {
  fromTable: string;
  fromColumn: string;
  filteredByParameters: string[];
}

export interface Option {
  key: any;
  value: any;
  subvalue?: any;
}

export interface GenericParam {
  key?: string;
  name: string;
  value?: YogaParamValueType;
  valueDescription?: string;
  type: YogaParamType;
  subtype?: string;
  mandatory?: boolean;
  description?: string;
  code?: string;
  updateProductOnChange?: boolean;
  updateQuestionnaireOnChange?: boolean;
  updatePartyOnChange?: boolean;
  updatePaymentMethodOnChange?: boolean;
  availableValues?: Array<string | { value: string; label: string }>;
  availableObjectValues?: CodeAndDescription[];
  sort?: boolean;
  disableBinarySelect?: boolean;
  validations?: ParamValidations;
  visible?: boolean;
  disabled?: boolean;
  slider?: boolean;
  order?: number;
  dynamicList?: DynamicListParam;
  max?: number | Date;
  min?: number | Date;
  searchList?: SearchList;
  options?: Option[];
  tags?: string[];
}

/** Parameter for input field in a form */
export interface FormInputParam extends GenericParam {
  label?: string;
  tag?: string;
  updatePartially?: boolean;
  placeholder?: string;
  updateOnChange?: boolean;
  className?: string;
  labelPadding?: boolean;
  foreign?: boolean;
  date?: Date;
}

type OptionalFields =
  | "validations"
  | "value"
  | "description"
  | "disableBinarySelect"
  | "valueDescription"
  | "availableObjectValues"
  | "sort"
  | "max"
  | "min"
  | "options"
  | "tags"
  | "slider"
  | "subtype";

/** Parameters of assets, coverages, etc. as described in a product DSL */
export interface YogaParam
  extends OrderedEntity,
    YuidEntity,
    // optional fields
    Pick<GenericParam, OptionalFields>,
    // mandatory fields
    Omit<Required<GenericParam>, OptionalFields> {
  code: string;
  defaultValue: YogaParamValueType;
}
