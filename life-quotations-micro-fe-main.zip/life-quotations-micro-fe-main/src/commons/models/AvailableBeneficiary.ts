import { CodeAndDescription } from "./CodeAndDescription";

export default interface AvailableBeneficiary extends CodeAndDescription {
  availableParentalRelationships?: CodeAndDescription[];
  partyDataRequired?: boolean;
}
