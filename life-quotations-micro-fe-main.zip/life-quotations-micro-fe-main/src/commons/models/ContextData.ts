import { Party } from "customers/models/Party";
import { FinancialAdvice } from "models/FinancialAdvice";

export interface ContextData {
  policyholder?: Party;
  financialAdvice?: FinancialAdvice;
}
