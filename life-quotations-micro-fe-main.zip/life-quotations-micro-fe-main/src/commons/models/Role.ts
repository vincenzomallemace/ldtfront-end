import { Permission } from "./Permission";

export interface Role {
  description: string;
  code: string;
  permissions: Permission[];
}
