import classNames from "classnames";
import { EMPTY } from "commons/Utils";
import { FormattedMessage } from "react-intl";
import Heading from "./Heading";
import { config } from "commons/Configuration";
import { YogaButton } from "./YogaButton";
import { ArrowCircleLeftIcon } from "@heroicons/react/outline";
import { Stepper } from "commons/stepper/Stepper";

interface StickyBarProps {
  title?: string;
  breadcrumb?: React.ReactNode;
  children?: React.ReactNode;
  hasBackButton?: boolean;
  backFunction?: () => void;
  showStepper?: boolean;
}

export function StickyBar({
  title,
  children,
  breadcrumb,
  hasBackButton = true,
  //backFunction
  showStepper = true,
}: StickyBarProps) {
  return (
    <>
      {showStepper && <Stepper />}
      <div
        id="sticky-bar"
        data-qa="sticky-bar"
        className={classNames("w-full sticky top-0 bg-background z-50 pb-2")}
      >
        <div className="flex flex-row justify-between min-h-[84px] items-center">
          <div className="flex items-center">
            {hasBackButton && (
              <>
                {config.BACK_BUTTON && (
                  <YogaButton
                    type="button"
                    kind="default"
                    className="mr-4"
                    data-qa="back-button"
                    // action={() => history.back()}
                    action={() => {
                      //if(backFunction) backFunction();
                      history.back();
                    }}
                  >
                    <ArrowCircleLeftIcon className="w-5" />
                  </YogaButton>
                )}
              </>
            )}
            {title && (
              <Heading back={true}>
                <FormattedMessage id={title || EMPTY} />
              </Heading>
            )}
            {breadcrumb && (
              <div className="max-w-max truncate items-center">
                <Heading>{breadcrumb}</Heading>
              </div>
            )}
          </div>
          {children && <div className="flex items-center">{children}</div>}
        </div>
      </div>
    </>
  );
}
