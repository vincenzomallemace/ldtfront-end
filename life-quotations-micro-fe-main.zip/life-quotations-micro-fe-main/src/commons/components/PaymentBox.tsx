import { CreditCardIcon } from "@heroicons/react/outline";
import { SearchIcon } from "@heroicons/react/solid";
import { Payment } from "payments/Payment";
import { useMemo, useState } from "react";
import { FormattedMessage, useIntl } from "react-intl";
import { YogaModal } from "./YogaModal";
import { CompleteParty, PartyBox } from "./PartyBox";
import { RoleType } from "contracts/enums/RoleType";
import usePaymentMethods from "payments/hooks/usePaymentMethods";
import ParametersDetail from "./ParametersDetail";
import ParameterBox from "./ParameterBox";

export function PaymentBox({ payment, payer, productCode }: { payment: Payment; payer: CompleteParty; productCode: string }) {
  const intl = useIntl();
  const [openDetailModal, setOpenDetailModal] = useState<boolean>(false);
  const { paymentMethods } = usePaymentMethods(productCode, payment.contractId);
  const confPaymentMethod = useMemo(() => {
    const conf = paymentMethods?.find((conf) => conf.code === payment.paymentMethod);
    if (conf) {
      conf.parameters = Object.values(conf.parameters)
        // eslint-disable-next-line no-prototype-builtins
        .filter((param) => payment.paymentData?.hasOwnProperty(param.code))
        .map((param) => {
          param.value = payment.paymentData[param.code];
          return param;
        })
        .reduce((acc, current) => {
          acc[current.code] = current;
          return acc;
        }, {});
    }
    return conf;
  }, [paymentMethods]);

  return (
    <>
      <div className="flex flex-row items-center gap-x-2 bg-box-background p-4 rounded-lg truncate" data-qa="payment-box">
        <CreditCardIcon className="w-8 h-8 shrink-0" />
        <div data-qa="payment-data" className="flex-1">
          <h4 className="truncate" data-qa="payment-method">
            <FormattedMessage id={payment.paymentMethod} />
          </h4>
        </div>
        <button
          type="button"
          data-qa="payment-box-detail-btn"
          className="text-white bg-primary hover:bg-hover-primary rounded-full p-1 self-start"
          onClick={() => setOpenDetailModal(true)}
        >
          <SearchIcon className="w-4 h-4 shrink-0" />
        </button>
      </div>
      <YogaModal isOpen={openDetailModal} onClose={() => setOpenDetailModal(false)} title={payment.paymentMethod} className="w-4/5">
        <PartyBox party={payer} type={RoleType.PAYER} border="background" openDetail={false} />

        {Object.keys(payment.paymentData).length > 0 && (
          <>
            {Object.keys(payment.paymentData).filter((code) => !confPaymentMethod?.parameters[code]).length > 0 && (
              <div className="grid grid-cols-2 lg:grid-cols-3 gap-4 mt-4">
                {Object.entries(payment.paymentData)
                  .filter(([code]) => !confPaymentMethod?.parameters[code])
                  .map(([code, value]) => (
                    <ParameterBox key={code} label={intl.formatMessage({ id: code })} value={value} />
                  ))}
              </div>
            )}
            {confPaymentMethod?.parameters && (
              <div className="mt-4">
                <ParametersDetail parameters={confPaymentMethod?.parameters} />
              </div>
            )}
          </>
        )}
      </YogaModal>
    </>
  );
}
