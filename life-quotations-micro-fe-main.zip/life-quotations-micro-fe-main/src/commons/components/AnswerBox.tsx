import { EMPTY } from "commons/Utils";
import { Question } from "questionnaires/models/Question";
import { FormattedDate, FormattedMessage, FormattedNumber } from "react-intl";

export function AnswerBox({ question }: { question: Question }) {
  function displayAnswer(values) {
    if (question.answer.type === "DATE") {
      return <FormattedDate value={values[0]} year="numeric" month="2-digit" day="2-digit" />;
    } else if (question.answer.type === "AMOUNT") {
      return <FormattedNumber value={values[0] as number} currency={"EUR"} style="currency" />;
    } else if (question.answer.type === "MULTIPLE_CHOICE") {
      if (values.length == 1) {
        return values[0] || "-";
      } else if (values.length > 1) {
        return (
          <ul className="list-disc ml-4">
            {orderMultipleValues(values).map((value, index) => (
              <li key={index}>{value}</li>
            ))}
          </ul>
        );
      } else return "-";
    } else return <FormattedMessage id={values[0] || "-"} />;
  }

  function orderMultipleValues(values: string[]) {
    return question.answer.availableValues?.filter((value) => values.includes(value));
  }

  return (
    <div className="p-4 bg-box-background text-body-text rounded-lg justify-start flex flex-col">
      <span data-qa={`${question.label}-label`}>
        <FormattedMessage id={question.label || EMPTY} />
      </span>
      <span className="font-bold leading-5" data-qa={`${question.label}-answer-value`}>
        {displayAnswer(question.answer.values)}
      </span>
    </div>
  );
}
