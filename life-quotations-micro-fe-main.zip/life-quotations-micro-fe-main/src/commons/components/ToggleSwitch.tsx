import { FieldInputProps } from "formik";
import { CheckIcon, XIcon } from "@heroicons/react/solid";
import classNames from "classnames";

interface ToggleSwitchProps {
  id: string;
  checked?: boolean;
  className?: string;
  dataQa?: String;
  onChange?: () => void;
  //used when toggle is used inside formik
  field?: FieldInputProps<any>;
  name?: string;
  disabled?: boolean;
  small?: boolean;
}

export default function ToggleSwitch({
  id,
  className,
  checked,
  dataQa,
  onChange = () => {},
  field,
  name,
  disabled = false,
  small,
}: ToggleSwitchProps) {
  return (
    <span
      className={classNames(
        "relative inline-block",
        disabled ? "cursor-not-allowed" : "cursor-pointer"
      )}
    >
      <input
        type="checkbox"
        id={id}
        checked={checked}
        className={`sr-only ${className}`}
        onChange={onChange}
        name={name}
        data-qa={dataQa}
        disabled={disabled}
        {...(field ? { ...field } : {})}
      />
      <span
        className={classNames(
          small
            ? "flex items-center rail w-12 h-6 rounded-full shadow-inner border-2"
            : "flex items-center rail w-20 h-10 rounded-full shadow-inner border-2",
          disabled
            ? "bg-action-disabled border-action-disabled"
            : "bg-box-background",
          checked && !disabled ? "border-primary" : "",
          !checked && !disabled ? "border-body-text" : ""
        )}
      />
      <span
        className={classNames(
          small
            ? "flex items-center absolute w-4 h-4  rounded-full transition mini-dot shadow-xl"
            : "flex items-center absolute w-8 h-8  rounded-full transition dot shadow-xl",
          checked || disabled ? "bg-box-background" : "",
          !checked && !disabled ? "bg-body-text" : ""
        )}
      >
        <CheckIcon
          className={classNames(
            "w-6 h-6",
            small ? "" : "ml-1",
            checked ? "block" : "hidden",
            disabled ? "text-action-disabled" : "text-primary"
          )}
        />
        <XIcon
          className={classNames(
            "w-6 h-6",
            small ? "" : "ml-1",
            checked ? "hidden" : "block",
            disabled ? "text-action-disabled" : "text-box-background"
          )}
        />
      </span>
    </span>
  );
}
