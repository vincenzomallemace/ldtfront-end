import { useFormikContext } from "formik";
import React, { useEffect } from "react";

export const YogaScrollToFieldError = ({
  refs,
}: {
  refs?: { condition: boolean; element: React.MutableRefObject<any> };
}) => {
  const { submitCount, isValid, errors } = useFormikContext();

  const transformObjectToDotNotation = (
    obj: any,
    prefix = "",
    result: string[] = []
  ) => {
    Object.keys(obj).forEach((key) => {
      const value = obj[key];
      if (!value) return;

      const nextKey = prefix ? `${prefix}.${key}` : key;
      if (typeof value === "object") {
        transformObjectToDotNotation(value, nextKey, result);
      } else {
        result.push(nextKey);
      }
    });

    return result;
  };

  useEffect(() => {
    let scrolled = false;

    if (!isValid) {
      const fieldNames = transformObjectToDotNotation(errors);

      const element = document.getElementById(fieldNames[0]);
      if (!element) return;

      // Scroll to first known error into view
      element.scrollIntoView({ behavior: "smooth", block: "center" });
      scrolled = true;
    }

    if (!scrolled && refs?.condition && refs.element) {
      refs.element?.current?.scrollIntoView({
        behavior: "smooth",
        block: "center",
      });
    }

    // Formik doesn't (yet) provide a callback for a client-failed submission,
    // thus why this is implemented through a hook that listens to changes on
    // the submit count.
  }, [submitCount, refs?.condition]);

  return null;
};
