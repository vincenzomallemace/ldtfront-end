import { Loader } from "@aws-amplify/ui-react";

const YogaLoader = ({ loading }: { loading: boolean }) => {
  return (
    <>
      {loading && (
        <div
          className="flex fixed top-0 left-0 right-0 bottom-0 justify-center items-center bg-modal-background bg-opacity-50 z-70"
          data-qa="loader-animation"
        >
          <Loader
            className="w-10 h-10 md:w-20 md:h-20"
            emptyColor="var(--box-background)"
            filledColor="var(--title-text)"
          />
        </div>
      )}
    </>
  );
};

export default YogaLoader;
