import { KeyValue } from "commons/models/YogaModels";
import { useMemo } from "react";
import { YogaMessage } from "./YogaMessage";
import { FormattedMessage } from "react-intl";

interface MessagesProps {
  messages: KeyValue<string[]>;
  entity: "product" | "contract";
}
export default function Messages({ messages, entity }: MessagesProps) {
  const errors = useMemo(() => {
    // eslint-disable-next-line no-prototype-builtins
    if (messages?.hasOwnProperty("errors")) {
      return messages.errors;
    }
    return [];
  }, [messages]);

  const danger = useMemo(() => {
    // eslint-disable-next-line no-prototype-builtins
    if (messages?.hasOwnProperty("danger")) {
      return messages.danger;
    }
    return [];
  }, [messages]);

  const info = useMemo(() => {
    // eslint-disable-next-line no-prototype-builtins
    if (messages?.hasOwnProperty("info")) {
      return messages.info;
    }
    return [];
  }, [messages]);

  return (
    <>
      {(errors.length > 0 || danger.length > 0 || info.length > 0) && (
        <div
          id={`${entity}-messages`}
          data-qa={`${entity}-messages`}
          className="flex flex-col gap-y-4 mb-4"
        >
          {errors && errors.length > 0 && (
            <div id={`${entity}-errors`} data-qa={`${entity}-errors`}>
              {errors.map((error, index) => {
                return (
                  <YogaMessage type="error" position="outer" key={index}>
                    <p data-qa={error}>
                      <FormattedMessage id={error} />
                    </p>
                  </YogaMessage>
                );
              })}
            </div>
          )}
          {danger && danger.length > 0 && (
            <div id={`${entity}-danger`} data-qa={`${entity}-danger`}>
              {danger.map((danger, index) => {
                return (
                  <YogaMessage type="danger" position="outer" key={index}>
                    <p data-qa={danger}>
                      <FormattedMessage id={danger} />
                    </p>
                  </YogaMessage>
                );
              })}
            </div>
          )}
          {info && info.length > 0 && (
            <div id={`${entity}-info`} data-qa={`${entity}-info`}>
              {info.map((info, index) => {
                return (
                  <YogaMessage type="info" position="outer" key={index}>
                    <p data-qa={info}>
                      <FormattedMessage id={info} />
                    </p>
                  </YogaMessage>
                );
              })}
            </div>
          )}
        </div>
      )}
    </>
  );
}
