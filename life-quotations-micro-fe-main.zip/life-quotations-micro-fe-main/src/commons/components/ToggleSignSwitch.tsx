import { FieldInputProps } from "formik";
import classNames from "classnames";
import { FormattedMessage } from "react-intl";

interface ToggleSwitchProps {
  id: string;
  checked?: boolean;
  className?: string;
  dataQa?: String;
  onChange?: () => void;
  //used when toggle is used inside formik
  field?: FieldInputProps<any>;
  name?: string;
  disabled?: boolean;
  small?: boolean;
}

export default function ToggleSignSwitch({
  id,
  className,
  checked,
  dataQa,
  onChange = () => {},
  field,
  name,
  disabled = false,
  small,
}: ToggleSwitchProps) {
  return (
    <span
      className={classNames(
        "relative inline-block",
        disabled ? "cursor-not-allowed" : "cursor-pointer"
      )}
    >
      <input
        type="checkbox"
        id={id}
        checked={checked}
        className={`sr-only ${className}`}
        onChange={onChange}
        name={name}
        data-qa={dataQa}
        disabled={disabled}
        {...(field ? { ...field } : {})}
      />
      <span
        className={classNames(
          small
            ? "flex items-center p-4 w-48 h-16 rounded-full shadow-inner border-2"
            : "flex items-center p-4 w-48 h-16 rounded-full shadow-inner border-2",
          disabled
          ? "color-sign-toggle-switcher-disabled"
          : "color-sign-toggle-switcher",
        checked && !disabled ? "border-primary" : "",
          !checked && !disabled ? "border-body-text" : ""
        )}
      />

    <div className={classNames("grid grid-cols-2 items-center absolute label-sign-switcher")}>
        <div className={classNames("col-span-1 breack-on-space", checked ? "": "color-sign-toggle-font-checked")}>
            <FormattedMessage id="holoSignature" />
        </div>
        <div className={classNames("col-span-1 breack-on-space", checked ? "color-sign-toggle-font-checked": "")}>
            <FormattedMessage id="digitalSignature" />
        </div>
      </div>
      
      <span
        className={classNames(
          small
            ? "flex absolute w-24 h-14 rounded-full transition dot-sign shadow-xl"
            : "flex absolute w-24 h-14 rounded-full transition dot-sign shadow-xl",
            disabled ? "color-sign-toggle-disabled" : "color-sign-toggle",
        )}
      >
      </span>
    </span>
  );
}
