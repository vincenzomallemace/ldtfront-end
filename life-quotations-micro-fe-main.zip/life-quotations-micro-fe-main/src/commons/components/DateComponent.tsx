import { isEndOfDay } from "commons/DateUtils";
import { FormattedDateParts, FormattedTimeParts } from "react-intl";

interface DateProps {
  /** The date to render, either as a Date object or an ISO 8601 formatted string */
  date: string | Date;
  /** CSS class name */
  className?: string;
  withTime?: boolean;
}

export function DateComponent({
  date,
  className = "date-component",
  withTime = false,
}: DateProps) {
  const d = new Date(date);
  return date != null ? (
    <>
      <FormattedDateParts
        value={d}
        year="numeric"
        month="2-digit"
        day="2-digit"
      >
        {(parts) => (
          <span className={className} data-qa="date-component">
            {parts.map((part, index) => {
              return (
                <span className={part.type} key={part.type + "-" + index}>
                  {part.value}
                </span>
              );
            })}
          </span>
        )}
      </FormattedDateParts>
      {withTime && (
        <FormattedTimeParts
          value={d}
          hour="2-digit"
          minute="2-digit"
          hour12={false}
        >
          {(parts) => (
            <>
              ,&nbsp;
              <span>{isEndOfDay(d) ? "24" : getPartValue(parts, "hour")}</span>:
              <span>
                {isEndOfDay(d) ? "00" : getPartValue(parts, "minute")}
              </span>
            </>
          )}
        </FormattedTimeParts>
      )}
    </>
  ) : (
    <div>-</div>
  );
}

// Possible types: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Intl/DateTimeFormat/formatToParts
function getPartValue(
  parts: Intl.DateTimeFormatPart[],
  type: Intl.DateTimeFormatPartTypes
) {
  return parts.find((p) => p.type === type)?.value || "";
}
