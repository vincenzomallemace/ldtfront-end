import { ChevronLeftIcon } from "@heroicons/react/outline";
import React from "react";

interface HeadingProps {
  children: React.ReactNode;
  back?: boolean;
}

const Heading = ({ children, back = false }: HeadingProps) => (
  <h4 className="my-4 text-title-text font-bold flex items-center">
    <div className="flex items-center w-full">
      {back && (
        <span
          role="link"
          className="mr-2 font-bold cursor-pointer"
          onClick={() => history.back()}
          data-qa="back-button"
        >
          <ChevronLeftIcon className="h-6" />
        </span>
      )}
      <div data-qa="header-title" className="flex items-center w-full">
        {children}
      </div>
    </div>
  </h4>
);

export default Heading;
