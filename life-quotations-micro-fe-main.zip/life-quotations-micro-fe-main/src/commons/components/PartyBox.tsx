import { IdentificationIcon, OfficeBuildingIcon, UserIcon } from "@heroicons/react/outline";
import { SearchIcon } from "@heroicons/react/solid";
import { getMobilePhoneAndPrefix } from "commons/FormUtils";
import { EMPTY } from "commons/Utils";
import { Location } from "commons/models/Location";
import { CodeAndDescription } from "commons/models/YogaModels";
import { RoleType } from "contracts/enums/RoleType";
import { Party } from "customers/models/Party";
import { useState } from "react";
import { FormattedMessage } from "react-intl";
import { DateComponent } from "./DateComponent";
import { DlElement } from "./DlElement";
import ParametersDetail from "./ParametersDetail";
import { YogaChip } from "./YogaChip";
import { YogaModal } from "./YogaModal";

export interface CompleteParty extends Party {
  parentalRelationship?: CodeAndDescription;
  unverified: boolean;
  percentage?: number;
  irrevocable?: boolean;
  contactAddress?: Location;
}

export function PartyBox({
  party,
  type,
  label,
  border = "white",
  openDetail = true,
  openSections = false,
}: {
  party?: CompleteParty;
  type: RoleType;
  label?: string;
  border?: "white" | "background";
  openDetail?: boolean;
  openSections?: boolean;
}) {
  const [openDetailModal, setOpenDetailModal] = useState<boolean>(false);

  function getPartyInfo() {
    if (type == RoleType.BENEFICIARY) {
      return <BeneficiaryInfo beneficiary={party} />;
    } else if (type == RoleType.THIRD_REFERENT) {
      return <ThirdReferentInfo thirdReferent={party} />;
    } else {
      return <PartyInfo party={party} />;
    }
  }

  return (
    <>
      {party && (
        <>
          <div
            className={`flex flex-row items-center gap-x-2 bg-box-background p-3.5 rounded-lg truncate border-2 border-${border}`}
            data-qa="party-box"
          >
            {party?.legalEntity ? (
              <OfficeBuildingIcon className="w-8 h-8 shrink-0" />
            ) : type == RoleType.THIRD_REFERENT ? (
              <IdentificationIcon className="w-8 h-8 shrink-0" />
            ) : (
              <UserIcon className="w-8 h-8 shrink-0" />
            )}
            <div className="flex flex-col justify-start w-full truncate" data-qa="party-data">
              <div className="flex flex-row items-center gap-x-2 truncate">
                <span className="truncate" data-qa="party-type">
                  <FormattedMessage id={type == RoleType.BENEFICIARY && party?.irrevocable ? "irrevocableBeneficiary" : type} />
                </span>
                {type == RoleType.BENEFICIARY && party?.percentage && (
                  <YogaChip size="small" type="default" style="solid" data-qa="beneficiary-percentage">
                    {party.percentage}%
                  </YogaChip>
                )}
              </div>

              <div className="flex flex-row gap-x-2 items-center truncate">
                {label && (
                  <span className="font-bold" data-qa="party-label">
                    <FormattedMessage id={label} />
                  </span>
                )}
                {party?.surnameOrCompanyName && (
                  <>
                    <span className="font-bold" data-qa={`party-${party.surnameOrCompanyName}-title`}>{`${party.surnameOrCompanyName} ${
                      (!party.legalEntity && party.name) || EMPTY
                    }`}</span>
                    {party.taxId && (
                      <span className="text-xs font-bold text-action-disabled truncate mt-0.5" data-qa="party-taxId">
                        {party.taxId}
                      </span>
                    )}
                  </>
                )}
              </div>
            </div>
            {openDetail && (
              <button
                type="button"
                data-qa="party-box-detail-btn"
                className="text-white bg-primary hover:bg-hover-primary rounded-full p-1 self-start"
                onClick={() => setOpenDetailModal(true)}
              >
                <SearchIcon className="w-4 h-4 shrink-0" />
              </button>
            )}
          </div>
          {openDetail && (
            <YogaModal
              isOpen={openDetailModal}
              onClose={() => setOpenDetailModal(false)}
              title={type == RoleType.BENEFICIARY && party.irrevocable ? "irrevocableBeneficiary" : type}
              className="w-4/5"
            >
              <div
                className="flex flex-row items-center gap-x-2 bg-box-background p-3.5 rounded-lg truncate border-2 border-background mb-4"
                data-qa="party-box"
              >
                {party.legalEntity ? (
                  <OfficeBuildingIcon className="w-8 h-8 shrink-0" />
                ) : type == RoleType.THIRD_REFERENT ? (
                  <IdentificationIcon className="w-8 h-8 shrink-0" />
                ) : (
                  <UserIcon className="w-8 h-8 shrink-0" />
                )}

                <div className="flex flex-row gap-x-2 items-center truncate">
                  {party?.surnameOrCompanyName && (
                    <>
                      <span className="font-bold" data-qa={`party-${party.surnameOrCompanyName}-title`}>{`${party.surnameOrCompanyName} ${
                        (!party.legalEntity && party.name) || EMPTY
                      }`}</span>
                      {party.taxId && (
                        <span className="text-xs font-bold text-action-disabled truncate mt-0.5" data-qa="party-taxId">
                          {party.taxId}
                        </span>
                      )}
                    </>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-2 lg:grid-cols-3 gap-4 mb-4" data-qa="partyData-container">
                {getPartyInfo()}
              </div>

              {type != RoleType.PAYER && party.parameters && !party.unverified && (
                <ParametersDetail parameters={party.parameters} isOpen={openSections} />
              )}
            </YogaModal>
          )}
        </>
      )}
    </>
  );
}

function PartyInfo({ party }: { party: CompleteParty }) {
  const [number, prefix] = getMobilePhoneAndPrefix(party?.mobilePhoneNumber, party?.mobilePhoneNumberPrefix);
  return (
    <>
      {party.legalEntity ? (
        <>
          <DlElement data-qa="companyType" title="companyType">
            {party.companyType ? <FormattedMessage id={party.companyType} /> : <>{"-"}</>}
          </DlElement>
          <DlElement data-qa="vatNumber" title="vatNumber">
            {party.vatNumber || "-"}
          </DlElement>
          <DlElement title="taxCode" data-qa="taxCode">
            {party.taxId || "-"}
          </DlElement>
          <DlElement title="companyName" data-qa="companyName">
            {party.surnameOrCompanyName || "-"}
          </DlElement>
        </>
      ) : (
        <>
          <DlElement title="birthDate" data-qa="birthDate">
            {party.birthDate ? <DateComponent date={party.birthDate} /> : <>{"-"}</>}
          </DlElement>

          {party.taxId.charAt(11).toUpperCase() !== "Z" ? (
            <DlElement title="birthPlace" data-qa="birthPlace">
              {party.birthPlace ? (party.birthCountyCode ? `${party.birthPlace} (${party.birthCountyCode})` : party.birthPlace) : "-"}
            </DlElement>
          ) : (
            <DlElement title="birthCountry" data-qa="birthCountry">
              {party.birthCountry || "-"}
            </DlElement>
          )}

          <DlElement title="gender" data-qa="gender">
            {party.gender ? <FormattedMessage id={party.gender} /> : <>{"-"}</>}
          </DlElement>
        </>
      )}
      {/*<DlElement data-qa="email" title="email">
        {party.email || "-"}
          </DlElement>*/}
      <DlElement data-qa="mobilePhoneNumber" title="mobilePhoneNumber">
        {party.mobilePhoneNumber ? (
          <>
            {prefix} {number}
          </>
        ) : (
          "-"
        )}
      </DlElement>
      {/*<DlElement title="iban" data-qa="iban">
        {party.iban || "-"}
      </DlElement>*/}
      <DlElement title="residentialAddressOrRegisteredAddress" data-qa="residentialAddressOrRegisteredAddress" className="col-span-2">
        {party.location?.label || "-"}
      </DlElement>
      {party.domicileIsNotResidence && (
        <DlElement title="domicile" data-qa="domicile" className="col-span-2">
          {party.domicile?.label || party?.contactAddress?.label || "-"}
        </DlElement>
      )}
    </>
  );
}

function BeneficiaryInfo({ beneficiary }: { beneficiary: CompleteParty }) {
  return (
    <>
      {beneficiary.unverified ? (
        <>
          {!beneficiary.legalEntity && (
            <>
              <DlElement title="birthDate" data-qa="birthDate">
                {beneficiary.birthDate ? <DateComponent date={beneficiary.birthDate} /> : <>{"-"}</>}
              </DlElement>
              {beneficiary.birthCountry && beneficiary.birthCountry != "ITALIA" ? (
                <DlElement title="birthCountry" data-qa="birthCountry">
                  {beneficiary.birthCountry || "-"}
                </DlElement>
              ) : (
                <DlElement title="birthPlace" data-qa="birthPlace">
                  {beneficiary.birthPlace
                    ? beneficiary.birthCountyCode
                      ? `${beneficiary.birthPlace} (${beneficiary.birthCountyCode})`
                      : beneficiary.birthPlace
                    : "-"}
                </DlElement>
              )}
            </>
          )}
        </>
      ) : (
        <PartyInfo party={beneficiary} />
      )}
      {/*<DlElement title="parentalRelationship" data-qa="parentalRelationship">
        <FormattedMessage id={beneficiary.parentalRelationship.description || EMPTY} />
      </DlElement>*/}
    </>
  );
}

export function ThirdReferentInfo({ thirdReferent }: { thirdReferent: CompleteParty }) {
  const [number, prefix] = getMobilePhoneAndPrefix(thirdReferent?.mobilePhoneNumber, thirdReferent?.mobilePhoneNumberPrefix);
  return (
    <>
      {thirdReferent.unverified ? (
        <>
          <DlElement data-qa="mobilePhoneNumber" title="mobilePhoneNumber">
            {thirdReferent.mobilePhoneNumber ? (
              <>
                {prefix} {number}
              </>
            ) : (
              "-"
            )}
          </DlElement>
          <DlElement title="domicile" data-qa="domicile" className="col-span-2">
            {thirdReferent?.contactAddress?.label || "-"}
          </DlElement>
        </>
      ) : (
        <PartyInfo party={thirdReferent} />
      )}
    </>
  );
}
