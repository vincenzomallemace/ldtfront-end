import classNames from "classnames";
import React from "react";

interface YogaCardProps {
  children: React.ReactNode;
  className?: string;
  "data-qa"?: string;
  error?: boolean;
  success?: boolean;
  border?: boolean;
  uniformPadding?: boolean;
  id?: string;
  inner?: boolean;
}

const YogaCard = ({
  children,
  className = "",
  "data-qa": qa = "yoga-card",
  error = false,
  success = false,
  border = false,
  uniformPadding = false,
  id = "yoga-card",
  inner = false,
}: YogaCardProps) => {
  const backgroundColorRegex = new RegExp("\\bbg-\\w");

  let borderClass = error
    ? "border-error border-4"
    : success
    ? "border-success border-4"
    : border
    ? "border-background border-2"
    : "border-box-background border-4";
  let defaultBgColor = "bg-box-background";
  if (backgroundColorRegex.test(className)) {
    defaultBgColor = "";
    if (!error && !success && !border) {
      borderClass = "border-4";
    }
  }

  return (
    <div
      data-qa={qa}
      className={classNames(
        borderClass,
        uniformPadding ? "py-3" : "py-5",
        inner ? "rounded-lg" : "rounded-2xl shadow-lg",
        `px-3 min-w-0 border-solid ${defaultBgColor} ring-0 relative ${className}`
      )}
      id={id}
    >
      {children}
    </div>
  );
};

export default YogaCard;
