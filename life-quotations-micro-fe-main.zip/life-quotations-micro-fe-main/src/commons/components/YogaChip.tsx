import classNames from "classnames";
import React, { PropsWithChildren } from "react";

// interface ChipProps extends PropsWithChildren<any> {
//   className?: string;
//   spanClass?: string;
//   baseClasses?: string;
//   roundedClass?: string;
//   justifyClass?: string;
//   "data-qa"?: string;
// }
//
// export const YogaChip = ({
//                            children,
//                            className = "",
//                            baseClasses = "border border-solid flex flex-row w-auto items-center text-base leading-none",
//                            roundedClass = " rounded-lg",
//                            spanClass = "inline-block mx-3 text-justify",
//                            justifyClass = "justify-center",
//                            "data-qa": dataQa,
//                          }: ChipProps) => (
//   <div
//     className={` ${baseClasses} ${roundedClass} ${className} ${justifyClass}`}
//     role="chip"
//     data-qa={dataQa ? `${dataQa}-chip` : "chip"}
//   >
//     <span className={spanClass}>{children}</span>
//   </div>
// );

export interface ChipProps extends PropsWithChildren {
  className?: string;
  size?: "regular" | "small";
  type: "default" | "success" | "warning" | "error";
  style?: "solid" | "outline" | "offerStatus";
  visibility?: "visible" | "invisible";
}

export const YogaChip = ({
  size = "regular",
  type,
  style = "outline",
  visibility = "visible",
  children,
  className = "",
  ...props
}: ChipProps) => {
  const sizeClasses = {
    regular: "rounded-lg px-3 py-1.5",
    small: "rounded px-2",
  };

  const typeClasses = {
    default: classNames(
      "border-body-text",
      style === "outline" && "bg-card-background text-body-text",
      style === "solid" && "bg-body-text text-white",
      style === "offerStatus" && "bg-card-background text-body-text",
      className
    ),
    success: classNames(
      "border-success",
      style === "outline" && "bg-card-background text-success",
      style === "solid" && "bg-success text-white",
      style === "offerStatus" &&
        "bg-success-background bg-opacity-50 text-success",
      className
    ),
    warning: classNames(
      "border-draft",
      style === "outline" && "bg-card-background text-draft",
      style === "solid" && "bg-draft text-white",
      style === "offerStatus" && "bg-draft-background bg-opacity-50 text-draft",
      className
    ),
    error: classNames(
      "border-error",
      style === "outline" && "bg-card-background text-error",
      style === "solid" && "bg-error text-white",
      style === "offerStatus" && "bg-error-background bg-opacity-50 text-error",
      className
    ),
  };

  return (
    <div
      className={classNames(
        "box-border w-min border border-solid",
        visibility,
        sizeClasses[size],
        typeClasses[type]
      )}
      {...props}
    >
      {children}
    </div>
  );
};
