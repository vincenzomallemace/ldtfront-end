import React, { useMemo } from "react";

interface ButtonProps {
  children?: React.ReactNode;
  action?: () => void;
  disabled?: boolean;
  className?: string;
  "data-qa"?: string;
  form?: string;
  type?: "submit" | "button";
  /** Button style: primary uses the primary color, success uses green, danger uses red. */
  kind?: "default" | "success" | "danger";
  /** If true, only shows borders; otherwise (default), the button is filled. */
  outline?: boolean;
  position?: "inner-most" | "inner" | "outer";
  "text-size"?: string;
  uppercase?: boolean;
}

const positions = {
  "inner-most": "rounded",
  inner: "rounded-lg",
  outer: "rounded-4xl",
};

const outline2colors = {
  default:
    "border-primary text-primary bg-box-background active:border-hover-primary active:text-hover-primary hover:border-hover-primary hover:text-hover-primary",
  success:
    "border-success text-success active:border-hover-success active:text-hover-success hover:border-hover-success hover:text-hover-success",
  danger:
    "border-error text-error active:border-hover-error active:text-hover-error hover:border-hover-error hover:text-hover-error",
};
const filled2colors = {
  default:
    "bg-primary text-button-text border border-primary active:border-hover-primary hover:border-hover-primary active:bg-hover-primary hover:bg-hover-primary",
  success:
    "bg-success text-button-text border border-success active:border-hover-success hover:border-hover-success active:bg-hover-success hover:bg-hover-success",
  danger:
    "bg-error text-button-text border border-error active:border-hover-error hover:border-hover-error active:bg-hover-error hover:bg-hover-error",
};

const getClasses = (
  kind: "default" | "success" | "danger",
  disabled: boolean,
  outline: boolean
) =>
  disabled
    ? "bg-box-background text-action-disabled border-action-disabled cursor-not-allowed"
    : outline
    ? outline2colors[kind]
    : filled2colors[kind];

export function YogaButton({
  children,
  action,
  disabled = false,
  className = "",
  form = "",
  type = "submit",
  kind = "default",
  outline = false,
  "data-qa": qa = "submit-button",
  position = "outer",
  uppercase = true,
  "text-size": textSize = "small",
}: ButtonProps) {
  const cls = getClasses(kind, disabled, outline);
  const paddingXRegExp = new RegExp("\\bpx-\\d");
  const paddingYRegExp = new RegExp("\\bpy-\\d");

  const padding = useMemo(() => {
    let px = "px-4";
    let py = "py-2";
    if (paddingXRegExp.test(className)) {
      px = "";
    }
    if (paddingYRegExp.test(className)) {
      py = "";
    }
    return [px, py];
  }, [className]);

  const txtCase = useMemo(() => (uppercase ? "uppercase" : ""), [uppercase]);

  const text = useMemo(() => {
    let res;
    switch (textSize) {
      case "large":
        res = "text-lg";
        break;
      case "base":
        res = "text-base";
        break;
      case "small":
      default:
        res = "text-sm";
    }
    return res;
  }, [textSize]);

  const props = {
    className: `${padding[0]} ${padding[1]} focus:ring-0 ${txtCase} border-2 inline-flex leading-5 transition-colors duration-300 ${text} ${cls} ${className} ${positions[position]}`,
    onClick: action,
    "data-qa": qa,
    form: form || undefined,
    type,
    disabled,
  };
  return <button {...props}>{children}</button>;
}
