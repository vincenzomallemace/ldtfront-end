import classNames from "classnames";
import { FormattedMessage } from "react-intl";

export function DlElement({
  title,
  bordered = true,
  horizontal = false,
  "border-color": borderColor = "ring-background",
  children,
  "data-qa": dataQa,
  className,
}: DescriptionListElementProps) {
  return (
    <div
      className={classNames(
        "flex",
        className ? className : "",
        horizontal ? "flex-row" : "flex-col",
        bordered && `ring-2 rounded-lg ${borderColor} py-1 px-4`
      )}
      data-qa={dataQa ? `dl-${dataQa}` : "dl-element-container"}
    >
      <div className="text-primary tracking-wider text-sm font-medium" data-qa="dl-element-title">
        {typeof title == "string" ? <FormattedMessage id={title} /> : <>{title}</>}
      </div>
      <div className="text-gray-8 tracking-wider text-base" data-qa="dl-element-content">
        {children}
      </div>
    </div>
  );
}

interface DescriptionListElementProps {
  /** The title of the element */
  title: string | JSX.Element;
  children: any;
  bordered?: boolean;
  horizontal?: boolean;
  "border-color"?: string;
  "data-qa"?: string;
  className?: string;
}
