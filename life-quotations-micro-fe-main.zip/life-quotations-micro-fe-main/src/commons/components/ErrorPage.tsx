import { FormattedMessage } from "react-intl";
import { StickyBar } from "./StickyBar";
import YogaCard from "./YogaCard";
import { ReactComponent as Engineer_svg } from "commons/images/engineer.svg";

export default function ErrorPage() {
  return (
    <>
      <StickyBar
        breadcrumb={
          <div className="flex flex-col truncate">
            <div className="truncate">
              <FormattedMessage id="errorPageTitle" />
            </div>
          </div>
        }
      />

      <YogaCard>
        <div className="p-1 flex flex-wrap lg:flex-nowrap w-full justify-center items-center gap-8">
          <Engineer_svg className="w-full lg:w-auto" />
          <h4 className="w-2/3 lg:w-1/3 text-xl font-bold text-body-text">
            <FormattedMessage id="unauthorizedErrorMessage" />
          </h4>
        </div>
      </YogaCard>
    </>
  );
}
