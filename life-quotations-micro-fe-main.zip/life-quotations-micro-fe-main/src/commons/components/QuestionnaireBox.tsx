import { DocumentTextIcon } from "@heroicons/react/outline";
import { SearchIcon } from "@heroicons/react/solid";
import { groupQuestionsByTag } from "commons/Utils";
import { Question } from "questionnaires/models/Question";
import { QuestionnaireModel } from "questionnaires/models/QuestionnaireModel";
import { useState } from "react";
import { FormattedDate, FormattedMessage, FormattedNumber } from "react-intl";
import { YogaModal } from "./YogaModal";
import { Answer } from "questionnaires/models/Answer";

export function QuestionnaireBox({ questionnaire }: { questionnaire: QuestionnaireModel }) {
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);

  function displayAnswerValue(answer) {
    if (answer.type === "DATE") {
      return <FormattedDate value={answer.value.toString()} year="numeric" month="2-digit" day="2-digit" />;
    } else if (answer.type === "AMOUNT") {
      return <FormattedNumber value={answer.value as number} currency={answer.currency || "EUR"} style="currency" />;
    } else if (answer.type === "MULTIPLE_CHOICE") {
      if (answer.values.length == 1) {
        return answer.values[0] || "-";
      } else if (answer.values.length > 1) {
        return (
          <ul className="list-disc ml-4">
            {orderMultipleValues(answer).map((value, index) => (
              <li key={index}>{value}</li>
            ))}
          </ul>
        );
      } else return "-";
    } else return <FormattedMessage id={answer.value.toString() || "-"} />;
  }

  function orderMultipleValues(answer: Answer) {
    return answer.availableValues?.filter((value) => answer.values.includes(value));
  }

  return (
    <>
      <div
        data-qa="quetionnaire-box"
        className="flex items-center gap-x-1 text-body-text bg-box-background p-3.5 rounded-lg border-2 border-background"
      >
        <DocumentTextIcon className="w-6 h-6 shrink-0" />
        <span data-qa="due-diligence-questionnaire-label" className="w-full">
          <FormattedMessage id="dueDiligenceQuestionnaire" />
        </span>

        <SearchIcon
          onClick={() => {
            setIsModalOpen(true);
          }}
          className="w-6 h-6 text-white bg-primary hover:bg-hover-primary rounded-full p-1 cursor-pointer shrink-0"
        />
      </div>

      <YogaModal
        isOpen={isModalOpen}
        onClose={() => {
          setIsModalOpen(false);
        }}
        title="dueDiligenceQuestionnaire"
      >
        <div data-qa="questionnaire-container" className="flex flex-col gap-y-4">
          {Object.keys(questionnaire?.questions)?.length > 0 &&
            Object.entries(groupQuestionsByTag(questionnaire.questions)).map(([tag, questions]) => (
              <div key={`${tag}-section`} data-qa={`${tag}-section`}>
                {tag !== "noTag" && (
                  <h4 data-qa={`${tag}-label`} className="mb-2 leading-none">
                    <FormattedMessage id={tag} />
                  </h4>
                )}
                <div className="flex flex-col gap-y-4 border-l border-table-divider pl-4" data-qa={`${tag}-questions`}>
                  {questions.map((question: Question) => (
                    <div key={`question-${question.code}`} data-qa={`question-${question.code}`} className="flex flex-col">
                      <span data-qa="question-label">{question.label}</span>
                      <span data-qa="answer-value" className="font-bold">
                        {displayAnswerValue(question.answer)}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
        </div>
      </YogaModal>
    </>
  );
}
