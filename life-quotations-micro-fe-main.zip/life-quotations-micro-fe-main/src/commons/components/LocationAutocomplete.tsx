import { BanIcon, ExclamationCircleIcon, InformationCircleIcon } from "@heroicons/react/outline";
import classnames from "classnames";
import { config } from "commons/Configuration";
import { validation } from "commons/FormUtils";
import { Context } from "commons/contexts/Context";
import { Location } from "commons/models/Location";
import { useContext, useEffect, useState } from "react";
import { FormattedMessage, useIntl } from "react-intl";
import { usePopper } from "react-popper";
import { Suggestion, suggestionToLocation } from "../models/Suggestion";
import { YogaButton } from "./YogaButton";
import { Field, Form, Formik, FormikProps } from "formik";
import * as Yup from "yup";
import { FormikInput } from "commons/formik/FormikInput";
import { YogaModal } from "./YogaModal";
import { geoService } from "commons/services/GeoService";
import { hasErrorsOnTouched } from "commons/formik/Utils";
import classNames from "classnames";

interface LocationAutocompleteProps {
  startLocation?: Location;
  form?: FormikProps<any>;
  error?: string;
  disabled?: boolean;
  onSelectLocation: (suggestion?: Suggestion) => any;
  label?: string;
  id?: string;
  mandatoryLocationParams?: string[];
  className?: string;
}

export const LocationAutocomplete = ({
  onSelectLocation,
  startLocation,
  form,
  error = undefined,
  disabled = false,
  label = "location",
  id = "location",
  mandatoryLocationParams,
  className,
}: LocationAutocompleteProps) => {
  const AUTOCOMPLETION_URL = config.HERE_URL;
  const ajaxRequest = new XMLHttpRequest();

  const { lang } = useContext(Context);

  const [availablePostalCodes, setAvailablePostalCodes] = useState<string[]>([]);

  const [searchInput, setSearchInput] = useState(null);
  const [isManualAddressVisible, setIsManualAddressVisible] = useState(false);
  const [popperElement, setPopperElement] = useState(null);
  const {
    styles,
    attributes,
    update: refreshMenuPosition,
  } = usePopper(searchInput, popperElement, {
    placement: "bottom-start",
    modifiers: [
      {
        name: "flip",
        enabled: true,
        options: {
          flipVariations: true,
        },
      },
    ],
  });

  const inCountryCode = getInCountryCode();

  const [suggestions, setSuggestions] = useState<Array<any>>([]);

  const [address, setAddress] = useState<string>();

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isLocationModalOpen, setIsLocationModalOpen] = useState(false);

  const intl = useIntl();
  const requiredMessage = intl.formatMessage({ id: "required" });

  const countryNames = ALLOWED_COUNTRY_NAMES.map((country) =>
    intl.formatMessage({
      id: country,
      defaultMessage: country,
    })
  );

  const message = intl.formatMessage({ id: "allowedCountries" }, { countries: countryNames.join(", ") });

  const [mandatoryMissingParams, setMandatoryMissingParams] = useState<string[]>(undefined);
  const [mandatoryMissingParamsMessage, setMandatoryMissingParamsMessage] = useState<string>(undefined);

  useEffect(() => {
    if (mandatoryMissingParams && mandatoryMissingParams?.length > 0) {
      setMandatoryMissingParamsMessage(intl.formatMessage({ id: "incompleteAddress" }, { params: mandatoryMissingParams.join(", ") }));
    } else {
      setMandatoryMissingParamsMessage(undefined);
    }
  }, [mandatoryMissingParams]);

  useEffect(() => {
    if (startLocation && (startLocation.label || startLocation.label === "")) {
      if (searchInput) {
        searchInput.value = startLocation.label;
      }
      if (validation.canValidate(startLocation)) {
        const mandatory = validation.missingParams(mandatoryLocationParams, startLocation);
        setMandatoryMissingParams(mandatory.map((e) => intl.formatMessage({ id: e })));
      }
    } else {
      if (searchInput) {
        searchInput.value = "";
        setAddress("");
      }
    }
  }, [startLocation]);

  function getInCountryCode(): string {
    //in=countryCode:CAN,USA ==> &in=countryCode%3ACAN%2CUSA
    let param = "";
    if (ALLOWED_COUNTRY_CODES.length > 0) {
      param = "&in=countryCode%3A" + ALLOWED_COUNTRY_CODES.join("%2C");
    }
    return param;
  }

  useEffect(() => {
    const delayDebounceFn = setTimeout(() => {
      if (address && address.length >= 10) {
        setIsManualAddressVisible(true);
      } else {
        setIsManualAddressVisible(false);
      }
      if (address && address.length >= 4) {
        const params = generateParams();
        ajaxRequest.open("GET", AUTOCOMPLETION_URL + params);
        ajaxRequest.send();
      } else if (address?.length === 0) {
        setSuggestions([]);
        onSelectLocation(undefined);
        setMandatoryMissingParams([]);
      }
    }, 300);

    return () => clearTimeout(delayDebounceFn);
  }, [address]);

  const generateParams = () => {
    let params =
      "?" +
      "q=" +
      encodeURIComponent(address) + // The search text which is the basis of the query
      "&limit=5" + // The upper limit the for number of suggestions to be included
      // in the response.  Default is set to 5.
      inCountryCode;
    if (lang) {
      params = params + "&lang=" + lang;
    }
    return params;
  };

  function onAutoCompleteSuccess() {
    setSuggestions(ajaxRequest.response?.items || []);
    if (refreshMenuPosition) {
      refreshMenuPosition();
    }
  }

  function onAutoCompleteFailed() {
    console.log("Error in search");
  }

  async function selectSuggestion(suggestion: Suggestion, manuallySet: boolean) {
    suggestion.manuallySet = manuallySet;
    if (searchInput) {
      searchInput.value = suggestion.title;
    }
    if (suggestion.address.countryName === "Italia") {
      let missingParams = [];
      mandatoryLocationParams.forEach((element) => {
        if (!suggestion.address[element]) {
          missingParams.push(intl.formatMessage({ id: element }));
        }
      });
      setMandatoryMissingParams(missingParams);
    } else {
      setMandatoryMissingParams([]);
    }
    suggestions.length > 0 && refreshMenuPosition();
    setSuggestions([]);
    setIsManualAddressVisible(false);
    let checked = await checkSuggestion(suggestion);
    onSelectLocation(checked);
  }

  async function checkSuggestion(suggestion: Suggestion): Promise<Suggestion> {
    let res = await geoService.checkLocation(suggestionToLocation(suggestion));
    let location = res.data;
    return {
      ...suggestion,
      address: {
        ...suggestion.address,
        cityCode: location.cityCode,
        countyCode: location.countyAbbreviation,
      },
    };
  }

  // Attach the event listeners to the XMLHttpRequest object
  ajaxRequest.addEventListener("load", onAutoCompleteSuccess);
  ajaxRequest.addEventListener("error", onAutoCompleteFailed);
  ajaxRequest.responseType = "json";

  function onSubmitLocation(values: any) {
    selectSuggestion(toSuggestion(values), true);
    setIsLocationModalOpen(false);
  }

  useEffect(() => {
    if (isLocationModalOpen) {
      setAvailablePostalCodes([]);
    }
  }, [isLocationModalOpen]);

  function toSuggestion(values: any): Suggestion {
    let label = `Italia, ${values.cap}, ${values.birthPlaceComplete.name}, ${values.address} ${values.streetNumber}`;
    return {
      id: values.birthPlaceComplete.geoId,
      title: label,
      address: {
        county: values.birthPlaceComplete.county,
        countyCode: values.birthPlaceComplete.countyCode,
        city: values.birthPlaceComplete.name,
        street: values.address,
        postalCode: values.cap,
        houseNumber: values.streetNumber,
        label: label,
        countryName: "Italia",
        countryCode: "ITA",
      },
    };
  }

  return (
    <>
      <div className={classNames("yoga-form-input", className ?? "")}>
        <label htmlFor={`${id}.label`} className="block text-body-text text-base" data-qa="location-label">
          <div className="inline-flex text-primary text-sm font-medium">
            <FormattedMessage id={label} />
            {mandatoryLocationParams && "*"}
          </div>
          {ALLOWED_COUNTRY_NAMES.length > 0 && (
            <button
              data-qa="info-button"
              className="flex-none ml-2 text-primary w-6 h-6 align-bottom"
              onClick={(e) => {
                e.preventDefault();
                setIsModalOpen(true);
              }}
            >
              <InformationCircleIcon />
            </button>
          )}

          {disabled && <BanIcon className="w-6 text-action-disabled relative -bottom-9 float-right -left-4 cursor-not-allowed" />}
          <input
            id={`${id}.label`}
            name={id}
            type="text"
            autoComplete="off"
            ref={setSearchInput}
            data-qa="location-input"
            className={classnames(
              "h-12 focus:outline-none focus:border-primary rounded-lg tracking-wider py-3 px-4 text-base w-full shadow-inner",
              (error || mandatoryMissingParamsMessage?.length > 0) && disabled
                ? "bg-background-disabled border-2 border-error cursor-not-allowed text-action-disabled"
                : "",
              (error || mandatoryMissingParamsMessage?.length > 0) && !disabled ? "border-2 border-error bg-box-background text-body-text" : "",
              !(error || mandatoryMissingParamsMessage?.length > 0) && disabled
                ? "bg-background-disabled border-2 border-action-disabled cursor-not-allowed text-action-disabled"
                : "",
              !(error || mandatoryMissingParamsMessage?.length > 0) && !disabled ? "border-2 border-title-text bg-box-background text-body-text" : ""
            )}
            onChange={(e) => setAddress(e.target.value)}
            defaultValue={startLocation?.label}
            disabled={disabled}
            placeholder={intl.formatMessage({
              id: "searchLocationPlaceholder",
            })}
          />
          {(error || mandatoryMissingParamsMessage?.length > 0) && !disabled && (
            <ExclamationCircleIcon className="w-6 text-error relative -top-9 float-right -left-4" />
          )}
        </label>
        {(suggestions.length > 0 || isManualAddressVisible) && (
          <div
            ref={setPopperElement}
            style={styles.popper}
            {...attributes.popper}
            className={classnames(
              "bg-white",
              suggestions.length < 0 ? "bg-white" : "bg-white rounded-lg shadow z-40 border-2 border-primary mt-2 mb-2 overflow-hidden"
            )}
          >
            <ul className="overflow-y-auto rounded-md">
              {suggestions.map((suggestion) => (
                <li
                  key={suggestion.id}
                  className="p-3 bg-box-background text-body-text cursor-pointer hover:bg-background"
                  onClick={() => {
                    selectSuggestion(suggestion, false);
                  }}
                >
                  {suggestion.title}
                </li>
              ))}
              {isManualAddressVisible && (
                <li key="insert-manually-row" className="p-3 bg-box-background text-action-disabled">
                  <div className="flex items-center gap-x-2">
                    <FormattedMessage id="didNotFindResult" />
                    <YogaButton
                      position="inner"
                      kind="default"
                      outline={true}
                      type="button"
                      data-qa="insert-manually-button"
                      className="px-2 py-1"
                      action={() => {
                        setSuggestions([]);
                        setIsManualAddressVisible(false);
                        setIsLocationModalOpen(true);
                      }}
                    >
                      <FormattedMessage id="insertManually" />
                    </YogaButton>
                  </div>
                </li>
              )}
            </ul>
          </div>
        )}

        {hasErrorsOnTouched(form) && (
          <div className="h-6">
            {error?.length > 0 && <span className="block text-base text-error">{error}</span>}

            {mandatoryMissingParamsMessage?.length > 0 && (
              <span className="block text-base text-error" id="incompleteAddressError" data-qa="incompleteAddressError">
                {mandatoryMissingParamsMessage}
              </span>
            )}
          </div>
        )}
      </div>

      {ALLOWED_COUNTRY_NAMES.length > 0 && (
        <YogaModal
          isOpen={isModalOpen}
          onClose={() => {
            setIsModalOpen(false);
          }}
          title="allowedCountriesTitle"
        >
          {message}
        </YogaModal>
      )}
      <YogaModal
        isOpen={isLocationModalOpen}
        onClose={() => {
          setIsLocationModalOpen(false);
          setAvailablePostalCodes([]);
        }}
        title="insertLocation"
      >
        <Formik
          initialValues={{
            birthPlace: "",
            birthPlaceComplete: {
              name: "",
              countyCode: "",
              county: "",
              istatCode: "",
            },
            cap: "",
            address: "",
            streetNumber: "",
          }}
          validationSchema={Yup.object().shape({
            birthPlace: Yup.string().required(requiredMessage),
            cap: Yup.string().required(requiredMessage),
            address: Yup.string().required(requiredMessage),
          })}
          onSubmit={onSubmitLocation}
        >
          {(props: any) => (
            <Form id="manualLocationForm">
              <div className="grid grid-cols-3 gap-x-8 gap-y-4">
                <div className="col-span-2 shrink self-end">
                  <Field
                    placeholder={intl.formatMessage({
                      id: "searchBirthplace",
                    })}
                    key="birthPlace"
                    name="birthPlace"
                    component={FormikInput}
                    content={{
                      name: "birthPlace",
                      value: "",
                      mandatory: true,
                      label: "municipality",
                      type: "CITY",
                    }}
                    values={props.values}
                    fieldName="birthPlace"
                    setAvailablePostalCodes={setAvailablePostalCodes}
                  />
                </div>
                <div className=" self-end">
                  <Field
                    key="cap"
                    name="cap"
                    component={FormikInput}
                    content={{
                      name: "cap",
                      value: "",
                      mandatory: true,
                      label: "zipCode",
                      type: "LIST",
                      availableValues: availablePostalCodes,
                      disableBinarySelect: true,
                    }}
                    disabled={availablePostalCodes.length == 0}
                    values={props.values}
                    autoselect
                    fieldName="cap"
                  />
                </div>
                <div className="col-span-2 self-end">
                  <Field
                    key="address"
                    name="address"
                    component={FormikInput}
                    placeholder={intl.formatMessage({
                      id: "addressPlaceholder",
                    })}
                    content={{
                      name: "address",
                      value: "",
                      mandatory: true,
                      label: "address",
                      type: "STRING",
                    }}
                    values={props.values}
                    fieldName="address"
                  />
                </div>
                <div className=" self-end">
                  <Field
                    key="streetNumber"
                    name="streetNumber"
                    component={FormikInput}
                    content={{
                      name: "streetNumber",
                      value: "",
                      mandatory: true,
                      label: "streetNumber",
                      type: "STRING",
                    }}
                    values={props.values}
                    fieldName="streetNumber"
                  />
                </div>
              </div>

              <div className="mt-8 flex gap-4 justify-end w-full">
                <YogaButton
                  data-qa="cancel-button"
                  kind="default"
                  type="button"
                  position="outer"
                  outline
                  action={() => {
                    setIsLocationModalOpen(false);
                    setAvailablePostalCodes([]);
                  }}
                >
                  <FormattedMessage id="cancel" />
                </YogaButton>
                <YogaButton data-qa="confirm-button" kind="default" type="submit" position="outer">
                  <FormattedMessage id="confirm" />
                </YogaButton>
              </div>
            </Form>
          )}
        </Formik>
      </YogaModal>
    </>
  );
};

const ALL_COUNTRIES = [
  {
    name: "Afghanistan",
    code: "AFG",
  },
  {
    name: "Albania",
    code: "ALB",
  },
  {
    name: "Algeria",
    code: "DZA",
  },
  {
    name: "American Samoa",
    code: "ASM",
  },
  {
    name: "Andorra",
    code: "AND",
  },
  {
    name: "Angola",
    code: "AGO",
  },
  {
    name: "Anguilla",
    code: "AIA",
  },
  {
    name: "Antarctica",
    code: "ATA",
  },
  {
    name: "Antigua and Barbuda",
    code: "ATG",
  },
  {
    name: "Argentina",
    code: "ARG",
  },
  {
    name: "Armenia",
    code: "ARM",
  },
  {
    name: "Aruba",
    code: "ABW",
  },
  {
    name: "Australia",
    code: "AUS",
  },
  {
    name: "Austria",
    code: "AUT",
  },
  {
    name: "Azerbaijan",
    code: "AZE",
  },
  {
    name: "Bahamas",
    code: "BHS",
  },
  {
    name: "Bahrain",
    code: "BHR",
  },
  {
    name: "Bangladesh",
    code: "BGD",
  },
  {
    name: "Barbados",
    code: "BRB",
  },
  {
    name: "Belarus",
    code: "BLR",
  },
  {
    name: "Belgium",
    code: "BEL",
  },
  {
    name: "Belize",
    code: "BLZ",
  },
  {
    name: "Benin",
    code: "BEN",
  },
  {
    name: "Bermuda",
    code: "BMU",
  },
  {
    name: "Bhutan",
    code: "BTN",
  },
  {
    name: "Bolivia",
    code: "BOL",
  },
  {
    name: "Bosnia and Herzegovina",
    code: "BIH",
  },
  {
    name: "Botswana",
    code: "BWA",
  },
  {
    name: "Brazil",
    code: "BRA",
  },
  {
    name: "British Indian Ocean Territory",
    code: "IOT",
  },
  {
    name: "British Virgin Islands",
    code: "VGB",
  },
  {
    name: "Brunei",
    code: "BRN",
  },
  {
    name: "Bulgaria",
    code: "BGR",
  },
  {
    name: "Burkina Faso",
    code: "BFA",
  },
  {
    name: "Burundi",
    code: "BDI",
  },
  {
    name: "Cambodia",
    code: "KHM",
  },
  {
    name: "Cameroon",
    code: "CMR",
  },
  {
    name: "Canada",
    code: "CAN",
  },
  {
    name: "Cape Verde",
    code: "CPV",
  },
  {
    name: "Cayman Islands",
    code: "CYM",
  },
  {
    name: "Central African Republic",
    code: "CAF",
  },
  {
    name: "Chad",
    code: "TCD",
  },
  {
    name: "Chile",
    code: "CHL",
  },
  {
    name: "China",
    code: "CHN",
  },
  {
    name: "Christmas Island",
    code: "CXR",
  },
  {
    name: "Cocos Islands",
    code: "CCK",
  },
  {
    name: "Colombia",
    code: "COL",
  },
  {
    name: "Comoros",
    code: "COM",
  },
  {
    name: "Cook Islands",
    code: "COK",
  },
  {
    name: "Costa Rica",
    code: "CRI",
  },
  {
    name: "Croatia",
    code: "HRV",
  },
  {
    name: "Cuba",
    code: "CUB",
  },
  {
    name: "Curacao",
    code: "CUW",
  },
  {
    name: "Cyprus",
    code: "CYP",
  },
  {
    name: "Czech Republic",
    code: "CZE",
  },
  {
    name: "Democratic Republic of the Congo",
    code: "COD",
  },
  {
    name: "Denmark",
    code: "DNK",
  },
  {
    name: "Djibouti",
    code: "DJI",
  },
  {
    name: "Dominica",
    code: "DMA",
  },
  {
    name: "Dominican Republic",
    code: "DOM",
  },
  {
    name: "East Timor",
    code: "TLS",
  },
  {
    name: "Ecuador",
    code: "ECU",
  },
  {
    name: "Egypt",
    code: "EGY",
  },
  {
    name: "El Salvador",
    code: "SLV",
  },
  {
    name: "Equatorial Guinea",
    code: "GNQ",
  },
  {
    name: "Eritrea",
    code: "ERI",
  },
  {
    name: "Estonia",
    code: "EST",
  },
  {
    name: "Ethiopia",
    code: "ETH",
  },
  {
    name: "Falkland Islands",
    code: "FLK",
  },
  {
    name: "Faroe Islands",
    code: "FRO",
  },
  {
    name: "Fiji",
    code: "FJI",
  },
  {
    name: "Finland",
    code: "FIN",
  },
  {
    name: "France",
    code: "FRA",
  },
  {
    name: "French Polynesia",
    code: "PYF",
  },
  {
    name: "Gabon",
    code: "GAB",
  },
  {
    name: "Gambia",
    code: "GMB",
  },
  {
    name: "Georgia",
    code: "GEO",
  },
  {
    name: "Germany",
    code: "DEU",
  },
  {
    name: "Ghana",
    code: "GHA",
  },
  {
    name: "Gibraltar",
    code: "GIB",
  },
  {
    name: "Greece",
    code: "GRC",
  },
  {
    name: "Greenland",
    code: "GRL",
  },
  {
    name: "Grenada",
    code: "GRD",
  },
  {
    name: "Guam",
    code: "GUM",
  },
  {
    name: "Guatemala",
    code: "GTM",
  },
  {
    name: "Guernsey",
    code: "GGY",
  },
  {
    name: "Guinea",
    code: "GIN",
  },
  {
    name: "Guinea-Bissau",
    code: "GNB",
  },
  {
    name: "Guyana",
    code: "GUY",
  },
  {
    name: "Haiti",
    code: "HTI",
  },
  {
    name: "Honduras",
    code: "HND",
  },
  {
    name: "Hong Kong",
    code: "HKG",
  },
  {
    name: "Hungary",
    code: "HUN",
  },
  {
    name: "Iceland",
    code: "ISL",
  },
  {
    name: "India",
    code: "IND",
  },
  {
    name: "Indonesia",
    code: "IDN",
  },
  {
    name: "Iran",
    code: "IRN",
  },
  {
    name: "Iraq",
    code: "IRQ",
  },
  {
    name: "Ireland",
    code: "IRL",
  },
  {
    name: "Isle of Man",
    code: "IMN",
  },
  {
    name: "Israel",
    code: "ISR",
  },
  {
    name: "Italy",
    code: "ITA",
  },
  {
    name: "Ivory Coast",
    code: "CIV",
  },
  {
    name: "Jamaica",
    code: "JAM",
  },
  {
    name: "Japan",
    code: "JPN",
  },
  {
    name: "Jersey",
    code: "JEY",
  },
  {
    name: "Jordan",
    code: "JOR",
  },
  {
    name: "Kazakhstan",
    code: "KAZ",
  },
  {
    name: "Kenya",
    code: "KEN",
  },
  {
    name: "Kiribati",
    code: "KIR",
  },
  {
    name: "Kosovo",
    code: "XKX",
  },
  {
    name: "Kuwait",
    code: "KWT",
  },
  {
    name: "Kyrgyzstan",
    code: "KGZ",
  },
  {
    name: "Laos",
    code: "LAO",
  },
  {
    name: "Latvia",
    code: "LVA",
  },
  {
    name: "Lebanon",
    code: "LBN",
  },
  {
    name: "Lesotho",
    code: "LSO",
  },
  {
    name: "Liberia",
    code: "LBR",
  },
  {
    name: "Libya",
    code: "LBY",
  },
  {
    name: "Liechtenstein",
    code: "LIE",
  },
  {
    name: "Lithuania",
    code: "LTU",
  },
  {
    name: "Luxembourg",
    code: "LUX",
  },
  {
    name: "Macau",
    code: "MAC",
  },
  {
    name: "Macedonia",
    code: "MKD",
  },
  {
    name: "Madagascar",
    code: "MDG",
  },
  {
    name: "Malawi",
    code: "MWI",
  },
  {
    name: "Malaysia",
    code: "MYS",
  },
  {
    name: "Maldives",
    code: "MDV",
  },
  {
    name: "Mali",
    code: "MLI",
  },
  {
    name: "Malta",
    code: "MLT",
  },
  {
    name: "Marshall Islands",
    code: "MHL",
  },
  {
    name: "Mauritania",
    code: "MRT",
  },
  {
    name: "Mauritius",
    code: "MUS",
  },
  {
    name: "Mayotte",
    code: "MYT",
  },
  {
    name: "Mexico",
    code: "MEX",
  },
  {
    name: "Micronesia",
    code: "FSM",
  },
  {
    name: "Moldova",
    code: "MDA",
  },
  {
    name: "Monaco",
    code: "MCO",
  },
  {
    name: "Mongolia",
    code: "MNG",
  },
  {
    name: "Montenegro",
    code: "MNE",
  },
  {
    name: "Montserrat",
    code: "MSR",
  },
  {
    name: "Morocco",
    code: "MAR",
  },
  {
    name: "Mozambique",
    code: "MOZ",
  },
  {
    name: "Myanmar",
    code: "MMR",
  },
  {
    name: "Namibia",
    code: "NAM",
  },
  {
    name: "Nauru",
    code: "NRU",
  },
  {
    name: "Nepal",
    code: "NPL",
  },
  {
    name: "Netherlands",
    code: "NLD",
  },
  {
    name: "Netherlands Antilles",
    code: "ANT",
  },
  {
    name: "New Caledonia",
    code: "NCL",
  },
  {
    name: "New Zealand",
    code: "NZL",
  },
  {
    name: "Nicaragua",
    code: "NIC",
  },
  {
    name: "Niger",
    code: "NER",
  },
  {
    name: "Nigeria",
    code: "NGA",
  },
  {
    name: "Niue",
    code: "NIU",
  },
  {
    name: "North Korea",
    code: "PRK",
  },
  {
    name: "Northern Mariana Islands",
    code: "MNP",
  },
  {
    name: "Norway",
    code: "NOR",
  },
  {
    name: "Oman",
    code: "OMN",
  },
  {
    name: "Pakistan",
    code: "PAK",
  },
  {
    name: "Palau",
    code: "PLW",
  },
  {
    name: "Palestine",
    code: "PSE",
  },
  {
    name: "Panama",
    code: "PAN",
  },
  {
    name: "Papua New Guinea",
    code: "PNG",
  },
  {
    name: "Paraguay",
    code: "PRY",
  },
  {
    name: "Peru",
    code: "PER",
  },
  {
    name: "Philippines",
    code: "PHL",
  },
  {
    name: "Pitcairn",
    code: "PCN",
  },
  {
    name: "Poland",
    code: "POL",
  },
  {
    name: "Portugal",
    code: "PRT",
  },
  {
    name: "Puerto Rico",
    code: "PRI",
  },
  {
    name: "Qatar",
    code: "QAT",
  },
  {
    name: "Republic of the Congo",
    code: "COG",
  },
  {
    name: "Reunion",
    code: "REU",
  },
  {
    name: "Romania",
    code: "ROU",
  },
  {
    name: "Russia",
    code: "RUS",
  },
  {
    name: "Rwanda",
    code: "RWA",
  },
  {
    name: "Saint Barthelemy",
    code: "BLM",
  },
  {
    name: "Saint Helena",
    code: "SHN",
  },
  {
    name: "Saint Kitts and Nevis",
    code: "KNA",
  },
  {
    name: "Saint Lucia",
    code: "LCA",
  },
  {
    name: "Saint Martin",
    code: "MAF",
  },
  {
    name: "Saint Pierre and Miquelon",
    code: "SPM",
  },
  {
    name: "Saint Vincent and the Grenadines",
    code: "VCT",
  },
  {
    name: "Samoa",
    code: "WSM",
  },
  {
    name: "San Marino",
    code: "SMR",
  },
  {
    name: "Sao Tome and Principe",
    code: "STP",
  },
  {
    name: "Saudi Arabia",
    code: "SAU",
  },
  {
    name: "Senegal",
    code: "SEN",
  },
  {
    name: "Serbia",
    code: "SRB",
  },
  {
    name: "Seychelles",
    code: "SYC",
  },
  {
    name: "Sierra Leone",
    code: "SLE",
  },
  {
    name: "Singapore",
    code: "SGP",
  },
  {
    name: "Sint Maarten",
    code: "SXM",
  },
  {
    name: "Slovakia",
    code: "SVK",
  },
  {
    name: "Slovenia",
    code: "SVN",
  },
  {
    name: "Solomon Islands",
    code: "SLB",
  },
  {
    name: "Somalia",
    code: "SOM",
  },
  {
    name: "South Africa",
    code: "ZAF",
  },
  {
    name: "South Korea",
    code: "KOR",
  },
  {
    name: "South Sudan",
    code: "SSD",
  },
  {
    name: "Spain",
    code: "ESP",
  },
  {
    name: "Sri Lanka",
    code: "LKA",
  },
  {
    name: "Sudan",
    code: "SDN",
  },
  {
    name: "Suriname",
    code: "SUR",
  },
  {
    name: "Svalbard and Jan Mayen",
    code: "SJM",
  },
  {
    name: "Swaziland",
    code: "SWZ",
  },
  {
    name: "Sweden",
    code: "SWE",
  },
  {
    name: "Switzerland",
    code: "CHE",
  },
  {
    name: "Syria",
    code: "SYR",
  },
  {
    name: "Taiwan",
    code: "TWN",
  },
  {
    name: "Tajikistan",
    code: "TJK",
  },
  {
    name: "Tanzania",
    code: "TZA",
  },
  {
    name: "Thailand",
    code: "THA",
  },
  {
    name: "Togo",
    code: "TGO",
  },
  {
    name: "Tokelau",
    code: "TKL",
  },
  {
    name: "Tonga",
    code: "TON",
  },
  {
    name: "Trinidad and Tobago",
    code: "TTO",
  },
  {
    name: "Tunisia",
    code: "TUN",
  },
  {
    name: "Turkey",
    code: "TUR",
  },
  {
    name: "Turkmenistan",
    code: "TKM",
  },
  {
    name: "Turks and Caicos Islands",
    code: "TCA",
  },
  {
    name: "Tuvalu",
    code: "TUV",
  },
  {
    name: "U.S. Virgin Islands",
    code: "VIR",
  },
  {
    name: "Uganda",
    code: "UGA",
  },
  {
    name: "Ukraine",
    code: "UKR",
  },
  {
    name: "United Arab Emirates",
    code: "ARE",
  },
  {
    name: "United Kingdom",
    code: "GBR",
  },
  {
    name: "United States",
    code: "USA",
  },
  {
    name: "Uruguay",
    code: "URY",
  },
  {
    name: "Uzbekistan",
    code: "UZB",
  },
  {
    name: "Vanuatu",
    code: "VUT",
  },
  {
    name: "Vatican",
    code: "VAT",
  },
  {
    name: "Venezuela",
    code: "VEN",
  },
  {
    name: "Vietnam",
    code: "VNM",
  },
  {
    name: "Wallis and Futuna",
    code: "WLF",
  },
  {
    name: "Western Sahara",
    code: "ESH",
  },
  {
    name: "Yemen",
    code: "YEM",
  },
  {
    name: "Zambia",
    code: "ZMB",
  },
  {
    name: "Zimbabwe",
    code: "ZWE",
  },
];

const ALL_COUNTRY_CODES = ALL_COUNTRIES.map((country) => country.code);

function getAllowedCountries(): string[] {
  return (config.ADDRESS_ALLOWED_COUNTRIES ?? "")
    .split(",")
    .map((country) => country.trim().toUpperCase())
    .filter((country) => ALL_COUNTRY_CODES.includes(country));
}

const ALLOWED_COUNTRY_CODES = getAllowedCountries();

const ALLOWED_COUNTRY_NAMES = ALL_COUNTRIES.filter((country) => ALLOWED_COUNTRY_CODES.includes(country.code)).map((country) => country.name);
