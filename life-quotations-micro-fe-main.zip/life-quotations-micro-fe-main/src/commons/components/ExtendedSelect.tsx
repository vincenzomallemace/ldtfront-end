import Select, { components } from "react-select";
import {
  BanIcon,
  CheckCircleIcon,
  ChevronDownIcon,
} from "@heroicons/react/solid";
import classnames from "classnames";
import { KeyValue } from "commons/models/YogaModels";

interface SelectProps<T extends { value: string; label: string }> {
  values: T[];
  selected: T;
  onUpdate: (selected: T) => void;
  disabled?: boolean;
  id: string;
  options?: KeyValue<any>;
}

export function ExtendedSelect<T extends { value: string; label: string }>({
  id,
  values,
  selected,
  onUpdate,
  options = { clearable: false },
  disabled = false,
}: SelectProps<T>) {
  const { Option } = components;
  const customOption = (props: any) => {
    // eslint-disable-next-line react/prop-types
    const label = props.data.label;
    // eslint-disable-next-line react/prop-types
    if (props.isSelected)
      return (
        <Option {...props}>
          {label}
          <CheckCircleIcon className="w-6 h-6" />
        </Option>
      );
    else return <Option {...props}>{label}</Option>;
  };

  const DropdownIndicator = (props: any) => {
    return (
      <components.DropdownIndicator {...props}>
        {disabled ? (
          <BanIcon className="w-6 h-6 text-action-disabled" />
        ) : (
          <ChevronDownIcon className="w-6 h-6 text-body-text" />
        )}
      </components.DropdownIndicator>
    );
  };

  const selectClasses = classnames({
    "rounded-lg border-2": true,
    "border-body-text": !disabled,
    "border-action-disabled": disabled,
    "text-body-text bg-box-background": !disabled,
    "text-action-disabled bg-background-disabled": disabled,
  });

  return (
    <div data-qa={`${id}-select`} className="w-full">
      <Select
        className={selectClasses}
        classNamePrefix="custom-select"
        placeholder=""
        id={id}
        components={{ Option: customOption, DropdownIndicator }}
        options={values}
        onChange={(selected) => {
          onUpdate(selected);
        }}
        defaultValue={selected}
        isClearable={options.clearable}
        isDisabled={disabled}
      />
    </div>
  );
}
