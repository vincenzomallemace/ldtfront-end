import { Money } from "commons/models/YogaModels";
import { FormattedNumber } from "react-intl";

export default function FormattedMoney({ money }: { money: Money }) {
  return (
    <FormattedNumber
      value={money.amount as number}
      currency={money.currency || "EUR"}
      style="currency"
    />
  );
}
