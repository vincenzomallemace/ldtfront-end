import { Dialog, Transition } from "@headlessui/react";
import { XIcon } from "@heroicons/react/outline";
import classname from "classnames";
import { Fragment, PropsWithChildren } from "react";
import { FormattedMessage } from "react-intl";

interface YogaModalProps extends PropsWithChildren<any> {
  isOpen: boolean;
  onClose: () => void;
  title: string | JSX.Element;
  closeClickOutside?: boolean;
  className?: any;
}

export function YogaModal({ isOpen, onClose, title, children, className, closeClickOutside = true, ...props }: YogaModalProps) {
  return (
    <Transition appear show={isOpen} as={Fragment}>
      <Dialog {...props} as="div" className="life-quotation-mfe fixed inset-0 z-60" onClose={closeClickOutside ? onClose : () => {}}>
        {/* Use the overlay to style a dim backdrop for your dialog */}
        <Dialog.Overlay className="fixed inset-0 bg-modal-background bg-opacity-50" />
        <div className="min-h-screen px-4 text-center flex justify-center items-center">
          <Transition.Child
            as={Fragment}
            enter="ease-out duration-300"
            enterFrom="opacity-0"
            enterTo="opacity-100"
            leave="ease-in duration-200"
            leaveFrom="opacity-100"
            leaveTo="opacity-0"
          >
            <Dialog.Overlay className="fixed inset-0" />
          </Transition.Child>

          {/* This element is to trick the browser into centering the modal contents. */}
          <span className="inline-block h-screen align-middle" aria-hidden="true">
            &#8203;
          </span>
          <Transition.Child
            as={Fragment}
            enter="ease-out duration-300"
            enterFrom="opacity-0 scale-95"
            enterTo="opacity-100 scale-100"
            leave="ease-in duration-200"
            leaveFrom="opacity-100 scale-100"
            leaveTo="opacity-0 scale-95"
          >
            <div
              data-qa="yoga-modal"
              className={classname("text-left transition-all transform bg-white shadow-xl rounded-2xl confirm-dialog min-w-1/2 max-w-7xl", className)}
            >
              <Dialog.Title as="div" className="pt-8 px-8 flex justify-between text-xl font-bold text-title-text">
                <span data-qa="modal-title">
                  <>
                    {typeof title === "string" && <FormattedMessage id={title} />}
                    {typeof title === "object" && { title }}
                  </>
                </span>
                <span>
                  <button title="modal-close" data-qa="modal-close-button" onClick={onClose}>
                    <XIcon className="w-8 cursor-pointer" />
                  </button>
                </span>
              </Dialog.Title>
              <div data-qa="modal-body" className="px-8 pb-8 overflow-auto text-body-text">
                {children}
              </div>
            </div>
          </Transition.Child>
        </div>
      </Dialog>
    </Transition>
  );
}
