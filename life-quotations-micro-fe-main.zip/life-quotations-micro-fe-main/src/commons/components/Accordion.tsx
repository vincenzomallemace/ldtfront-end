import { CheckCircleIcon, ChevronDownIcon, ChevronUpIcon, ExclamationIcon } from "@heroicons/react/outline";
import classnames from "classnames";
import { transformObjectToDotNotation } from "commons/FormUtils";
import { useFormikContext } from "formik";
import React, { ReactNode, useEffect, useMemo, useRef, useState } from "react";

interface AccordionProps extends React.HTMLAttributes<HTMLDivElement> {
  accordionTitle: ReactNode;
  open?: boolean;
  disabled?: boolean;
  name?: string;
  className?: string;
  titleContainerClasses?: string;
  bordered?: boolean;
  withStatus?: boolean;
  withDivider?: boolean;
  arrowColor?: string;
}

export function Accordion({
  accordionTitle,
  open = false,
  disabled = false,
  className,
  children,
  name = "",
  titleContainerClasses = "",
  bordered,
  withStatus,
  withDivider = true,
  arrowColor = "text-primary hover:text-hover-primary",
}: AccordionProps) {
  const [isOpen, setIsOpen] = useState(disabled || open);
  const [hasErrors, setHasErrors] = useState(false);
  const formikContext = useFormikContext();
  const accordionBody = useRef<HTMLDivElement>(null);

  const hasValidChildren = useMemo(() => React.Children.map(children, (child) => !!child).some((val) => val === true), [children]);

  useEffect(() => {
    setIsOpen(open);
    if (open) {
      accordionBody.current?.classList.remove("hidden");
      accordionBody.current?.classList.add("block");
    } else {
      accordionBody.current?.classList.add("hidden");
      accordionBody.current?.classList.remove("block");
    }
  }, [open]);

  useEffect(() => {
    if (withStatus && formikContext?.errors) {
      const fieldNames = transformObjectToDotNotation(formikContext?.errors);
      for (const name of fieldNames) {
        const element = document.getElementById(name);
        if (!element) continue;
        if (accordionBody.current?.contains(element)) {
          setHasErrors(true);
          return;
        }
      }
      setHasErrors(false);
    }
  }, [formikContext?.errors]);

  function toggleOpen() {
    const bOpen = !isOpen;
    if (!disabled) {
      setIsOpen(bOpen);
      if (bOpen) {
        accordionBody.current?.classList.remove("hidden");
        accordionBody.current?.classList.add("block");
        accordionBody.current?.scrollIntoView({
          behavior: "smooth",
          block: "center",
        });
      } else {
        accordionBody.current?.classList.add("hidden");
        accordionBody.current?.classList.remove("block");
      }
    }
  }

  return (
    <>
      <div className={classnames("flex", className, bordered ? "border-2 rounded-lg" : "")} data-qa={"accordion" + (name ? "-" + name : "")}>
        <div className="flex flex-col mb-2">
          {withDivider && <span className="middle-border-accordion mb-2"></span>}
          <div
            className={classnames(
              "inline-flex w-full items-center",
              hasValidChildren && !disabled ? "cursor-pointer" : "cursor-auto",
              titleContainerClasses
            )}
            onClick={toggleOpen}
          >
            <div className="flex-1 inline-flex gap-2 items-center">
              {withStatus && hasErrors && <ExclamationIcon className="h-6 w-6 text-error" />}
              {withStatus && !hasErrors && <CheckCircleIcon className="h-6 w-6 text-success" />}
              {accordionTitle}
            </div>
            {hasValidChildren && !disabled && (
              <button type="button" className={classnames(arrowColor, bordered ? "mr-4" : "")}>
                {isOpen ? <ChevronUpIcon className="h-6 w-6" /> : <ChevronDownIcon className="h-6 w-6" />}
              </button>
            )}
          </div>
        </div>
        <div className="hidden mb-4 px-2" ref={accordionBody} data-qa={"accordion-body" + (name ? "-" + name : "")}>
          {children}
        </div>
      </div>
    </>
  );
}
