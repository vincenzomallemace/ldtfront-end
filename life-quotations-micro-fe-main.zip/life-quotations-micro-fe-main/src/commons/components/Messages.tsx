import { KeyValue } from "commons/models/YogaModels";
import { useMemo } from "react";
import { YogaMessage } from "./YogaMessage";
import { FormattedMessage } from "react-intl";

export const scrollToProductMessages = () => document.getElementById("product-messages")?.scrollIntoView({ behavior: "smooth", block: "center" });
export const scrollToContractMessages = () => document.getElementById("contract-messages")?.scrollIntoView({ behavior: "smooth", block: "center" });

interface MessagesProps {
  messages: KeyValue<string[]>;
  entity: "product" | "contract";
}

export default function Messages({ messages, entity }: MessagesProps) {
  const errors = useMemo(() => {
    // eslint-disable-next-line no-prototype-builtins
    if (messages?.hasOwnProperty("errors")) {
      return messages.errors;
    }
    return [];
  }, [messages]);

  const danger = useMemo(() => {
    // eslint-disable-next-line no-prototype-builtins
    if (messages?.hasOwnProperty("danger")) {
      return messages.danger;
    }
    return [];
  }, [messages]);

  const info = useMemo(() => {
    // eslint-disable-next-line no-prototype-builtins
    if (messages?.hasOwnProperty("info")) {
      return messages.info;
    }
    return [];
  }, [messages]);

  const failures = useMemo(() => {
    // eslint-disable-next-line no-prototype-builtins
    if (messages?.hasOwnProperty("failures")) {
      return messages.failures;
    }
    return [];
  }, [messages]);

  return (
    <>
      {(failures.length > 0 || errors.length > 0 || danger.length > 0 || info.length > 0) && (
        <div id={`${entity}-messages`} data-qa={`${entity}-messages`} className="flex flex-col gap-y-4 mb-4">
          {failures && failures.length > 0 && (
            <div id={`${entity}-failures`} data-qa={`${entity}-failures`} className="flex flex-col gap-y-4">
              {failures.map((failure, index) => {
                return (
                  <YogaMessage type="error" position="outer" key={index}>
                    <p data-qa={failure}>
                      <FormattedMessage id={failure} />
                    </p>
                  </YogaMessage>
                );
              })}
            </div>
          )}
          {errors && errors.length > 0 && (
            <div id={`${entity}-errors`} data-qa={`${entity}-errors`} className="flex flex-col gap-y-4">
              {errors.map((error, index) => {
                return (
                  <YogaMessage type="error" position="outer" key={index}>
                    <p data-qa={error}>
                      <FormattedMessage id={error} />
                    </p>
                  </YogaMessage>
                );
              })}
            </div>
          )}
          {danger && danger.length > 0 && (
            <div id={`${entity}-danger`} data-qa={`${entity}-danger`} className="flex flex-col gap-y-4">
              {danger.map((danger, index) => {
                return (
                  <YogaMessage type="danger" position="outer" key={index}>
                    <p data-qa={danger}>
                      <FormattedMessage id={danger} />
                    </p>
                  </YogaMessage>
                );
              })}
            </div>
          )}
          {info && info.length > 0 && (
            <div id={`${entity}-info`} data-qa={`${entity}-info`} className="flex flex-col gap-y-4">
              {info.map((info, index) => {
                return (
                  <YogaMessage type="info" position="outer" key={index}>
                    <p data-qa={info}>
                      <FormattedMessage id={info} />
                    </p>
                  </YogaMessage>
                );
              })}
            </div>
          )}
        </div>
      )}
    </>
  );
}
