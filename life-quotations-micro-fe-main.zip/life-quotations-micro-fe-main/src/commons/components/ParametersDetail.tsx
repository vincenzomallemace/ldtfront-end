import { groupKeyValueParamsByTag } from "commons/Utils";
import { KeyValue } from "commons/models/YogaModels";
import { YogaParam } from "commons/models/YogaParam";
import { useMemo } from "react";
import { FormattedMessage } from "react-intl";
import ParameterBox from "./ParameterBox";
import { Accordion } from "./Accordion";

interface ParametersDetailProps {
  parameters: KeyValue<YogaParam>;
  isOpen?: boolean;
}

export default function ParametersDetail({ parameters, isOpen = true }: ParametersDetailProps) {
  const parametersByTag = useMemo(() => {
    if (Object.keys(parameters)?.length > 0) return groupKeyValueParamsByTag(parameters);
    else return undefined;
  }, [parameters]);

  return (
    <>
      {parametersByTag &&
        Object.entries(parametersByTag).map(([tag, params]) =>
          tag === "noTags" ? (
            <div key={`${tag}-section`} className="grid grid-cols-2 lg:grid-cols-3 gap-4 mb-4" data-qa={`${tag}-container`}>
              {params
                .filter((param) => param.visible)
                .filter((param) => !param.code.endsWith("hidden"))
                .map((param) => (
                  <ParameterBox key={param.key} label={param.name} value={param.value as any} type={param.type} currency="EUR" />
                ))}
            </div>
          ) : (
            <Accordion
              name={`${tag}-section`}
              open={isOpen}
              className="flex flex-col gap-2 border-t-2 border-background last-of-type:border-b-2 "
              titleContainerClasses=""
              accordionTitle={
                <h4 className="text-title-text whitespace-nowrap py-2">
                  <FormattedMessage id={tag} />
                </h4>
              }
              key={`${tag}-section`}
            >
              <div key={`${tag}-section`} data-qa={`${tag}-container`} className="grid grid-cols-2 lg:grid-cols-3 gap-4 mb-4">
                {params
                  .filter((param) => param.visible)
                  .filter((param) => !param.code.endsWith("hidden"))
                  .map((param) => (
                    <ParameterBox key={param.key} label={param.name} value={param.value as any} type={param.type} currency="EUR" />
                  ))}
              </div>
            </Accordion>
          )
        )}
    </>
  );
}
