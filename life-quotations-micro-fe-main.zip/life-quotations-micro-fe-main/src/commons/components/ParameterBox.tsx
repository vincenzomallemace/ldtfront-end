import { EMPTY } from "commons/Utils";
import { FormattedDate, FormattedMessage, FormattedNumber } from "react-intl";

interface SingleDataProps {
  label: string;
  value: string;
  type?: string;
  currency?: string;
}
export default function ParameterBox({
  label,
  value,
  type = "STRING",
  currency = "EUR",
}: SingleDataProps) {
  function displayValue(value) {
    if (type === "DATE") {
      return (
        <FormattedDate
          value={value}
          year="numeric"
          month="2-digit"
          day="2-digit"
        />
      );
    } else if (type === "AMOUNT") {
      return (
        <FormattedNumber
          value={value as number}
          currency={currency}
          style="currency"
        />
      );
    } else return <FormattedMessage id={value || "-"} />;
  }

  return (
    <div className="flex flex-col px-4 py-1 border-2 border-background rounded-lg justify-start">
      <span data-qa={`${label}-label`}>
        <FormattedMessage id={label || EMPTY} />
      </span>
      <span className="font-bold leading-5" data-qa={`${label}-value`}>
        {displayValue(value)}
      </span>
    </div>
  );
}
