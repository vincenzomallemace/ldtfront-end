import Skeleton, { SkeletonProps } from "react-loading-skeleton";
import "react-loading-skeleton/dist/skeleton.css";

interface YogaSkeletonProps extends SkeletonProps {
  position: "inner" | "outer";
}

export default function YogaSkeleton({
  position,
  ...props
}: YogaSkeletonProps) {
  return (
    <>
      {position === "outer" ? (
        <Skeleton
          {...props}
          baseColor="var(--bg-skeleton-outer)"
          highlightColor="var(--highlight-skeleton-outer)"
        />
      ) : (
        <Skeleton
          {...props}
          baseColor="var(--bg-skeleton-inner)"
          highlightColor="var(--highlight-skeleton-inner)"
        />
      )}
    </>
  );
}
