import { InformationCircleIcon } from "@heroicons/react/outline";
import { EMPTY, groupKeyValueParamsByTag } from "commons/Utils";
import { DetailsModal } from "commons/modals/DetailsModal";
import { ContractContractualOption } from "offers/models/ContractualOption";
import { useState } from "react";
import { FormattedMessage } from "react-intl";
import { Accordion } from "./Accordion";
import ParameterBox from "./ParameterBox";

export default function ContractualOptionBox({ contractualOption, open = false }: { contractualOption: ContractContractualOption; open?: boolean }) {
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);

  const handleModalOpen = (event: React.MouseEvent<HTMLButtonElement>) => {
    event.stopPropagation();
    setIsModalOpen(true);
  };

  return (
    <>
      {Object.values(contractualOption.parameters)?.some((param) => param.visible) ? (
        <Accordion
          open={open}
          name={`${contractualOption.code}-option-parameters`}
          data-qa={`${contractualOption.code}-option-accordion`}
          className="flex flex-col bg-box-background overflow-hidden w-full rounded-lg"
          titleContainerClasses="p-4"
          accordionTitle={
            <div className="flex items-center gap-x-2">
              <h4 data-qa={`${contractualOption.code}-option-name`}>
                <FormattedMessage id={contractualOption.name || EMPTY} />
              </h4>
              {contractualOption.description && (
                <button
                  type="button"
                  className="text-primary w-6 h-6 cursor-pointer"
                  data-qa={`${contractualOption.code}-info`}
                  onClick={handleModalOpen}
                >
                  <InformationCircleIcon />
                </button>
              )}
            </div>
          }
        >
          <div className="mx-4 mb-4">
            {Object.entries(groupKeyValueParamsByTag(contractualOption.parameters)).map(([tag, params]) => {
              return (
                <div key={`${tag}-section`} data-qa={`${tag}-section`}>
                  {tag !== "noTags" && (
                    <div data-qa={`${tag}-label`} className="mb-2 mt-4 flex items-center gap-x-2">
                      <span className="shrink-0 font-bold">
                        <FormattedMessage id={tag} />
                      </span>
                      <span className="line" />
                    </div>
                  )}
                  <div className="grid grid-cols-2 lg:grid-cols-3 gap-4" data-qa={`${tag}-params`}>
                    {params.map((param: any) => (
                      <ParameterBox
                        key={param.code}
                        label={param.name}
                        value={param.value as any}
                        type={param.type}
                        currency={param.currency || "EUR"}
                      />
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </Accordion>
      ) : (
        <div className="flex items-center gap-x-2 bg-box-background p-4 rounded-lg">
          <h4 data-qa={`${contractualOption.code}-option-name`}>
            <FormattedMessage id={contractualOption.name || EMPTY} />
          </h4>
          {contractualOption.description && (
            <button
              type="button"
              className="text-primary w-6 h-6 cursor-pointer"
              data-qa={`${contractualOption.code}-info`}
              onClick={handleModalOpen}
            >
              <InformationCircleIcon />
            </button>
          )}
        </div>
      )}
      {contractualOption.description && (
        <DetailsModal
          data-qa={`${contractualOption.code}-modal`}
          isOpen={isModalOpen}
          onClose={() => {
            setIsModalOpen(false);
          }}
          title={contractualOption.name || EMPTY}
        >
          <FormattedMessage id={contractualOption.description} />
        </DetailsModal>
      )}
    </>
  );
}
