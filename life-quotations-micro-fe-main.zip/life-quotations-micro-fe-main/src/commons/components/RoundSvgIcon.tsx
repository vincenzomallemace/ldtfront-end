import { FC } from "react";

interface Props {
  className?: string;
  SvgIcon?: FC;
}

export function RoundSvgIcon({ SvgIcon, className = "" }: Props) {
  const cls = `${className} rounded-full flex-shrink-0`;
  return (
    <div className={cls}>
      {/*@ts-ignore*/}
      <SvgIcon role="img" aria-hidden="true" />
    </div>
  );
}
