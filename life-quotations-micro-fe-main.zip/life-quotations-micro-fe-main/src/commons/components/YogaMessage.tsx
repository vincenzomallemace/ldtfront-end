import React, { PropsWithChildren } from "react";
import {
  XCircleIcon,
  ExclamationIcon,
  InformationCircleIcon,
  CheckCircleIcon,
} from "@heroicons/react/solid";
import { Loader } from "@aws-amplify/ui-react";
import classNames from "classnames";

interface MessageProps extends PropsWithChildren<any> {
  className?: string;
  type: "error" | "danger" | "warning" | "info" | "loader" | "success";
  outline?: boolean;
  position: "inner" | "outer";
  prefix?: string;
}

const positions = {
  inner: "rounded-lg",
  outer: "rounded-2xl",
};

const borders = {
  error: "border-error",
  danger: "border-title-text",
  warning: "border-title-text",
  info: "border-title-text",
  success: "border-title-text",
  loader: "border-title-text",
};

const backgrounds = {
  error: "bg-error",
  danger: "bg-draft",
  warning: "bg-draft",
  info: "bg-body-text",
  success: "bg-success",
  loader: "bg-box-background",
};

export const YogaMessage = ({
  children,
  className = "",
  type,
  outline = true,
  position,
  prefix = "",
}: MessageProps) => (
  <div
    className={classNames(
      `py-1 pl-1 pr-2 flex flex-row text-base items-center ${className} ${positions[position]} `,
      outline
        ? `${borders[type]} border-2 border-solid text-body-text bg-box-background`
        : `${backgrounds[type]} border-none text-box-background`
    )}
    role="message"
    data-qa={prefix ? `${prefix}-message` : "message"}
  >
    {type === "error" && (
      <XCircleIcon
        className={classNames(
          "mr-2 inline-block h-6 flex-shrink-0",
          outline && "text-error"
        )}
      />
    )}
    {type === "danger" && (
      <ExclamationIcon
        className={classNames(
          "mr-2 inline-block h-6 flex-shrink-0",
          outline && "text-draft"
        )}
      />
    )}
    {type === "warning" && (
      <InformationCircleIcon
        className={classNames(
          "mr-2 inline-block h-6 flex-shrink-0",
          outline && "text-draft"
        )}
      />
    )}
    {type === "info" && (
      <InformationCircleIcon
        className={classNames(
          "mr-2 inline-block h-6 flex-shrink-0",
          outline && "text-body-text"
        )}
      />
    )}
    {type === "success" && (
      <CheckCircleIcon
        className={classNames(
          "mr-2 inline-block h-6 flex-shrink-0",
          outline && "text-success"
        )}
      />
    )}
    {type === "loader" && (
      <Loader
        size="large"
        className="mr-2 inline-block h-6 flex-shrink-0"
        filledColor={`var(--body-text)`}
        fr={undefined}
      />
    )}
    <span className="inline-block w-full">{children}</span>
  </div>
);
