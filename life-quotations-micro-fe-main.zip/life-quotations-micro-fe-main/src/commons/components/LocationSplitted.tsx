import { FormikInput } from "commons/formik/FormikInput";
import { Location } from "commons/models/Location";
import { KeyValue } from "commons/models/YogaModels";
import { YogaParam } from "commons/models/YogaParam";
//import { Formik, Field, Form } from "formik";
//import * as Yup from "yup";
import { Field, FormikProps, useField } from "formik";
import { useEffect, useState } from "react";
import { fromYogaParamToFormParam } from "commons/FormUtils";
import { YogaModal } from "./YogaModal";
import { YogaButton } from "./YogaButton";
import { FormattedMessage } from "react-intl";
import classnames from "classnames";

//import { Portal } from "@headlessui/react";

interface LocationSplittedProps {
  name: string; // Form name to modify
  startLocation: Location;
  label?: string;
  form?: FormikProps<any>;
  disabled?: boolean;
  error?: string;
  mandatory?: boolean;
  // setter: (s: string, value: any) => void; // formik method to modify
}

export const LocationSplitted = ({
  name,
  label,
  startLocation,
  form,
  mandatory = true,
  disabled = false,
  error = undefined,
}: // setter,
LocationSplittedProps) => {
  const [field] = useField<Location>(name);
  const [fieldL, , helpersL] = useField(`${name}.label`);

  useEffect(() => {
    if (fieldL.value === undefined || fieldL.value === null) {
      form.setFieldValue(name, { label: "" }, true);
    }
    //else {
    //  form.validateForm();
    //}
  }, [fieldL.value]);

  const [isLocationModalOpen, setIsLocationModalOpen] = useState(false);

  function setLabel(): any {
    let loc = field.value;
    let tempLabel = `${loc.district ? loc.district + " " : ""}`;
    tempLabel += `${loc.street ? loc.street + ", " : ""}`;
    tempLabel += `${loc.houseNumber ? loc.houseNumber + ", " : ""}`;
    tempLabel += `${loc.postalCode ? loc.postalCode + ", " : ""}`;
    tempLabel += `${loc.city ? loc.city + ", " : ""}`;
    tempLabel += `${loc.countyAbbreviation ? loc.countyAbbreviation + ", " : ""}`;
    tempLabel += `${loc.country ? loc.country : ""}`;
    helpersL.setValue(tempLabel);
    //helpersL.setTouched(true);
  }

  const [params, setParams] = useState<KeyValue<YogaParam>>({
    [`${name}.country`]: {
      name: "Country",
      code: `${name}.country`,
      key: `${name}.country`,
      value: startLocation?.country,
      mandatory: true,
      defaultValue: "",
      order: 1,
      updateProductOnChange: false,
      updateQuestionnaireOnChange: false,
      updatePartyOnChange: false,
      updatePaymentMethodOnChange: false,
      searchList: undefined,
      disabled: false,
      visible: true,
      availableValues: [],
      type: "LOCATION_DYNAMIC_LIST",
      yuid: `${name}.country`,
      dynamicList: {
        fromTable: "NazioneProvincieComuni",
        fromColumn: "descrizioneStato",
        filteredByParameters: [],
      },
    },
    [`${name}.countryCode`]: {
      name: "Country",
      code: `${name}.countryCode`,
      key: `${name}.countryCode`,
      value: startLocation?.countryCode,
      mandatory: true,
      defaultValue: "",
      order: 1,
      updateProductOnChange: false,
      updateQuestionnaireOnChange: false,
      updatePartyOnChange: false,
      updatePaymentMethodOnChange: false,
      searchList: undefined,
      disabled: false,
      visible: false,
      availableValues: [],
      type: "LOCATION_DYNAMIC_LIST",
      yuid: `${name}.countryCode`,
      dynamicList: {
        fromTable: "NazioneProvincieComuni",
        fromColumn: "codiceISO",
        filteredByParameters: [`${name}.country`],
      },
    },
    [`${name}.county`]: {
      name: "County",
      code: `${name}.county`,
      key: `${name}.county`,
      value: startLocation?.county,
      mandatory: true,
      defaultValue: "",
      order: 2,
      updateProductOnChange: false,
      updateQuestionnaireOnChange: false,
      updatePartyOnChange: false,
      updatePaymentMethodOnChange: false,
      searchList: undefined,
      disabled: false,
      visible: true,
      availableValues: [],
      type: "LOCATION_DYNAMIC_LIST",
      yuid: `${name}.county`,
      dynamicList: {
        fromTable: "NazioneProvincieComuni",
        fromColumn: "descrizioneProvincia",
        filteredByParameters: [`${name}.country`],
      },
    },
    [`${name}.countyAbbreviation`]: {
      name: "County",
      code: `${name}.countyAbbreviation`,
      key: `${name}.countyAbbreviation`,
      value: startLocation?.county,
      mandatory: true,
      defaultValue: "",
      order: 2,
      updateProductOnChange: false,
      updateQuestionnaireOnChange: false,
      updatePartyOnChange: false,
      updatePaymentMethodOnChange: false,
      searchList: undefined,
      disabled: false,
      visible: false,
      availableValues: [],
      type: "LOCATION_DYNAMIC_LIST",
      yuid: `${name}.countyAbbreviation`,
      dynamicList: {
        fromTable: "NazioneProvincieComuni",
        fromColumn: "codiceProvincia",
        filteredByParameters: [`${name}.country`, `${name}.county`],
      },
    },
    [`${name}.city`]: {
      name: "municipality",
      code: `${name}.city`,
      key: `${name}.city`,
      value: startLocation?.city,
      mandatory: true,
      defaultValue: "",
      order: 3,
      updateProductOnChange: false,
      updateQuestionnaireOnChange: false,
      updatePartyOnChange: false,
      updatePaymentMethodOnChange: false,
      searchList: undefined,
      disabled: false,
      visible: true,
      availableValues: [],
      type: "LOCATION_DYNAMIC_LIST",
      yuid: `${name}.city`,
      dynamicList: {
        fromTable: "NazioneProvincieComuni",
        fromColumn: "descrizioneComune",
        filteredByParameters: [`${name}.country`, `${name}.county`],
      },
    },
    [`${name}.cityCode`]: {
      name: "municipality",
      code: `${name}.cityCode`,
      key: `${name}.cityCode`,
      value: startLocation?.cityCode,
      mandatory: true,
      defaultValue: "",
      order: 3,
      updateProductOnChange: false,
      updateQuestionnaireOnChange: false,
      updatePartyOnChange: false,
      updatePaymentMethodOnChange: false,
      searchList: undefined,
      disabled: false,
      visible: false,
      availableValues: [],
      type: "LOCATION_DYNAMIC_LIST",
      yuid: `${name}.cityCode`,
      dynamicList: {
        fromTable: "NazioneProvincieComuni",
        fromColumn: "codiceComune",
        filteredByParameters: [`${name}.country`, `${name}.county`, `${name}.city`],
      },
    },
    [`${name}.postalCode`]: {
      name: "zipCode",
      code: `${name}.postalCode`,
      key: `${name}.postalCode`,
      value: startLocation?.postalCode,
      mandatory: true,
      defaultValue: "",
      order: 3,
      updateProductOnChange: false,
      updateQuestionnaireOnChange: false,
      updatePartyOnChange: false,
      updatePaymentMethodOnChange: false,
      searchList: undefined,
      disabled: false,
      visible: true,
      availableValues: [],
      type: "LOCATION_DYNAMIC_LIST",
      yuid: `${name}.postalCode`,
      dynamicList: {
        fromTable: "NazioneProvincieComuni",
        fromColumn: "Cap",
        filteredByParameters: [`${name}.country`, `${name}.county`, `${name}.city`],
      },
    },
    [`${name}.district`]: {
      name: "roadType",
      code: `${name}.district`,
      key: `${name}.district`,
      value: startLocation?.district,
      mandatory: true,
      defaultValue: "",
      order: 4,
      updateProductOnChange: false,
      updateQuestionnaireOnChange: false,
      updatePartyOnChange: false,
      updatePaymentMethodOnChange: false,
      searchList: undefined,
      disabled: false,
      visible: true,
      availableValues: [],
      type: "LOCATION_DYNAMIC_LIST",
      yuid: `${name}.district`,
      dynamicList: {
        fromTable: "toponimi",
        fromColumn: "descrizioneToponimo",
        filteredByParameters: [],
      },
    },
    [`${name}.street`]: {
      name: "address",
      code: `${name}.street`,
      key: `${name}.street`,
      value: startLocation?.street ? startLocation?.street : "",
      mandatory: true,
      defaultValue: "",
      order: 4,
      updateProductOnChange: false,
      updateQuestionnaireOnChange: false,
      updatePartyOnChange: false,
      updatePaymentMethodOnChange: false,
      searchList: undefined,
      disabled: false,
      visible: true,
      availableValues: [],
      type: "STRING",
      yuid: `${name}.street`,
      dynamicList: undefined,
    },
    [`${name}.houseNumber`]: {
      name: "streetNumber",
      code: `${name}.houseNumber`,
      key: `${name}.houseNumber`,
      value: startLocation?.houseNumber ? startLocation?.houseNumber : "",
      mandatory: true,
      defaultValue: "",
      order: 4,
      updateProductOnChange: false,
      updateQuestionnaireOnChange: false,
      updatePartyOnChange: false,
      updatePaymentMethodOnChange: false,
      searchList: undefined,
      disabled: false,
      visible: true,
      availableValues: [],
      type: "STRING",
      yuid: `${name}.houseNumber`,
      dynamicList: undefined,
    },
  });

  useEffect(() => {
    if (params[`${name}.countyAbbreviation`].value == "EE") {
      params[`${name}.city`].type = "STRING";
      params[`${name}.postalCode`].type = "STRING";
      params[`${name}.postalCode`].mandatory = false;
      params[`${name}.district`].type = "STRING";
      params[`${name}.district`].mandatory = false;
    } else {
      params[`${name}.city`].type = "LOCATION_DYNAMIC_LIST";
      params[`${name}.postalCode`].type = "LOCATION_DYNAMIC_LIST";
      params[`${name}.postalCode`].mandatory = true;
      params[`${name}.district`].type = "LOCATION_DYNAMIC_LIST";
      params[`${name}.district`].mandatory = true;
    }
  }, [params]);

  return (
    <>
      <Field
        key={`${name}.label`}
        name={`${name}.label`}
        component={FormikInput}
        content={{
          name: `${name}.label`,
          type: "STRING",
          label: label,
          mandatory: mandatory,
        }}
        onFocus={(e) => {
          setIsLocationModalOpen(true);
          e.target.blur();
        }}
        onClick={(e) => {
          setIsLocationModalOpen(true);
          e.target.blur();
        }}
        values={form.values}
        disabled={disabled}
        error={error}
        form={form}
      />
      <YogaModal
        isOpen={isLocationModalOpen}
        className="life-quotation-mfe"
        onClose={() => {
          setLabel();
          setIsLocationModalOpen(false);
        }}
        title={`${label}ModalTitle`}
      >
        <div className="grid grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-4">
          {Object.values(params).map((param) => (
            <div key={param.yuid} className={classnames("yoga-form-input self-end", !param.visible ? "hidden" : "")}>
              <Field
                key={param.code}
                name={param.code}
                data-qa={param.code}
                component={FormikInput}
                content={{
                  ...fromYogaParamToFormParam(param),
                  name: param.code,
                }}
                /* onUpdate={(values) => {
                  // console.log("onUpdate lanciato da", param.code);
                  updateParameters(values);
                }}*/
                /*onPartialUpdate={(args: any) => {
                  form.setFieldValue(
                    `${param.code}`,
                    {
                      ...param,
                      value: args[param.code],
                    },
                    false
                  );
                  form.setFieldTouched(`${param.code}`, true, false);
                }}

                onPartialUpdate={(args: any) => {
                  form.setFieldValue(
                    `${param.code}`,
                    `${args[param.code]}`,
                    false
                  );
                  form.setFieldTouched(`${param.code}`, true, false);
                }}*/
                fieldName={`${param.code}`}
                disabled={param.disabled}
                values={form.values}
                slider={param.slider}
                parameters={params}
                paramType={"party"}
                setParameters={setParams}
              />
            </div>
          ))}
        </div>

        <div className="mt-8 flex gap-4 justify-end w-full">
          <YogaButton
            data-qa="cancel-button"
            kind="default"
            type="button"
            position="outer"
            outline
            action={() => {
              setLabel();
              setIsLocationModalOpen(false);
            }}
          >
            <FormattedMessage id="close" />
          </YogaButton>
        </div>
      </YogaModal>
    </>
  );
};
