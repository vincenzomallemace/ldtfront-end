import React, {
  PropsWithChildren,
  useContext,
  useEffect,
  useRef,
  useState,
} from "react";
import DatePicker, { registerLocale } from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import "react-datepicker/dist/react-datepicker-cssmodules.css";
import "./YogaDatePicker.css";
import it from "date-fns/locale/it";
import en from "date-fns/locale/en-GB";
import { BanIcon, CalendarIcon } from "@heroicons/react/outline";
import { Context } from "commons/contexts/Context";
import classNames from "classnames";
import classnames from "classnames";

registerLocale("it", it);
registerLocale("en", en);

const format: {
  [k: string]: string;
} = {
  it: "dd/MM/yyyy",
  en: "MM/dd/yyyy",
};

const placeholder: {
  [k: string]: string;
} = {
  it: "gg/mm/aaaa",
  en: "mm/dd/yyyy",
};

interface DatePickerProps extends PropsWithChildren<any> {
  className?: string;
  action?: (date: Date) => void;
  updateProduct?: () => void;
  inputDate?: Date;
  minDate?: Date;
  maxDate?: Date;
  disabled?: boolean;
  error?: boolean;
  errorsInForm?: boolean;
  dataQa?: string;
}

export const YogaDatePicker = ({
  action,
  updateProduct,
  children,
  inputDate,
  minDate,
  maxDate,
  disabled = false,
  error = false,
  dataQa,
}: DatePickerProps) => {
  const context = useContext(Context);
  const [startDate, setStartDate] = useState<Date>();

  const updateStartDate = (date: Date) => {
    setStartDate(date);
    if (action) action(date);
  };

  const applyUpdate = () => {
    if (updateProduct) updateProduct();
  };

  useEffect(() => {
    if (inputDate) {
      setStartDate(new Date(inputDate));
    } else {
      setStartDate(undefined);
    }
  }, [inputDate]);

  const ref = useRef<DatePicker>();

  return (
    <div role="date-picker" data-qa={dataQa}>
      <DatePicker
        selected={startDate}
        ref={ref as React.LegacyRef<DatePicker<never>>}
        onChange={(date: Date) => updateStartDate(date)}
        onCalendarClose={() => applyUpdate()}
        locale={context.lang}
        dateFormat={format[context.lang]}
        strictParsing
        minDate={minDate}
        maxDate={maxDate}
        disabled={disabled}
        placeholderText={placeholder[context.lang]}
        portalId="life-quotation-mfe"
        showYearDropdown
        showMonthDropdown
        yearDropdownItemNumber={100}
        scrollableYearDropdown
        useShortMonthInDropdown
        className={classNames(
          "w-full h-12 py-3 px-4 focus:outline-none focus:border-primary rounded-lg text-base",
          error && disabled
            ? "bg-background-disabled text-action-disabled border-2 border-error cursor-not-allowed"
            : "",
          error && !disabled
            ? "border-2 border-error bg-box-background text-body-text"
            : "",
          !error && disabled
            ? "bg-background-disabled border-2 border-action-disabled cursor-not-allowed text-action-disabled"
            : "",
          !error && !disabled
            ? "border-2 border-body-text bg-box-background text-body-text"
            : ""
        )}
      >
        <div>{children}</div>
      </DatePicker>
      <div
        className={classnames("relative")}
        onClick={() => {
          ref.current?.setOpen(true);
        }}
      >
        {disabled ? (
          <BanIcon
            className={classnames(
              "w-6 absolute right-4 -top-9 text-action-disabled cursor-not-allowed"
            )}
          />
        ) : (
          <CalendarIcon
            className={classnames(
              "w-6 absolute right-4 -top-9 text-primary cursor-pointer"
            )}
          />
        )}
      </div>
    </div>
  );
};
