import { isEqual, endOfDay } from "date-fns";

export const getISODate = (date: Date) => {
  date = new Date(date);
  const offset = date.getTimezoneOffset();
  date = new Date(date.getTime() - offset * 60 * 1000);
  return date.toISOString().split("T")[0];
};

export const getDateFromISO = (date: Date) => {
  date = new Date(date);
  const offset = date.getTimezoneOffset();
  return new Date(date.getTime() + offset * 60 * 1000);
};

export const isEndOfDay = (date: Date) => {
  return isEqual(endOfDay(date), date);
};
