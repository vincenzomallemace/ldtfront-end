declare global {
  interface Window {
    YOGA_CONFIG: Config;
    YOGA: Yoga;
  }
}

type Config = {
  [key: string]: string | number | any | undefined;
};

type T = string | boolean | number;

type Yoga = {
  [key in Flags]: T;
};

enum Flags {
  LOADER = "LOADER",
}

const _configuration = (window.YOGA_CONFIG as Config) ?? {};
const REMOTES = _configuration.REMOTE_URLS ?? {};

export const config = {
  PROJECT: _configuration.FF_PROJECT as string,
  YOGA_CHANNEL: (_configuration.FF_YOGA_CHANNEL as string) ?? "b2b",
  LANGUAGES: _configuration?.FF_LANGUAGES as string,
  SKIP_SSO: _configuration?.FE_SKIP_SSO as string,

  ADDRESS_ALLOWED_COUNTRIES:
    (_configuration.FF_ADDRESS_ALLOWED_COUNTRIES as string) ?? "",
  BACK_BUTTON: _configuration.FF_BACK_BUTTON as string,
  EXTERNAL_POLICY_DOCS_NEEDED:
    _configuration.FF_EXTERNAL_POLICY_DOCS_NEEDED as string,
  DISPLAY_PARTY_IBAN: _configuration.FF_DISPLAY_PARTY_IBAN as string,
  GEOLOCATION: _configuration.FF_GEOLOCATION as string,
  HERE_URL: (_configuration.FF_HERE_URL ??
    "/api/v1/geo/autocomplete") as string,
  OTP_SIGN: _configuration.FF_OTP_SIGN as string,
  FINANCIAL_ADVICE_TEMPLATE: _configuration.FINANCIAL_ADVICE_TEMPLATE,
  INDIVIDUAL_COMPANY_REFERENT:
    _configuration.FF_INDIVIDUAL_COMPANY_REFERENT as string,
  SEND_PAYMENT_AND_SIGN_TO_CUSTOMER_AREA:
    _configuration.FF_SEND_PAYMENT_AND_SIGN_TO_CUSTOMER_AREA as string,
  LIFE_CASH_LIMITS: _configuration.FF_LIFE_CASH_LIMITS as number,
  MOTOR_CASH_LIMITS: _configuration.FF_MOTOR_CASH_LIMITS as number,
  NO_MOTOR_CASH_LIMITS: _configuration.FF_NO_MOTOR_CASH_LIMITS as number,
  PARTY_DOMICILE: _configuration.FF_PARTY_DOMICILE as string,
  PAYMENTS: _configuration.FF_PAYMENTS as string,
  PAYMENT_METHOD_ACCOUNT_DEBIT:
    _configuration.FF_PAYMENT_METHOD_ACCOUNT_DEBIT as string,
  PAYMENT_METHOD_SDD: _configuration.FF_PAYMENT_METHOD_SDD as string,
  PAYMENT_METHOD_CASH: _configuration.FF_PAYMENT_METHOD_CASH as string,
  PAYMENT_METHOD_POS: _configuration.FF_PAYMENT_METHOD_POS as string,
  PAYMENT_METHOD_RESERVED_AREA:
    _configuration.FF_PAYMENT_METHOD_RESERVED_AREA as string,
  PAYMENT_METHOD_LATER: _configuration.FF_PAYMENT_METHOD_LATER as string,
  PAYMENT_METHOD_CHECK: _configuration.FF_PAYMENT_METHOD_CHECK as string,
  PAYMENT_METHOD_TRANSFER: _configuration.FF_PAYMENT_METHOD_TRANSFER as string,
  PAYMENT_METHOD_OTHER: _configuration.FF_PAYMENT_METHOD_OTHER as string,
  SAVE_DRAFT_LIFE_PROPOSAL:
    _configuration.FF_SAVE_DRAFT_LIFE_PROPOSAL as string,
};

export const getApiContext = (): string =>
  (_configuration?.FF_API_CONTEXT_ROOT ?? "/api") as string;

export const CTX = (
  REMOTES.life_quotations?.ctx ? `/${REMOTES.life_quotations.ctx}` : ""
) as string;

export const AUTH = {
  region: (_configuration?.FF_COGNITO_REGION ?? "eu-central-1") as string,
  userPoolId: (_configuration?.FF_COGNITO_POOL_ID ??
    "eu-central-1_H5auFmsbV") as string,
  userPoolWebClientId: (_configuration?.FF_COGNITO_WEBCLIENT_ID ??
    "sbmqt4mfs498e550d8sm0hdpv") as string,
};

const DEFAULT: Yoga = {
  LOADER: 0,
};

const Dictionary = {
  put: (key: string, value: T) => {
    if (window.YOGA) {
      return (window.YOGA[key] = value);
    }
    return (DEFAULT[key] = value);
  },
  get: (value: string): T => {
    if (window.YOGA && Object.hasOwn(window.YOGA, value)) {
      return window.YOGA[value];
    }
    return DEFAULT[value];
  },
};

export const Runtime = {
  setLoader: (n: number) => Dictionary.put(Flags.LOADER, n),
  getLoader: () => Dictionary.get(Flags.LOADER) as number,
};
