import { noop } from "commons/Utils";
import { useSessionStorage } from "commons/hooks/useSessionStorage";
import { Consent } from "customers/models/Consent";
import { Party } from "customers/models/Party";
import { QuestionnaireModel } from "questionnaires/models/QuestionnaireModel";
import { createContext } from "react";

interface CustomerContextType {
  selectedCustomers: Party[];
  setSelectedCustomers: (selectedCustomers: Party[]) => void;
  questionnaire: QuestionnaireModel;
  setQuestionnaire: (questionnaire: QuestionnaireModel) => void;
  policyholderAnonymous: any;
  setPolicyholderAnonymous: (policyholder: any) => void;
  consents: Consent[];
  setConsents: (consents: Consent[]) => void;
}

export const CustomerContext = createContext({
  selectedCustomers: [],
  setSelectedCustomers: noop,
  questionnaire: undefined,
  setQuestionnaire: noop,
  policyholderAnonymous: undefined,
  setPolicyholderAnonymous: noop,
  consents: undefined,
  setConsents: noop,
} as CustomerContextType);

const useCustomerContext = () => {
  const [selectedCustomers, setSelectedCustomers] = useSessionStorage<Party[]>(
    "yoga-selected-customers",
    []
  );
  const [questionnaire, setQuestionnaire] = useSessionStorage<
    QuestionnaireModel | {}
  >("yoga-questionnaire", {});
  const [consents, setConsents] = useSessionStorage<Consent[] | []>(
    "yoga-consents",
    []
  );
  const [policyholderAnonymous, setPolicyholderAnonymous] =
    useSessionStorage<Party>("yoga-policyholder-anonymous", null);

  return {
    selectedCustomers,
    setSelectedCustomers,
    questionnaire,
    setQuestionnaire,
    policyholderAnonymous,
    setPolicyholderAnonymous,
    consents,
    setConsents,
  };
};

export default useCustomerContext;
