import { noop } from "commons/Utils";
import { createContext } from "react";

interface ContextType {
  lang: string;
  setLang: (s: string) => void;
  loading: number;
  changeLoading: (n: number) => void;
  clearLoading: () => void;
}
export const Context = createContext({
  lang: "",
  setLang: noop,
  loading: 0,
  changeLoading: noop,
  clearLoading: noop,
} as ContextType);
