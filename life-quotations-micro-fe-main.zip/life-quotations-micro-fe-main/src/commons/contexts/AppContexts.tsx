import { Context } from "commons/contexts/Context";
import { PropsWithChildren, useEffect, useState } from "react";
import { IntlProvider } from "react-intl";
import { Slide, ToastContainer } from "react-toastify";
import useCustomerContext, { CustomerContext } from "./CustomerContext";
import { Runtime } from "commons/Configuration";
import { useNavigatorLanguage } from "commons/hooks/useNavigatorLanguage";
import useTranslations from "commons/hooks/useTranslations";
import { UserProvider } from "./UserProvider";

export const AppContexts = ({ children }: PropsWithChildren) => {
  const langNav = useNavigatorLanguage();
  const [lang, setLang] = useState(langNav);
  const { i18n, error } = useTranslations(lang);
  const [loading, setLoading] = useState(0);

  const customerCtx = useCustomerContext();

  useEffect(() => {
    window.localStorage.setItem("language", lang);
    window.dispatchEvent(new Event("yoga-storage"));
  }, [lang]);

  const changeLoading = (val: number) => {
    let newLoading: number = Runtime.getLoader();
    if (newLoading >= 0) {
      newLoading = newLoading + val;
    } else {
      newLoading = loading + val;
    }
    if (newLoading < 0) {
      newLoading = 0;
    }
    Runtime.setLoader(newLoading);
    window.dispatchEvent(new Event("yoga-loading"));
  };

  const clearLoading = () => {
    Runtime.setLoader(0);
    window.dispatchEvent(new Event("yoga-loading"));
  };

  window.addEventListener("yoga-loading", () => {
    setLoading(Runtime.getLoader());
  });

  return (
    i18n && (
      <Context.Provider
        value={{
          lang,
          setLang,
          loading,
          changeLoading,
          clearLoading,
        }}
      >
        <UserProvider>
          <CustomerContext.Provider value={customerCtx}>
            <IntlProvider {...i18n}>
              {children}
              <ToastContainer
                position="top-right"
                transition={Slide}
                autoClose={8000}
                hideProgressBar={false}
                closeOnClick
                pauseOnHover
                draggable
                theme="colored"
              />
            </IntlProvider>
            <p>{error?.message}</p>
          </CustomerContext.Provider>
        </UserProvider>
      </Context.Provider>
    )
  );
};
