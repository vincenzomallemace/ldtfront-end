import { useUser } from "commons/hooks/useUser";
import { ManagementNode } from "commons/models/nodes/ManagementNode";
import { User } from "commons/models/User";
import { YogaUser } from "commons/models/YogaUser";
import { createContext, PropsWithChildren } from "react";

export const UserContext = createContext<{
  user: User | null;
  yogaUser: YogaUser | null;
  rootManagementNodes: ManagementNode[];
  role: string;
  signOut: () => void;
}>({
  user: null,
  yogaUser: null,
  rootManagementNodes: [],
  role: "",
  signOut: () => { },
});

export function UserProvider({ children }: PropsWithChildren<{}>) {
  const { user, yogaUser, rootManagementNodes, role, signOut } = useUser();
  return (
    <UserContext.Provider
      value={{
        user,
        yogaUser,
        rootManagementNodes,
        role,
        signOut,
      }}
    >
      {children}
    </UserContext.Provider>
  );
}
