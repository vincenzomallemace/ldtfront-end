import { AxiosError } from "axios";
import { KeyValue, OrderedEntity } from "./models/YogaModels";
import { YogaParam } from "./models/YogaParam";
import { Question } from "questionnaires/models/Question";

export const noop = () => {};

export const scrollToTop = () => document.getElementById("life-quotation-mfe")?.scrollIntoView({ behavior: "smooth", block: "start" });//window.scrollTo({ top: 0, behavior: "smooth" });

export const EMPTY = " ";

const sortByOrder = <T extends OrderedEntity>(array: T[]): T[] => array.sort((a: T, b: T) => a.order - b.order);

export function orderedMapToArray<T extends OrderedEntity>(obj: KeyValue<T>): T[] {
  return sortByOrder(Object.values(obj ?? {}));
}

export const getErrorMessageFromReason = (reason: AxiosError) => {
  let message = reason.message;
  if (typeof reason.response.data == "object" && "message" in reason.response.data) {
    message = reason.response.data["message"] as string;
  }
  return message;
};

export function groupKeyValueParamsByTag(parameters: KeyValue<YogaParam>) {
  const map: KeyValue<YogaParam[]> = {};
  Object.values(parameters)
    .filter((p) => p.visible)
    .sort((a, b) => (a.tags[0] > b.tags[0] ? 1 : -1))
    .sort((a, b) => a.order - b.order)
    .map((param) => {
      if (param.tags?.length > 0) {
        if (map[param.tags[0]]) {
          map[param.tags[0]].push(param);
        } else {
          map[param.tags[0]] = [param];
        }
      } else {
        if (map["noTags"]) {
          map["noTags"].push(param);
        } else {
          map["noTags"] = [param];
        }
      }
    });
  return map;
}

export function groupQuestionsByTag(questions: KeyValue<Question>) {
  const map: KeyValue<Question[]> = {};
  Object.values(questions)
    .filter((q) => q.visible)
    .sort((a, b) => (a.tags[0] > b.tags[0] ? 1 : -1))
    .sort((a, b) => a.order - b.order)
    .map((question) => {
      if (question.tags?.length > 0) {
        if (map[question.tags[0]]) {
          map[question.tags[0]].push(question);
        } else {
          map[question.tags[0]] = [question];
        }
      } else {
        if (map["noTag"]) {
          map["noTag"].push(question);
        } else {
          map["noTag"] = [question];
        }
      }
    });
  return map;
}

export function orderQuestionByTag(questions: KeyValue<Question>) {
  const map: KeyValue<Question[]> = {};
  Object.values(questions)
    .filter((q) => q.visible)
    .sort((a, b) => (a.tags[0] > b.tags[0] ? 1 : -1))
    .sort((a, b) => a.order - b.order)
    .map((question) => {
      if (question.tags?.length > 0) {
        if (map[question.tags[0]]) {
          map[question.tags[0]].push(question);
        } else {
          map[question.tags[0]] = [question];
        }
      } else {
        if (map["noTag"]) {
          map["noTag"].push(question);
        } else {
          map["noTag"] = [question];
        }
      }
    });
  return map;
}
