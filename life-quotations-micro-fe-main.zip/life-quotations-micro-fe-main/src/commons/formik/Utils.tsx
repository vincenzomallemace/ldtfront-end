import { CF_REGEXP, paramsToMap, transformObjectToDotNotation, TAXID_REGEXP } from "commons/FormUtils";
import { KeyValue } from "commons/models/YogaModels";
import { FormInputParam, YogaParam } from "commons/models/YogaParam";
import { FormikProps, getIn } from "formik";
import { IntlShape } from "react-intl";
import { RoleType } from "contracts/enums/RoleType";
import { Product } from "offers/models/Product";
import { Contract } from "contracts/models/Contract";
import { ThirdReferentData } from "customers/models/Beneficiaries";
import { Party } from "customers/models/Party";
import { isValidIBAN } from "ibantools";
import { isValidPhoneNumber } from "react-phone-number-input";
import * as yup from "yup";

export function hasErrorsOnTouched(form: FormikProps<any>) {
  return form && transformObjectToDotNotation(form.errors).filter((v) => !!getIn(form.touched, v)).length > 0;
}

export function validateParameters(confParams: YogaParam[], editedValues: KeyValue<YogaParam>, intl: IntlShape) {
  let errors: { [code: string]: { value: string } } = {};
  if (confParams) {
    confParams.forEach(({ code, visible, mandatory, type, validations }) => {
      const value = editedValues ? editedValues[code]?.value : null;
      if (visible && mandatory && (value === null || value === undefined || value === "")) {
        errors[code] = { value: intl.formatMessage({ id: "required" }) };
      }
      if (validations) {
        if (validations.max !== null && validations.max !== undefined) {
          if (value && Number(value) > validations.max) {
            errors[code] = {
              value: `${intl.formatMessage({
                id: "form.validateMaxError",
                defaultMessage: "Must be less than",
              })} ${validations.max}`,
            };
          }
        }
        if (validations.min !== null && validations.min !== undefined) {
          if (value && Number(value) < validations.min) {
            errors[code] = {
              value: `${intl.formatMessage({
                id: "form.validateMinError",
                defaultMessage: "Must be greater than",
              })} ${validations.min}`,
            };
          }
        }
        if (type === "STRING" && validations.regExp) {
          const confRegex = new RegExp(validations.regExp);
          if (value && !confRegex.test(value as string)) {
            errors[code] = {
              value: `${intl.formatMessage({
                id: "form.validateRegExpError",
              })}`, //${validations.regExp}`,
            };
          }
        }

        if (validations.format) {
          switch (validations.format) {
            case "EMAIL":
              if (value) {
                const emailSchema = yup.string().email();
                if (!emailSchema.isValidSync(value as string)) {
                  errors[code] = {
                    value: intl.formatMessage({ id: "invalidEmail" }),
                  };
                }
              }
              break;
            case "IBAN":
              if (value && !isValidIBAN(value as string)) {
                errors[code] = {
                  value: intl.formatMessage({ id: "ibanFormatError" }),
                };
              }
              break;
            case "PHONE_NUMBER":
              if (value && !isValidPhoneNumber(value as string)) {
                errors[code] = {
                  value: intl.formatMessage({ id: "invalidPhoneNumber" }),
                };
              }
              break;
            case "TAX_ID":
              if (value && !(CF_REGEXP.test(value as string) || TAXID_REGEXP.test(value as string))) {
                errors[code] = {
                  value: intl.formatMessage({ id: "invalidTaxId" }),
                };
              }
              break;
            default:
              break;
          }
        }
      }
    });
  }
  return Object.keys(errors).length > 0 ? errors : undefined;
}

const birthPlaceRegExp = new RegExp("birthPlace$");
const birthCountryRegExp = new RegExp("birthCountry$");

export function getDate(p: FormInputParam, birthDate?: Date): FormInputParam {
  return birthPlaceRegExp.test(p.name) || birthCountryRegExp.test(p.name)
    ? {
        ...p,
        date: birthDate,
      }
    : p;
}

export function initialPartyParametersFromProduct(product: Product, role: RoleType, defaultParams: YogaParam[]): KeyValue<YogaParam[]> {
  const defaultParamsByCode = paramsToMap(defaultParams);
  return (
    Object.values(product.assets)
      .flatMap((assets) => Object.values(assets))
      .filter((asset) => asset?.parties && asset?.parties[role])
      .flatMap((asset) => asset.parties[role])
      .reduce((acc, party) => {
        if (party?.partyId && party?.parameters) {
          acc[party.partyId] = Object.values({ ...defaultParamsByCode, ...party.parameters });
        }
        return acc;
      }, {}) ?? {}
  );
}

export function initialPartyParametersFromContract(contract: Contract, role: RoleType, defaultParams: YogaParam[]): KeyValue<YogaParam[]> {
  const defaultParamsByCode = paramsToMap(defaultParams);
  return (
    Object.values(contract.parties[role] ?? []).reduce((acc, party) => {
      if (party?.partyId && party?.parameters) {
        acc[party.partyId] = Object.values({ ...defaultParamsByCode, ...party.parameters });
      }
      return acc;
    }, {}) ?? {}
  );
}

export function initialPartyParametersFromBeneficiaries(contract: Contract, role: RoleType, defaultParams: YogaParam[]): KeyValue<YogaParam[]> {
  const defaultParamsByCode = paramsToMap(defaultParams);
  if (role == RoleType.THIRD_REFERENT) {
    const party: ThirdReferentData = contract?.beneficiaries?.thirdReferent;
    return party?.partyId && party?.parameters ? { [party.partyId]: Object.values({ ...defaultParamsByCode, ...party.parameters }) } : {};
  } else if (role == RoleType.BENEFICIARY) {
    return (
      contract?.beneficiaries?.partyData?.reduce((acc, party) => {
        if (party?.partyId && party?.parameters) {
          acc[party.partyId] = Object.values({ ...defaultParamsByCode, ...party.parameters });
        }
        return acc;
      }, {}) ?? {}
    );
  } else {
    return {};
  }
}

export function initialPartiesFromProduct(product: Product, role: RoleType): KeyValue<Party> {
  return (
    Object.values(product.assets)
      .flatMap((assets) => Object.values(assets))
      .filter((asset) => asset?.parties && asset?.parties[role])
      .flatMap((asset) => asset.parties[role])
      .reduce((acc, party) => {
        if (party?.partyId) {
          acc[party.partyId] = party;
        }
        return acc;
      }, {}) ?? {}
  );
}

export function initialPartiesFromContract(contract: Contract, role: RoleType): KeyValue<Party> {
  return (
    Object.values(contract.parties[role] ?? []).reduce((acc, party) => {
      if (party?.partyId) {
        acc[party.partyId] = party;
      }
      return acc;
    }, {}) ?? {}
  );
}

export function initialPartisFromBeneficiaries(contract: Contract, role: RoleType): KeyValue<Party> {
  if (role == RoleType.THIRD_REFERENT) {
    const party: ThirdReferentData = contract?.beneficiaries?.thirdReferent;
    // @ts-ignore
    return (party?.partyId ? { [party.partyId]: party } : {}) as KeyValue<Party>;
  } else if (role == RoleType.BENEFICIARY) {
    return (contract?.beneficiaries?.partyData?.reduce((acc, party) => {
      if (party?.partyId) {
        acc[party.partyId] = party;
      }
      return acc;
    }, {}) ?? {}) as KeyValue<Party>;
  } else {
    return {};
  }
}
