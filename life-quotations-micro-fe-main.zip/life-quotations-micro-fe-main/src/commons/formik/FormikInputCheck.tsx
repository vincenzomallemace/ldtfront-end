import { InformationCircleIcon } from "@heroicons/react/outline";
import { EMPTY } from "commons/Utils";
import { DetailsModal } from "commons/modals/DetailsModal";
import { FormInputParam } from "commons/models/YogaParam";
import { useField } from "formik";
import { useEffect, useState } from "react";
import { FormattedMessage } from "react-intl";
import { hasErrorsOnTouched } from "./Utils";
import { FormikInputProps } from "./FormikInput";

interface FormikInputCheckProps extends FormikInputProps<boolean> {
  content: FormInputParam;
  hidden?: boolean;
  infoLabel?: string;
  notShowErrorMessage?: boolean;
}

export function FormikInputCheck({
  content: { label, mandatory, updateOnChange },
  disabled = false,
  hidden = false,
  onUpdate,
  field: { name },
  form,
  "data-qa": dataQa,
  infoLabel,
  notShowErrorMessage = false,
}: FormikInputCheckProps) {
  const [field, meta, helpers] = useField(name);
  const { setValue } = helpers;
  const [isChecked, setIsChecked] = useState(field.value);
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);

  useEffect(() => {
    if (updateOnChange && onUpdate && form.dirty) onUpdate(form.values);
  }, [field.value]);

  return (
    <>
      {!hidden && (
        <div className="yoga-form-input" data-qa={dataQa}>
          <label htmlFor={name} className="checkbox-container" data-qa={`${label}-label`}>
            <input
              type="checkbox"
              checked={isChecked}
              onChange={(event) => {
                setIsChecked(event.target.checked);
                setValue(event.target.checked, true);
              }}
              id={name}
              data-qa={`${name}-input`}
              disabled={disabled}
            />
            <span className="checkmark" />
            <div className="flex items-center">
              <div className="inline-flex text-primary text-sm font-medium">
                <FormattedMessage id={label || EMPTY} />
                {mandatory && "*"}
              </div>
              {infoLabel && (
                <button
                  type="button"
                  className="flex-none ml-2 text-primary w-6 h-6 align-bottom hover:cursor-pointer"
                  data-qa={`${name}-info`}
                  onClick={() => setIsModalOpen(true)}
                >
                  <InformationCircleIcon />
                </button>
              )}
            </div>
          </label>

          {!notShowErrorMessage && hasErrorsOnTouched(form) && (
            <div className="h-6">
              {meta.error && (
                <span className="block text-base text-error" data-qa={`error-message-${field.name}`}>
                  {meta.error}
                </span>
              )}
            </div>
          )}
        </div>
      )}
      {infoLabel && (
        <DetailsModal
          data-qa={`${name}-modal`}
          isOpen={isModalOpen}
          onClose={() => {
            setIsModalOpen(false);
          }}
          title={label}
        >
          <FormattedMessage id={infoLabel || EMPTY} />
          {mandatory && "*"}
        </DetailsModal>
      )}
    </>
  );
}
