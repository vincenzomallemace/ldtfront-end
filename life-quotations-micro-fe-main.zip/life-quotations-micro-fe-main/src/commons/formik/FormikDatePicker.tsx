import { FormikProps, useField } from "formik";
import { FormattedMessage } from "react-intl";
import { FormInputParam, YogaParamValueType } from "commons/models/YogaParam";
import React, { useState } from "react";
import { KeyValue } from "commons/models/YogaModels";
import { InformationCircleIcon } from "@heroicons/react/outline";
import { EMPTY } from "commons/Utils";
import { DetailsModal } from "commons/modals/DetailsModal";
import { getISODate } from "commons/DateUtils";
import { YogaDatePicker } from "commons/components/YogaDatePicker";
//import { hasErrorsOnTouched } from "./Utils";

interface FormikDatePickerProps {
  content: FormInputParam;
  disabled?: boolean;
  form: FormikProps<any>;
  onUpdate: (values: KeyValue<YogaParamValueType>) => any;
  onPartialUpdate?: (
    values: KeyValue<YogaParamValueType>,
    updateOnChange: boolean
  ) => any;
  fieldName?: string;
  values: any;
  dataQa?: string;
  questionnaireForm?: boolean;
}

export function FormikDatePicker({
  content: { label, description, mandatory, name, updateOnChange, max, min },
  disabled = false,
  form,
  onUpdate,
  onPartialUpdate,
  fieldName,
  dataQa,
  questionnaireForm = false,
}: FormikDatePickerProps) {
  const [field, meta, helpers] = useField(name);
  const { setValue, setTouched, setError } = helpers;
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);

  const hasError = /*hasErrorsOnTouched(form) &&*/ meta.error;

  function updateProduct() {
    if (updateOnChange && form?.dirty && onUpdate) {
      onUpdate(form?.values);
    }

    if (onPartialUpdate && form?.dirty && fieldName) {
      onPartialUpdate({ [fieldName]: field.value }, updateOnChange || false);
    }
  }

  function onChange(date: Date) {
    setTouched(true);
    if (meta.error) setError(meta.error);
    if (date) setValue(new Date(getISODate(date)));
    else setValue("");
  }

  return (
    <>
      {!questionnaireForm ? (
        <div className="yoga-form-input self-end" data-qa={dataQa} id={name}>
          <label
            htmlFor={name}
            className="block text-body-text text-base"
            data-qa={`${label}-label`}
          >
            <div className="inline-flex text-sm text-primary font-medium">
              <FormattedMessage id={label || EMPTY} />
              {mandatory && "*"}
            </div>
            {description && (
              <button
                type="button"
                className="flex-none ml-2 text-primary w-6 h-6 align-bottom hover:cursor-pointer"
                data-qa={`${name}-info`}
                onClick={() => setIsModalOpen(true)}
              >
                <InformationCircleIcon />
              </button>
            )}
            <YogaDatePicker
              dataQa={`${name}-input`}
              className="flex-grow "
              inputDate={field.value}
              action={onChange}
              updateProduct={updateProduct}
              disabled={disabled}
              error={!!hasError}
              maxDate={max as Date}
              minDate={min as Date}
            />
          </label>

          {
            /*hasErrorsOnTouched(form) && (*/
            <div className="h-6">
              {hasError && (
                <span
                  className="block text-base text-error"
                  data-qa={`error-message-${name}`}
                >
                  {hasError && meta.error}
                </span>
              )}
            </div>
            /*)*/
          }
          {description && (
            <DetailsModal
              data-qa={`${name}-modal`}
              isOpen={isModalOpen}
              onClose={() => {
                setIsModalOpen(false);
              }}
              title={label}
            >
              {description}
            </DetailsModal>
          )}
        </div>
      ) : (
        <div className="questionnaire-yoga-form-input w-full" data-qa={dataQa}>
          <label
            htmlFor={name}
            className="block text-body-text text-base pr-4 w-2/3"
            data-qa={`${label}-label`}
          >
            <div className="inline-flex text-primary text-sm">
              <FormattedMessage id={label || EMPTY} />
              {mandatory && "*"}
            </div>
          </label>

          <div className="ygInput-container flex relative w-1/3">
            <div className="w-full relative py-3">
              <YogaDatePicker
                id={name}
                dataQa={`${name}-input`}
                className="flex-grow"
                inputDate={field.value}
                action={onChange}
                updateProduct={updateProduct}
                disabled={disabled}
                error={!!hasError}
                maxDate={max as Date}
                minDate={min as Date}
              />

              {
                /*hasErrorsOnTouched(form) && (*/
                <div className="h-3">
                  {meta.error && (
                    <span
                      className="block text-base text-error leading-[1.2rem] absolute bottom-0"
                      data-qa={`error-message-${name}`}
                    >
                      {meta.error}
                    </span>
                  )}
                </div>
                /*)*/
              }
            </div>

            {description && (
              <button
                type="button"
                className="w-6 h-6 align-bottom hover:cursor-pointer questionnaire-info-btn mt-3"
                data-qa={`${name}-info`}
                onClick={() => setIsModalOpen(true)}
              >
                <InformationCircleIcon />
              </button>
            )}

            {description && (
              <DetailsModal
                data-qa={`${name}-modal`}
                isOpen={isModalOpen}
                onClose={() => {
                  setIsModalOpen(false);
                }}
                title={label}
              >
                {description}
              </DetailsModal>
            )}
          </div>
        </div>
      )}
    </>
  );
}
