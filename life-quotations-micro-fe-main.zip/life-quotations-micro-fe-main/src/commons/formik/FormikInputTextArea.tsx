import { FormikProps, useField } from "formik";
import { useEffect, useState } from "react";
import { FormattedMessage } from "react-intl";
import { FormInputParam, YogaParamValueType } from "commons/models/YogaParam";
import classnames from "classnames";
import { KeyValue } from "commons/models/YogaModels";
import { InformationCircleIcon } from "@heroicons/react/outline";
import { DetailsModal } from "commons/modals/DetailsModal";
import { hasErrorsOnTouched } from "./Utils";

interface FormikInputTextAreaProps {
  content: FormInputParam;
  disabled?: boolean;
  hidden?: boolean;
  maxLength?: number;
  form?: FormikProps<any>;
  onUpdate?: (values: KeyValue<YogaParamValueType>) => any;
  onPartialUpdate?: (
    values: KeyValue<YogaParamValueType>,
    updateOnChange: boolean
  ) => any;
  noDelayOnUpdate?: boolean;
  fieldName?: string;
  values?: any;
  placeholder?: string;
  dataQa?: string;
}

export function FormikInputTextArea({
  content: {
    label,
    description,
    mandatory,
    name,
    updateOnChange,
    updatePartially,
  },
  disabled = false,
  hidden = false,
  maxLength,
  form,
  onUpdate,
  onPartialUpdate,
  noDelayOnUpdate,
  fieldName,
  placeholder,
  dataQa,
  ...props
}: FormikInputTextAreaProps) {
  const [field, meta] = useField(name);
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);

  useEffect(() => {
    const delayDebounceFn = setTimeout(() => {
      if (updateOnChange && form?.dirty && onUpdate) {
        form?.validateForm().then((result) => {
          if (!result[name]) {
            onUpdate(form?.values);
          }
        });
      }
    }, 1000);
    return () => clearTimeout(delayDebounceFn);
  }, [field.value]);

  useEffect(() => {
    const update = updateOnChange || updatePartially;
    if (onPartialUpdate && form?.dirty && fieldName) {
      if (noDelayOnUpdate) {
        form.validateForm().then((result) => {
          if (!result[name]) {
            onPartialUpdate({ [fieldName]: field.value }, update || false);
          }
        });
      } else {
        const delayDebounceFn = setTimeout(() => {
          form.validateForm().then((result) => {
            if (!result[name]) {
              onPartialUpdate({ [fieldName]: field.value }, update || false);
            }
          });
        }, 1000);
        return () => clearTimeout(delayDebounceFn);
      }
    }
  }, [field.value]);

  return (
    <>
      {!hidden && (
        <div className="yoga-form-input w-full self-end" data-qa={dataQa}>
          <label
            htmlFor={name}
            className="block text-body-text w-full text-base"
            data-qa={`${name}-label`}
          >
            {label && (
              <div className="inline-flex text-primary text-sm font-medium">
                <FormattedMessage id={label} />
                {mandatory && "*"}
              </div>
            )}
            {description && (
              <button
                type="button"
                className="flex-none ml-2 text-primary w-6 h-6 align-bottom hover:cursor-pointer"
                data-qa={`${name}-info`}
                onClick={() => setIsModalOpen(true)}
              >
                <InformationCircleIcon />
              </button>
            )}
          </label>
          <textarea
            className={classnames(
              "bg-box-background w-full min-h-[96px] focus:outline-none focus:border-primary rounded-lg tracking-wider py-2 px-3 text-base text-body-text shadow-inner min-h-24",
              meta.touched && meta.error && disabled
                ? "bg-background-disabled border-2 border-error cursor-not-allowed text-action-disabled"
                : "",
              meta.touched && meta.error && !disabled
                ? "border-2 border-error bg-box-background text-body-text"
                : "",
              !(meta.touched && meta.error) && disabled
                ? "bg-background-disabled border-2 border-action-disabled cursor-not-allowed text-action-disabled"
                : "",
              !(meta.touched && meta.error) && !disabled
                ? "border-2 border-primary bg-box-background text-body-text"
                : ""
            )}
            {...field}
            {...props}
            id={name}
            data-qa={`${name}-input`}
            disabled={disabled}
            maxLength={maxLength}
            placeholder={placeholder}
          />
          {hasErrorsOnTouched(form) && (
            <div className="h-6">
              {meta.error && (
                <span
                  className="block text-base text-error"
                  data-qa={`error-message-${field.name}`}
                >
                  {meta.error}
                </span>
              )}
            </div>
          )}
        </div>
      )}
      {description && (
        <DetailsModal
          data-qa={`${name}-modal`}
          isOpen={isModalOpen}
          onClose={() => {
            setIsModalOpen(false);
          }}
          title={label}
        >
          {description}
        </DetailsModal>
      )}
    </>
  );
}
