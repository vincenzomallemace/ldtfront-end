import { KeyValue } from "commons/models/YogaModels";
import { FormInputParam, YogaParamValueType } from "commons/models/YogaParam";
import { FieldProps } from "formik";
import { FormikInputNumeric } from "./FormikInputNumeric";
import { FormikDatePicker } from "./FormikDatePicker";
import { FormikSelect } from "./FormikSelect";
import { FormikToggleSwitch } from "./FormikToggleSwitch";
import { FormikToggle } from "./FormikToggle";
import { FormikMultiSelect } from "commons/formik/FormikMultiSelect";
import { FormikInputPhone } from "./FormikInputPhone";
import { FormikInputTextArea } from "./FormikInputTextArea";
import { FormikInputCheck } from "./FormikInputCheck";
import { FormikInputTime } from "./FormikInputTime";
import { FormikInputGeo } from "./FormikInputGeo";
import { FormikRadioGroup } from "./FormikRadioGroup";
import { FormikInputText } from "./FormikInputText";
import { FormikDynamicSelect } from "./FormikDynamicSelect";
import FormikLocation from "./FormikLocation";
import FormikBirthPlace from "./FormikBirthPlace";
import FormikMultiChoice from "./FormikMultiChoice";
import { FormikLocationDynamicSelect } from "./FormikLocationDynamicSelect";

const dictionary: KeyValue<any> = {
  STRING: FormikInputText,
  NUMBER: FormikInputNumeric,
  AMOUNT: FormikInputNumeric,
  LIST: FormikSelect,
  DYNAMIC_LIST: FormikDynamicSelect,
  LOCATION_DYNAMIC_LIST: FormikLocationDynamicSelect,
  BOOLEAN: FormikToggle,
  DATE: FormikDatePicker,
  MULTIPLE_CHOICE: FormikMultiChoice,
  SWITCH: FormikToggleSwitch,
  MULTI: FormikMultiSelect,
  PHONE: FormikInputPhone,
  TEXTAREA: FormikInputTextArea,
  CHECKMARK: FormikInputCheck,
  TIME: FormikInputTime,
  COUNTRY: FormikInputGeo,
  CITY: FormikInputGeo,
  RADIO: FormikRadioGroup,
  LOCATION: FormikLocation,
  BIRTHPLACE: FormikBirthPlace,
};

const subtypeDictionary = {
  LIST: {
    RADIO: FormikRadioGroup,
  },
};

export interface FormikInputProps<T> extends FieldProps<T> {
  content: FormInputParam;
  onUpdate?: (values: KeyValue<YogaParamValueType>) => any;
  onPartialUpdate?: (values: KeyValue<YogaParamValueType>, updateOnChange: boolean) => any;
  "data-qa": string;
  disabled?: boolean;
}

export function FormikInput({ content, onUpdate, onPartialUpdate, "data-qa": dataQa, form, ...props }: FormikInputProps<any>) {
  let Tag = dictionary[content.type];
  if (content.type === "STRING" && content.validations?.format === "PHONE_NUMBER") {
    Tag = dictionary.PHONE;
  }
  if (content.subtype && subtypeDictionary[content.type] && Object.prototype.hasOwnProperty.call(subtypeDictionary[content.type], content.subtype)) {
    Tag = subtypeDictionary[content.type][content.subtype];
  }

  const noDelayOnUpdate = (props as any).noDelayOnUpdate as boolean;
  const fieldName = (props as any).fieldName as string;
  const questionnaireForm = (props as any).questionnaireForm as string;

  return (
    <Tag
      {...props}
      content={content}
      form={form}
      onUpdate={onUpdate}
      onPartialUpdate={onPartialUpdate}
      noDelayOnUpdate={noDelayOnUpdate}
      values={form.values}
      fieldName={fieldName}
      data-qa={dataQa}
      questionnaireForm={questionnaireForm}
      maxLength={content.max}
      minLength={content.min}
    />
  );
}
