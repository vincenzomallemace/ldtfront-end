import { KeyValue } from "commons/models/YogaModels";
import { YogaParam } from "commons/models/YogaParam";
import { Field, FieldProps } from "formik";
import { useMemo } from "react";
import { FormikInput } from "../FormikInput";
import { fromYogaParamToFormParam } from "commons/FormUtils";
import { Accordion } from "commons/components/Accordion";
import { FormattedMessage } from "react-intl";

interface ParametersFormProps extends FieldProps<KeyValue<YogaParam>> {
  parameters: KeyValue<YogaParam>;
  onUpdateOnChange: (parameters: KeyValue<YogaParam>) => any;
  currency?: string;
}

export default function ParametersForm({ field: { name, value }, form, parameters, onUpdateOnChange, currency = "EUR" }: ParametersFormProps) {
  const parametersByTag = useMemo(() => {
    const map: KeyValue<YogaParam[]> = {};
    Object.values(parameters)
      .filter((p) => p.visible)
      .sort((a, b) => (a.tags[0] > b.tags[0] ? 1 : -1))
      .sort((a, b) => a.order - b.order)
      .map((param) => {
        if (param.tags?.length > 0) {
          if (map[param.tags[0]]) {
            map[param.tags[0]].push(param);
          } else {
            map[param.tags[0]] = [param];
          }
        } else {
          if (map["noTags"]) {
            map["noTags"].push(param);
          } else {
            map["noTags"] = [param];
          }
        }
      });
    return map;
  }, [parameters]);

  function onChange() {
    onUpdateOnChange(value);
  }

  return (
    <>
      {Object.entries(parametersByTag).map(([tag, params]) =>
        tag === "noTags" ? (
          <div key={`${tag}-section`}>
            <div className="grid grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-4" data-qa={`${tag}-values-form`}>
              {params
                .filter((param) => param.visible)
                .map((param) => (
                  <Field
                    key={param.code}
                    name={`${name}.${param.code}.value`}
                    data-qa={`${name}.${param.code}`}
                    component={FormikInput}
                    content={{
                      ...fromYogaParamToFormParam(param),
                      name: `${name}.${param.code}.value`,
                    }}
                    fieldName={`${param.code}`}
                    disabled={param.disabled}
                    values={form.values}
                    onUpdate={onChange}
                    parameters={parameters}
                    currency={currency}
                    isParameterForm
                  />
                ))}
            </div>
          </div>
        ) : (
          <Accordion
            name={`${tag}-section`}
            open={true}
            className="flex flex-col mt-4 gap-2"
            titleContainerClasses=""
            accordionTitle={
              <div className="inline-flex items-center w-full">
                <h4 className="text-title-text whitespace-nowrap">
                  <FormattedMessage id={tag} />
                </h4>
                <span className="middle-border-accordion"></span>
              </div>
            }
            key={`${tag}-section`}
          >
            <div className="border-b-2 last:border-b-0 border-background" key={`${tag}-section`}>
              <div className="grid grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-4" data-qa={`${tag}-values-form`}>
                {params
                  .filter((param) => param.visible)
                  .map((param) => (
                    <Field
                      key={param.code}
                      name={`${name}.${param.code}.value`}
                      data-qa={`${name}.${param.code}`}
                      component={FormikInput}
                      content={{
                        ...fromYogaParamToFormParam(param),
                        name: `${name}.${param.code}.value`,
                      }}
                      fieldName={`${param.code}`}
                      disabled={param.disabled}
                      values={form.values}
                      onUpdate={onChange}
                      parameters={parameters}
                      currency={currency}
                      {...(param.type == "LIST" && { isParameterForm: true })}
                    />
                  ))}
              </div>
            </div>
          </Accordion>
        )
      )}
    </>
  );
}
