import { FormikProps, getIn, useField } from "formik";
import { format, isValid, parse } from "date-fns";
import it from "date-fns/locale/it";
import { FormattedMessage } from "react-intl";
import { FormInputParam } from "commons/models/YogaParam";
import DatePicker, {
  CalendarContainer,
  CalendarContainerProps,
  registerLocale,
} from "react-datepicker";
import { forwardRef, useEffect, useRef, useState } from "react";
import { BanIcon, ClockIcon } from "@heroicons/react/outline";
import classNames from "classnames";
import "react-datepicker/dist/react-datepicker.css";
import "react-datepicker/dist/react-datepicker-cssmodules.css";
import "../components/YogaDatePicker.css";
import { EMPTY } from "commons/Utils";
import { hasErrorsOnTouched } from "./Utils";

registerLocale("it", it);

function range(min: number, max: number) {
  const values: Array<number> = [];
  for (var i = min; i <= max; i++) {
    values.push(i);
  }
  return values;
}

interface FormikInputTimeProps {
  content: FormInputParam;
  disabled?: boolean;
  hidden?: boolean;
  form?: FormikProps<any>;
  values?: any;
  placeholder?: string;
  dataQa?: string;
}

export function FormikInputTime({
  content: { label, mandatory, name, min, max },
  disabled,
  hidden = false,
  form,
  dataQa,
}: FormikInputTimeProps) {
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const [field, meta, helpers] = useField(name);
  const { setValue, setTouched } = helpers;
  const fieldValue = getIn(form.values, name);

  const picker = useRef<DatePicker>();

  const minTime = typeof min == "number" ? new Date(min).getHours() : 0;
  const maxTime = typeof max == "number" ? new Date(max).getHours() : 23;

  const minutes = [0, 15, 30, 45];
  const hours = range(minTime, maxTime);

  const [current, setCurrent] = useState<Date>(null);

  useEffect(() => {
    if (fieldValue) {
      setCurrent(parse(fieldValue, "HH:mm", new Date()));
    } else {
      setCurrent(null);
    }
  }, [fieldValue]);

  function tryChange(value: Date | null) {
    try {
      if (isValid(value)) {
        setValue(format(value, "HH:mm"), false);
        setCurrent(value);
      } else {
        setValue("", false);
        setCurrent(null);
      }
    } catch (error) {
      console.error(error);
    }
    setTouched(true, false);
  }

  function setHour(hour: number) {
    let temp: Date = current;
    if (!current) {
      temp = new Date();
      // arrotondo al quarto d'ora più vicino
      const remains = 15 - (temp.getMinutes() % 15);
      temp.setMinutes(temp.getMinutes() + remains);
    }
    temp.setHours(hour);
    tryChange(temp);
  }

  function setMinutes(minutes: number) {
    let temp: Date = current;
    if (!current) {
      temp = new Date();
      // arrotondo al quarto d'ora più vicino
      const remains = 15 - (temp.getMinutes() % 15);
      temp.setMinutes(temp.getMinutes() + remains);
    }
    temp.setMinutes(minutes);
    tryChange(temp);

    // chiudo la tendina
    setTimeout(() => {
      picker?.current.setOpen(false);
    }, 50);
  }

  function insertColon(event) {
    var char = String.fromCharCode(event.keyCode);
    var currentLength = event.target.value.length;
    if (/[0-9]/.test(char)) {
      if ("nn:nn".charAt(currentLength + 1) === ":") {
        event.preventDefault();
        event.target.value += char;
        event.target.value += ":";
      }
    }
  }

  const MyCustomInput = forwardRef<unknown, any>(
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    ({ onClick, ...props }, ref) => {
      return (
        <>
          <input
            type="text"
            {...props}
            autoComplete="off"
            placeholder="hh:mm"
            maxLength={5}
            onKeyDown={insertColon}
            className={classNames(
              "w-full h-12 py-3 px-4 focus:outline-none focus:border-primary rounded-lg text-base border-2",
              meta.error &&
                disabled &&
                "bg-background-disabled text-action-disabled border-error cursor-not-allowed",
              meta.error &&
                !disabled &&
                "border-error bg-box-background text-body-text",
              !meta.error &&
                disabled &&
                "bg-background-disabled border-action-disabled cursor-not-allowed text-action-disabled",
              !meta.error &&
                !disabled &&
                "border-body-text bg-box-background text-body-text"
            )}
          />
          <button
            type="button"
            onClick={onClick}
            className={classNames(
              "p-3 float-right absolute z-60 right-2",
              disabled
                ? "cursor-not-allowed text-action-disabled"
                : "cursor-pointer text-primary"
            )}
          >
            {disabled ? (
              <BanIcon className="w-6 h-6" />
            ) : (
              <ClockIcon className="w-6 h-6" />
            )}
          </button>
        </>
      );
    }
  );
  MyCustomInput.displayName = "MyCustomInput";

  const MyContainer = ({ className }: CalendarContainerProps) => {
    return (
      <CalendarContainer className={className}>
        <div className="inline-flex gap-x-2 w-full ">
          <div className="text-center">
            <FormattedMessage id="hour" />
            <div className="max-h-60 overflow-y-auto">
              <ul>
                {hours.map((hour) => (
                  <li
                    className={classNames(
                      "rounded-md px-4 py-2 cursor-pointer hover:bg-hover-primary hover:text-button-text",
                      current?.getHours() === hour
                        ? "bg-primary text-button-text"
                        : ""
                    )}
                    key={`hour_${hour}`}
                    onClick={() => setHour(hour)}
                  >
                    {`${hour}`.padStart(2, "0")}
                  </li>
                ))}
              </ul>
            </div>
          </div>
          <div className="text-center">
            <FormattedMessage id="minutes" />
            <div className="max-h-60 overflow-y-auto">
              <ul>
                {minutes.map((mins) => (
                  <li
                    className={classNames(
                      "rounded-md px-4 py-2 cursor-pointer hover:bg-hover-primary hover:text-button-text",
                      current?.getMinutes() === mins
                        ? "bg-primary text-button-text"
                        : ""
                    )}
                    key={`mins_${mins}`}
                    onClick={() => setMinutes(mins)}
                  >
                    {`${mins}`.padStart(2, "0")}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </CalendarContainer>
    );
  };

  return (
    <>
      {!hidden && (
        <div className="yoga-form-input self-end" data-qa={dataQa}>
          <label
            htmlFor={`${name}`}
            className="block text-body-text text-base font-medium"
          >
            <div className="text-primary text-sm font-medium">
              <FormattedMessage id={label || EMPTY} />
              {mandatory && "*"}
            </div>
            <DatePicker
              id={`${name}`}
              name={`${name}`}
              onChange={tryChange}
              selected={current}
              strictParsing={true}
              showTimeSelect
              showTimeSelectOnly
              dateFormat="HH:mm"
              customInput={<MyCustomInput />}
              calendarContainer={MyContainer}
              clearButtonClassName="timepicker-clear-btn"
              popperPlacement="bottom-end"
              ref={picker}
            />
          </label>
          {hasErrorsOnTouched(form) && (
            <div className="h-6">
              {meta.error && (
                <span
                  className="block text-base text-error"
                  data-qa={`error-message-${field.name}`}
                >
                  {meta.error}
                </span>
              )}
            </div>
          )}
        </div>
      )}
    </>
  );
}
