import { FormikProps, useField } from "formik";
import React, { useEffect, useState } from "react";
import { FormattedMessage } from "react-intl";
import { EMPTY } from "commons/Utils";
import { FormInputParam, YogaParamValueType } from "commons/models/YogaParam";
import classnames from "classnames";
import {
  BanIcon,
  ExclamationCircleIcon,
  InformationCircleIcon,
} from "@heroicons/react/outline";
import { KeyValue } from "commons/models/YogaModels";
import { DetailsModal } from "commons/modals/DetailsModal";
//import { hasErrorsOnTouched } from "./Utils";

interface FormikInputTextProps {
  content: FormInputParam;
  disabled?: boolean;
  hidden?: boolean;
  maxLength?: number;
  form?: FormikProps<any>;
  onUpdate?: (values: KeyValue<YogaParamValueType>) => any;
  onPartialUpdate?: (
    values: KeyValue<YogaParamValueType>,
    updateOnChange: boolean
  ) => any;
  noDelayOnUpdate?: boolean;
  noValidate?: boolean;
  fieldName?: string;
  values?: any;
  placeholder?: string;
  dataQa?: string;
  questionnaireForm?: boolean;
}

export function FormikInputText({
  content: {
    label,
    name,
    description,
    mandatory,
    updateOnChange,
    updatePartially,
  },
  disabled = false,
  hidden = false,
  maxLength,
  form,
  onUpdate,
  onPartialUpdate,
  noDelayOnUpdate,
  noValidate = false,
  fieldName,
  placeholder,
  dataQa,
  questionnaireForm = false,
  ...props
}: FormikInputTextProps) {
  const [field, meta] = useField(name);
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  if (typeof props == "object") {
    // eslint-disable-next-line react/prop-types
    delete props["slider"];
    // eslint-disable-next-line react/prop-types
    delete props["paramType"];
  }

  const toInputUppercase = (e) => {
    if (!name.includes("email")) {
      e.target.value = ("" + e.target.value).toUpperCase();
    }
  };

  const hasError = /*hasErrorsOnTouched(form) &&*/ meta.error;

  useEffect(() => {
    const delayDebounceFn = setTimeout(() => {
      if (updateOnChange && form?.dirty && onUpdate) {
        form?.validateForm().then((result) => {
          if (!result[name]) {
            onUpdate(form?.values);
          }
        });
      }
    }, 1000);
    return () => clearTimeout(delayDebounceFn);
  }, [field.value]);

  useEffect(() => {
    const update = updateOnChange || updatePartially;
    if (onPartialUpdate && form?.dirty && fieldName) {
      if (noDelayOnUpdate) {
        form.validateForm().then((result) => {
          if (!result[name] || noValidate) {
            onPartialUpdate({ [fieldName]: field.value }, update || false);
          }
        });
      } else {
        const delayDebounceFn = setTimeout(() => {
          form.validateForm().then((result) => {
            if (!result[name] || noValidate) {
              onPartialUpdate({ [fieldName]: field.value }, update || false);
            }
          });
        }, 1000);
        return () => clearTimeout(delayDebounceFn);
      }
    }
  }, [field.value]);

  return (
    <>
      {!hidden && (
        <>
          {!questionnaireForm ? (
            <div className="yoga-form-input self-end" data-qa={dataQa}>
              <label
                htmlFor={name}
                className="block text-body-text text-base"
                data-qa={`${label}-label`}
              >
                <div className="inline-flex text-primary text-sm font-medium">
                  <FormattedMessage id={label || EMPTY} />
                  {mandatory && "*"}
                </div>
                {description && (
                  <button
                    type="button"
                    className="flex-none ml-2 text-primary w-6 h-6 align-bottom hover:cursor-pointer"
                    data-qa={`${name}-info`}
                    onClick={() => setIsModalOpen(true)}
                  >
                    <InformationCircleIcon />
                  </button>
                )}
                {disabled && (
                  <BanIcon className="w-6 text-action-disabled relative -bottom-9 float-right -left-4 cursor-not-allowed" />
                )}
                <input
                  className={classnames(
                    "h-12 focus:outline-none focus:border-primary tracking-wider py-3 px-4 text-base w-full shadow-inner",
                    hasError && disabled
                      ? "bg-background-disabled border-b hover:border-b-2 focus:border-b-2 border-error cursor-not-allowed text-action-disabled"
                      : "",
                    hasError && !disabled
                      ? "border-b hover:border-b-2 focus:border-b-2 border-error bg-box-background text-body-text"
                      : "",
                    !hasError && disabled
                      ? "bg-background-disabled border-b border-primary hover:border-b-2 focus:border-b-2 border-action-disabled cursor-not-allowed text-action-disabled"
                      : "",
                    !hasError && !disabled
                      ? "border-b border-primary hover:border-b-2 focus:border-b-2 border-primary bg-box-background text-body-text"
                      : ""
                  )}
                  {...field}
                  {...props}
                  type="text"
                  id={name}
                  data-qa={`${name}-input`}
                  disabled={disabled}
                  maxLength={maxLength}
                  placeholder={placeholder}
                  onInput={toInputUppercase}
                />
                {hasError && !disabled && false && (
                  <ExclamationCircleIcon className="w-6 text-error relative float-right -top-9 -left-4" />
                )}

                {
                  /*hasErrorsOnTouched(form) && (*/
                  <div className="h-6">
                    {hasError && (
                      <span
                        className="block text-base text-error"
                        data-qa={`error-message-${field.name}`}
                      >
                        {hasError && meta.error}
                      </span>
                    )}
                  </div>
                  /*)*/
                }
              </label>
            </div>
          ) : (
            <div
              className="questionnaire-yoga-form-input w-full"
              data-qa={dataQa}
            >
              <label
                htmlFor={name}
                className="block text-body-text text-base pr-4 w-2/3"
                data-qa={`${label}-label`}
              >
                <div className="inline-flex text-primary text-sm font-medium">
                  <FormattedMessage id={label || EMPTY} />
                  {mandatory && "*"}
                </div>
              </label>

              <div className="ygInput-container flex relative w-1/3">
                <div className="w-full relative pt-3">
                  <input
                    className={classnames(
                      "h-12 focus:outline-none focus:border-primary tracking-wider py-3 px-4 text-base w-full shadow-inne",
                      hasError && disabled
                        ? "bg-background-disabled border-b hover:border-b-2 focus:border-b-2 border-error cursor-not-allowed text-action-disabled"
                        : "",
                      hasError && !disabled
                        ? "border-b hover:border-b-2 focus:border-b-2 border-error bg-box-background text-body-text"
                        : "",
                      !hasError && disabled
                        ? "bg-background-disabled border-b hover:border-b-2 focus:border-b-2 border-action-disabled cursor-not-allowed text-action-disabled"
                        : "",
                      !hasError && !disabled
                        ? "border-b hover:border-b-2 focus:border-b-2 border-primary bg-box-background text-body-text"
                        : ""
                    )}
                    {...field}
                    {...props}
                    type="text"
                    id={name}
                    data-qa={`${name}-input`}
                    disabled={disabled}
                    maxLength={maxLength}
                    placeholder={placeholder}
                    onInput={toInputUppercase}
                  />

                  {
                    /*hasErrorsOnTouched(form) &&*/ hasError && (
                      <span
                        className="block text-base h-3 text-error leading-[1.2rem]"
                        data-qa={`error-message-${field.name}`}
                      >
                        {hasError && meta.error}
                      </span>
                    )
                  }

                  {/* {meta.touched && meta.error ? (
                <span className="block text-base h-6 text-error leading-[1.2rem]">
                  {meta.touched && meta.error}
                </span>
              ) : (
                <>
                  {form &&
                    Object.keys(toDotNotation(form.errors)).filter((v) =>
                      Object.keys(toDotNotation(form.touched)).includes(v)
                    ).length > 0 && <div className="h-6" />}
                </>
              )} */}
                  {disabled && (
                    <BanIcon className="w-6 text-action-disabled cursor-not-allowed position-icon" />
                  )}
                  {hasError && !disabled && false && (
                    <ExclamationCircleIcon className="w-6 text-error position-icon" />
                  )}
                </div>

                {description && (
                  <button
                    type="button"
                    className="inline ml-2 text-primary w-6 h-6 align-bottom hover:cursor-pointer questionnaire-info-btn mt-3"
                    data-qa={`${name}-info`}
                    onClick={() => setIsModalOpen(true)}
                  >
                    <InformationCircleIcon />
                  </button>
                )}
              </div>
            </div>
          )}

          {description && (
            <DetailsModal
              data-qa={`${name}-modal`}
              isOpen={isModalOpen}
              onClose={() => {
                setIsModalOpen(false);
              }}
              title={label}
            >
              {description}
            </DetailsModal>
          )}
        </>
      )}
    </>
  );
}
