import { InformationCircleIcon } from "@heroicons/react/outline";
import { BanIcon, CheckCircleIcon, ChevronDownIcon } from "@heroicons/react/solid";
import classnames from "classnames";
import { EMPTY } from "commons/Utils";
import "commons/components/YogaMultiChoice.css";
import { DetailsModal } from "commons/modals/DetailsModal";
import { KeyValue } from "commons/models/YogaModels";
import { FormInputParam, YogaParamValueType } from "commons/models/YogaParam";
import { FieldProps, useField } from "formik";
import { useEffect, useState } from "react";
import { FormattedMessage, useIntl } from "react-intl";
import Select, { ValueContainerProps, components } from "react-select";

interface FormikMultiChoiceProps extends FieldProps<any> {
  content: FormInputParam;
  disabled?: boolean;
  questionnaireForm?: boolean;
  hidden?: boolean;
  dataQa?: string;
  onUpdate?: (values: KeyValue<YogaParamValueType>) => any;
  onPartialUpdate?: (values: KeyValue<YogaParamValueType>, updateOnChange: boolean) => any;
  fieldName?: string;
}

export default function FormikMultiChoice({
  content: { label, availableValues, description, placeholder, updateOnChange, mandatory },
  field: { name },
  form,
  disabled = false,
  onUpdate,
  onPartialUpdate,
  fieldName,
  hidden,
  questionnaireForm,
  dataQa,
}: FormikMultiChoiceProps) {
  const [field, meta, helpers] = useField(name);
  const { setValue, setTouched, setError } = helpers;
  // const [selection, setSelection] = useState([]);
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);

  const intl = useIntl();

  const hasError = /*meta.touched &&*/ meta.error;

  useEffect(() => {
    // if (field.value || field.value.length === 0) {
    //   setSelection(undefined);
    // }
    // if (field.value || field.value === "") {
    //   setSelection(undefined);
    // }

    if (onPartialUpdate && meta.touched && fieldName) {
      onPartialUpdate({ [fieldName]: field.value }, updateOnChange || false);
    }

    if (updateOnChange && form.dirty && onUpdate) {
      onUpdate(form.values);
    }
  }, [field.value]);

  // useEffect(() => {
  //   if (selection === undefined) {
  //     setSelection(field.value || []);
  //   }
  // }, [selection]);

  const { Option } = components;

  const customOption = (props: any) => {
    // eslint-disable-next-line react/prop-types
    const label = props.data.label;
    // eslint-disable-next-line react/prop-types
    const bgColor = props.data.index % 2 === 0 ? "option0" : "option1";
    console.log(props.data + " " + bgColor);
    // eslint-disable-next-line react/prop-types
    if (props.isSelected)
      return (
        <Option {...props} className={bgColor}>
          {label}
          <CheckCircleIcon className="w-6 h-6" />
        </Option>
      );
    else
      return (
        <Option {...props} className={bgColor}>
          {label}
        </Option>
      );
  };

  const DropdownIndicator = (props: any) => {
    return (
      <components.DropdownIndicator {...props}>
        {disabled ? <BanIcon className="w-6 h-6 text-action-disabled" /> : <ChevronDownIcon className="w-6 h-6 text-primary" />}
      </components.DropdownIndicator>
    );
  };

  const ValueContainer = ({ children, ...props }: ValueContainerProps) => {
    const values: Array<any> = props.selectProps.value as Array<any>;
    return (
      <components.ValueContainer {...props}>
        {values && values.length > 3 ? intl.formatMessage({ id: "optionsSelected" }, { number: values.length }) : children}
      </components.ValueContainer>
    );
  };

  // const getLabel = (a: any): string | undefined => a?.label ?? a;

  // const sortAlphabetically = (a?: any, b?: any) =>
  //   getLabel(a)?.localeCompare(getLabel(b)) ?? 0;

  // const sortBySelectedAndAlphabetically = (a?: any, b?: any) => {
  //   const isSelected = (opt): number => {
  //     const found = selection?.some(
  //       (it: string) => it === getLabel(opt) || it === opt?.value
  //     );
  //     return found ? 1 : 0;
  //   };
  //   return -isSelected(a) + isSelected(b) || sortAlphabetically(a, b);
  // };

  function onChange(selected: any[]) {
    // selected?.sort(sortAlphabetically);
    let value;
    if (selected.length > 0) {
      value = selected.map((e) => e.value);
    } else value = "";

    // setSelection(value);
    setTouched(true);
    setValue(value);
    if (meta.error) setError(meta.error);
  }

  function stringToOptionMap(value: string[]) {
    if (!value) return;
    return value.map((element) => {
      return { value: element, label: element };
    });
  }

  const mutipleChoiceClasses = classnames({
    "border-b hover:border-b-2 focus:border-b-2 w-full": true,
    "border-error": hasError,
    "border-primary": !hasError && !disabled,
    "border-action-disabled": !hasError && disabled,
    "text-body-text bg-box-background": !disabled,
    "text-action-disabled bg-background-disabled": disabled,
  });

  const options = availableValues?.map((value) => {
    if (typeof value === "string")
      return {
        value: value,
        label: intl.formatMessage({ id: value || EMPTY }),
      };
    else
      return {
        value: value.value,
        label: intl.formatMessage({ id: value.label }),
      };
  });

  return (
    <>
      {!hidden && (
        <>
          {!questionnaireForm ? (
            <></>
          ) : (
            <div className="questionnaire-yoga-form-input w-full" data-qa={dataQa}>
              <label htmlFor={name} className="block text-body-text text-base pr-4 w-2/3" data-qa={`${label}-label`}>
                <div className="inline-flex items-center text-primary text-sm font-medium">
                  <FormattedMessage id={label || EMPTY} />
                  {mandatory && "*"}
                </div>
              </label>
              <div className="ygInput-container w-1/3">
                <div className="flex pt-3">
                  {availableValues && (
                    <Select
                      classNamePrefix="multi-choice-select"
                      className={mutipleChoiceClasses}
                      id={name}
                      data-qa={`${name}-multi-select`}
                      defaultValue={stringToOptionMap(field.value)}
                      options={options}
                      onChange={onChange}
                      hideSelectedOptions={false}
                      components={{
                        Option: customOption,
                        DropdownIndicator,
                        ValueContainer,
                      }}
                      placeholder={placeholder ?? ""}
                      noOptionsMessage={() => intl.formatMessage({ id: "noResults" })}
                      isDisabled={disabled}
                      isClearable={true}
                      isMulti
                      closeMenuOnSelect={false}
                    />
                  )}
                  {description && (
                    <button
                      type="button"
                      className="flex-none ml-2 text-primary w-6 h-6 align-bottom hover:cursor-pointer questionnaire-info-btn"
                      data-qa={`${name}-info`}
                      onClick={() => setIsModalOpen(true)}
                    >
                      <InformationCircleIcon className="text-body-text" />
                    </button>
                  )}

                  {description && (
                    <DetailsModal
                      data-qa={`${name}-modal`}
                      isOpen={isModalOpen}
                      onClose={() => {
                        setIsModalOpen(false);
                      }}
                      title={label}
                    >
                      {description}
                    </DetailsModal>
                  )}
                </div>
                <span className="block text-base h-3 text-error leading-[1.2rem]">{hasError && meta.error}</span>
              </div>
            </div>
          )}
        </>
      )}
    </>
  );
}
