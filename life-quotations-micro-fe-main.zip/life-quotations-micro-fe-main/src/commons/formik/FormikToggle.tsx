import { FormikProps, useField } from "formik";
import { FormattedMessage } from "react-intl";
import { EMPTY } from "commons/Utils";
import { FormInputParam, YogaParamValueType } from "commons/models/YogaParam";
import { KeyValue } from "commons/models/YogaModels";
import { useEffect, useState } from "react";
import classnames from "classnames";
import { InformationCircleIcon } from "@heroicons/react/outline";
import { DetailsModal } from "commons/modals/DetailsModal";
//import { hasErrorsOnTouched } from "./Utils";

interface FormikToggleProps {
  content: FormInputParam;
  disabled?: boolean;
  form?: FormikProps<any>;
  onUpdate?: (values: KeyValue<YogaParamValueType>) => any;
  onPartialUpdate?: (values: KeyValue<YogaParamValueType>, updateOnChange: boolean) => any;
  fieldName?: string;
  values?: any;
  dataQa?: string;
  questionnaireForm?: boolean;
}

export function FormikToggle({
  content: { label, description, mandatory, name, updateOnChange },
  disabled = false,
  form,
  onUpdate,
  onPartialUpdate,
  fieldName,
  dataQa,
  questionnaireForm = false,
}: FormikToggleProps) {
  const [field, meta, helpers] = useField(name);
  const { setValue } = helpers;
  const hasError = /*(meta.touched || form.submitCount > 0) &&*/ meta.error;
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);

  useEffect(() => {
    if (updateOnChange && form?.dirty && onUpdate) {
      onUpdate(form?.values);
    }
  }, [field.value]);

  useEffect(() => {
    if (onPartialUpdate && form?.dirty && fieldName) {
      onPartialUpdate({ [fieldName]: field.value }, updateOnChange || false);
    }
  }, [field.value]);

  const isSelected = (val: boolean) => {
    return field.value === val || field.value === String(val);
  };

  return (
    <>
      {!questionnaireForm ? (
        <div className="yoga-form-input self-end" data-qa={dataQa}>
          <label htmlFor={name} className="block text-body-text text-base" data-qa={`${label}-label`}>
            <span className="block">
              <div className="inline-flex text-primary text-sm font-medium">
                <FormattedMessage id={label || EMPTY} />
                {mandatory && "*"}
              </div>
              {description && (
                <button
                  type="button"
                  className="flex-none ml-2 text-body-text w-6 h-6 align-bottom hover:cursor-pointer"
                  data-qa={`${name}-info`}
                  onClick={() => setIsModalOpen(true)}
                >
                  <InformationCircleIcon />
                </button>
              )}
            </span>

            <div id={name} data-qa={`${name}-select-buttons`} className="flex w-1/2 h-10">
              <button
                data-qa="false"
                type="button"
                onClick={() => setValue(false)}
                disabled={disabled}
                className={classnames("flex align-middle items-center border-2 rounded-3xl w-1/2 h-8 text-base", {
                  "bg-background-disabled border-error cursor-not-allowed text-action-disabled": hasError && disabled,
                  "border-error bg-box-background text-body-text": hasError && !disabled && !isSelected(false),
                  "border-error bg-primary text-button-text": hasError && !disabled && isSelected(false),
                  "bg-transparent text-action-disabled border-action-disabled cursor-not-allowed": !hasError && disabled && !isSelected(false),
                  "bg-action-disabled text-button-text border-action-disabled cursor-not-allowed": disabled && isSelected(false),
                  "bg-primary text-button-text border-primary": !hasError && !disabled && isSelected(false),
                  "border-body-text text-body-text bg-box-background border-r-primary": !hasError && !disabled && !isSelected(false),
                })}
              >
                <span className="w-6 mx-auto">
                  <FormattedMessage id="no" />
                </span>
              </button>
              <button
                data-qa="true"
                type="button"
                onClick={() => setValue(true)}
                disabled={disabled}
                className={classnames("flex align-middle items-center  border-2 border-l-0 rounded-3xl w-1/2 h-8 text-base", {
                  "bg-background-disabled border-2 border-error cursor-not-allowed text-action-disabled": hasError && disabled,
                  "border-error bg-box-background text-body-text": hasError && !disabled && !isSelected(true),
                  "border-error bg-primary text-button-text": hasError && !disabled && isSelected(true),
                  "bg-transparent text-action-disabled border-action-disabled cursor-not-allowed": !hasError && disabled && !isSelected(true),
                  "bg-action-disabled text-button-text border-action-disabled cursor-not-allowed": disabled && isSelected(true),
                  "bg-primary text-button-text border-primary": !hasError && !disabled && isSelected(true),
                  "border-body-text text-body-text bg-box-background": !hasError && !disabled && !isSelected(true),
                })}
              >
                <span className="w-6 mx-auto">
                  <FormattedMessage id="yes" />
                </span>
              </button>
            </div>
          </label>
          {
            /*hasErrorsOnTouched(form) && (*/
            <div className="h-6">
              {hasError && (
                <span className="block text-base text-error" data-qa={`error-message-${name}`}>
                  {hasError && meta.error}
                </span>
              )}
            </div>
            /*)*/
          }
          {description && (
            <DetailsModal
              data-qa={`${name}-modal`}
              isOpen={isModalOpen}
              onClose={() => {
                setIsModalOpen(false);
              }}
              title={label}
            >
              {description}
            </DetailsModal>
          )}
        </div>
      ) : (
        <div className="questionnaire-yoga-form-input w-full" data-qa={dataQa}>
          <label htmlFor={name} className="block text-body-text text-base pr-4 w-2/3" data-qa={`${label}-label`}>
            <span className="block">
              <div className="inline-flex text-primary text-sm font-medium">
                <FormattedMessage id={label || EMPTY} />
                {mandatory && "*"}
              </div>
            </span>
          </label>

          <div className="ygInput-container flex relative pt-3 w-1/3">
            <div className="w-full relative">
              <div id={name} data-qa={`${name}-select-buttons`} className="flex w-full">
                <button
                  data-qa="false"
                  type="button"
                  onClick={() => setValue(false)}
                  disabled={disabled}
                  className={classnames("border-2 rounded-lg rounded-r-none w-1/2 h-12 text-base", {
                    "bg-background-disabled border-error cursor-not-allowed text-action-disabled": hasError && disabled,
                    "border-error bg-box-background text-body-text": hasError && !disabled && !isSelected(false),
                    "border-error bg-primary text-button-text": hasError && !disabled && isSelected(false),
                    "bg-background-disabled text-action-disabled border-action-disabled cursor-not-allowed":
                      !hasError && disabled && !isSelected(false),
                    "bg-action-disabled text-button-text border-action-disabled cursor-not-allowed": disabled && isSelected(false),
                    "bg-primary text-button-text border-primary": !hasError && !disabled && isSelected(false),
                    "border-body-text text-body-text bg-box-background border-r-primary": !hasError && !disabled && !isSelected(false),
                  })}
                >
                  <span className="w-6 mx-auto">
                    <FormattedMessage id="no" />
                  </span>
                </button>
                <button
                  data-qa="true"
                  type="button"
                  onClick={() => setValue(true)}
                  disabled={disabled}
                  className={classnames("border-2 border-l-0 rounded-lg rounded-l-none w-1/2 h-12 text-base", {
                    "bg-background-disabled border-2 border-error cursor-not-allowed text-action-disabled": hasError && disabled,
                    "border-error bg-box-background text-body-text": hasError && !disabled && !isSelected(true),
                    "border-error bg-primary text-button-text": hasError && !disabled && isSelected(true),
                    "bg-background-disabled text-action-disabled border-action-disabled cursor-not-allowed":
                      !hasError && disabled && !isSelected(true),
                    "bg-action-disabled text-button-text border-action-disabled cursor-not-allowed": disabled && isSelected(true),
                    "bg-primary text-button-text border-primary": !hasError && !disabled && isSelected(true),
                    "border-body-text text-body-text bg-box-background": !hasError && !disabled && !isSelected(true),
                  })}
                >
                  <span className="w-6 mx-auto">
                    <FormattedMessage id="yes" />
                  </span>
                </button>
              </div>

              <span className="block text-base h-3 text-error leading-[1.2rem]">{meta.touched && meta.error}</span>

              {/* {meta.touched && meta.error ? (
                <span className="block text-base h-6 text-error">
                  {meta.touched && meta.error}
                </span>
              ) : (
                <>
                  {form &&
                    Object.keys(toDotNotation(form.errors)).filter((v) =>
                      Object.keys(toDotNotation(form.touched)).includes(v)
                    ).length > 0 && <div className="h-6" />}
                </>
              )} */}
            </div>

            {description && (
              <button
                type="button"
                className="w-6 h-6 align-bottom hover:cursor-pointer questionnaire-info-btn text-body-text"
                data-qa={`${name}-info`}
                onClick={() => setIsModalOpen(true)}
              >
                <InformationCircleIcon />
              </button>
            )}
            {description && (
              <DetailsModal
                data-qa={`${name}-modal`}
                isOpen={isModalOpen}
                onClose={() => {
                  setIsModalOpen(false);
                }}
                title={label}
              >
                {description}
              </DetailsModal>
            )}
          </div>
        </div>
      )}
    </>
  );
}
