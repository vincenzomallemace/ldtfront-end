import { FormikProps, useField } from "formik";
import React, { useState } from "react";
import { FormattedMessage } from "react-intl";
import { EMPTY } from "commons/Utils";
import { FormInputParam } from "commons/models/YogaParam";
import {
  BanIcon,
  ExclamationCircleIcon,
  InformationCircleIcon,
} from "@heroicons/react/outline";
import PhoneInput from "react-phone-number-input";
import "react-phone-number-input/style.css";
import "./FormikInputPhone.css";
import classnames from "classnames";
import { DetailsModal } from "commons/modals/DetailsModal";
//import { hasErrorsOnTouched } from "./Utils";

interface FormikInputPhoneProps {
  content: FormInputParam;
  disabled?: boolean;
  form?: FormikProps<any>;
  values?: any;
  dataQa?: string;
}

export function FormikInputPhone({
  content: { label, description, mandatory, name },
  disabled = false,
  //form,
  dataQa,
}: FormikInputPhoneProps) {
  const [field, meta, helpers] = useField(name);
  const { setValue, setTouched, setError } = helpers;
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);

  function onChange(number: any) {
    setTouched(true);
    if (meta.error) setError(meta.error);
    if (number) setValue(number);
    else setValue(null);
  }

  const hasError = /*hasErrorsOnTouched(form) &&*/ meta.error;

  return (
    <div className="yoga-form-input self-end" data-qa={dataQa}>
      <label
        htmlFor={name}
        className="block text-body-text text-base"
        data-qa={`${label}-label`}
      >
        <div className="inline-flex text-primary text-sm font-medium">
          <FormattedMessage id={label || EMPTY} />
          {mandatory && "*"}
        </div>
        {description && (
          <button
            type="button"
            className="flex-none ml-2 text-primary w-6 h-6 align-bottom hover:cursor-pointer"
            data-qa={`${name}-info`}
            onClick={() => setIsModalOpen(true)}
          >
            <InformationCircleIcon />
          </button>
        )}
        <div
          data-qa={`${name}-input`}
          id={name}
          className={classnames(
            "h-12 focus:outline-none focus:border-primary rounded-lg tracking-wider text-base w-full shadow-inner",
            meta.touched && meta.error && disabled
              ? "bg-background-disabled border-2 border-error cursor-not-allowed text-action-disabled"
              : "",
            meta.touched && meta.error && !disabled
              ? "border-2 border-error bg-box-background text-body-text"
              : "",
            !(meta.touched && meta.error) && disabled
              ? "bg-background-disabled border-2 border-action-disabled cursor-not-allowed text-action-disabled"
              : "",
            !(meta.touched && meta.error) && !disabled
              ? "border-2 border-primary bg-box-background text-body-text"
              : ""
          )}
        >
          {disabled && (
            <BanIcon className="w-6 text-action-disabled relative -bottom-2.5 float-right -left-4 cursor-not-allowed" />
          )}
          <PhoneInput
            value={field.value}
            onChange={onChange}
            defaultCountry="IT"
            international={false}
            className="mt-[2px] mr-[2px]"
            disabled={disabled}
          />
        </div>
        {meta.touched && meta.error && false && !disabled && (
          <ExclamationCircleIcon className="w-6 text-error relative -top-9 float-right -left-4" />
        )}
      </label>

      {
        /*hasErrorsOnTouched(form) && (*/
        <div className="h-6">
          {hasError && (
            <span
              className="block text-base text-error"
              data-qa={`error-message-${field.name}`}
            >
              {hasError && meta.error}
            </span>
          )}
        </div>
        /*)*/
      }
      {description && (
        <DetailsModal
          data-qa={`${name}-modal`}
          isOpen={isModalOpen}
          onClose={() => {
            setIsModalOpen(false);
          }}
          title={label}
        >
          {description}
        </DetailsModal>
      )}
    </div>
  );
}
