import { FormattedMessage, useIntl } from "react-intl";
import { FormikProps, useField } from "formik";
import React, { useEffect, useState } from "react";
import { FormInputParam, YogaParamValueType } from "commons/models/YogaParam";
import { KeyValue } from "commons/models/YogaModels";
import { EMPTY } from "commons/Utils";
import classnames from "classnames";
import Select, {
  ActionMeta,
  components,
  StylesConfig,
  ValueContainerProps,
} from "react-select";
import {
  CheckIcon,
  ChevronDownIcon,
  InformationCircleIcon,
} from "@heroicons/react/outline";
import "commons/components/YogaMultiSelect.css";
import { DetailsModal } from "commons/modals/DetailsModal";

interface FormikMultiSelectProps {
  content: FormInputParam;
  disabled?: boolean;
  hidden?: boolean;
  form?: FormikProps<any>;
  onUpdate?: (values: KeyValue<YogaParamValueType>) => any;
  onPartialUpdate?: (
    values: KeyValue<YogaParamValueType>,
    updateOnChange: boolean
  ) => any;
  fieldName?: string;
  dataQa?: string;
  fixedValues: string[];
}

export function FormikMultiSelect({
  content: {
    label,
    description,
    name,
    availableValues,
    updateOnChange,
    mandatory,
    updatePartially,
  },
  form,
  disabled = false,
  hidden = false,
  fieldName,
  onUpdate,
  onPartialUpdate,
  dataQa,
  fixedValues = [],
}: FormikMultiSelectProps) {
  const [field, meta, helpers] = useField(name);
  const { setValue, setTouched, setError } = helpers;
  const [selection, setSelection] = useState([]);
  const [values, setValues] = useState([]);
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);

  useEffect(() => {
    if (availableValues?.length > 0) {
      const orderedFilteredValues = orderOptions(
        availableValues.map((entry) => {
          entry["isFixed"] = fixedValues.indexOf(entry["value"]) != -1;
          return entry;
        })
      );
      setValues(orderedFilteredValues);
    }
  }, [availableValues]);

  useEffect(() => {
    if (field.value || field.value?.length === 0) {
      setSelection(undefined);
    }
    if (updateOnChange && form?.dirty && onUpdate) {
      onUpdate(form.values);
    }
  }, [field.value]);

  const intl = useIntl();
  const VISIBLE_CHIPS = 5;

  useEffect(() => {
    const update = updateOnChange || updatePartially;
    if (field.value || field.value?.length === 0) {
      setSelection(undefined);
    }
    if (onPartialUpdate && form?.dirty && fieldName) {
      onPartialUpdate({ [fieldName]: field.value }, update || false);
    }
  }, [field.value]);

  useEffect(() => {
    if (selection === undefined) {
      setSelection(field.value || []);
    }
  }, [selection]);

  const { Option } = components;
  const customOption = (props: any) => {
    // eslint-disable-next-line react/prop-types
    const label = props.data.label;
    // eslint-disable-next-line react/prop-types
    if (props.isSelected)
      return (
        <Option {...props}>
          {label}
          <CheckIcon className="w-6" />
        </Option>
      );
    else return <Option {...props}>{label}</Option>;
  };

  const DropdownIndicator = (props: any) => {
    return (
      <components.DropdownIndicator {...props}>
        <ChevronDownIcon className="w-6 text-body-text" />
      </components.DropdownIndicator>
    );
  };

  const getLabel = (a: any): string | undefined => a?.label ?? a;

  const sortAlphabetically = (a?: any, b?: any) =>
    getLabel(a)?.localeCompare(getLabel(b)) ?? 0;

  const sortBySelectedAndAlphabetically = (a?: any, b?: any) => {
    const isSelected = (opt): number => {
      const found = selection?.some(
        (it: string) => it === getLabel(opt) || it === opt?.value
      );
      return found ? 1 : 0;
    };
    return -isSelected(a) + isSelected(b) || sortAlphabetically(a, b);
  };

  const orderOptions = (values: any[]) => {
    return values
      .filter((v) => v.isFixed)
      .concat(values.filter((v) => !v.isFixed));
  };

  function onChange(selected: any[], actionMeta: ActionMeta<any>) {
    switch (actionMeta.action) {
      case "remove-value":
      case "pop-value":
        if (actionMeta.removedValue.isFixed) {
          return;
        }
        break;
      case "clear":
        selected = values.filter((v) => v.isFixed);
        break;
    }

    let orderedVallues = orderOptions(selected?.sort(sortAlphabetically));
    let value = [];
    if (orderedVallues.length > 0) {
      value = orderedVallues.map((e) => e.value);
    }

    setSelection(value);
    setTouched(true);
    setValue(value);
    if (meta.error) setError(meta.error);
  }

  const ValueContainer = ({
    children,
    ...props
  }: ValueContainerProps<any, any>) => {
    let [values, input] = children as any;
    if (Array.isArray(values)) {
      if (values.length > VISIBLE_CHIPS) {
        values = `${values.length} ${intl.formatMessage({
          id: "optionsSelected",
        })}`;
      }
    }
    return (
      <components.ValueContainer {...props}>
        {values}
        {input}
      </components.ValueContainer>
    );
  };

  function stringToOptionMap(value: string[]) {
    if (!value) return;
    return value.map((element) => {
      const item = values.filter((item) => element === item.value);
      return {
        value: element,
        label: item.length > 0 ? item[0]?.label : element,
        isFixed: fixedValues.indexOf(element) > -1,
      };
    });
  }

  const styles: StylesConfig<any, true> = {
    multiValue: (base, state) => {
      return state.data.isFixed ? { ...base, backgroundColor: "gray" } : base;
    },
    multiValueLabel: (base, state) => {
      return state.data.isFixed ? { ...base, paddingRight: 6 } : base;
    },
    multiValueRemove: (base, state) => {
      return state.data.isFixed ? { ...base, display: "none" } : base;
    },
  };

  const hasError = meta.touched && meta.error;
  const selectClasses = classnames({
    "rounded-lg border-2": true,
    "border-error": hasError,
    "border-body-text": !hasError && !disabled,
    "border-action-disabled": !hasError && disabled,
    "text-body-text bg-box-background": !disabled,
    "text-action-disabled bg-background-disabled": disabled,
  });

  const options = values
    .filter((value) => !value.isFixed)
    .sort(sortBySelectedAndAlphabetically);

  return (
    !hidden && (
      <div className="yoga-form-input" data-qa={dataQa}>
        <label
          htmlFor={name}
          className="block text-body-text text-base"
          data-qa={`${label}-label`}
        >
          <div className="inline-flex text-primary text-sm font-medium">
            <FormattedMessage id={label || EMPTY} />
            {mandatory && "*"}
            {mandatory && "*"}
          </div>
          {description && (
            <button
              type="button"
              className="flex-none ml-2 text-primary w-6 h-6 align-bottom hover:cursor-pointer"
              data-qa={`${name}-info`}
              onClick={() => setIsModalOpen(true)}
            >
              <InformationCircleIcon />
            </button>
          )}
          {selection && availableValues && values?.length > 0 && (
            <Select
              isMulti
              placeholder=""
              id={name}
              styles={styles}
              data-qa={`${name}-multi-select`}
              classNamePrefix="multi-select"
              className={selectClasses}
              value={stringToOptionMap(field.value)}
              options={options}
              onChange={onChange}
              hideSelectedOptions={false}
              components={{
                Option: customOption,
                DropdownIndicator,
                ValueContainer: ValueContainer,
              }}
              noOptionsMessage={() => intl.formatMessage({ id: "noResults" })}
              isDisabled={disabled}
              isClearable={!mandatory || (options && options.length > 1)}
            />
          )}
        </label>

        {meta.touched && meta.error && (
          <span className="block text-base h-6 text-error">
            {meta.touched && meta.error}
          </span>
        )}
        {description && (
          <DetailsModal
            data-qa={`${name}-modal`}
            isOpen={isModalOpen}
            onClose={() => {
              setIsModalOpen(false);
            }}
            title={label}
          >
            {description}
          </DetailsModal>
        )}
      </div>
    )
  );
}
