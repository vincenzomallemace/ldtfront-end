import { BanIcon } from "@heroicons/react/outline";
import { CheckIcon, ChevronDownIcon } from "@heroicons/react/solid";
import { default as classNames, default as classnames } from "classnames";
import { FieldProps, getIn, useField } from "formik";
import { FormattedMessage, useIntl } from "react-intl";
import Select, { SingleValue, components } from "react-select";
import { CodeAndDescription } from "../models/CodeAndDescription";
import { EMPTY } from "commons/Utils";
import { hasErrorsOnTouched } from "./Utils";

interface FormikCodeAndDescriptionSelectProps
  extends FieldProps<CodeAndDescription> {
  label?: string;
  disabled?: boolean;
  mandatory?: boolean;
  hidden?: boolean;
  onChange?: (value?: CodeAndDescription) => any;
  options?: CodeAndDescription[];
}

export function FormikCodeAndDescriptionSelect({
  field: { name, value },
  form,
  onChange = () => {},
  disabled = false,
  mandatory = false,
  hidden = false,
  label = EMPTY,
  options = [],
}: FormikCodeAndDescriptionSelectProps) {
  const [, meta, helpers] = useField(name);
  const { setValue, setTouched } = helpers;
  const intl = useIntl();
  const initSelection = options.find(
    (e) => e.code === getIn(form.initialValues, `${name}.code`)
  );

  const { Option } = components;
  const customOption = (props: any) => {
    // eslint-disable-next-line react/prop-types
    const label = intl.formatMessage({
      id: props.data.description || props.data.code,
    });
    // eslint-disable-next-line react/prop-types
    if (props.isSelected)
      return (
        <Option {...props}>
          <span className="flex-1">{label}</span>
          <CheckIcon className="w-6 text-primary" />
        </Option>
      );
    else return <Option {...props}>{label}</Option>;
  };

  const DropdownIndicator = (props: any) => {
    return (
      <components.DropdownIndicator {...props}>
        {disabled ? (
          <BanIcon className="w-6 text-disabled-text" />
        ) : (
          <ChevronDownIcon className="w-6 text-primary" />
        )}
      </components.DropdownIndicator>
    );
  };

  const NoOptionsMessage = (props: any) => {
    return (
      <components.NoOptionsMessage {...props}>
        <FormattedMessage id="noResults" />
      </components.NoOptionsMessage>
    );
  };

  function innerChange(v: SingleValue<CodeAndDescription>) {
    let value: CodeAndDescription | undefined = { code: "", description: "" };
    if (v) value = { code: v.code, description: v.description };
    setTouched(true);
    setValue(value, true);
    onChange(value);
    // if (meta.error) setError(meta.error)
  }

  const hasError = meta.touched && meta.error;
  const selectClasses = classnames({
    "rounded-lg border-2": true,
    "border-error": hasError,
    "border-body-text": !hasError && !disabled,
    "border-action-disabled": !hasError && disabled,
    "text-body-text bg-box-background": !disabled,
    "text-action-disabled bg-background-disabled": disabled,
  });

  return (
    <div className={classNames("yoga-form-input self-end", hidden && "hidden")}>
      <label
        htmlFor={name}
        className="block text-field-label text-base"
        data-qa={`${label}-label`}
      >
        <div className="text-primary text-sm font-medium">
          <FormattedMessage id={label || EMPTY} />
          {mandatory && "*"}
        </div>
        <Select
          className={selectClasses}
          id={name}
          data-qa={`${name}-select`}
          classNamePrefix="custom-select"
          components={{
            Option: customOption,
            DropdownIndicator,
            NoOptionsMessage,
          }}
          getOptionLabel={(opt) => {
            const label = opt.description || opt.code;
            return !label
              ? ""
              : intl.formatMessage({ id: opt.description || opt.code });
          }}
          isOptionSelected={(opt) => opt.code === value?.code}
          placeholder=""
          defaultValue={initSelection}
          onChange={innerChange}
          options={options as any}
          isDisabled={disabled}
          isClearable={!mandatory && options && options.length > 1}
          noOptionsMessage={() => intl.formatMessage({ id: "noResults" })}
          menuPlacement="auto"
          menuPosition="absolute"
          menuPortalTarget={document.body}
          value={value}
          styles={{
            menuPortal: (provided) => ({
              ...provided,
              zIndex: 9999,
            }),
            singleValue: (base) => ({
              ...base,
              color: "var(--field-text)",
            }),
          }}
          captureMenuScroll
        />
      </label>

      {hasErrorsOnTouched(form) && (
        <div className="h-6">
          {meta.error && (
            <span
              className="block text-base text-error"
              data-qa={`error-message-${name}`}
            >
              {meta.error}
            </span>
          )}
        </div>
      )}
    </div>
  );
}
