import { Location } from "commons/models/Location";
import { useField } from "formik";
import { FormikInputProps } from "./FormikInput";
//import { FormInputParam } from "commons/models/YogaParam";
import { useEffect } from "react";
import { mandatoryLocationParams, Suggestion, suggestionToLocation } from "commons/models/Suggestion";
import { config } from "commons/Configuration";
import { LocationAutocomplete } from "commons/components/LocationAutocomplete";
import { LocationSplitted } from "commons/components/LocationSplitted";

interface FormikLocationProps extends FormikInputProps<Location> {
  className?: string;
}

export default function FormikLocation({ content, field: { name }, disabled = false, form }: FormikLocationProps) {
  const [field, meta, helpers] = useField(`${name}.label`); // mi serve l'errore sulla label mancante perchè  quello che viene valorizzato in caso di config.GEOLOCATION == "disabled"
  const { setValue } = helpers;

  // const paramForDisabledGeolocation: FormInputParam = Object.assign(
  //   {},
  //   content,
  //   {
  //     name: `${name}.label`,
  //     type: "STRING",
  //   }
  // );

  useEffect(() => {
    (field.value === undefined || field.value === null) && form.setFieldValue(name, { label: "" }, true);
  }, [field.value]);

  function setLocation(suggestion?: Suggestion) {
    if (suggestion) {
      let location = suggestionToLocation(suggestion);
      setValue(location.label);
      form.setFieldValue(name, location);
    } else {
      setValue("");
      form.setFieldValue(name, { label: null }, true);
    }
  }

  return (
    <>
      {config.GEOLOCATION == "disabled" ? (
        /*
        < Field
          key={`${name}.label`}
          name={`${name}.label`}
          component={FormikInput}
          content={paramForDisabledGeolocation}
          values={form.values}
          />*/
        <LocationSplitted
          name={name}
          label={content.label}
          startLocation={form.getFieldProps(name).value}
          form={form}
          error={meta.error}
          disabled={disabled}
        />
      ) : (
        <LocationAutocomplete
          id={`${name}`}
          label={content.label}
          className={content.className}
          onSelectLocation={setLocation}
          startLocation={form.getFieldProps(name).value}
          form={form}
          error={meta.touched ? meta.error : undefined}
          disabled={disabled}
          mandatoryLocationParams={mandatoryLocationParams}
        />
      )}
    </>
  );
}
