import { InformationCircleIcon } from "@heroicons/react/outline";
import { BanIcon, CheckCircleIcon, ChevronDownIcon } from "@heroicons/react/solid";
import classnames from "classnames";
import { EMPTY } from "commons/Utils";
import "commons/components/YogaMultiSelect.css";
import "commons/components/YogaSelect.css";
import { DetailsModal } from "commons/modals/DetailsModal";
import { CodeAndDescription } from "commons/models/CodeAndDescription";
import { KeyValue } from "commons/models/YogaModels";
import { FormInputParam, YogaParamValueType } from "commons/models/YogaParam";
import { FieldInputProps, FormikProps, useField } from "formik";
import { useEffect, useState } from "react";
import { FormattedMessage, useIntl } from "react-intl";
import Select, { components } from "react-select";
import ReactTooltip from "react-tooltip";

//import { hasErrorsOnTouched } from "./Utils";

interface FormikSelectProps {
  content: FormInputParam;
  disabled?: boolean;
  externalField?: boolean;
  form?: FormikProps<any>;
  onUpdate?: (values: KeyValue<YogaParamValueType>) => any;
  onPartialUpdate?: (values: KeyValue<YogaParamValueType>, updateOnChange: boolean) => any;
  onFieldChange?: (field: FieldInputProps<any>) => any;
  fieldName?: string;
  values?: any;
  dataQa?: string;
  autoselect?: boolean;
  questionnaireForm?: boolean;
  isParameterForm?: boolean;
}

export function FormikSelect({
  content: {
    label,
    description,
    name,
    availableValues,
    availableObjectValues,
    sort,
    disableBinarySelect = false,
    updateOnChange,
    mandatory,
    updatePartially,
    placeholder = "",
  },
  disabled = false,
  externalField = false,
  form,
  fieldName,
  onUpdate,
  onPartialUpdate,
  onFieldChange,
  dataQa,
  autoselect = false,
  questionnaireForm = false,
  isParameterForm = false,
}: FormikSelectProps) {
  const [field, meta, helpers] = useField(name);
  const { setValue, setTouched, setError } = helpers;
  const intl = useIntl();
  const [selection, setSelection] = useState<string>();
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);

  disableBinarySelect = availableObjectValues?.length > 0 ? true : disableBinarySelect;

  const transformToValueLabel = (objectValues: CodeAndDescription[]): { value: string; label: string }[] => {
    return objectValues?.map((item) => ({
      value: item.code,
      label: intl.formatMessage({ id: item?.code || EMPTY }) + " " + intl.formatMessage({ id: item.description || EMPTY }),
    }));
  };

  useEffect(() => {
    if (field.value || field.value === "") {
      setSelection(undefined);
    }
    if (updateOnChange && form?.dirty && onUpdate) {
      onUpdate(form.values);
    }
  }, [field.value]);

  useEffect(() => {
    if (onFieldChange) {
      onFieldChange(field);
    }
  }, [field.value]);

  useEffect(() => {
    const update = updateOnChange || updatePartially;
    if (onPartialUpdate && meta.touched && fieldName) {
      onPartialUpdate({ [fieldName]: field.value }, update || false);
    }
  }, [field.value]);

  useEffect(() => {
    if (selection === undefined) {
      setSelection(field.value || "");
    }
  }, [selection]);

  useEffect(() => {
    if (isParameterForm && availableObjectValues?.length > 0) {
      const valueDescription = availableObjectValues.find((v) => v.code == field.value)?.description || "";
      form.setFieldValue(`${name}Description`, valueDescription, false);
    }
  }, [field.value]);

  const options =
    availableObjectValues?.length > 0
      ? transformToValueLabel(availableObjectValues).sort((a, b) => (sort ? a.label.localeCompare(b.label) : 0))
      : availableValues
          ?.map((value, index) => {
            if (typeof value === "string")
              return {
                value: value,
                label: intl.formatMessage({ id: value || EMPTY }),
                index: index,
              };
            else
              return {
                value: value.value,
                label: intl.formatMessage({ id: value?.label || EMPTY }),
                index: index,
              };
          })
          .sort((a, b) => (sort ? a.label.localeCompare(b.label) : 0));

  const { Option } = components;
  const customOption = (props: any) => {
    // eslint-disable-next-line react/prop-types
    const value = props.data.value;

    // eslint-disable-next-line react/prop-types
    const label = props.data.label;

    // eslint-disable-next-line react/prop-types
    const bgColor = props.data.index % 2 === 0 ? "option0" : "option1";

    let description = "";
    if (availableObjectValues?.length > 0) {
      description = availableObjectValues.find((e) => e.code === value).description;
    }
    // eslint-disable-next-line react/prop-types
    if (props.isSelected)
      return (
        <Option {...props} className={bgColor}>
          {availableObjectValues?.length > 0 ? (
            <>
              {value}
              <br />
              {description}
            </>
          ) : (
            label
          )}
          <CheckCircleIcon className="w-6 h-6" />
        </Option>
      );
    else
      return (
        <Option {...props} className={bgColor}>
          {availableObjectValues?.length > 0 ? (
            <>
              {value}
              <br />
              {description}
            </>
          ) : (
            label
          )}
        </Option>
      );
  };

  const DropdownIndicator = (props: any) => {
    return (
      <components.DropdownIndicator {...props}>
        {disabled ? <BanIcon className="w-6 h-6 text-action-disabled" /> : <ChevronDownIcon className="w-6 h-6 text-primary" />}
      </components.DropdownIndicator>
    );
  };

  function onChange(v: any) {
    let value = "";
    if (v) value = v.value;
    setSelection(value as any);
    setTouched(true);
    setValue(value);
    if (meta.error) setError(meta.error);
  }

  useEffect(() => {
    if (autoselect) {
      if (availableObjectValues && availableObjectValues.length == 1) {
        setTouched(true);
        setValue(availableObjectValues[0].code);
      } else if (availableValues && availableValues.length == 1) {
        setTouched(true);
        setValue(getValue(availableValues[0]));
      } else if (
        ((availableValues?.length > 0 && !isIncluded(availableValues, selection)) ||
          (availableObjectValues?.length > 0 && !isInObjects(availableObjectValues, selection))) &&
        selection
      ) {
        setTouched(true);
        setValue("");
      }
    }
  }, [availableValues, selection]);

  const getValue = (value: string | { value: string; label: string }) => {
    if (typeof value === "string") {
      return value;
    }
    // eslint-disable-next-line react/prop-types
    return (value as { value: string; label: string }).value;
  };

  const getLabel = (values: (string | { value: string; label: string })[], selected: string) => {
    if (!values || values.length < 1 || typeof values[0] === "string") {
      return intl.formatMessage({ id: selection || EMPTY });
    }
    return intl.formatMessage({
      id: (values as { value: string; label: string }[]).find((e) => e.value === selected)?.label,
    });
  };

  const getObjectLabel = (values: CodeAndDescription[], selected: string) => {
    let label = "";
    const selectedObject = values?.find((object) => object.code === selected);
    label = intl.formatMessage({ id: selectedObject?.code || EMPTY }) + " " + intl.formatMessage({ id: selectedObject?.description || EMPTY });
    return label;
  };

  const getInitSelection = (select: string) => {
    if (availableObjectValues && availableObjectValues?.length > 0) {
      return {
        value: select,
        label: getObjectLabel(availableObjectValues, select),
      };
    } else
      return {
        value: select,
        label: getLabel(availableValues as string[] | { value: string; label: string }[], select),
      };
  };

  const isIncluded = (values: (string | { value: string; label: string })[], selected: string): boolean => {
    if (!values || values.length < 1) {
      return false;
    }
    if (typeof values[0] === "string") {
      return (values as string[]).includes(selected);
    }
    return (values as { value: string; label: string }[]).map((e) => e.value).includes(selected);
  };

  const isInObjects = (values: CodeAndDescription[], selected: string) => {
    return values.map((e) => e.code).includes(selected);
  };

  const initSelection = selection ? getInitSelection(selection) : null;

  const hasError = meta.error; /*&& (meta.touched || form.submitCount > 0)*/
  const selectClasses = classnames({
    "border-b hover:border-b-2 focus:border-b-2 w-full": true,
    "border-error": hasError,
    "border-primary": !hasError && !disabled,
    "border-action-disabled": !hasError && disabled,
    "text-body-text bg-box-background": !disabled,
    "text-action-disabled bg-background-disabled": disabled,
  });

  return (
    <>
      {!questionnaireForm ? (
        <div className="yoga-form-input w-full self-end" data-qa={dataQa}>
          <label htmlFor={name} className="block text-body-text text-base" data-qa={`${label}-label`}>
            <div className="inline-flex items-center text-primary text-sm font-medium">
              <FormattedMessage id={label || EMPTY} />
              {mandatory && "*"}
              {externalField && (
                <div className="bg-body-text rounded ml-1 text-box-background px-1 text-sm">
                  <FormattedMessage id="externalField" />
                </div>
              )}
            </div>
            {description && (
              <button
                type="button"
                className="flex-none ml-2 text-primary w-6 h-6 align-bottom hover:cursor-pointer"
                data-qa={`${name}-info`}
                onClick={() => setIsModalOpen(true)}
              >
                <InformationCircleIcon />
              </button>
            )}
            {(selection || selection === "") && (availableValues || availableObjectValues) && (
              <>
                {(availableObjectValues?.length == 2 || availableValues?.length == 2) && !disableBinarySelect ? (
                  <div id={name} data-qa={`${name}-select-buttons`} className="flex">
                    <div key={options[0].value || EMPTY} data-tip data-for={options[0].value || EMPTY} className="cursor-pointer w-1/2">
                      <ReactTooltip id={options[0].value || EMPTY} place="top" effect="solid" className="w-1/6" delayShow={1000}>
                        {options[0].label}
                      </ReactTooltip>
                      <button
                        title={options[0].label}
                        data-qa={options[0].value}
                        type="button"
                        onClick={() => onChange(options[0])}
                        disabled={disabled}
                        className={classnames("rounded-lg rounded-r-none w-full h-12 text-base truncate px-2", {
                          "bg-background-disabled border-error cursor-not-allowed text-action-disabled": hasError && disabled,
                          "border-error bg-box-background text-primary": hasError && !disabled && field.value !== options[0].value,
                          "border-error bg-primary text-button-text": hasError && !disabled && field.value === options[0].value,
                          "bg-background-disabled text-action-disabled border-action-disabled cursor-not-allowed":
                            !hasError && disabled && field.value !== options[0].value,
                          "bg-action-disabled text-button-text border-action-disabled cursor-not-allowed":
                            disabled && field.value === options[0].value,
                          "bg-primary border-primary text-button-text": !hasError && !disabled && field.value === options[0].value,
                          "text-body-text bg-box-background border-body-text": !hasError && !disabled && field.value !== options[0].value,
                          "border-r-primary": !hasError && !disabled && field.value === options[1].value, // è selezionato quello a fianco!
                        })}
                      >
                        {options[0].label}
                      </button>
                    </div>
                    <div key={options[1].value || EMPTY} data-tip data-for={options[1].value || EMPTY} className="cursor-pointer w-1/2">
                      <ReactTooltip id={options[1].value || EMPTY} place="top" effect="solid" className="w-1/6" delayShow={1000}>
                        {options[1].label}
                      </ReactTooltip>
                      <button
                        title={options[1].label}
                        data-qa={options[1].value}
                        type="button"
                        onClick={() => onChange(options[1])}
                        disabled={disabled}
                        className={classnames("border-l-0 rounded-lg rounded-l-none w-full h-12 text-base truncate px-2", {
                          "bg-background-disabled border-2 border-error cursor-not-allowed text-action-disabled": hasError && disabled,
                          "border-error bg-box-background text-primary": hasError && !disabled && field.value !== options[1].value,
                          "border-error bg-primary text-button-text": hasError && !disabled && field.value === options[1].value,
                          "bg-background-disabled text-action-disabled border-action-disabled cursor-not-allowed":
                            !hasError && disabled && field.value !== options[1].value,
                          "bg-action-disabled text-button-text border-action-disabled cursor-not-allowed":
                            disabled && field.value === options[1].value,
                          "bg-primary border-primary text-button-text": !hasError && !disabled && field.value === options[1].value,
                          "text-body-text border-body-text bg-box-background": !hasError && !disabled && field.value !== options[1].value,
                        })}
                      >
                        {options[1].label}
                      </button>
                    </div>
                  </div>
                ) : (
                  <Select
                    className={selectClasses}
                    id={name}
                    data-qa={`${name}-select`}
                    classNamePrefix="custom-select"
                    components={{ Option: customOption, DropdownIndicator }}
                    placeholder={placeholder}
                    defaultValue={initSelection}
                    onChange={onChange}
                    options={options as any}
                    isDisabled={disabled}
                    isClearable={!mandatory || (options && options.length > 1)}
                    menuPlacement="auto"
                    menuPosition="absolute"
                    menuPortalTarget={document.body}
                    noOptionsMessage={() => intl.formatMessage({ id: "noResults" })}
                    styles={{
                      menuPortal: (provided) => ({
                        ...provided,
                        zIndex: 49,
                      }),
                    }}
                    captureMenuScroll
                  />
                )}
              </>
            )}
          </label>
          {/*hasErrorsOnTouched(form) && (*/}
          <div className="h-6">
            {hasError && (
              <span className="block text-base text-error" data-qa={`error-message-${field.name}`}>
                {hasError && meta.error}
              </span>
            )}
          </div>
          {/*)}*/}
          {description && (
            <DetailsModal
              data-qa={`${name}-modal`}
              isOpen={isModalOpen}
              onClose={() => {
                setIsModalOpen(false);
              }}
              title={label}
            >
              {description}
            </DetailsModal>
          )}
        </div>
      ) : (
        <div className="questionnaire-yoga-form-input w-full" data-qa={dataQa}>
          <label htmlFor={name} className="block text-body-text text-base pr-4 w-2/3" data-qa={`${label}-label`}>
            <div className="inline-flex items-center text-primary text-sm font-medium">
              <FormattedMessage id={label || EMPTY} />
              {mandatory && "*"}
              {externalField && (
                <div className="bg-body-text rounded ml-1 text-box-background px-1 text-sm">
                  <FormattedMessage id="externalField" />
                </div>
              )}
            </div>
          </label>

          <div className="ygInput-container w-1/3">
            <div className="flex pt-3">
              {(selection || selection === "") && availableValues && (
                <>
                  {availableValues.length !== 2 || disableBinarySelect ? (
                    <Select
                      className={selectClasses}
                      id={name}
                      data-qa={`${name}-select`}
                      classNamePrefix="custom-select"
                      components={{ Option: customOption, DropdownIndicator }}
                      placeholder={placeholder}
                      defaultValue={initSelection}
                      onChange={onChange}
                      options={options as any}
                      isDisabled={disabled}
                      isClearable={!mandatory || (options && options.length > 1)}
                      menuPlacement="auto"
                      menuPosition="absolute"
                      menuPortalTarget={document.body}
                      noOptionsMessage={() => intl.formatMessage({ id: "noResults" })}
                      styles={{
                        menuPortal: (provided) => ({
                          ...provided,
                          zIndex: 9999,
                        }),
                      }}
                      captureMenuScroll
                    />
                  ) : (
                    <div id={name} data-qa={`${name}-select-buttons`} className="flex w-full">
                      <div key={options[0].value || EMPTY} data-tip data-for={options[0].value || EMPTY} className="cursor-pointer w-1/2">
                        <ReactTooltip id={options[0].value || EMPTY} place="top" effect="solid" className="w-1/6" delayShow={1000}>
                          {options[0].label}
                        </ReactTooltip>
                        <button
                          title={options[0].label}
                          data-qa={options[0].value}
                          type="button"
                          onClick={() => onChange(options[0])}
                          disabled={disabled}
                          className={classnames("rounded-lg rounded-r-none w-full h-12 text-base truncate px-2 grid", {
                            "bg-background-disabled border-error cursor-not-allowed text-action-disabled": hasError && disabled,
                            "border-error bg-box-background text-primary": hasError && !disabled && field.value !== options[0].value,
                            "border-error bg-primary text-button-text": hasError && !disabled && field.value === options[0].value,
                            "bg-background-disabled text-action-disabled border-action-disabled cursor-not-allowed":
                              !hasError && disabled && field.value !== options[0].value,
                            "bg-action-disabled text-button-text border-action-disabled cursor-not-allowed":
                              disabled && field.value === options[0].value,
                            "bg-primary border-primary text-button-text": !hasError && !disabled && field.value === options[0].value,
                            "text-body-text bg-box-background border-body-text": !hasError && !disabled && field.value !== options[0].value,
                            "border-r-primary": !hasError && !disabled && field.value === options[1].value, // è selezionato quello a fianco!
                          })}
                        >
                          <span className="m-auto truncate w-full">{options[0].label}</span>
                        </button>
                      </div>
                      <div key={options[1].value || EMPTY} data-tip data-for={options[1].value || EMPTY} className="cursor-pointer w-1/2">
                        <ReactTooltip id={options[1].value || EMPTY} place="top" effect="solid" className="w-1/6" delayShow={1000}>
                          {options[1].label}
                        </ReactTooltip>
                        <button
                          title={options[1].label}
                          data-qa={options[1].value}
                          type="button"
                          onClick={() => onChange(options[1])}
                          disabled={disabled}
                          className={classnames("border-l-0 rounded-lg rounded-l-none w-full h-12 text-base truncate px-2 grid", {
                            "bg-background-disabled border-2 border-error cursor-not-allowed text-action-disabled": hasError && disabled,
                            "border-error bg-box-background text-primary": hasError && !disabled && field.value !== options[1].value,
                            "border-error bg-primary text-button-text": hasError && !disabled && field.value === options[1].value,
                            "bg-background-disabled text-action-disabled border-action-disabled cursor-not-allowed":
                              !hasError && disabled && field.value !== options[1].value,
                            "bg-action-disabled text-button-text border-action-disabled cursor-not-allowed":
                              disabled && field.value === options[1].value,
                            "bg-primary border-primary text-button-text": !hasError && !disabled && field.value === options[1].value,
                            "text-body-text border-body-text bg-box-background": !hasError && !disabled && field.value !== options[1].value,
                          })}
                        >
                          <span className="m-auto truncate w-full">{options[1].label}</span>
                        </button>
                      </div>
                    </div>
                  )}
                </>
              )}
              {description && (
                <button
                  type="button"
                  className="flex-none ml-2 text-primary w-6 h-6 align-bottom hover:cursor-pointer questionnaire-info-btn"
                  data-qa={`${name}-info`}
                  onClick={() => setIsModalOpen(true)}
                >
                  <InformationCircleIcon />
                </button>
              )}

              {description && (
                <DetailsModal
                  data-qa={`${name}-modal`}
                  isOpen={isModalOpen}
                  onClose={() => {
                    setIsModalOpen(false);
                  }}
                  title={label}
                >
                  {description}
                </DetailsModal>
              )}
            </div>

            <span className="block text-base h-3 text-error leading-[1.2rem]">{hasError && meta.error}</span>

            {/* {hasError ? (
              <span className="block text-base h-6 text-error">
                {hasError}
              </span>
              ) : (
              <>
                {form &&
                  Object.keys(toDotNotation(form.errors)).filter((v) =>
                    Object.keys(toDotNotation(form.touched)).includes(v)
                  ).length > 0 && <div className="h-6" />}
              </>
            )} */}
          </div>
        </div>
      )}
    </>
  );
}
