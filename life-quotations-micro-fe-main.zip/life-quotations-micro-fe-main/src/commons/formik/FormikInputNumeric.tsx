import { useField } from "formik";
import { useEffect, useMemo, useRef, useState } from "react";
import { FormattedMessage, useIntl } from "react-intl";
import { EMPTY } from "commons/Utils";
import CurrencyInput from "react-currency-input-field";
import { CurrencyInputOnChangeValues } from "react-currency-input-field/dist/components/CurrencyInputProps";
import { FormInputParam } from "commons/models/YogaParam";
import classnames from "classnames";
import { BanIcon, ExclamationCircleIcon, InformationCircleIcon } from "@heroicons/react/outline";
import { DetailsModal } from "commons/modals/DetailsModal";
import { FormikInputProps } from "./FormikInput";

//import { hasErrorsOnTouched } from "./Utils";

interface FormikInputNumericProps extends FormikInputProps<any> {
  content: FormInputParam;
  percentage?: boolean;
  currency?: string;
  maxLength?: number;
  fieldName?: string;
  values?: any;
  className?: string;
  notShowErrorMessage?: boolean;
  questionnaireForm?: boolean;
}

const allowNegativeValue = false;
const numericFieldOptions = (locale: string, currency: string, decimalsLimit: number) => ({
  allowNegativeValue,
  decimalsLimit,
  allowDecimals: decimalsLimit > 0,
  decimalScale: decimalsLimit,
  intlConfig: {
    currency,
    locale,
  },
});

const toCurrencyInputValues = (value?: number) => {
  if (!value) return undefined;
  return {
    float: value,
    formatted: `${value}`,
    value: `${value}`,
  };
};

export function FormikInputNumeric({
  content: { label, placeholder, description, name, mandatory, type, updateOnChange },
  className,
  currency = "",
  disabled = false,
  maxLength,
  form,
  fieldName,
  onUpdate,
  onPartialUpdate,
  "data-qa": dataQa,
  notShowErrorMessage = false,
  questionnaireForm = false,
  percentage = false,
}: FormikInputNumericProps) {
  const [field, meta, helpers] = useField(name);
  const isAmount = type === "AMOUNT";
  const fieldCurrency = isAmount ? currency : "";
  const isDecimal = isAmount || label == "discountAllCoverages" || "Premio Versato";
  const decimalsLimit = isDecimal ? 2 : 0;
  const intl = useIntl();
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);

  useEffect(() => {
    if (updateOnChange && form.dirty && onUpdate) {
      const delayDebounceFn = setTimeout(() => {
        form.validateForm().then((result) => {
          if (!result[name]) {
            onUpdate(form.values);
          }
        });
      }, 1000);
      return () => clearTimeout(delayDebounceFn);
    }
  }, [field.value]);

  useEffect(() => {
    if (onPartialUpdate && form.dirty && fieldName) {
      const delayDebounceFn = setTimeout(() => {
        form.validateForm().then((result) => {
          if (!result[name]) {
            onPartialUpdate({ [fieldName]: field.value }, updateOnChange || false);
          }
        });
      }, 1000);
      return () => clearTimeout(delayDebounceFn);
    }
  }, [field.value]);

  const value = useRef<CurrencyInputOnChangeValues | undefined>(toCurrencyInputValues(field.value));
  const onValueChange = (_: string | undefined, name?: string, values?: CurrencyInputOnChangeValues) => {
    value.current = values;
    helpers.setValue(value.current?.float ?? "");
  };

  const widthRegExp = new RegExp("\\bw-\\d");
  const heigthRegExp = new RegExp("\\bh-\\d");

  const dimension = useMemo(() => {
    let w = "w-full";
    let h = "h-12";
    if (widthRegExp.test(className)) {
      w = "";
    }
    if (heigthRegExp.test(className)) {
      h = "";
    }
    return [w, h];
  }, [className]);

  return (
    <>
      {!questionnaireForm ? (
        <>
          <div className="yoga-form-input self-end" data-qa={dataQa}>
            <label htmlFor={name} className="block text-body-text text-base" data-qa={`${label}-label`}>
              {label && (
                <div className="inline-flex text-primary text-sm font-medium">
                  <FormattedMessage id={label} />
                  {mandatory && "*"}
                </div>
              )}
              {description && (
                <button
                  type="button"
                  className="flex-none ml-2 text-primary w-6 h-6 align-bottom hover:cursor-pointer"
                  data-qa={`${name}-info`}
                  onClick={() => setIsModalOpen(true)}
                >
                  <InformationCircleIcon />
                </button>
              )}
              <div className="relative">
                {percentage ? (
                  <CurrencyInput
                    {...numericFieldOptions(intl.locale, fieldCurrency, decimalsLimit)}
                    className={classnames(
                      "focus:outline-none focus:border-primary rounded-lg tracking-wider py-3 px-4 text-base shadow-inner",
                      meta.touched && meta.error && disabled
                        ? "bg-background-disabled border-2 border-error cursor-not-allowed text-action-disabled"
                        : "",
                      meta.touched && meta.error && !disabled ? "border-2 border-error bg-box-background text-body-text" : "",
                      !(meta.touched && meta.error) && disabled
                        ? "bg-background-disabled border-2 border-action-disabled cursor-not-allowed text-action-disabled"
                        : "",
                      !(meta.touched && meta.error) && !disabled ? "border-2 border-primary bg-box-background text-body-text" : "",
                      className,
                      dimension
                    )}
                    value={field.value}
                    onBlur={field.onBlur}
                    id={name}
                    name={name}
                    data-qa={`${name}-input`}
                    onValueChange={onValueChange}
                    disabled={disabled}
                    maxLength={maxLength}
                    placeholder={placeholder}
                    suffix="%"
                  />
                ) : (
                  <CurrencyInput
                    {...numericFieldOptions(intl.locale, fieldCurrency, decimalsLimit)}
                    className={classnames(
                      "focus:outline-none focus:border-primary rounded-lg tracking-wider py-3 px-4 text-base shadow-inner",
                      meta.touched && meta.error && disabled
                        ? "bg-background-disabled border-2 border-error cursor-not-allowed text-action-disabled"
                        : "",
                      meta.touched && meta.error && !disabled ? "border-2 border-error bg-box-background text-body-text" : "",
                      !(meta.touched && meta.error) && disabled
                        ? "bg-background-disabled border-2 border-action-disabled cursor-not-allowed text-action-disabled"
                        : "",
                      !(meta.touched && meta.error) && !disabled ? "border-2 border-primary bg-box-background text-body-text" : "",
                      className,
                      dimension
                    )}
                    value={field.value}
                    onBlur={field.onBlur}
                    id={name}
                    name={name}
                    data-qa={`${name}-input`}
                    onValueChange={onValueChange}
                    disabled={disabled}
                    maxLength={maxLength}
                    placeholder={placeholder}
                  />
                )}
                {disabled && (
                  <BanIcon
                    className={classnames(
                      "w-6 text-action-disabled absolute right-4 cursor-not-allowed",
                      dimension?.includes("h-10") ? "bottom-2" : "bottom-3"
                    )}
                  />
                )}
              </div>
              {!notShowErrorMessage && meta.touched && meta.error && !disabled && (
                <ExclamationCircleIcon className="w-6 text-error relative -top-9 float-right -left-4" />
              )}
            </label>

            {!notShowErrorMessage ? (
              /*hasErrorsOnTouched(form) && (*/
              <div className="h-6">
                {meta.error && (
                  <span className="block text-base text-error" data-qa={`error-message-${field.name}`}>
                    {meta.error}
                  </span>
                )}
              </div>
            ) : (
              /*)*/
              <></>
            )}
          </div>
          {description && (
            <DetailsModal
              data-qa={`${name}-modal`}
              isOpen={isModalOpen}
              onClose={() => {
                setIsModalOpen(false);
              }}
              title={label}
            >
              {description}
            </DetailsModal>
          )}
        </>
      ) : (
        <>
          <div className="questionnaire-yoga-form-input w-full" data-qa={dataQa}>
            <label htmlFor={name} className="block text-body-text text-base pr-4 w-2/3" data-qa={`${label}-label`}>
              <div className="inline-flex text-primary text-sm font-medium">
                <FormattedMessage id={label || EMPTY} />
              </div>
            </label>

            <div className="ygInput-container flex relative w-1/3">
              <div className="w-full relative pt-3">
                {disabled && <BanIcon className="w-6 text-action-disabled cursor-not-allowed position-icon" />}

                {!notShowErrorMessage && meta.touched && meta.error && !disabled && (
                  <ExclamationCircleIcon className="w-6 text-error position-icon" />
                )}
                <CurrencyInput
                  {...numericFieldOptions(intl.locale, fieldCurrency, decimalsLimit)}
                  className={classnames(
                    "focus:outline-none focus:border-primary rounded-lg tracking-wider py-3 px-4 text-base shadow-inner",
                    meta.touched && meta.error && disabled
                      ? "bg-background-disabled border-2 border-error cursor-not-allowed text-action-disabled"
                      : "",
                    meta.touched && meta.error && !disabled ? "border-2 border-error bg-box-background text-body-text" : "",
                    !(meta.touched && meta.error) && disabled
                      ? "bg-background-disabled border-2 border-action-disabled cursor-not-allowed text-action-disabled"
                      : "",
                    !(meta.touched && meta.error) && !disabled ? "border-2 border-primary bg-box-background text-body-text" : "",
                    className,
                    dimension
                  )}
                  value={field.value}
                  onBlur={field.onBlur}
                  id={name}
                  name={name}
                  data-qa={`${name}-input`}
                  onValueChange={onValueChange}
                  disabled={disabled}
                  maxLength={maxLength}
                  placeholder={placeholder}
                />

                <span className="block text-base h-3 text-error leading-[1.2rem]">{meta.touched && meta.error}</span>

                {/* {!notShowErrorMessage ? (
                  meta.touched && meta.error ? (
                    <span className="block text-base h-6 text-error">
                      {meta.touched && meta.error}
                    </span>
                  ) : (
                    <>
                      {form &&
                        Object.keys(toDotNotation(form.errors)).filter((v) =>
                          Object.keys(toDotNotation(form.touched)).includes(v)
                        ).length > 0 && <div className="h-6" />}
                    </>
                  )
                ) : (
                  <></>
                )} */}
              </div>

              {description && (
                <button
                  type="button"
                  className="flex-none ml-2 text-primary w-6 h-6 align-bottom hover:cursor-pointer questionnaire-info-btn mt-3"
                  data-qa={`${name}-info`}
                  onClick={() => setIsModalOpen(true)}
                >
                  <InformationCircleIcon />
                </button>
              )}
            </div>
            {description && (
              <DetailsModal
                data-qa={`${name}-modal`}
                isOpen={isModalOpen}
                onClose={() => {
                  setIsModalOpen(false);
                }}
                title={label}
              >
                {description}
              </DetailsModal>
            )}
          </div>
        </>
      )}
    </>
  );
}

// array1.filter(value => array2.includes(value))

// .length > 0 &&
//             Object.keys(form.touched).length > 0
