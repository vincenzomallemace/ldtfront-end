import { Radio, RadioGroupField } from "@aws-amplify/ui-react";
import { useField } from "formik";
import classNames from "classnames";
import { useIntl } from "react-intl";
import { FormikInputProps } from "./FormikInput";
import { useEffect } from "react";

interface FormikRadioGroupProps extends FormikInputProps<any> {
  fieldName?: string;
}

export const FormikRadioGroup = ({
  content: { name, label, availableValues, availableObjectValues, disabled: fieldDisabled, updateOnChange },
  form,
  onUpdate,
  onPartialUpdate,
  fieldName,
  disabled,
}: FormikRadioGroupProps) => {
  const intl = useIntl();
  const [field, meta, helpers] = useField(name);
  const hasDescription = availableObjectValues && availableObjectValues.length > 0 ? true : false;

  useEffect(() => {
    if (updateOnChange && form.dirty && onUpdate) {
      onUpdate(form.values);
    }

    if (onPartialUpdate && meta.touched && fieldName) {
      onPartialUpdate({ [fieldName]: field.value }, updateOnChange || false);
    }
  }, [field.value]);

  const onChange = (value: string) => {
    helpers.setTouched(true);
    helpers.setValue(value);
  };

  const options =
    availableObjectValues && availableObjectValues.length > 0
      ? availableObjectValues.map((v) => {
          return {
            label: intl.formatMessage({ id: v.description }),
            value: v.code,
          };
        })
      : availableValues && availableValues.length > 0
      ? availableValues.map((v) => {
          if (typeof v === "string") {
            return {
              label: intl.formatMessage({ id: v }),
              value: v,
            };
          }
          return {
            label: intl.formatMessage({ id: v.label }),
            value: v.value,
          };
        })
      : [];

  return (
    <div id={name} className="col-span-2 lg:col-span-3 flex flex-col gap-y-4" data-qa={"radio-group-" + field.name + "-container"}>
      <RadioGroupField
        label={
          <>
            <span data-qa="radio-label">{label}</span>
            {meta.touched && meta.error && (
              <span className="ml-4 text-base text-error" data-qa={`error-message-${field.name}`}>
                {meta.touched && meta.error}
              </span>
            )}
          </>
        }
        name={name}
        value={field.value}
        onChange={(e) => onChange(e.target.value)}
        data-qa={"radio-group-" + field.name}
        isDisabled={disabled || fieldDisabled}
        /* isRequired={mandatory} non usare! */
        labelPosition="end"
      >
        {options?.map((option) => (
          <Radio
            key={option.value}
            value={option.value}
            className={classNames("custom-radio", disabled ? "disabled cursor-not-allowed" : "cursor-pointer")}
            data-qa={"radio-" + option.value}
            hasError={meta.touched && !!meta.error}
          >
            {hasDescription ? (
              <div className="flex flex-col">
                <div data-qa="option-code">{option.value}</div>
                <div data-qa="option-description">{option.label}</div>
              </div>
            ) : (
              option.label
            )}
          </Radio>
        ))}
      </RadioGroupField>
    </div>
  );
};
