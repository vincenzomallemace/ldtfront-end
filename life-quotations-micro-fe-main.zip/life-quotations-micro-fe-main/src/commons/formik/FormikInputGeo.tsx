import { BanIcon, ExclamationCircleIcon } from "@heroicons/react/outline";
import classnames from "classnames";
import { EMPTY } from "commons/Utils";
import { Geo } from "commons/models/Geo";
import { FormInputParam } from "commons/models/YogaParam";
import { searchService } from "commons/services/SearchService";
import { FormikProps, useField } from "formik";
import { useEffect, useRef, useState } from "react";
import { FormattedMessage, useIntl } from "react-intl";
import { usePopper } from "react-popper";
//import { hasErrorsOnTouched } from "./Utils";

interface Props {
  content: FormInputParam;
  disabled?: boolean;
  hidden?: boolean;
  form?: FormikProps<any>;
  values?: any;
  placeholder?: string;
  dataQa?: string;
  setAvailablePostalCodes?;
}

export function FormikInputGeo({
  content: {
    label,
    mandatory,
    name,
    type,
    labelPadding = false,
    foreign = false,
    date,
  },
  disabled = false,
  hidden = false,
  form,
  placeholder,
  dataQa,
  setAvailablePostalCodes,
}: Props) {
  const [field, meta] = useField(name);

  const [searchCount, setSearchCount] = useState<number>(-1);
  const [userInput, setUserInput] = useState(false); // used to know if user changed the field

  const input = useRef<HTMLInputElement>();
  const popper = useRef<HTMLDivElement>();

  const hasError = /*hasErrorsOnTouched(form) &&*/ meta.error;

  const { update, styles, attributes } = usePopper(
    input.current,
    popper.current,
    {
      placement: "bottom-start",
      modifiers: [
        {
          name: "flip",
          enabled: true,
          options: {
            flipVariations: true,
          },
        },
      ],
    }
  );

  const [suggestions, setSuggestions] = useState<Array<Geo>>([]);

  const intl = useIntl();

  const handleBlur = () => {
    if (userInput) {
      input.current.value = "";
      form.setFieldValue(name, "", form.isValidating);
      form.setFieldTouched(name, true, form.isValidating);
      setSuggestions([]);
      setSearchCount(-1);
      setUserInput(false);
    }
  };

  const selectSuggestion = (selected: Geo) => {
    input.current.value = toString(selected);
    form.setFieldValue(name, toString(selected), form.isValidating);
    form.setFieldValue(`${name}Complete`, selected, form.isValidating);
    form.setFieldTouched(name, false, form.isValidating);
    setUserInput(false);
    setSuggestions([]);
    setSearchCount(-1);

    setAvailablePostalCodes && setAvailablePostalCodes(selected.cap);
  };

  const handleChange = () => {
    // this is called during user input
    setUserInput(true);
    form.setFieldValue(name, "", form.isValidating);
    form.setFieldTouched(name, true, form.isValidating);
  };

  useOnClickOutside(popper, handleBlur);

  useEffect(() => {
    if (input.current && !userInput) {
      input.current.value = field.value ?? "";
      setUserInput(false);
    }
  }, [field.value]);

  useEffect(() => {
    if (userInput) {
      const delayDebounceFn = setTimeout(() => {
        if (input.current?.value.length > 2) {
          fetchData(input.current?.value);
        } else {
          setSuggestions([]);
          setSearchCount(-1);
        }
      }, 300);
      return () => clearTimeout(delayDebounceFn);
    }
  }, [input.current?.value]);

  const fetchData = async (q: string) => {
    const result = await searchService.geo(type, q, foreign, date);
    const data = result.data;
    setSearchCount(data.length);
    setSuggestions(data || []);
    update();
  };

  const toString = (geo: Geo) => {
    return geo.countyCode ? `${geo.name} (${geo.countyCode})` : geo.name;
  };

  return (
    <>
      {!hidden && (
        <div className="yoga-form-input self-end" data-qa={dataQa}>
          <label
            htmlFor={name}
            className="block text-body-text text-base"
            data-qa={`${label}-label`}
          >
            <div
              className={`inline-flex text-primary text-sm font-medium ${
                labelPadding && "pb-0.5"
              }`}
            >
              <FormattedMessage id={label || EMPTY} />
              {mandatory && "*"}
            </div>
            {disabled && (
              <BanIcon className="w-6 text-action-disabled relative -bottom-9 float-right -left-4 cursor-not-allowed" />
            )}
            <input
              className={classnames(
                "h-12 focus:outline-none focus:border-primary rounded-lg tracking-wider py-3 px-4 text-base w-full shadow-inner",
                meta.touched && meta.error && disabled
                  ? "bg-background-disabled border-2 border-error cursor-not-allowed text-action-disabled"
                  : "",
                meta.touched && meta.error && !disabled
                  ? "border-2 border-error bg-box-background text-body-text"
                  : "",
                !(meta.touched && meta.error) && disabled
                  ? "bg-background-disabled border-2 border-action-disabled cursor-not-allowed text-action-disabled"
                  : "",
                !(meta.touched && meta.error) && !disabled
                  ? "border-2 border-primary bg-box-background text-body-text"
                  : ""
              )}
              autoComplete="off"
              defaultValue={field.value ?? ""}
              type="text"
              id={name}
              data-qa={`${name}-input`}
              disabled={disabled}
              placeholder={placeholder}
              ref={input}
              onChange={handleChange}
            />
            {meta.touched && meta.error && !disabled && (
              <ExclamationCircleIcon className="w-6 text-error relative -top-9 float-right -left-4" />
            )}
          </label>
          <div
            ref={popper}
            style={styles.popper}
            {...attributes.popper}
            className={classnames(
              "bg-white",
              searchCount < 0
                ? "bg-white"
                : "bg-white rounded-lg shadow z-40 border-2 border-primary mt-2 mb-2 overflow-hidden"
            )}
          >
            {searchCount == 0 ? (
              <span
                className="text-action-disabled p-4"
                id="noResults"
                data-qa="noResults"
              >
                {intl.formatMessage({ id: "noResults" })}
              </span>
            ) : (
              searchCount > 10 && (
                <span
                  className="text-action-disabled p-3"
                  id="refineSearch"
                  data-qa="refineSearch"
                >
                  {intl.formatMessage({ id: "refineSearch" })}
                </span>
              )
            )}
            <ul className="divide-y table-divider max-h-[293px] overflow-y-auto rounded-md">
              {suggestions.map((suggestion) => (
                <li
                  key={suggestion.geoId}
                  className="p-3 bg-box-background text-body-text cursor-pointer hover:bg-background"
                  onClick={() => selectSuggestion(suggestion)}
                >
                  {toString(suggestion)}
                </li>
              ))}
            </ul>
          </div>

          {
            /*hasErrorsOnTouched(form) && (*/
            <div className="h-6">
              {hasError && (
                <span
                  className="block text-base text-error"
                  data-qa={`error-message-${field.name}`}
                >
                  {hasError && meta.error}
                </span>
              )}
            </div>
            /*)*/
          }
        </div>
      )}
    </>
  );
}

// Hook
function useOnClickOutside(ref, handler) {
  useEffect(
    () => {
      const listener = (event) => {
        // Do nothing if clicking ref's element or descendent elements
        if (!ref.current || ref.current.contains(event.target)) {
          return;
        }
        handler(event);
      };
      document.addEventListener("mousedown", listener);
      document.addEventListener("touchstart", listener);
      return () => {
        document.removeEventListener("mousedown", listener);
        document.removeEventListener("touchstart", listener);
      };
    },
    // Add ref and handler to effect dependencies
    // It's worth noting that because passed in handler is a new ...
    // ... function on every render that will cause this effect ...
    // ... callback/cleanup to run every render. It's not a big deal ...
    // ... but to optimize you can wrap handler in useCallback before ...
    // ... passing it into this hook.
    [ref, handler]
  );
}
