import { FieldInputProps, FormikProps, useField } from "formik";
import { FormattedMessage, useIntl } from "react-intl";

import { Tab } from "@headlessui/react";
import { InformationCircleIcon } from "@heroicons/react/outline";
import classNames from "classnames";
import { EMPTY } from "commons/Utils";
import { DetailsModal } from "commons/modals/DetailsModal";
import { KeyValue } from "commons/models/YogaModels";
import { FormInputParam, YogaParamValueType } from "commons/models/YogaParam";
import { useEffect, useState } from "react";

interface FormikTabSwitchProps {
  content: FormInputParam;
  disabled?: boolean;
  externalField?: boolean;
  form?: FormikProps<any>;
  onUpdate?: (values: KeyValue<YogaParamValueType>) => any;
  onPartialUpdate?: (
    values: KeyValue<YogaParamValueType>,
    updateOnChange: boolean
  ) => any;
  onFieldChange?: (field: FieldInputProps<any>) => any;
  fieldName?: string;
  values?: any;
  dataQa?: string;
  onManuallyChange?: () => any;
}

export function FormikTabSwitch({
  content: {
    label,
    description,
    name,
    mandatory,
    updateProductOnChange,
    updateQuestionnaireOnChange,
    availableValues,
  },
  disabled = false,
  externalField = false,
  form,
  onUpdate,
  onPartialUpdate,
  onFieldChange,
  fieldName,
  dataQa,
  onManuallyChange = null,
}: FormikTabSwitchProps) {
  const intl = useIntl();
  const [field] = useField(name);
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);

  useEffect(() => {
    const updateOnChange = updateProductOnChange || updateQuestionnaireOnChange;
    if (updateOnChange && form?.dirty && onUpdate) {
      onUpdate(form?.values);
    }
  }, [field.value]);

  useEffect(() => {
    if (onFieldChange) {
      onFieldChange(field);
    }
  }, [field.value]);

  useEffect(() => {
    const updateOnChange = updateProductOnChange || updateQuestionnaireOnChange;
    if (onPartialUpdate && form?.dirty && fieldName) {
      onPartialUpdate({ [fieldName]: field.value }, updateOnChange || false);
    }
  }, [field.value]);

  const options = availableValues?.map((value) => {
    if (typeof value === "string")
      return {
        value: value,
        label: intl.formatMessage({ id: value || EMPTY }),
      };
    else return value;
  });

  return (
    <div className="yoga-form-input self-end" data-qa={dataQa}>
      <label
        htmlFor={name}
        className="block text-body-text text-base"
        data-qa={`${label}-label`}
      >
        <span className="block">
          {label && (
            <div className="inline-flex items-center text-primary text-sm font-medium">
              <FormattedMessage id={label || EMPTY} />
              {mandatory && "*"}
              {externalField && (
                <div className="bg-body-text rounded ml-1 text-box-background px-1 text-sm">
                  <FormattedMessage id="externalField" />
                </div>
              )}
            </div>
          )}
          {description && (
            <button
              type="button"
              className="flex-none ml-2 text-primary w-6 h-6 align-bottom hover:cursor-pointer"
              data-qa={`${name}-info`}
              onClick={() => setIsModalOpen(true)}
            >
              <InformationCircleIcon />
            </button>
          )}
        </span>

        <span
          className={classNames(
            "relative inline-block",
            disabled ? "cursor-not-allowed" : "cursor-pointer"
          )}
          data-qa={"tab-switch-" + dataQa}
        >
          <Tab.Group>
            <div className="lg:flex flex-none items-center">
              <div className="flex w-full justify-between">
                <Tab.List
                  className={classNames(
                    "flex space-x-1 rounded-lg p-1",
                    disabled ? "bg-slate-300" : "bg-primary",
                    options.length === 1 && "cursor-default"
                  )}
                >
                  {options.map((option) => (
                    <Tab
                      disabled={disabled}
                      key={option.value}
                      data-qa={`button-${option.value}`}
                      className={() =>
                        classNames(
                          "w-full whitespace-nowrap rounded-full py-0.5 px-3 text-regular font-medium leading-5",
                          options.length === 1 && "cursor-default",
                          option.value === field.value
                            ? disabled
                              ? "bg-white text-action-disabled cursor-not-allowed"
                              : "bg-white text-primary"
                            : disabled
                            ? "text-white cursor-not-allowed"
                            : "text-button-text hover:bg-white/[0.12]"
                        )
                      }
                      onClick={() => {
                        form.setFieldValue(name, option.value, false);
                        if (onManuallyChange) {
                          onManuallyChange();
                        }
                      }}
                    >
                      <FormattedMessage id={option.label} />
                    </Tab>
                  ))}
                </Tab.List>
              </div>
            </div>
          </Tab.Group>
        </span>
      </label>
      {/* {hasErrorsOnTouched(form) && (
        <div className="h-6">
          {meta.error && (
            <span
              className="block text-base text-error"
              data-qa={`error-message-${name}`}
            >
              {meta.error}
            </span>
          )}
        </div>
      )} */}
      {description && (
        <DetailsModal
          data-qa={`${name}-modal`}
          isOpen={isModalOpen}
          onClose={() => {
            setIsModalOpen(false);
          }}
          title={label}
        >
          {description}
        </DetailsModal>
      )}
    </div>
  );
}
