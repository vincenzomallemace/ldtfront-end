import { FormattedMessage, useIntl } from "react-intl";
import { FormInputParam, YogaParam, YogaParamValueType } from "commons/models/YogaParam";
import Select, { components } from "react-select";
import { BanIcon, CheckCircleIcon, ChevronDownIcon } from "@heroicons/react/solid";
import { FormikProps, useField } from "formik";
import { useEffect, useState } from "react";
import "commons/components/YogaSelect.css";
import "commons/components/YogaMultiSelect.css";
import classnames from "classnames";
import { KeyValue } from "commons/models/YogaModels";
import { InformationCircleIcon } from "@heroicons/react/outline";
import { DetailsModal } from "commons/modals/DetailsModal";
import { productService } from "commons/services/ProductService";
import { EMPTY } from "commons/Utils";
import { partyService } from "commons/services/PartyService";
import { contractService } from "commons/services/ContractService";
//import { hasErrorsOnTouched } from "./Utils";

export const PRODUCT_PARAM = "product";
export const PARTY_PARAM = "party";
export const CONTRACT_PARAM = "contract";

interface FormikDynamicSelectProps {
  content: FormInputParam;
  disabled?: boolean;
  form?: FormikProps<any>;
  onUpdate?: (values: KeyValue<YogaParamValueType>) => any;
  onPartialUpdate?: (values: KeyValue<YogaParamValueType>, updateOnChange: boolean) => any;
  fieldName?: string;
  values?: any;
  parameters?: KeyValue<YogaParam>;
  setParameters?: (parameters: KeyValue<YogaParam>) => any;
  dataQa?: string;
  paramType?: "product" | "party" | "contract" | "external";
}

export function FormikDynamicSelect({
  content: { label, name, description, mandatory, updateOnChange, dynamicList },
  disabled = false,
  form,
  parameters,
  setParameters,
  fieldName,
  onUpdate,
  onPartialUpdate,
  // dataQa,
  paramType = PRODUCT_PARAM,
}: FormikDynamicSelectProps) {
  const [field, meta, helpers] = useField(name);
  const { setValue, setError } = helpers;
  const intl = useIntl();
  const [selection, setSelection] = useState<string>();
  const [availableValues, setAvailableValues] = useState<string[]>([]);
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);

  useEffect(() => {
    if (paramType == "external") {
      setSelection(field.value);
    } else if (field.value || field.value === "") {
      setSelection(undefined);
    }
    if (updateOnChange && form?.dirty && onUpdate) {
      onUpdate(form.values);
    }
    if (onPartialUpdate && meta.touched && fieldName) {
      onPartialUpdate({ [fieldName]: field.value }, updateOnChange);
    }
  }, [field.value]);

  useEffect(() => {
    if (parameters) {
      const filter = prepareFilter();
      const applyFilter = loadTableFilter();

      if (!Object.values(filter).includes("") && !disabled) {
        applyFilter(dynamicList.fromTable, dynamicList.fromColumn, filter).then((result) => {
          const availableValues = (result as string[]) ?? [];
          setAvailableValues(availableValues);
          // The previous value may have previously been canceled by the conditions imposed on the filters,
          // in this case we recover it from the parameters
          let previousValue = field.value || parameters[fieldName]?.value;

          // If there is only one available values and the field is mandatory
          // set the only value
          if (availableValues.length === 1 && mandatory) setValue(result[0]);
          // If the previous value is not present in the new received list
          // The current value will be undefined
          else if (availableValues.length && availableValues.indexOf(previousValue) < 0) setValue("");
          // If the previous value (or, if null, the one still present in the parameters)
          // is present in the possible values   of the updated filters, we restore it
          else setValue(previousValue);
        });
      } else {
        if (!disabled) setValue("");
        setAvailableValues([]);
      }
    }
  }, [parameters]);

  function loadTableFilter() {
    let applyFilter;

    switch (paramType) {
      case PARTY_PARAM:
        applyFilter = partyService.applyTableFilter;
        break;
      case CONTRACT_PARAM:
        applyFilter = contractService.applyTableFilter;
        break;
      case "external":
        applyFilter = partyService.applyExternalTableFilter;
        break;
      default:
        applyFilter = productService.applyTableFilter;
    }

    return applyFilter;
  }

  function prepareFilter(): KeyValue<string> {
    return (
      dynamicList.filteredByParameters?.reduce(
        (a, v) => ({
          ...a,
          [parameters[v].dynamicList.fromColumn]: parameters[v].value || "",
        }),
        {}
      ) || {}
    );
  }

  useEffect(() => {
    if (selection === undefined) {
      setSelection(field.value || "");
    }
  }, [selection]);

  useEffect(() => {
    // Update the current value of the related parameter
    if (parameters) {
      const currentYuid = field.name;
      Object.values(parameters).forEach((param) => {
        if (param.yuid === currentYuid) {
          param.value = selection;
        }
      });
      if (setParameters) {
        setParameters({ ...parameters });
      }
    }
  }, [selection]);

  const options = availableValues?.map((value, index) => {
    return {
      value: value,
      label: intl.formatMessage({ id: value || EMPTY }),
      index: index,
    };
  });

  const isDisabled = disabled || !options || options.length < 1;

  const { Option } = components;
  const customOption = (props: any) => {
    // eslint-disable-next-line react/prop-types
    const label = props.data.label;
    // eslint-disable-next-line react/prop-types
    const bgColor = props.data.index % 2 === 0 ? "option0" : "option1";
    // eslint-disable-next-line react/prop-types
    if (props.isSelected)
      return (
        <Option {...props} className={bgColor}>
          {label}
          <CheckCircleIcon className="w-6 h-6" />
        </Option>
      );
    else
      return (
        <Option {...props} className={bgColor}>
          {label}
        </Option>
      );
  };

  const DropdownIndicator = (props: any) => {
    return (
      <components.DropdownIndicator {...props}>
        {isDisabled ? <BanIcon className="w-6 h-6 text-action-disabled" /> : <ChevronDownIcon className="w-6 h-6 text-body-text" />}
      </components.DropdownIndicator>
    );
  };

  function onChange(v: any) {
    let value = "";
    if (v) value = v.value;
    setSelection(value as any);
    // setTouched(true);
    setValue(value);
    if (meta.error) setError(meta.error);
  }

  const initSelection = selection
    ? {
        value: selection,
        label: intl.formatMessage({ id: selection || EMPTY }),
      }
    : null;

  const hasError = /*hasErrorsOnTouched(form) &&*/ meta.error;
  const selectClasses = classnames({
    "rounded-lg border-2": true,
    "border-error": hasError,
    "border-body-text": !hasError && !isDisabled,
    "border-action-disabled": !hasError && isDisabled,
    "text-body-text bg-box-background": !isDisabled,
    "text-action-disabled bg-background-disabled": isDisabled,
  });

  return (
    <div className="yoga-form-input w-full self-end" data-qa={`${name}-div`}>
      <label htmlFor={name} className="block text-body-text text-base" data-qa={`${label}-label`}>
        <div className="inline-flex text-primary text-sm font-medium">
          <FormattedMessage id={label || EMPTY} />
          {mandatory && "*"}
        </div>
        {description && (
          <button
            type="button"
            className="flex-none ml-2 text-primary w-6 h-6 align-bottom hover:cursor-pointer"
            data-qa={`${name}-info`}
            onClick={() => setIsModalOpen(true)}
          >
            <InformationCircleIcon />
          </button>
        )}
        <Select
          className={selectClasses}
          id={name}
          data-qa={`${name}-select`}
          classNamePrefix="custom-select"
          components={{ Option: customOption, DropdownIndicator }}
          placeholder=""
          value={initSelection}
          onChange={onChange}
          options={options as any}
          isDisabled={isDisabled}
          isClearable={!mandatory || (options && options.length > 1)}
          menuPlacement="auto"
          menuPosition="absolute"
          menuPortalTarget={document.body}
          styles={{
            menuPortal: (provided) => ({
              ...provided,
              zIndex: 49,
            }),
          }}
          captureMenuScroll
        />
      </label>
      {/*hasErrorsOnTouched(form) && (*/}
      <div className="h-6">
        {hasError && (
          <span className="block text-base text-error" data-qa={`error-message-${field.name}`}>
            {meta.error}
          </span>
        )}
      </div>
      {/*})}*/}
      {description && (
        <DetailsModal
          data-qa={`${name}-modal`}
          isOpen={isModalOpen}
          onClose={() => {
            setIsModalOpen(false);
          }}
          title={label}
        >
          {description}
        </DetailsModal>
      )}
    </div>
  );
}
