/* eslint-disable @typescript-eslint/no-unused-vars */
import { Field } from "formik";
import { FormikInput, FormikInputProps } from "./FormikInput";

type BirthPlaceData = {
  taxId: string;
  birthPlace: string;
  birthPlaceCode: string;
  birthCountry: string;
  birthCountryCode: string;
  birthCountyCode: string;
  foreign: boolean;
};

interface FormikBirthPlaceProps extends FormikInputProps<BirthPlaceData> {
  foreignIsVisible?: boolean;
}

export default function FormikBirthPlace({
  content,
  foreignIsVisible = true,
  field: { name, value },
  disabled,
  form,
  meta,
}: FormikBirthPlaceProps) {
  function updatePlace() {
    if (value.foreign) {
      value.birthCountry = "";
      value.birthCountryCode = "";
      value.birthCountyCode = "";
      value.birthPlace = "";
      value.birthPlaceCode = "";
    } else {
      value.birthCountry = "";
      value.birthCountryCode = "";
    }
  }

  return (
    <div key={`${name}.birthPlace`} className="relative order-6">
      {!value.taxId && foreignIsVisible && (
        <div className="absolute top-0 right-0">
          <Field
            key={`${name}.foreign`}
            name={`${name}.foreign`}
            component={FormikInput}
            disabled={disabled}
            content={{
              label: "foreign",
              type: "SWITCH",
              name: `${name}.foreign`,
              updateOnChange: true,
            }}
            onUpdate={updatePlace}
            small
          />
        </div>
      )}
      {value.foreign ? (
        <Field
          key={`${name}.birthCountry`}
          name={`${name}.birthCountry`}
          component={FormikInput}
          disabled={disabled}
          content={{
            label: "birthCountry",
            type: "COUNTRY",
            name: `${name}.birthCountry`,
            labelPadding: true,
            foreign: true,
            mandatory: content.mandatory,
            date: content.date,
          }}
        />
      ) : (
        <Field
          key={`${name}.birthPlace`}
          name={`${name}.birthPlace`}
          component={FormikInput}
          disabled={disabled}
          content={{
            label: "birthPlace",
            type: "CITY",
            name: `${name}.birthPlace`,
            labelPadding: true,
            mandatory: content.mandatory,
            date: content.date,
          }}
        />
      )}
    </div>
  );
}
