import { FormikProps, useField } from "formik";
import { FormattedMessage } from "react-intl";
import { FormInputParam, YogaParamValueType } from "commons/models/YogaParam";
import { KeyValue } from "commons/models/YogaModels";
import { useEffect, useState } from "react";
import { InformationCircleIcon } from "@heroicons/react/outline";
import { DetailsModal } from "commons/modals/DetailsModal";
import { EMPTY } from "commons/Utils";
import classNames from "classnames";
import ToggleSwitch from "commons/components/ToggleSwitch";
import { hasErrorsOnTouched } from "./Utils";

interface FormikToggleSwitchProps {
  content: FormInputParam;
  disabled?: boolean;
  form?: FormikProps<any>;
  onUpdate?: (values: KeyValue<YogaParamValueType>) => any;
  onPartialUpdate?: (
    values: KeyValue<YogaParamValueType>,
    updateOnChange: boolean
  ) => any;
  fieldName?: string;
  values?: any;
  dataQa?: string;
  labelInline?: boolean;
  small?: boolean;
  notShowErrorMessage?: boolean;
  ignoreDirty?: boolean;
  className?: string;
}

export function FormikToggleSwitch({
  content: { label, description, mandatory, name, updateOnChange },
  disabled = false,
  form,
  onUpdate,
  onPartialUpdate,
  fieldName,
  dataQa,
  labelInline = false,
  small = false,
  notShowErrorMessage = false,
  ignoreDirty = false,
  className,
}: FormikToggleSwitchProps) {
  const [field, meta] = useField(name);
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);

  useEffect(() => {
    if (updateOnChange && (form?.dirty || ignoreDirty) && onUpdate) {
      onUpdate(form?.values);
    }
  }, [field.value]);

  useEffect(() => {
    if (onPartialUpdate && (form?.dirty || ignoreDirty) && fieldName) {
      onPartialUpdate({ [fieldName]: field.value }, updateOnChange || false);
    }
  }, [field.value]);

  return (
    <div className="yoga-form-input self-end" data-qa={dataQa}>
      <label
        htmlFor={name}
        className={classNames("text-body-text text-base flex", className)}
        data-qa={`${label}-label`}
      >
        <span className="block">
          {label && !labelInline && (
            <div className="inline-flex mr-1 text-primary text-sm font-medium">
              <FormattedMessage id={label || EMPTY} />
              {mandatory && "*"}
            </div>
          )}
          {description && (
            <button
              type="button"
              className="flex-none ml-2 text-primary w-6 h-6 align-bottom hover:cursor-pointer"
              data-qa={`${name}-info`}
              onClick={() => setIsModalOpen(true)}
            >
              <InformationCircleIcon />
            </button>
          )}
        </span>

        {labelInline ? (
          <div className="inline-flex h-12 items-center">
            <ToggleSwitch
              id={name}
              field={field}
              checked={field.value}
              dataQa={`${name}-input`}
              disabled={disabled}
              small={small}
            />
            {labelInline && label && (
              <span
                className={classNames(
                  "text-body-text text-base font-bold ml-2 my-auto"
                )}
              >
                <FormattedMessage id={label} data-qa={`${label}-label`} />
                {mandatory && "*"}
              </span>
            )}
          </div>
        ) : (
          <ToggleSwitch
            id={name}
            field={field}
            checked={field.value}
            dataQa={`${name}-input`}
            disabled={disabled}
            small={small}
          />
        )}
      </label>
      {notShowErrorMessage ? (
        hasErrorsOnTouched(form) && (
          <div className="h-6">
            {meta.error && (
              <span
                className="block text-base text-error"
                data-qa={`error-message-${field.name}`}
              >
                {meta.error}
              </span>
            )}
          </div>
        )
      ) : (
        <></>
      )}

      {description && (
        <DetailsModal
          data-qa={`${name}-modal`}
          isOpen={isModalOpen}
          onClose={() => {
            setIsModalOpen(false);
          }}
          title={label}
        >
          {description}
        </DetailsModal>
      )}
    </div>
  );
}
