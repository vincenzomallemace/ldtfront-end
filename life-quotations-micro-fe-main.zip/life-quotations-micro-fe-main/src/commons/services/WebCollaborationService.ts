import axios from "axios";
import { getApiContext } from "commons/Configuration";
import { Contract } from "contracts/models/Contract";
import { AdviceData } from "documents/models/AdviceInformation";

const api = `${getApiContext()}/v1/adapters/webcollaboration`;

export const webCollaborationService = {
  initFirma: (dossierID: string, contract: Contract, adviceData: AdviceData, partialProcess: boolean) =>
    axios.post(`${api}/initFirma`, {
      dossierID: dossierID,
      contract: contract,
      adviceData: adviceData,
      partialProcess: partialProcess
    }),
  initFirmaAsync: (dossierID: string, contract: Contract, adviceData: AdviceData, partialProcess: boolean) =>
    axios.post(`${api}/initFirmaAsync`, {
      dossierID: dossierID,
      contract: contract,
      adviceData: adviceData,
      partialProcess: partialProcess
    }),
  processAsyncStatus: (dossierID: string) =>
    axios.get(`${api}/processAsyncStatus`, {
      params: { dossierId: dossierID },
    }),
  // initFirmaAsync: (dossierID: string, adviceData: AdviceData) =>
  //   axios.post(`http://localhost:4002/api/v1/adapters/webcollaboration/initFirmaAsync`, {
  //     dossierID: dossierID,
  //     adviceData: adviceData,
  //   }),
  // processAsyncStatus: (dossierID: string) =>
  //   axios.get(`http://localhost:4002/api/v1/adapters/webcollaboration/processAsyncStatus`, {
  //     params: { dossierId: dossierID },
  //   }),
  signatureInfo: (contractId: string) =>
    axios.get(`${api}/signatureInfo`, {
      params: { contractId: contractId },
    }),
};

export enum ProcessStatus {
  INIT = "INIT",
  RUNNING = "RUNNING",
  ERROR = "ERROR",
  END = "END",
}
