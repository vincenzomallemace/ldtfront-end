import axios from "axios";
import { getApiContext } from "commons/Configuration";
import { NAWSaveProposalInfo } from "../../documents/models/NAWSaveProposalInfo";

const api = `${getApiContext()}/v1/adapters/naw`;

export const nawService = {
  lastSaveNAW: (input: NAWSaveProposalInfo) =>
    axios.post(`${api}/contract/lastSaveNAW`, input),
  // lastSaveNAW: (contract: Contract) =>
  //   axios.post(`${api}/contract/lastSaveNAW`, contract),
    // axios.post(`http://localhost:4002/api/v1/adapters/contract/lastSaveNAW`),
  processAsyncStatus: (contractId: string) =>
    axios.get(`${api}/contract/processAsyncStatus`, {
      params: { contractId: contractId },
    }),
    ibanDetails:(iban: string) => 
        axios.get(`${api}/dominio/ibanDetail/${iban}`)
    // processAsyncStatus: (contractId: string) =>
    //     axios.get(`http://localhost:4002/api/v1/adapters/naw/contract/processAsyncStatus`, {
    //         params: { contractId: contractId },
    // }),
};

export enum ProcessNAWStatus {
  INIT = "INIT",
  RUNNING = "RUNNING",
  ERROR = "ERROR",
  END = "END",
}
