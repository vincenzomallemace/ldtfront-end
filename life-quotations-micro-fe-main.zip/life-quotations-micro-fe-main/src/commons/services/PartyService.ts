import axios, { AxiosResponse } from "axios";
import { getApiContext } from "commons/Configuration";
import { Consent, ConsentType } from "customers/models/Consent";
import { Party } from "customers/models/Party";
import { YogaParam } from "commons/models/YogaParam";
import { ManagementNode } from "commons/models/nodes/ManagementNode";
import { IPaginatedService } from "./IPaginatedService";
import { KeyValue } from "commons/models/YogaModels";

let cachedTable: KeyValue<string[]> = {};
let isTableLoading: KeyValue<boolean> = {};

const until = (condition) => {
  const poll = (resolve) => {
    if (condition()) resolve();
    else setTimeout(() => poll(resolve), 100);
  };
  return new Promise(poll);
};

class PartyService implements IPaginatedService<Party> {
  private api_parties = `${getApiContext()}/v2/parties`;
  private api_profiles = `${getApiContext()}/v1/profiles`;
  private api_naw = `${getApiContext()}/v1/adapters/naw`;

  list(
    search: string,
    limit: number = 1,
    page: number = 0,
    sortFields: string = "",
    sortOrder: string = "asc",
    user: string = ""
  ): Promise<AxiosResponse<Party[]>> {
    return axios.get(`${this.api_parties}`, {
      headers: {
        tags: user || "",
        search,
        sortFields,
        sortOrder,
      },
      params: {
        limit,
        page,
      },
    });
  }

  get(partyId: string, excludeNode?: boolean): Promise<AxiosResponse<Party>> {
    if (excludeNode) {
      return axios.get(`${this.api_parties}/${partyId}?excludeNode=${excludeNode}`);
    } else {
      return axios.get(`${this.api_parties}/${partyId}`);
    }
  }

  getPartyByUsername(username: string) {
    return axios.get(`${this.api_parties}/username/${username}`);
  }

  getPartyByTaxId(id: string, legalEntity: boolean): Promise<AxiosResponse<Party>> {
    return axios.get(`${this.api_parties}/taxId/${id}?legalEntity=${legalEntity}`);
  }

  getPartyByVatNumber(vatNumber: string): Promise<AxiosResponse<Party>> {
    return axios.get(`${this.api_parties}/vatNumber/${vatNumber}`);
  }

  getConsents(consentType?: ConsentType): Promise<AxiosResponse<Consent[]>> {
    const config = consentType ? { params: { type: consentType } } : {};
    return axios.get(`${this.api_profiles}/consents/`, config);
  }

  create(data: Party): Promise<AxiosResponse<string>> {
    return axios.post(`${this.api_parties}`, data);
  }

  update(partyId: string, data: Party, excludeNode?: boolean): Promise<AxiosResponse<any>> {
    if (excludeNode) {
      return axios.put(`${this.api_parties}/${partyId}?excludeNode=${excludeNode}`, data);
    } else {
      return axios.put(`${this.api_parties}/${partyId}`, data);
    }
  }

  addManagementNode(partyId: string, managementNode: ManagementNode): Promise<AxiosResponse<Party>> {
    return axios.post(`${this.api_parties}/${partyId}/managementNode`, managementNode);
  }

  checkTaxId(data: Party, dataConsistency?: boolean): Promise<AxiosResponse<boolean>> {
    const config = {
      headers: {
        dataConsistency: dataConsistency,
      },
    };
    return axios.post(`${this.api_parties}/checkTaxId`, data, config);
  }

  getParametersByRole(role: string, productCode?: string, productId?: string, productType?: string): Promise<AxiosResponse<YogaParam[]>> {
    if (productId?.length > 0 && productCode?.length > 0) {
      return axios.post(`${this.api_parties}/parameters/role/${role}?productCode=${productCode}&productId=${productId}&productType=${productType}`);
    } else {
      return axios.post(`${this.api_parties}/parameters/role/${role}`);
    }
  }

  // getParametersByRole(role: string): Promise<AxiosResponse<YogaParam[]>> {
  //   return axios.post(`${this.api_parties}/parameters/role/${role}`);
  // }

  // updateParameters(params: YogaParam[]): Promise<AxiosResponse<YogaParam[]>> {
  //   return axios.put(`${this.api_parties}/parameters`, params);
  // }

  // updateParameters(params: YogaParam[]): Promise<AxiosResponse<YogaParam[]>> {
  //   if (productId?.length > 0) {
  //   } else {
  //     return axios.put(`${this.api_parties}/parameters`, params);
  //   }
  // }

  updateParametersWithParty(
    role: string,
    partyId: string,
    params: YogaParam[],
    productId?: string,
    productType?: string,
    productCode?: string
  ): Promise<AxiosResponse<YogaParam[]>> {
    if (productId) {
      return axios.put(
        `${this.api_parties}/parameters/role/${role}/${partyId}?productId=${productId}&productType=${productType}&productCode=${productCode}`,
        params
      );
    } else {
      return axios.put(`${this.api_parties}/parameters/role/${role}/${partyId}`, params);
    }
  }

  applyTableFilter = async (fromTable: string, fromColumn: string, body: KeyValue<string> = {}) => {
    const tableColumnKey = `${fromTable}_${fromColumn}`;
    const bodyKey = Object.entries(body)
      .map(([key, value]) => `${key}_${value}`)
      .join("_");
    const key = `${tableColumnKey}_${bodyKey}`;

    if (isTableLoading[key]) {
      return new Promise((resolutionFunc) => {
        until(() => !isTableLoading[key]).then(() => {
          if (Object.keys(cachedTable).includes(key)) {
            return resolutionFunc(cachedTable[key]);
          } else {
            resolutionFunc([]);
          }
        });
      });
    }

    if (Object.keys(cachedTable).includes(key)) {
      return new Promise((resolutionFunc) => {
        resolutionFunc(cachedTable[key]);
      });
    } else {
      isTableLoading[key] = true;
      try {
        try {
          const result = await axios.post(`${this.api_parties}/tables/filter/${fromTable}/column/${fromColumn}`, body);
          cachedTable[key] = result.data as string[];
          return await new Promise((resolutionFunc_2) => {
            resolutionFunc_2(cachedTable[key]);
          });
        } catch (message) {
          return console.error(message);
        }
      } finally {
        isTableLoading[key] = false;
      }
    }
  };

  applyExternalTableFilter = async (fromTable: string, fromColumn: string, body: KeyValue<string> = {}) => {
    const tableColumnKey = `${fromTable}_${fromColumn}`;
    const bodyKey = Object.entries(body)
      .map(([key, value]) => `${key}_${value}`)
      .join("_");
    const key = `${tableColumnKey}_${bodyKey}`;

    if (isTableLoading[key]) {
      return new Promise((resolutionFunc) => {
        until(() => !isTableLoading[key]).then(() => {
          if (Object.keys(cachedTable).includes(key)) {
            return resolutionFunc(cachedTable[key]);
          } else {
            resolutionFunc([]);
          }
        });
      });
    }

    if (Object.keys(cachedTable).includes(key)) {
      return new Promise((resolutionFunc) => {
        resolutionFunc(cachedTable[key]);
      });
    } else {
      isTableLoading[key] = true;
      try {
        try {
          const result = await axios.post(`${this.api_naw}/dominio/${fromColumn}`, body);
          cachedTable[key] = result.data as string[];
          return await new Promise((resolutionFunc_2) => {
            resolutionFunc_2(cachedTable[key]);
          });
        } catch (message) {
          return console.error(message);
        }
      } finally {
        isTableLoading[key] = false;
      }
    }
  };
}

export const partyService: PartyService = new PartyService();
