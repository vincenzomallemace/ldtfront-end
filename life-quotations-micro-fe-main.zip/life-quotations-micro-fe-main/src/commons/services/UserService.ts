import axios from "axios";
import { getApiContext } from "commons/Configuration";

const api: string = `${getApiContext()}/v1/users`;

export const userService = {
  get: () =>  axios.get(`${api}`)
};
