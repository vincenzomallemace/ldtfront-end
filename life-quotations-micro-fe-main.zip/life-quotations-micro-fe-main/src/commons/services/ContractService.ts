import axios, { AxiosResponse } from "axios";
import { getApiContext } from "commons/Configuration";
import { ManagementNode } from "commons/models/nodes/ManagementNode";
import { Contract } from "contracts/models/Contract";
import { Beneficiaries } from "customers/models/Beneficiaries";
import { Party } from "customers/models/Party";
import { Payment } from "payments/Payment";
import { QuestionnaireModel } from "questionnaires/models/QuestionnaireModel";
import { KeyValue } from "commons/models/YogaModels";
import { applyTableFilter } from "./utils/TableFilterUtils";

const api = `${getApiContext()}/v1/contracts`;

export const contractService = {
  addQuestionnaire: (id: string, questionnaire: QuestionnaireModel) => axios.patch(`${api}/${id}/questionnaire`, questionnaire),
  addBeneficiaries: (id: string, beneficiaries: Beneficiaries) => axios.patch<Contract>(`${api}/beneficiaries/${id}`, beneficiaries),
  addPartyByRole: (id: string, role: string, party: Party) => axios.patch(`${api}/${id}/party/${role}`, party),
  removePartyByRoleAndId: (contractId: string, role: string, partyId: string) => axios.delete(`${api}/${contractId}/party/${role}/${partyId}`),
  addPayer: (id: string, party: Party) => axios.patch(`${api}/payer/${id}`, party),
  addThirdParty: (id: string, party: Party) => axios.patch<Contract>(`${api}/thirdParty/${id}`, party),
  get: (id: string) => axios.get(`${api}/${id}`),
  getByQuotationId: (id: string) => axios.get(`${api}/quotation/${id}`),
  complete: (id: string) =>
    axios.put(
      `${api}/complete/${id}`,
      {},
      {
        params: { wait: true },
      }
    ),
  getPayments: (contractId: string, checkLegacyPayments: boolean) =>
    axios.get(`${api}/${contractId}/payments?checkLegacyPayments=${checkLegacyPayments}`),
  updatePayment: (payment: Payment) => axios.put(`${api}/payments`, payment),
  createPayment: (payment: Payment) => axios.post(`${api}/payments`, payment),
  updateContractFlags: (contractId: string, flags: any) => axios.patch(`${api}/${contractId}/flags`, flags),
  updateContractAddendum: (contractId: string, addendum: any) =>
    axios.patch(`${api}/${contractId}/addendum`, {
      hasAddendum: !!addendum.hasAddendum,
      addendum: addendum.addendum,
    }),
  authorizationRequest: (id: string, node?: ManagementNode) => axios.put(`${api}/${id}/authorization-request`, node || undefined),
  issueAuthorized: (id: string) => axios.put(`${api}/${id}/authorized/issue`),
  addPolicyHolder: (id: string, policyholder: Party, wait: boolean = true): Promise<AxiosResponse<Contract>> =>
    axios.patch(`${api}/policyholder/${id}`, policyholder, {
      params: { wait },
    }),
  getPermissionsByRole: (role: string) => axios.get(`${api}/authorization/${role}`),
  updateContractDraft: (id: string, contract: Contract) => axios.put(`${api}/${id}/draft`, contract),
  applyTableFilter: (table: string, column: string, body: KeyValue<string>) => applyTableFilter(api, table, column, body),
};
