import { AxiosResponse } from "axios";

export interface IPaginatedService<T> {
  list(
    search: string,
    limit: number,
    page: number,
    sortFields: string,
    sortOrder: string,
    tags?: string,
    withProfile?: boolean,
    withoutProfile?: boolean
  ): Promise<AxiosResponse<T[]>>;

  get(userName: string): Promise<AxiosResponse<T>>;
}
