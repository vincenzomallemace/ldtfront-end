import axios from "axios";
import { getApiContext } from "commons/Configuration";
import { Location } from "commons/models/Location";

const api = `${getApiContext()}/v1/geo`;

export const geoService = {
  checkLocation: (location: Location) =>
    axios.post<Location>(`${api}/checkLocation`, location),
};
