import axios, { AxiosResponse } from "axios";
import { getApiContext } from "commons/Configuration";
import { Geo } from "commons/models/Geo";

const api: string = `${getApiContext()}/v1/search`;

export const searchService = {
  search: (
    resourceType: string,
    search: string,
    status: string,
    size: number = undefined
  ) =>
    axios.get(`${api}/${resourceType}`, {
      params: {
        search,
        size,
        status,
      },
    }),
  geo: (
    type: string,
    q: string,
    foreign: boolean,
    date: Date = undefined
  ): Promise<AxiosResponse<Geo[], any>> => {
    const params = {};
    if (foreign) {
      params["foreign"] = foreign;
    }
    if (date != undefined) {
      if (typeof date === "string" && date != "") {
        params["date"] = date;
      } else if (date instanceof Date) {
        params["date"] = date.toISOString().split("T")[0];
      }
    }
    return axios.get(`${api}/geo/${type}/${q}`, { params });
  },
};
