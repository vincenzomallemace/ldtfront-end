import axios from "axios";
import {getApiContext} from "commons/Configuration";
import {Contract} from "contracts/models/Contract";
import {DocumentAttributes} from "documents/models/DocumentAttributes";
import {TYPE} from "documents/models/Dossier";

const api: string = `${getApiContext()}/v1/dossiers`;

export const dossierService = {
  getDossier: (dossierId: string) => axios.get(`${api}/${dossierId}`),
  getDossierByEntityId: (entityId: string) =>
    axios.get(`${api}/entity/${entityId}`),
  getDossierDocumentsByEntityId: (entityId: string) =>
    axios.get(`${api}/entity/${entityId}/documents`),
  getDossierHistory: (entityId: string, operationId: string) =>
    axios.get(`${api}/entity/${entityId}/operations/${operationId}/documents`),
  getDossierOutputsByEntityId: (entityId: string) =>
    axios.get(`${api}/entity/${entityId}/outputs`),
  getDossierModelByEntityType: (type: TYPE) =>
    axios.get(`${api}/models/entity/${type}`),
  getDossierByEntityCode: (type: TYPE, code: string) =>
    axios.get(`${api}/models/entity/${type}/code/${code}`),
  checkEntityDossierValidity: (entityId: string) =>
    axios.get(`${api}/entity/check/${entityId}`),
  uploadToDossier: (
    dossierId: string,
    input: string,
    attributes: DocumentAttributes
  ) => axios.post(`${api}/${dossierId}/document/${input}`, attributes),
  uploadToGroup: (
    dossierId: string,
    group: string,
    input: string,
    attributes: DocumentAttributes
  ) =>
    axios.post(
      `${api}/${dossierId}/group/${group}/document/${input}`,
      attributes
    ),
  removeDocumentFromDossier: (
    dossierId: string,
    code: string,
    docIdToDelete?: string
  ) =>
    axios.delete(
      docIdToDelete
        ? `${api}/${dossierId}/document/${code}/${docIdToDelete}`
        : `${api}/${dossierId}/document/${code}`
    ),
  removeDocumentFromGroup: (
    dossierId: string,
    group: string,
    code: string,
    docIdToDelete?: string
  ) =>
    axios.delete(
      docIdToDelete
        ? `${api}/${dossierId}/group/${group}/document/${code}/${docIdToDelete}`
        : `${api}/${dossierId}/group/${group}/document/${code}`
    ),
  hasDossierByEntityId: (entityId: string) =>
    axios.head(`${api}/entity/${entityId}`),
  checkSignatureDossier: (dossierId: string) =>
    axios.head(`${api}/${dossierId}/signature`),
  checkDossierWithSignature: (dossierId: string, contract: Contract) =>
    axios.post(`${api}/${dossierId}/signature`, {dossierId, contract}),
  createDossierFromContract: (contract: Contract) =>
    axios.post(`${api}/contract`, contract),
  checkDossierDocuments: (dossierId: string, checkOutputDocument: boolean) =>
    axios.post(
      `${api}/${dossierId}/check/documents`,
      {},
      {params: {output: checkOutputDocument}}
    ),
};
