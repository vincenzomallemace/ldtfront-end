import axios from "axios";
import { getApiContext } from "commons/Configuration";
import { KeyValue } from "commons/models/YogaModels";

const api: string = `${getApiContext()}/v1/products`;

let cachedTable: KeyValue<string[]> = {};
let isTableLoading: KeyValue<boolean> = {};

const until = (condition) => {
  const poll = (resolve) => {
    if (condition()) resolve();
    else setTimeout(() => poll(resolve), 100);
  };
  return new Promise(poll);
};

export const productService = {
  applyTableFilter: async (
    fromTable: string,
    fromColumn: string,
    body: KeyValue<string> = {}
  ) => {
    const tableColumnKey = `${fromTable}_${fromColumn}`;
    const bodyKey = Object.entries(body)
      .map(([key, value]) => `${key}_${value}`)
      .join("_");
    const key = `${tableColumnKey}_${bodyKey}`;

    if (isTableLoading[key]) {
      return new Promise((resolutionFunc) => {
        until(() => !isTableLoading[key]).then(() => {
          if (Object.keys(cachedTable).includes(key)) {
            return resolutionFunc(cachedTable[key]);
          } else {
            resolutionFunc([]);
          }
        });
      });
    }

    if (Object.keys(cachedTable).includes(key)) {
      return new Promise((resolutionFunc) => {
        resolutionFunc(cachedTable[key]);
      });
    } else {
      isTableLoading[key] = true;
      return axios
        .post(`${api}/tables/filter/${fromTable}/column/${fromColumn}`, body)
        .then((result) => {
          cachedTable[key] = result.data as string[];
          return new Promise((resolutionFunc) => {
            resolutionFunc(cachedTable[key]);
          });
        })
        .catch(console.error)
        .finally(() => {
          isTableLoading[key] = false;
        });
    }
  },
};
