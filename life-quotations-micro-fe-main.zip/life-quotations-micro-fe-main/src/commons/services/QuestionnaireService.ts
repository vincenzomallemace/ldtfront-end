import axios, { AxiosResponse } from "axios";
import { getApiContext } from "commons/Configuration";
import { QuestionnaireModel } from "questionnaires/models/QuestionnaireModel";
import { QuestionnaireUpdateData } from "questionnaires/models/QuestionnaireUpdateData";

const api: string = `${getApiContext()}/v1/questionnaires`;

export const questionnaireService = {
  get: (id: string): Promise<AxiosResponse<QuestionnaireModel>> =>
    axios.get(`${api}/${id}`),
  createFrom: (code: string, contextData: {}, partyId?: string) =>
    axios.post(`${api}/${code}`, contextData, {
      headers: {
        entityId: partyId ? partyId : "",
        entityType: "party",
      },
    }),

  createType: (
    type: string,
    contextData: {},
    entityId: string,
    entityType: string,
    productCode?: string
  ) =>
    axios.post(`${api}/type/${type}`, contextData, {
      params: {
        productCode: productCode,
      },
      headers: {
        entityId: entityId,
        entityType: entityType,
      },
    }),

  update: (
    id: string,
    data: QuestionnaireUpdateData,
    entityId: string,
    entityType: string,
    riskAnalysis: boolean = false,
    questionnaireCompleted: boolean = true
  ) =>
    axios.put(`${api}/${id}`, data, {
      headers: {
        entityId: entityId,
        entityType: entityType,
        riskAnalysis: riskAnalysis,
        questionnaireCompleted: questionnaireCompleted,
      },
    }),
  partialUpdate: (
    id: string,
    data: QuestionnaireUpdateData,
    entityId: string,
    entityType: string,
    questionnaireCompleted: boolean = false
  ) =>
    axios.patch(`${api}/${id}`, data, {
      headers: {
        entityId: entityId,
        entityType: entityType,
        questionnaireCompleted: questionnaireCompleted,
      },
    }),
};
