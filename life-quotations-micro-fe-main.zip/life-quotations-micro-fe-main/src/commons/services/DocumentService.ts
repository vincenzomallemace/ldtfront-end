import axios, { AxiosRequestConfig } from "axios";
import { getApiContext } from "commons/Configuration";
import { DocumentAttributes } from "documents/models/DocumentAttributes";

const api: string = `${getApiContext()}/v1/documents`;

export const documentService = {
  getSettings: () => axios.get(`${api}/content/settings`),
  post: (documentAttribute: DocumentAttributes) =>
    axios.post(`${api}`, documentAttribute),
  update: (documentAttribute: DocumentAttributes) =>
    axios.put(`${api}/${documentAttribute.documentId}`, documentAttribute),
  put: (documentId: string, document: File) => {
    return axios.put(`${api}/${documentId}/content`, document);
  },
  get: (documentId: string) => {
    return axios.get(`${api}/${documentId}`);
  },
  delete: (documentId: string) => axios.delete(`${api}/${documentId}`),
  getContentDocuments: (entityId: string, params?: any) =>
    axios.get(`${api}/folders/${entityId}`, params),
  downloadContentDocument: (documentId: string) =>
    axios.get(`${api}/${documentId}/content`, { responseType: "blob" }),
  downloadDocumentOfDossier: (dossierId: string, documentId: string) =>
    axios.get(`${api}/${dossierId}/${documentId}/content`, {
      responseType: "blob",
    }),
  getDocumentsByOwner: (ownerUserName: string) =>
    axios.get(`${api}/owner/${ownerUserName}`),
  getDocumentsByViewer: (viewerUserName: string, config: AxiosRequestConfig) =>
    axios.get(`${api}/viewer/${viewerUserName}`, config),
  getDocumentsByIds: (documentIds: string[]) => {
    var params = new URLSearchParams();
    documentIds.forEach((x) => params.append("documentIds", x));
    var request = {
      params: params,
    };

    return axios.get(`${api}/list`, request);
  },
};
