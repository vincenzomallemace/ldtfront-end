import axios from "axios";
import { getApiContext } from "commons/Configuration";
import { KeyValue, Money } from "commons/models/YogaModels";
import { YogaParam } from "commons/models/YogaParam";
import { Party } from "customers/models/Party";
import { ProductParty } from "customers/models/ProductParty";
import { Product } from "offers/models/Product";
import { AppliedDiscount, FinancialOfferProduct, InvestmentLine } from "models/FinancialAdvice";
import { ContextData } from "commons/models/ContextData";
import { ContractualOption } from "offers/models/ContractualOption";
import { PartitionOption } from "offers/models/PartitionOption";

const api: string = `${getApiContext()}/v1/life/products`;

interface ProductLifeRequest {
  policyholder: Party;
  financialAdviceOffer: FinancialAdviceOffer;
}

export interface FinancialAdviceOffer {
  financialAdviceId: string;
  financialOfferId: string;
  product: FinancialOfferProduct;
  investmentLines: KeyValue<InvestmentLine>;
  operationValue?: Money;
  appliedDiscount?: AppliedDiscount;
}

export const lifeProductService = {
  createLifeProduct: (productLifeRequest: ProductLifeRequest) => axios.post(`${api}`, productLifeRequest),
  getIncompleteLifeProduct: (id: string) => axios.get(`${api}/${id}/incomplete`),
  addPolicyholderToProduct: (id: string, policyholder: Party) => axios.patch(`${api}/policyholder/${id}`, policyholder),
  addInsuredPerson: (id: string, assetCode: string, assetId: string, party: ProductParty) =>
    axios.patch(`${api}/${id}/${assetCode}/${assetId}/insured`, party),
  updateProductIncomplete: (id: string, product: Product, contextData?: ContextData) =>
    axios.put<Product>(`${api}/${id}/incomplete`, {
      productInstance: product,
      contextData: contextData,
    }),
  saveProductIncompleteDraft: (id: string, product: Product, contextData?: ContextData) =>
    axios.put<Product>(`${api}/${id}/incomplete/draft`, {
      productInstance: product,
      contextData: contextData,
    }),
  updateProductParameters: (id: string, parameters: KeyValue<YogaParam>) => axios.patch(`${api}/${id}/parameters`, parameters),
  updateAndQuoteIncompleteProduct: (id: string, product: Product, contextData?: ContextData) =>
    axios.put<Product>(`${api}/${id}/incomplete/quote`, {
      productInstance: Object.assign(product, { channel: "b2b" }),
      contextData: contextData,
    }),
  confirmProductAsync: (id: string) => axios.post(`${getApiContext()}/v1/life/async/products/${id}/confirm`),
  confirmProductSync: (id: string) => axios.post(`${getApiContext()}/v1/life/sync/products/${id}/confirm`),
  addContractualOptions: (id: string, options: KeyValue<ContractualOption>) => axios.patch(`${api}/${id}/contractual-options`, options),
  addPartitionOption: (id: string, partitionOption: PartitionOption) => axios.patch(`${api}/${id}/partition-option`, partitionOption),
};
