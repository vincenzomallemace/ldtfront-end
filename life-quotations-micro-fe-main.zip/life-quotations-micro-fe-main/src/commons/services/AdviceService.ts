import axios, { AxiosResponse } from "axios";
import { getApiContext } from "commons/Configuration";
import { Adviceinformation } from "documents/models/AdviceInformation";

const api: string = `${getApiContext()}/v1/adapters/zurich-bank`;

export const adviceService = {
  getAdviceInformation: (
    ndgPatrimonio: string,
    codiceIac: string
  ): Promise<AxiosResponse<Adviceinformation>> =>
    axios.get(
      `${api}/advice?codiceIac=${codiceIac}` + `&ndgPatrimonio=${ndgPatrimonio}`
    ),
};
