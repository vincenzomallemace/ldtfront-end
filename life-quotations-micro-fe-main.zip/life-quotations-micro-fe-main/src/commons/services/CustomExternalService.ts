import axios from "axios";
import { KeyValue } from "commons/models/YogaModels";
import { YogaParam } from "commons/models/YogaParam";

// TODO: ATTESA API APPOSITE PER IL SERVIZIO

const api = `https://jsonplaceholder.typicode.com`; // TODO - REPLACE

export const CustomExternalService = {
  // MOCKUP PURPOSE
  getPosts: () => axios.get(`${api}/posts`),
  getPostComments: (postId: string) =>
    axios.get(`${api}/posts/${postId}/comments`),
};

export const customExternalParams = async (
  params: YogaParam[],
  newVals?: KeyValue<YogaParam>
) => {
  const loadValues = async (param: YogaParam, postId?: string) => {
    let data: string[];
    if (postId) {
      const res = await CustomExternalService.getPostComments(postId);
      data = res.data.map((item) => item.name.toString());
    } else {
      const res = await CustomExternalService.getPosts();
      data = res.data.map((item) => item.id.toString());
    }
    param.availableValues = data;
    param.updatePartyOnChange = true;
  };

  const previous: YogaParam[] = [];
  for (const param of params) {
    const regex = /(CustomerExternal)(\d+)/g;
    const match = [...param.code.matchAll(regex)];

    if (match.length === 0) {
      continue;
    }
    if (previous.length == 0) {
      await loadValues(param);
    } else if (
      previous[previous.length - 1].value &&
      previous[previous.length - 1].value.toString().length > 0
    ) {
      param.value = undefined;
      await loadValues(
        param,
        newVals[previous[previous.length - 1].code].value.toString()
      );
    }
    previous.push(param);
  }
  return params;
};
