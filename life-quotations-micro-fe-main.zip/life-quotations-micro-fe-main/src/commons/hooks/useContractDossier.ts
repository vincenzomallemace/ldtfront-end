import { useEffect, useState } from "react";
import useInterval from "commons/hooks/useInterval";
import { Dossier, DossierState } from "documents/models/Dossier";
import { DocumentAttributes } from "documents/models/DocumentAttributes";
import { documentService } from "commons/services/DocumentService";
import useDossierInfo from "documents/hooks/useDossierInfo";
import { dossierService } from "commons/services/DossierService";

export default function useContractDossier(
  contractId: string,
  onlyOutput?: boolean
) {
  const [dossier, setDossier] = useState<Dossier>(undefined);
  const [dossierError, setDossierError] = useState<Error | undefined>();
  const [isPollingDossier, setPollingDossier] = useState<boolean>(false);
  const [startPolling, setStartPolling] = useState<boolean>(false);
  const [documents, setDocuments] = useState<DocumentAttributes[]>();
  const [dossierSignature, setDossierSignature] = useState<boolean>(false);
  const [isPollingDossierSignature, setPollingDossierSignature] =
    useState<boolean>(false);
  const [isPollingTerminated, setIsPollingTerminated] =
    useState<boolean>(false);
  const { getInfo } = useDossierInfo();

  let counterRetries = 0;
  const maxRetries = 10;
  const delay = 5000;

  let signatureCounterRetries = 0;
  const signatureMaxRetries = 4;
  const signatureDelay = 1000;

  async function getDossier() {
    let dossierInfo = await getInfo(contractId);
    if (dossierInfo?.state === DossierState.READY) {
      let documents = dossierInfo.documents
        .filter((d) => !d.acknowledgmentRequired)
        .map((doc) => doc.attributes);
      setDossier(dossierInfo.dossier);
      setPollingDossier(false);
      setDocuments(documents);
    } else {
      setPollingDossier(true);
    }
  }

  useEffect(() => {
    const fetchData = async () => {
      if (startPolling && contractId) {
        getDossier();
      }
    };

    fetchData().catch((e) => {
      setPollingDossier(true);
      setDossierError(e);
    });
  }, [startPolling]);

  useInterval(
    async () => {
      if (counterRetries > maxRetries) {
        setIsPollingTerminated(true);
        setPollingDossier(false);
        return;
      }
      try {
        getDossier();
      } catch (e) {
        // @ts-ignore
        setDossierError(e.response?.data?.message);
      } finally {
        counterRetries++;
      }
    },
    // Delay in milliseconds or null to stop it
    isPollingDossier ? delay : null
  );

  useEffect(() => {
    const fetchData = async () => {
      if (dossierSignature) {
        setPollingDossierSignature(false);
        setDossierSignature(false);
        // Reset the signatureCounterRetries
        signatureCounterRetries = 0;
        setIsPollingTerminated(false);
        await dossierService.checkSignatureDossier(dossier.dossierId);
        setPollingDossierSignature(true);
      }
    };

    fetchData().catch((e) => {
      setPollingDossierSignature(false);
      setDossierError(e);
    });
  }, [dossierSignature]);

  useInterval(
    async () => {
      if (signatureCounterRetries > signatureMaxRetries) {
        setPollingDossierSignature(false);
        setIsPollingTerminated(true);
        return;
      }
      try {
        let result = await dossierService.getDossier(dossier.dossierId);

        if (result) {
          let dossier = result?.data as Dossier;
          let outputDocuments = dossier?.outputDocuments;
          let areDocumentsSigned =
            outputDocuments &&
            Object.values(outputDocuments)
              .filter((document) => document.signRequired)
              .every((document) => document.signed);

          if (areDocumentsSigned) {
            setPollingDossierSignature(false);
            setDossier(dossier);
            let documentResult = await documentService.getContentDocuments(
              contractId,
              onlyOutput
                ? {
                    params: { output: true },
                  }
                : {}
            );
            setDocuments(documentResult.data);
          }
        }
      } catch (e) {
        // @ts-ignore
        setDossierError(e.response?.data?.message);
      } finally {
        signatureCounterRetries++;
      }
    },
    // Delay in milliseconds or null to stop it
    isPollingDossierSignature ? signatureDelay : null
  );

  return {
    dossier,
    dossierError,
    setStartPolling,
    documents,
    setDossierSignature,
    isPollingTerminated,
    isPollingDossierSignature,
  };
}
