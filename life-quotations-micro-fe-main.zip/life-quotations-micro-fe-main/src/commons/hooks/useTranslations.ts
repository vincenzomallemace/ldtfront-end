import { translations } from "@aws-amplify/ui";
import { I18n } from "aws-amplify";
import axios from "axios";
import { config, getApiContext } from "commons/Configuration";
import { noop } from "commons/Utils";
import { KeyValue } from "commons/models/YogaModels";
import { feMessages } from "i18n/messages";
import { useEffect, useState } from "react";
import { getLanguages } from "./useNavigatorLanguage";

I18n.putVocabularies(translations);
I18n.putVocabularies(feMessages);

export default function useTranslations(lang: any) {
  const AVAIBLE_LANGUAGES = Object.keys(getLanguages());

  // TODO: Add a service
  const api: string = `${getApiContext()}/v2/translations`;

  const [beMessages, setBEMessages] = useState<KeyValue<KeyValue<string>>>();
  const [i18n, setI18n] = useState<any>();

  const [error, setError] = useState<Error | undefined>(undefined);

  useEffect(() => {
    const fetchData = async () => {
      const result = await axios.get(`${api}`, {
        params: {
          channel: config.YOGA_CHANNEL,
        },
      });
      const translations = result.data;
      const be = { it: {}, en: {} };
      translations.forEach((t) => {
        be[t.language][t.key] = t.value;
      });
      setBEMessages(be);
    };
    fetchData().catch((e) => {
      setError(e);
    });
  }, []);

  useEffect(() => {
    if (beMessages) {
      setI18n({
        messages: {
          ...feMessages[lang],
          ...beMessages[lang],
        },
        key: lang,
        locale: lang,
        defaultLocale: AVAIBLE_LANGUAGES[0],
        onError: noop,
      });
    }
  }, [lang, beMessages, error]);

  return { i18n, error };
}
