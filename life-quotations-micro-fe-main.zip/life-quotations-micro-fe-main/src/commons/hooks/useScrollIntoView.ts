import React, { useEffect, useState } from "react";

const useScrollIntoView = ({
  id,
  ref,
}: {
  id?: string;
  ref?: React.MutableRefObject<HTMLElement>;
}) => {
  const [shouldScroll, setShouldScroll] = useState(false);

  useEffect(() => {
    if (shouldScroll) {
      scrollIntoView();
      setShouldScroll(false);
    }
  }, [shouldScroll]);

  const scroll = () => {
    setShouldScroll(true);
  };

  const scrollIntoView = () => {
    if (id) {
      const element = document.getElementById(id);
      if (element) {
        element.scrollIntoView({ behavior: "smooth", block: "center" });
      }
    } else if (ref && ref.current) {
      ref.current.scrollIntoView({ behavior: "smooth", block: "center" });
    }
  };

  return { scroll };
};

export default useScrollIntoView;
