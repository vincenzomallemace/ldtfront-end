export default () => {
  const reload = () => {
    window.dispatchEvent(new Event("yoga-notices-reload"));
  };

  return { reload };
};
