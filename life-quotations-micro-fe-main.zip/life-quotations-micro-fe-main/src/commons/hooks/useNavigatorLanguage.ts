import { config } from "commons/Configuration";
import { useState } from "react";

const createLanguagesObject = (langByConf: string) => {
  var ret = {};
  langByConf.split(",").forEach((lang) => {
    let split = lang.split(":");
    ret[split[0]] = { description: split[1] };
  });
  return ret;
}

export function getLanguages() {
  const LANGUAGES = config.LANGUAGES;
  return LANGUAGES ? createLanguagesObject(LANGUAGES) : { en: { description: "English" } };
}

type Language = string;
const AVAILABLE_LANGUAGES = Object.keys(getLanguages());
const DEFAULT_LANGUAGE = AVAILABLE_LANGUAGES[0];

// @ts-ignore
const getNavLang = () => navigator?.language || navigator["userLanguage"];

const getLanguage = (): Language => {
  try {
    let selectedLanguage = (
      window.localStorage.getItem("language") || getNavLang()
    ).match(/\w+/)[0];
    if (AVAILABLE_LANGUAGES.indexOf(selectedLanguage) === -1) {
      selectedLanguage = DEFAULT_LANGUAGE;
    }
    return selectedLanguage;
  } catch (e) {
    return DEFAULT_LANGUAGE;
  }
};

/**
 * useNavigatorLanguage hook
 * Returns the language of the navigator
 * @return {Language}
 */
export function useNavigatorLanguage(): Language {
  const [language] = useState<Language>(getLanguage);
  return language;
}
