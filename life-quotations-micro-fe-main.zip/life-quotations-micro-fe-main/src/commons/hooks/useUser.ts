import { Amplify, Auth } from "aws-amplify";
import { AUTH, config } from "commons/Configuration";
import { Context } from "commons/contexts/Context";
import { ManagementNode } from "commons/models/nodes/ManagementNode";
import { userService } from "commons/services/UserService";
import { useContext, useEffect, useMemo, useState } from "react";

Amplify.configure({
  Auth: import.meta.env.MODE === "test" ? {
    region: "eu-fake-1",
    userPoolId: "eu-fake-1_424242",
    userPoolWebClientId: "4242424242",
  } : {
    region: AUTH.region,
    userPoolId: AUTH.userPoolId,
    userPoolWebClientId: AUTH.userPoolWebClientId,
    authenticationFlowType: "USER_SRP_AUTH",
  },
});

export function useUser(configuration?: any) {
  const [user, setUser] = useState(null);
  const [yogaUser, setYogaUser] = useState(null);
  const [rootManagementNodes, setRootManagementNodes] = useState<ManagementNode[]>([]);
  const [role, setRole] = useState<string>(undefined);

  const context = useContext(Context);

  const auth = useMemo(() => {
    Auth.configure(configuration);
    return Auth;
  }, []);

  useEffect(() => {
    checkUser()
  }, []);


  //CONFIGURARE CON LO SKIPP_SSSO, Valorizzare user con quello che ritorna dalla get senza passare da cognito
  const checkUser = async () => {
    try {
      context.changeLoading(1);
      const response = await userService.get()
      if(config.SKIP_SSO && config.SKIP_SSO === 'enabled'){
        const user = response.data;
        setUser(user);
      }
      else{
        const user = await auth.currentAuthenticatedUser();
        setUser(user);
      }
      if (user) {
        // const response = await userService.get()
        setYogaUser(response.data);
        setRole(response.data.groups?.length > 0 ? response.data.groups[0] : undefined);
        setRootManagementNodes(response.data.rootManagementNodes);
      }
    } catch (error) {
      console.error("check user failed", error);
    } finally {
      context.changeLoading(-1);
    }
  }

  // const signOut = () =>
  //   auth.signOut().then(() => {
  //     setUser(null);
  //     setYogaUser(null);
  //     setRole("");
  //     setRootManagementNodes([]);
  //     window.location.reload();
  //   });

  const signOut = () => {
    if(config.SKIP_SSO && config.SKIP_SSO === 'enabled'){
      setUser(null);
      setYogaUser(null);
      setRole("");
      setRootManagementNodes([]);
      window.close();
    } else {
      auth.signOut().then(() => {
        setUser(null);
        setYogaUser(null);
        setRole("");
        setRootManagementNodes([]);
        window.location.reload();
      });
    }
  }

  return {
    user,
    yogaUser,
    rootManagementNodes,
    role,
    signOut,
  };
}