import { useState } from "react";

export const useSessionStorage = <T>(key: string, defaultValue: T) => {
  const getStorageValue = <T>(key: string, defaultValue: T) => {
    const saved = sessionStorage.getItem(key);
    return saved !== null ? JSON.parse(saved) : defaultValue;
  };

  const [value, setValue] = useState(() =>
    getStorageValue<T>(key, defaultValue)
  );

  const set = <T>(v: T) => {
    sessionStorage.setItem(key, JSON.stringify(v));
    setValue(v);
  };

  return [value, set];
};
