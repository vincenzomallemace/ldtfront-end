import * as yup from "yup";
import { KeyValue } from "commons/models/YogaModels";
import { IntlShape } from "react-intl";
import { FormInputParam, GenericParam, YogaParam, YogaParamValueType } from "./models/YogaParam";
import { Location } from "./models/Location";
import { formatPhoneNumberIntl, isValidPhoneNumber, parsePhoneNumber } from "react-phone-number-input";
import { Question } from "questionnaires/models/Question";
import { EntityWithBirthData } from "customers/models/Party";
import { Answer } from "questionnaires/models/Answer";
import { OptionalArraySchema } from "yup/lib/array";
import { isValidIBAN } from "ibantools";

export const CF_REGEXP = /^[A-Za-z]{6}[0-9LMNPQRSTUV]{2}[A-Za-z]{1}[0-9LMNPQRSTUV]{2}[A-Za-z]{1}[0-9LMNPQRSTUV]{3}[A-Za-z]{1}$/;
export const TAXID_REGEXP = /^[0-9]{11}$/;
export const EMAIL_REGEXP = /^[0-9a-zA-Z\\.!#$%&'*+/=?^_`{|}~-]+@[0-9a-zA-Z_]+?\\.[a-zA-Z]{2,3}$/;

const typeDescriptors: Record<string, any> = {
  STRING: yup.string().ensure(),
  NUMBER: yup.number(),
  AMOUNT: yup.number(),
  BOOLEAN: yup.bool().oneOf([false, true]),
  LIST: yup.string(),
  DATE: yup.string(), // FIXME: una data per yup è una stringa?
  DYNAMIC_LIST: yup.string(),
  SEARCHLIST: yup.string(),
  CITY: yup.string(),
  COUNTRY: yup.string(),
  PHONE: yup.string(),
  EMAIL: yup.string().email(),
  MULTIPLE_CHOICE: yup.array(),
};

export const validation = {
  canValidate(v: Location) {
    return v && v.country === "Italia";
  },
  missingParams: (mandatory: string[], value: any) => {
    let missingParams = [];
    if (!mandatory) {
      return missingParams;
    }
    mandatory.forEach((el) => {
      if (!value[el]) {
        missingParams.push(el);
      }
    });
    return missingParams;
  },
};

export const toDotNotation = (obj, res = {}, current = "") => {
  for (const key in obj) {
    let value = obj[key];
    let newKey = current ? current + "." + key : key; // joined key with dot
    if (value && typeof value === "object") {
      toDotNotation(value, res, newKey); // it's a nested object, so do it again
    } else {
      res[newKey] = value; // it's not an object, so set the property
    }
  }
  return res;
};

export const toYupFieldsByName = (params: GenericParam[], intl: IntlShape) => toYupTypedList<FormInputParam>(params, "name", intl);

const toYupTypedList = <T extends GenericParam>(params: T[], fieldName: string & keyof T, intl: IntlShape): KeyValue<any> =>
  params.reduce((acc, param) => {
    const key = param[fieldName] as unknown as string;
    const value = toYupTypedSingleWithValidations(param, intl);
    return { ...acc, [key]: value };
  }, {});

export const toYupObjectByCode = (params: YogaParam[], intl: IntlShape) =>
  params.reduce((acc, param) => {
    const key = param["code"] as string;
    const value = toYupTypedSingleWithValidations(param, intl);
    return { ...acc, [key]: yup.object({ value: value }) };
  }, {});

const toYupTypedSingleWithValidations = (param: GenericParam, intl: IntlShape) => {
  const maxMessage = intl.formatMessage({
    id: "form.validateMaxError",
    defaultMessage: "Must be less than",
  });
  const minMessage = intl.formatMessage({
    id: "form.validateMinError",
    defaultMessage: "Must be greater than",
  });
  const requiredMessage = intl.formatMessage({ id: "required" });
  const regExpMessage = intl.formatMessage({ id: "form.validateRegExpError" });

  const { mandatory, type, validations, visible } = param;

  let elem: yup.BaseSchema = typeDescriptors[type];
  if (mandatory && visible) {
    elem = elem.required(requiredMessage);
  }
  if (validations) {
    if (validations.max !== null && validations.max !== undefined) {
      elem = (elem as yup.NumberSchema).max(validations.max, `${maxMessage} ${validations.max}`);
    }
    if (validations.min !== null && validations.min !== undefined) {
      elem = (elem as yup.NumberSchema).min(validations.min, `${minMessage} ${validations.min}`);
    }
    if (validations.maxSelected && validations.minSelected) {
      if (validations.maxSelected == validations.minSelected) {
        elem = (elem as OptionalArraySchema<any>).length(
          validations.minSelected,
          intl.formatMessage({ id: "multiChoiceNumberMessage" }, { number: validations.minSelected })
        );
      }
    }
    if (validations.maxSelected) {
      elem = (elem as OptionalArraySchema<any>).max(
        validations.maxSelected,
        intl.formatMessage({ id: "multiChoiceMaxMessage" }, { number: validations.maxSelected })
      );
    }
    if (validations.minSelected) {
      elem = (elem as OptionalArraySchema<any>).min(
        validations.minSelected,
        intl.formatMessage({ id: "multiChoiceMinMessage" }, { number: validations.minSelected })
      );
    }

    if (type === "STRING" && validations.regExp) {
      elem = (elem as yup.StringSchema).matches(new RegExp(validations.regExp), `${regExpMessage}`); // ${validations.regExp}`);
    }
    if (validations.format) {
      switch (validations.format) {
        case "EMAIL":
          elem = (elem as yup.StringSchema).email(intl.formatMessage({ id: "invalidEmail" }));
          break;
        case "IBAN":
          elem = (elem as yup.StringSchema).test("iban", intl.formatMessage({ id: "ibanFormatError" }), (v) => v && isValidIBAN(v));
          break;
        case "PHONE_NUMBER":
          elem = (elem as yup.StringSchema).test(
            "phoneValid",
            intl.formatMessage({ id: "invalidPhoneNumber" }),
            (val) => val && isValidPhoneNumber(val)
          );
          break;
        case "TAX_ID":
          elem = (elem as yup.StringSchema).test(
            "taxIdValid",
            intl.formatMessage({ id: "invalidTaxId" }),
            (val) => CF_REGEXP.test(val) || TAXID_REGEXP.test(val)
          );
          break;
        default:
          break;
      }
    }
  }
  return elem;
};

export function valuesOf(params: GenericParam[]): KeyValue<YogaParamValueType> {
  const obj: KeyValue<YogaParamValueType> = {};
  params.forEach((param) => (obj[param.name] = getValueOf(param)));
  return obj;
}

function getValueOf(param: GenericParam) {
  const value = param.value;
  if (param.type === "BOOLEAN" || param.type === "CHECKMARK") {
    return value === "true";
  } else if (param.type === "NUMBER" || param.type === "AMOUNT") {
    const number = Number(`${value}` as string);
    return isNaN(number) || value === "" ? "" : number;
  } else {
    return value;
  }
}

export const geoValidationError = (intl: IntlShape) => intl.formatMessage({ id: "requiredGeo" });

export const fromYogaParamToFormParam = (p: YogaParam): FormInputParam => ({
  ...p,
  label: p.name,
  name: p.yuid,
  updateOnChange: p.updateProductOnChange || p.updateQuestionnaireOnChange || p.updatePartyOnChange || p.updatePaymentMethodOnChange,
});

export const getMobilePhoneAndPrefix = (phone?: string, phonePrefix?: string) => {
  let number = phone?.trim() ?? "";
  let parsed = parsePhoneNumber(number);
  let prefix = "";

  if (parsed && parsed.countryCallingCode) {
    prefix = `+${parsed.countryCallingCode}`;
    number = parsed.nationalNumber;
  } else {
    prefix = phonePrefix?.trim() ? phonePrefix?.trim()?.replaceAll("00", "+") : "+39";
    number = number.replaceAll(prefix, "");
  }
  return [number, prefix];
};

export const getBirthPlace = (party: EntityWithBirthData) => {
  let birthPlace: string = party.birthPlace;
  if (birthPlace && !party.birthPlace.includes("(" + party.birthCountyCode + ")")) {
    birthPlace = party.birthPlace ? (party.birthCountyCode ? `${party.birthPlace} (${party.birthCountyCode})` : party.birthPlace) : "";
  } else if (birthPlace && party.birthPlace.includes("(" + party.birthCountyCode + ")")) {
    party.birthPlace = party.birthPlace.slice(0, -5);
  }

  return {
    birthPlace: birthPlace ?? "",
    birthPlaceCode: party.birthPlaceCode ?? "",
    birthCountyCode: party.birthCountyCode ?? "",
    birthCountry: party.birthCountry ?? "",
    birthCountryCode: party.birthCountryCode ?? "",
    birthPlaceComplete: {
      geoId: "",
      name: party.birthPlace ?? "",
      countyCode: party.birthCountyCode ?? "",
    },
  };
};

export const setMobilePhoneAndPrefix = (phoneAndPrefix?: string) => {
  let number = null;
  let prefix = null;
  if (phoneAndPrefix) {
    const numberPrefix = formatPhoneNumberIntl(phoneAndPrefix).split(" ")[0];
    number = phoneAndPrefix.replace(prefix, "");
    prefix = numberPrefix.replace("+", "00");
  }
  return [number, prefix];
};

export const transformObjectToDotNotation = (obj, prefix = "", result: string[] = []) => {
  Object.keys(obj).forEach((key) => {
    const value = obj[key];
    if (!value) return;

    const nextKey = prefix ? `${prefix}.${key}` : key;
    if (typeof value === "object") {
      transformObjectToDotNotation(value, nextKey, result);
    } else {
      result.push(nextKey);
    }
  });

  return result;
};

function setAnswerValue(answer: Answer) {
  if (answer.type == "MULTIPLE_CHOICE") {
    return answer.values?.length > 0 && answer.values[0] != "" ? answer.values : "";
  } else {
    return answer.values?.length > 0 ? answer.values[0] : "";
  }
}

export const questionsToInputParams = (questions: Question[]): FormInputParam[] => {
  const params = [];
  questions.forEach((question) => {
    const param = {
      value: setAnswerValue(question.answer),
      type: question.answer.type,
      order: question.order,
      name: question.code,
      label: question.label,
      mandatory: question.answer.mandatory,
      updateOnChange: question.updateQuestionnaireOnChange,
      code: question.code,
      description: question.description,
      availableValues: question.answer.availableValues,
      visible: question.visible,
      disabled: question.answer.disabled,
      searchList: question.answer.searchList,
      validations: question.answer.validations,
      tags: question.tags,
      tag: question.tags ? question.tags[0] : undefined,
    };
    params.push(param);
  });
  return params;
};

export const filterParams = (partyParams: KeyValue<YogaParam>, defaultParams: YogaParam[]): YogaParam[] => {
  return Object.values(partyParams).filter((pp) => {
    return defaultParams.find((dp) => dp.code == pp.code) != null;
  });
};

export const paramsToMap = (params: YogaParam[]): KeyValue<YogaParam> => {
  return params?.reduce((acc, current) => {
    acc[current.code] = current;
    return acc;
  }, {} as KeyValue<YogaParam>);
};

export const preparePartyParams = (partyParams: KeyValue<YogaParam>, defaultParams: YogaParam[]) => {
  const newVals: KeyValue<YogaParam> = (
    partyParams && Object.keys(partyParams).length > 0 ? partyParams : JSON.parse(JSON.stringify(paramsToMap(defaultParams)))
  ) as KeyValue<YogaParam>;
  const filteredParams = filterParams(newVals, defaultParams);
  return paramsToMap(filteredParams);
};

export const setDefaultParams = (params: YogaParam[]): KeyValue<YogaParam> => {
  return paramsToMap(JSON.parse(JSON.stringify(params)));
};

export const questionairesByTag = (questions: FormInputParam[]) => {
  const params = questions
    .filter((p) => p.visible)
    .sort((a, b) => (a.tags[0] > b.tags[0] ? 1 : -1))
    .sort((a, b) => a.order - b.order);

  return params.reduce((previous: { [tag: string]: FormInputParam[] }, current: FormInputParam) => {
    let tag = "noTags";
    if (current.tags && current.tags.length) {
      tag = current.tags[0];
    }
    if (!previous[tag]) {
      previous[tag] = [];
    }
    previous[tag] = previous[tag].concat(current);
    return previous;
  }, {});
};
