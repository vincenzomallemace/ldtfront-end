import classNames from "classnames";
import { Route, checkIfRoute } from "models/Route";
import { FormattedMessage } from "react-intl";
import { routes } from "routes";
import "./Stepper.css";

interface StepperProps {
  dot?: boolean;
}

export function Stepper({ dot = true }: StepperProps) {
  const current =
    routes.find((route) => checkIfRoute(window.location.pathname, route.path))
      .sequence ?? 0;

  return (
    <div className="w-full z-50 py-4">
      <div className={classNames("flex flex-row justify-center")}>
        {routes
          .filter((route) => route.sequence >= 0)
          .sort((a, b) => (a.sequence < b.sequence ? -1 : 1))
          .map((route) => (
            <RouteStep
              key={route.sequence}
              first={route.sequence === 0}
              last={
                route.sequence ===
                routes.filter((route) => route.sequence >= 0).length - 1
              }
              route={route}
              current={current}
              dot={dot}
            />
          ))}
      </div>
    </div>
  );
}

interface RouteStepProps {
  route: Route;
  current: number;
  first: boolean;
  last: boolean;
  dot?: boolean;
}

function RouteStep({ route, current, first, dot, last }: RouteStepProps) {
  const isOverpassed = route.sequence < current;
  const isCurrent = route.sequence === current;
  const isOneBefore = route.sequence === current - 1;

  function getStyle(done = isOverpassed, doing = isCurrent): string {
    if (done) return "previousStep";
    if (doing) return "currentStep";
    return "nextStep";
  }

  function getDividerStyle(position: string): string {
    if (position === "left") {
      return getStyle();
    }
    // position === right
    if (isOneBefore) return getStyle(false, true);
    if (isCurrent) return getStyle(false, false);

    return getStyle();
  }

  return (
    <div
      className={classNames(
        "flex flex-row shrink",
        !first && "grow",
        getStyle(),
        dot ? "" : "items-center"
      )}
    >
      {!first && <Divider dot={dot} bgStyle={() => getStyle()} />}
      <div className="flex flex-col items-center select-none">
        {dot && (
          <div className="flex flex-row w-full justify-between align-middle">
            <div className="flex grow basis-1/4">
              {!first && (
                <Divider
                  position="left"
                  dot={dot}
                  bgStyle={() => getDividerStyle("left")}
                />
              )}{" "}
            </div>
            <div
              className={classNames(
                "flex border-2 w-6 h-6 rounded-full text-center align-middle items-center justify-center font-semibold text-sm mb-1",
                getStyle(),
                isOverpassed && "bg-primary text-button-text"
              )}
            >
              {route.sequence + 1}
            </div>
            <div className="flex grow basis-1/4">
              {!last && (
                <Divider
                  position="right"
                  dot={dot}
                  bgStyle={() => getDividerStyle("right")}
                />
              )}
            </div>
          </div>
        )}
        <div
          className={classNames(
            "w-12 md:w-14 lg:w-20 xl:w-24",
            "align-middle tracking-tight leading-none text-center text-sm font-medium mx-2 line-clamp-3"
          )}
        >
          <FormattedMessage id={route.title ?? "titleNotSet"} />
        </div>
      </div>
    </div>
  );
}

interface DividerProps {
  position?: string;
  dot: boolean;
  bgStyle: () => string;
}

function Divider({ position, bgStyle, dot }: DividerProps) {
  return (
    <span
      className={classNames(
        !position && dot ? "middle-divider-stepper" : "middle-border-stepper",
        position ? "w-full border-t-2" : "grow border-t-2",
        position && position === "left" && "mr-2",
        position && position === "right" && "ml-2",
        bgStyle()
      )}
    />
  );
}
