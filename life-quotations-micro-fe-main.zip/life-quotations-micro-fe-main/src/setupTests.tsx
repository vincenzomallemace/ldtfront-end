import "@testing-library/jest-dom";
import { configure as configureTestingLibrary } from "@testing-library/react";
import { TextDecoder, TextEncoder } from "util";

global.TextEncoder = TextEncoder;
global.TextDecoder = TextDecoder;
// https://ui.docs.amplify.aws/react/getting-started/troubleshooting#jest
if (typeof window.URL.createObjectURL === "undefined") {
  window.URL.createObjectURL = jest.fn();
}

configureTestingLibrary({ testIdAttribute: "data-qa" });

// beforeAll(() => {
// mockAuth();
// });

global.ResizeObserver = class {
  contructor(): ResizeObserver {
    return this;
  }
  disconnect() {}
  observe() {}
  unobserve() {}
};

beforeEach(() => {
  Object.defineProperty(window, "scrollTo", {
    value: () => {},
    writable: true,
  });
});

afterEach(() => {
  //expect.hasAssertions();
});
