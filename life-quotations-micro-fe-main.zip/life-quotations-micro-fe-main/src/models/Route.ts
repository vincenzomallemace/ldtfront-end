export interface Route {
  path: string;
  component: Function;
  /** Text that will be shown in Stepper */
  title: string;
  /** Number to sort the Stepper */
  sequence: number;
}

export function checkIfRoute(url: string, path: string): boolean {
  const urlParts = (url[0] === "/" ? url.substring(1) : url).split("/");
  const pathParts = (path[0] === "/" ? path.substring(1) : path).split("/");
  // check each parts starting from the end to the beginning
  for (let i = 1; i <= pathParts.length; i++) {
    if (pathParts[pathParts.length - i].startsWith(":")) continue;
    if (urlParts[urlParts.length - i] !== pathParts[pathParts.length - i])
      return false;
  }
  return true;
}
