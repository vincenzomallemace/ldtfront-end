import { ManagementNode } from "commons/models/nodes/ManagementNode";
import { KeyValue, Money } from "commons/models/YogaModels";

export class FinancialAdvice {
  financialAdviceId: string;
  status: string;
  financialAdvisor?: string;
  endOfValidityDate?: Date;
  sharingToSuscriberDate?: Date;
  subscriberAcceptanceDate?: Date;
  contractHolder?: ContractHolder;
  subscriber?: Subscriber;
  bankAccount?: BankAccount;
  financialOffers: FinancialOffer[];
  creationInstant?: Date;
  lastUpdateInstant?: Date;
}

export class ContractHolder {
  partyId: string;
}

export class Subscriber {
  partyId?: string;
  taxId?: string;
  relationWithContractHolder: string;
}

export class BankAccount {
  iban: string;
  description: string;
  type: string;
}

export class FinancialOffer {
  financialOfferId: string;
  product?: FinancialOfferProduct;
  managementNode?: ManagementNode;
  operationValue?: Money;
  appliedDiscount?: AppliedDiscount;
  investmentLines: KeyValue<InvestmentLine>;
}

export class FinancialOfferProduct {
  code: string;
  description?: string;
  productId?: string;
  contractId?: string;
  category?: string;
  status?: "INCOMPLETE" | "DRAFT" | "VALID_PROPOSAL" | "COMPLETED_PROPOSAL" | "PROPOSAL_TO_SIGN";
}

export class AppliedDiscount {
  code: string;
}

export class InvestmentLine {
  code: string;
  description?: string;
  type?: string;
  financialAssets: FinancialAsset[];
}

export class FinancialAsset {
  code: string;
  description?: string;
  isinCode?: string;
  type: FundType;
  investmentPercentage?: number;
}

export enum FundType {
  INTERNAL = "INTERNAL",
  EXTERNAL = "EXTERNAL",
}
