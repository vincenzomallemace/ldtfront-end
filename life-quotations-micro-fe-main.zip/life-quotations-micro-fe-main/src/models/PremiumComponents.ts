import { Money } from "commons/models/YogaModels";

export interface PremiumComponents {
  uniqueOrAnnual: Premium;
  installment: Premium;
  subscriptionInstallment: Premium;
}

export interface Premium {
  dues: Money;
  managementFees: Money;
  commissionFees: Money;
  commission: Money;
  bonus: Money;
  gross: Money;
  grossBeforeDiscount: Money;
  net: Money;
  investment: Money;
  taxes: Money;
  ssn: Money;
  paymentFrequencyInterest: Money;
}
