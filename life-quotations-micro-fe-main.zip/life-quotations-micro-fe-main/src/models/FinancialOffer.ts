import { CodeAndDescription, Money } from "commons/models/YogaModels";

export class FinancialOfferRequest {
  productCode: string;
  investmentLineCode?: string = null;
  amount?: Money = null;
}

export class FinancialOffer {
  product: CodeAndDescription;
  investmentLine?: CodeAndDescription = null;
  amount?: Money = null;
}

export class FinancialOfferList {
  financialOfferListId: string;
  financialOffers: Array<FinancialOffer>;
  creationInstant: Date;
}
