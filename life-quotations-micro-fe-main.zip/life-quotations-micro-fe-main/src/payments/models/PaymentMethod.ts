import { KeyValue } from "commons/models/YogaModels";
import { YogaParam } from "commons/models/YogaParam";

export default class PaymentMethodConfig {
  code: string;
  description: string;
  type: "FUTURE" | "IMMEDIATE";
  visible: boolean;
  amountLimit?: number;
  parameters?: KeyValue<YogaParam>;
  order?: number;
}
