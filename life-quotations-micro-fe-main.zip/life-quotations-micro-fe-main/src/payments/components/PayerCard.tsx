import { UserIcon } from "@heroicons/react/outline";
import YogaCard from "commons/components/YogaCard";
import { FormikTabSwitch } from "commons/formik/FormikTabSwitch";
import { RoleType } from "contracts/enums/RoleType";
import { Contract } from "contracts/models/Contract";
import { Party } from "customers/models/Party";
import { Field } from "formik";
import { useMemo } from "react";
import { FormattedMessage } from "react-intl";

interface PayerCardProps {
  contract: Contract;
  currentPayer: Party;
  setCurrentPayer: any;
}

export default function PayerCard({
  contract,
  currentPayer,
  setCurrentPayer,
}: PayerCardProps) {
  const policyholder: Party = useMemo(() => {
    return contract.parties[RoleType.POLICYHOLDER][0];
  }, [contract]);

  const typeValues: string[] = useMemo(() => {
    let payerTypes: string[] = ["POLICYHOLDER"];
    Object.keys(contract.parties).forEach((type) => {
      if (type != RoleType.POLICYHOLDER && type != RoleType.PAYER)
        payerTypes.push(type);
    });
    return payerTypes;
  }, [policyholder]);

  function changePayer(type: string) {
    setCurrentPayer(contract.parties[type][0]);
  }

  return (
    <YogaCard
      uniformPadding
      data-qa="paying-party-card"
      className="flex flex-col gap-y-4"
    >
      <div
        data-qa="paying-party-header"
        className="flex flex-row items-center justify-between"
      >
        <span
          data-qa="paying-party-label"
          className="font-bold text-2xl text-title-text"
        >
          <FormattedMessage id="payer" />
        </span>
        <div
          data-qa="paying-party-type-section"
          className="flex flex-row items-center gap-2.5"
        >
          <span
            data-qa="paying-party-type-label"
            className="font-bold text-xl text-title-text"
          >
            <FormattedMessage id="coincidesWith" />
          </span>
          <Field
            name="payerType"
            component={FormikTabSwitch}
            content={{
              name: "payerType",
              type: "TABSWITCH",
              mandatory: true,
              availableValues: typeValues,
            }}
            onFieldChange={(field) => changePayer(field.value)}
          />
        </div>
      </div>
      {currentPayer && (
        <div
          data-qa="payer-data"
          className="flex flex-row items-center gap-x-4"
        >
          <UserIcon className="w-6 h-6 -mr-2" />
          <span data-qa={`payer-title`} className="font-bold leading-none">
            {currentPayer?.surnameOrCompanyName}&nbsp;
            {currentPayer?.name}
          </span>
          <span
            data-qa={`payer-${
              currentPayer.legalEntity ? "vatNumber" : "taxId"
            }`}
            className="text-title-text text-sm leading-none"
          >
            {currentPayer.legalEntity
              ? currentPayer.vatNumber
              : currentPayer.taxId}
          </span>
        </div>
      )}
    </YogaCard>
  );
}
