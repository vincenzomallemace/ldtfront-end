import { ArrowCircleRightIcon, SaveIcon } from "@heroicons/react/outline";
import { ReactComponent as DangerImage } from "assets/images/danger.svg";
import ErrorPage from "commons/components/ErrorPage";
import { StickyBar } from "commons/components/StickyBar";
import { YogaButton } from "commons/components/YogaButton";
import YogaCard from "commons/components/YogaCard";
import { YogaMessage } from "commons/components/YogaMessage";
import YogaSkeleton from "commons/components/YogaSkeleton";
import { config, CTX } from "commons/Configuration";
import { Context } from "commons/contexts/Context";
import { ManagementNode } from "commons/models/nodes/ManagementNode";
import { contractService } from "commons/services/ContractService";
import { partyService } from "commons/services/PartyService";
import { EMPTY } from "commons/Utils";
import { Contract } from "contracts/models/Contract";
import { Party } from "customers/models/Party";
import { getPremiumGross } from "offers/models/Product";
import { SignatureAndPaymentForm } from "payments/form/SignatureAndPaymentForm";
import useAuthorizePolicy from "payments/hooks/useAuthorizePolicy";
import useContractPayments from "payments/hooks/useContractPayments";
import useLifeProductIncompleteOnly from "payments/hooks/useLifeProductIncompleteOnly";
import { Payment } from "payments/Payment";
import useQuestionnaireHelper from "questionnaires/hooks/useQuestionnaireHelper";
import { useContext, useEffect, useState } from "react";
import { FormattedMessage, useIntl } from "react-intl";
import { formatPhoneNumberIntl } from "react-phone-number-input";
import { useNavigate, useParams } from "react-router-dom";
import { toast } from "react-toastify";
import useContractAuthorization from "./hooks/useContractAuthorization";
import useContract from "contracts/hooks/useContract";

export default function SignatureAndPaymentPage() {
  const intl = useIntl();
  const navigate = useNavigate();
  const { productId } = useParams<string>();

  const { changeLoading } = useContext(Context);
  const questionnaireHelper = useQuestionnaireHelper();

  const { contract, policyholder, setContract, contractError } = useContract(productId, true);
  const { payments, setContract: setContractForPayments } = useContractPayments();

  const { product, error: productError } = useLifeProductIncompleteOnly(productId);

  const [currentPayer, setCurrentPayer] = useState<Party>(undefined);

  const { toAuthorize, issueAuthorized, setContract: setContractForAuthorize } = useAuthorizePolicy();
  const { canAddAddendum } = useContractAuthorization();

  const [emailAlreadyUsed, setEmailAlreadyUsed] = useState<boolean>();
  const [submitError, setSubmitError] = useState(false);

  const [isReady, setIsReady] = useState(false);

  const isOtpEnabled = config.OTP_SIGN !== "disabled";
  const issuingInReservedArea = config.SEND_PAYMENT_AND_SIGN_TO_CUSTOMER_AREA === "enabled";

  useEffect(() => {
    if (contract) {
      setContractForPayments(contract);
      setContractForAuthorize(contract);

      showErrors();
    }
  }, [contract]);

  useEffect(() => {
    setIsReady(contract != undefined && product != undefined && policyholder != undefined && payments != undefined);
  }, [contract, product, policyholder, payments]);

  const showErrors = () => {
    if (contract) {
      let errorId = "";
      if (contract.messages["errors"] && contract.messages["errors"].length > 0) {
        errorId = "contract.errors";
      }
      if (errorId !== "") {
        document.getElementById(errorId)?.scrollIntoView({ behavior: "smooth", block: "center" });
      }
    }
  };

  useEffect(() => {
    if (emailAlreadyUsed) {
      const element = document.getElementById("emailAlreadyUsed");
      if (element) {
        element.scrollIntoView({ behavior: "smooth", block: "center" });
      }
    }
  }, [emailAlreadyUsed]);

  const onSubmit = async (values: any, formParty?: Party) => {
    changeLoading(1);
    setSubmitError(false);
    if (issuingInReservedArea && !toAuthorize && values.completeIssueInCustomerArea) {
      try {
        const party = (await partyService.getPartyByUsername(values.reservedAreaEmail)).data;
        if (party.profile && party.partyId != policyholder.partyId) {
          setEmailAlreadyUsed(true);
        } else {
          nextPage(values, formParty);
        }
      } catch (e: any) {
        if (e.response.status == 404) {
          nextPage(values, formParty);
        } else {
          console.error(e);
        }
      }
    } else {
      nextPage(values, formParty);
    }
    changeLoading(-1);
  };

  const nextPage = async (values: any, formParty?: Party) => {
    const flags = {
      completeIssueInCustomerArea: values.completeIssueInCustomerArea,
      substates: {
        signCompleted: !isOtpEnabled || (values.otpSignature && !values.otpSignature.policyholderOtpSignatureEnabled),
      },
    };

    let updatedContract = contract;
    updatedContract = (await contractService.updateContractFlags(contract.contractId, flags)).data as Contract;

    if (canAddAddendum && values.addendum) {
      updatedContract = (await contractService.updateContractAddendum(contract.contractId, values.addendum)).data as Contract;
    }

    let errorMessages: string[] = [];
    if (contract.completeIssueInCustomerArea || isOtpEnabled) {
      [updatedContract, errorMessages] = await savePolicyHolder(values.otpSignature, values.reservedAreaEmail, formParty);
    }

    if (updatedContract == undefined && errorMessages == undefined) {
      setSubmitError(true);
    } else if (updatedContract && errorMessages?.length === 0) {
      await contractService.addPayer(contract.contractId, contract.parties[values.payerType][0]);
      await confirm(updatedContract, values);
    } else {
      showErrors();
    }
  };

  const confirm = async (contract: Contract, values: any) => {
    changeLoading(1);
    try {
      if (toAuthorize) {
        const response = await contractService.authorizationRequest(contract.contractId as string);
        navigate(`${CTX}/customers/${policyholder.partyId}/authorizationContracts/${response.data.contractId}`);
        toast.success(intl.formatMessage({ id: "contractSentToAuthorization" }), { className: "bg-success" });
      } else if (contract.contractStatus === "AUTHORIZED") {
        await issueAuthorized();
        navigate(`${CTX}/offers/${contract.quotationId}/summary`);
      } else {
        await savePayment(values.paymentMethod, contract["operation"]?.operationId);

        const hasDueDiligence = await questionnaireHelper.checkHasDueDiligence(policyholder, product, contract);

        if (hasDueDiligence) {
          const questionnaire = await questionnaireHelper.createDueDiligence(policyholder, product, contract);
          navigate(`${CTX}/offers/${contract.contractId}/dueDiligence/${questionnaire.questionnaireId}`);
        } else {
          navigate(`${CTX}/offers/${contract.contractId}/summary`);
        }
      }
    } catch (e: any) {
      setSubmitError(true);
      console.error(e);
    } finally {
      changeLoading(-1);
    }
  };

  const updateContractWithToggle = async (hasAddendum: boolean) => {
    changeLoading(1);
    contract.hasAddendum = hasAddendum;
    try {
      const response = await contractService.updateContractAddendum(contract.contractId, {
        hasAddendum: contract.hasAddendum,
        adddendum: contract.addendum,
      });
      setContract(response.data);
    } finally {
      changeLoading(-1);
    }
  };

  const mergeParty = (formParty?: Party, previousParty?: Party): Party => {
    let res = formParty;
    if (previousParty) {
      res = { ...previousParty, ...(formParty || {}) };
    }
    return res;
  };

  async function savePolicyHolder(otpSignature, reservedEmail, formParty?: Party): Promise<[Contract, string[]]> {
    const policyHolder = policyholder;
    policyHolder.partyId = policyholder.partyId;
    let updateNodes: ManagementNode[] = policyholder.managementNodes ? policyholder.managementNodes : [];
    if (updateNodes.filter((node) => node?.code === contract.managementNode.code).length === 0) {
      updateNodes.push(contract.managementNode);
    }
    policyHolder.managementNodes = updateNodes;

    if (isOtpEnabled) {
      policyHolder.otpSignatureEnabled = otpSignature.policyholderOtpSignatureEnabled;
      if (policyHolder.otpSignatureEnabled && policyHolder.legalEntity === false) {
        const prefix = formatPhoneNumberIntl(otpSignature.mobilePhoneNumber).split(" ")[0];
        policyHolder.mobilePhoneNumber = otpSignature.mobilePhoneNumber.replace(prefix, "");
        policyHolder.mobilePhoneNumberPrefix = prefix.replace("+", "00");
        policyHolder.email = otpSignature.email;
        if (policyHolder.profile) {
          policyHolder.profile.email = otpSignature.email;
        }
      }

      if (policyHolder.legalEntity && policyHolder.companyType !== "Ditta Individuale" && otpSignature.policyholderOtpSignatureEnabled) {
        const party = (await partyService.getPartyByTaxId(otpSignature.partyId, false)).data;
        policyHolder.linkedParties = {
          "LEGAL-REPRESENTATIVE": [mergeParty(formParty, party)],
        };
      }
      if (
        (config.INDIVIDUAL_COMPANY_REFERENT === "enabled" &&
          policyHolder.legalEntity &&
          policyHolder.companyType === "Ditta Individuale" &&
          !policyHolder.otpSignatureEnabled) ||
        (policyHolder.legalEntity && policyHolder.companyType === "Ditta Individuale" && policyHolder.otpSignatureEnabled)
      ) {
        const party = (await partyService.getPartyByTaxId(otpSignature.partyId, false)).data;
        policyHolder.linkedParties = {
          REFERENT: [mergeParty(formParty, party)],
        };
      }
    }
    if (contract.completeIssueInCustomerArea && !policyHolder.profile) {
      policyHolder.email = reservedEmail;
    }
    const result = await contractService.addPolicyHolder(contract?.contractId as string, policyHolder);

    if (result.data) {
      const resultContract = result.data;

      setContract(resultContract);
      if (resultContract && resultContract.messages["errors"] && resultContract.messages["errors"].length) {
        return [resultContract, resultContract.messages["errors"]];
      } else {
        return [resultContract, []];
      }
    } else {
      return [undefined, undefined];
    }
  }

  async function savePayment(paymentMethod, operationId?: string) {
    if (toAuthorize) {
      return;
    }
    const payment: Payment = {
      paymentId: paymentMethod.paymentId,
      contractId: contract?.contractId as string,
      paymentMethod: paymentMethod.type,
      policyholderId: policyholder?.partyId ?? "",
      effectInstant: product?.effectiveDateInstant,
      expirationInstant: product?.subscriptionInstallmentExpirationDate,
      amount: getPremiumGross(product),
      paymentData: getPaymentData(paymentMethod),
      operationId: operationId,
    };
    if (payments.length > 0) {
      await contractService.updatePayment(payment);
    } else {
      await contractService.createPayment(payment);
    }
  }

  function getPaymentData(paymentMethod) {
    let data = {
      ...paymentMethod.paymentData,
    };

    return data;
  }

  async function saveDraft() {
    changeLoading(1);

    const currentPayerType = Object.keys(contract.parties).find((type) => contract.parties[type][0].partyId == currentPayer.partyId);

    await contractService.addPayer(contract.contractId, contract.parties[currentPayerType][0]);
    contractService
      .updateContractDraft(contract.contractId, contract)
      .then((response) => {
        setContract(response.data);
        toast.success(
          intl.formatMessage(
            {
              id: "proposalDrafted",
            },
            { number: response.data.quotationNumber }
          )
        );
      })
      .catch((e) => {
        console.error(e);
        toast.error(
          intl.formatMessage(
            {
              id: "proposalDraftedErrorWithNumber",
            },
            { number: contract.quotationNumber }
          )
        );
      })
      .finally(() => changeLoading(-1));
  }

  return (
    <>
      {contractError || productError ? (
        <ErrorPage></ErrorPage>
      ) : (
        <>
          {isReady && (
            <>
              <StickyBar
                //backFunction={() => saveDraft()}
                breadcrumb={
                  <>
                    <div className="flex flex-col truncate" data-qa="signatureAndPayment-title">
                      {toAuthorize ? (
                        <div className="truncate">
                          <FormattedMessage id="authorizationRequest" />
                        </div>
                      ) : (
                        <div className="truncate">
                          {config.OTP_SIGN !== "disabled" ? <FormattedMessage id="signatureAndPayment" /> : <FormattedMessage id="payment" />}
                        </div>
                      )}
                      <div className="inline-flex flex-wrap gap-x-4 items-center" data-qa="extra-info">
                        {/*contract.quotationNumber && (
                          <span
                            className="text-base font-normal truncate"
                            data-qa="product-quotationNumber"
                          >
                            N. {contract.quotationNumber}
                          </span>
                        )*/}
                        <span className="text-base font-normal truncate" data-qa="policyholder-title">
                          {policyholder?.surnameOrCompanyName}&nbsp;
                          {policyholder?.name}
                        </span>
                        <span className="text-base font-normal truncate" data-qa="product-description">
                          {contract.contractProductName}
                        </span>
                      </div>
                    </div>
                  </>
                }
              >
                <div className="self-end text-right flex-1 flex gap-x-4">
                  {config.SAVE_DRAFT_LIFE_PROPOSAL && (
                    <YogaButton
                      kind="default"
                      type="button"
                      outline
                      className="flex gap-2 items-center"
                      data-qa="save-draft-button"
                      action={() => saveDraft()}
                    >
                      <SaveIcon className="w-5 -ml-1 shrink-0" />
                      <FormattedMessage id="saveDraft" />
                    </YogaButton>
                  )}
                  {toAuthorize !== undefined ? (
                    <>
                      {toAuthorize ? (
                        <YogaButton kind="default" data-qa="authorize-button" type="submit" form="signatureAndPayment">
                          <ArrowCircleRightIcon className="w-5 mr-2 -ml-1" />
                          <FormattedMessage id="askForPermission" />
                        </YogaButton>
                      ) : (
                        <YogaButton
                          kind="default"
                          form="signatureAndPayment"
                          type="submit"
                          data-qa="continue-button"
                          className="flex items-center gap-x-2"
                          //action={() => saveDraft()}
                        >
                          <ArrowCircleRightIcon className="w-5 h-5" />
                          <div className="hidden lg:block">
                            <FormattedMessage id="continue" />
                          </div>
                        </YogaButton>
                      )}
                    </>
                  ) : (
                    <div className="w-32">
                      <YogaSkeleton className="h-10" position="outer" style={{ borderRadius: "32px" }} />
                    </div>
                  )}
                </div>
              </StickyBar>

              <div className="px-3">
                {!toAuthorize ? (
                  <>
                    {((contract.messages["errors"] && contract.messages["errors"].length > 0) ||
                      (contract.messages["danger"] && contract.messages["danger"].length > 0) ||
                      submitError) && (
                      <div className="flex flex-col gap-y-4 mb-4">
                        {submitError && (
                          <YogaMessage type="error" position="outer">
                            <p data-qa="submit-error">
                              {intl.formatMessage({
                                id: toAuthorize ? "submitAuthorizationError" : "submitIssueError",
                              })}
                            </p>
                          </YogaMessage>
                        )}
                        {contract.messages["errors"] && contract.messages["errors"].length > 0 && (
                          <div id="contract.errors" data-qa="contract.errors">
                            {contract.messages["errors"].map((message, index) => {
                              return (
                                <YogaMessage type="error" position="outer" key={index}>
                                  <p data-qa={message}>
                                    {intl.formatMessage({
                                      id: message || EMPTY,
                                    })}
                                  </p>
                                </YogaMessage>
                              );
                            })}
                          </div>
                        )}
                        {contract.messages["danger"] && contract.messages["danger"].length > 0 && (
                          <div id="contract.danger" data-qa="contract.danger">
                            {contract.messages["danger"].map((message, index) => {
                              return (
                                <YogaMessage type="danger" position="outer" key={index}>
                                  <p data-qa={message}>
                                    {intl.formatMessage({
                                      id: message || EMPTY,
                                    })}
                                  </p>
                                </YogaMessage>
                              );
                            })}
                          </div>
                        )}
                      </div>
                    )}
                  </>
                ) : (
                  <div className="flex flex-col gap-y-4 mb-4">
                    {(contract.messages?.errors || submitError) && (
                      <div data-qa="error-messages-container">
                        {submitError && (
                          <YogaMessage type="error" position="outer">
                            <FormattedMessage data-qa="submit-error" id="submitAuthorizationError" />
                          </YogaMessage>
                        )}
                        {contract.messages?.errors?.map((message, index) => (
                          <YogaMessage type="error" position="outer" key={index}>
                            <p data-qa={message}>
                              {intl.formatMessage({
                                id: message || EMPTY,
                              })}
                            </p>
                          </YogaMessage>
                        ))}
                      </div>
                    )}

                    <YogaCard uniformPadding className="lg:pr-8" data-qa="contract.danger">
                      <div className="flex flex-col-reverse lg:flex-row w-full gap-8 lg:items-center">
                        <div className="flex flex-col gap-4 flex-1">
                          <p data-qa="authorizationInfoMessage" className="text-base font-bold text-body-text">
                            <FormattedMessage id="authorizationInfoMessage" />
                          </p>
                          {contract.messages?.danger && (
                            <div className="flex flex-col gap-2">
                              {contract.messages?.danger?.map((message, index) => (
                                <p data-qa={message} className="text-base font-medium text-body-text" key={index}>
                                  <FormattedMessage id={message || EMPTY} />
                                </p>
                              ))}
                            </div>
                          )}
                        </div>
                        <DangerImage className="mx-auto" />
                      </div>
                    </YogaCard>
                  </div>
                )}

                <SignatureAndPaymentForm
                  contract={contract}
                  policyholder={policyholder}
                  premium={{
                    total: contract?.contractPremium,
                    toPay: getPremiumGross(product),
                  }}
                  customerArea={{
                    enabled: true,
                    emailAlreadyUsed: emailAlreadyUsed,
                    setEmailAlreadyUsed: setEmailAlreadyUsed,
                  }}
                  payment={{
                    current: payments.length > 0 ? payments[0] : null,
                  }}
                  onSubmit={onSubmit}
                  addendum={{
                    enabled: true,
                    update: updateContractWithToggle,
                  }}
                  currentPayer={currentPayer}
                  setCurrentPayer={setCurrentPayer}
                />
              </div>
            </>
          )}
        </>
      )}
    </>
  );
}
