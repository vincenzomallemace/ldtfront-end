import axios from "axios";
import { getApiContext } from "commons/Configuration";
import PaymentMethodConfig from "payments/models/PaymentMethod";
import { AxiosResponse } from "axios/index";
import { Party } from "customers/models/Party";

const api = `${getApiContext()}/v1/payments/methods`;

export const paymentMethodsService = {
  getByProductCode: (
    productCode: string
  ): Promise<AxiosResponse<PaymentMethodConfig[]>> =>
    axios.get(`${api}/product/${productCode}`),

  getByProductCodeAndContractId: (
    productCode: string,
    contractId: string
  ): Promise<AxiosResponse<PaymentMethodConfig[]>> =>
    axios.get(`${api}/product/${productCode}/contract/${contractId}`),

  updateParameters: (
    contractId: string,
    paymentMethod: PaymentMethodConfig,
    payer: Party
  ): Promise<AxiosResponse<PaymentMethodConfig>> =>
    axios.put(`${api}/contract/${contractId}`, { paymentMethod, payer }),
};
