import { RadioGroup } from "@headlessui/react";
import classnames from "classnames";
import { config } from "commons/Configuration";
import { EMPTY } from "commons/Utils";
import { YogaMessage } from "commons/components/YogaMessage";
import { FormikInput } from "commons/formik/FormikInput";
import { Money } from "commons/models/YogaModels";
import { BankAccount } from "customers/models/BankAccount";
import { Field, FieldProps } from "formik";
import { PaymentMethodEnum, getPaymentMethods } from "payments/Payment";
import React, { useEffect, useState } from "react";
import { FormattedMessage, FormattedNumber } from "react-intl";

export function SDDPaymentDataForm({
  field: { name, value },
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  form: { getFieldHelpers },
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  ...props
}: FieldProps) {
  function stripSpaces(event) {
    const helpers = getFieldHelpers(`${name}.iban`);
    const strip = (event.target.value as string).replaceAll(" ", "");
    helpers.setTouched(true);
    helpers.setValue(strip, true);
  }

  return (
    <div
      className="mt-4 border-2 border-background rounded-lg p-4 flex flex-col"
      data-qa="SDD-form"
    >
      <div className="grid grid-cols-2 lg:grid-cols-3 gap-8">
        <div className="col-span-2 lg:col-span-3">
          <Field
            key={`${name}.iban`}
            name={`${name}.iban`}
            component={FormikInput}
            onBlur={stripSpaces}
            content={{
              name: `${name}.iban`,
              value: value?.iban,
              mandatory: true,
              label: "iban",
              type: "STRING",
            }}
          />
        </div>
      </div>
      <div className="mt-4">
        <div className="inline-flex w-full items-center">
          <span className="text-title-text font-bold">
            <FormattedMessage id="accountOwner" />
          </span>
          <span className="ml-[10px] flex-1 h-[2px] bg-background"></span>
        </div>
        <div className="grid grid-cols-2 lg:grid-cols-3 w-full gap-x-8 gap-y-4 items-center mt-2">
          <Field
            key={`${name}.ownerName`}
            name={`${name}.ownerName`}
            component={FormikInput}
            content={{
              name: `${name}.ownerName`,
              value: value?.ownerName,
              mandatory: true,
              label: "name",
              type: "STRING",
            }}
          />
          <Field
            key={`${name}.ownerTaxId`}
            name={`${name}.ownerTaxId`}
            component={FormikInput}
            content={{
              name: `${name}.ownerTaxId`,
              value: value?.ownerTaxId,
              mandatory: true,
              label: "taxId",
              type: "STRING",
            }}
          />
          <Field
            key={`${name}.ownerAddress`}
            name={`${name}.ownerAddress`}
            component={FormikInput}
            content={{
              name: `${name}.ownerAddress`,
              value: value?.ownerAddress,
              mandatory: true,
              label: "address",
              type: "STRING",
            }}
          />
        </div>
      </div>
      <div className="mt-4">
        <div className="inline-flex w-full items-center">
          <span className="text-title-text font-bold">
            <FormattedMessage id="subscriber" />
          </span>
          <span className="ml-[10px] flex-1 h-[2px] bg-background"></span>
        </div>
        <div className="grid grid-cols-2 lg:grid-cols-3 w-full gap-8 items-center mt-2">
          <Field
            key={`${name}.subscriberName`}
            name={`${name}.subscriberName`}
            component={FormikInput}
            content={{
              name: `${name}.subscriberName`,
              value: value?.subscriberName,
              mandatory: true,
              label: "name",
              type: "STRING",
            }}
          />
          <Field
            key={`${name}.subscriberTaxId`}
            name={`${name}.subscriberTaxId`}
            component={FormikInput}
            content={{
              name: `${name}.subscriberTaxId`,
              value: value?.subscriberTaxId,
              mandatory: true,
              label: "taxId",
              type: "STRING",
            }}
          />
          <div className="hidden lg:block flex-1 w-0"></div>
        </div>
      </div>
    </div>
  );
}

export function AccountDebitPaymentDataForm({
  field: { name, value },
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  form: { getFieldHelpers, setFieldValue },
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  ...props
}: FieldProps) {
  const bankAccounts = (props as any).bankAccounts as BankAccount[];

  useEffect(() => {
    if (bankAccounts) {
      bankAccounts?.length === 1 &&
        setFieldValue(`${name}.iban`, bankAccounts[0].iban);
    }
  }, [bankAccounts]);

  return (
    <div
      className="mt-4 border-2 border-background rounded-lg p-4 flex flex-col"
      data-qa="account-debit-form"
    >
      {bankAccounts && bankAccounts.length > 0 ? (
        <Field
          key={`${name}.iban`}
          name={`${name}.iban`}
          component={FormikInput}
          content={{
            name: `${name}.iban`,
            value: value?.iban,
            mandatory: true,
            type: "RADIO",
            options: bankAccounts.map((account) => {
              return {
                subvalue: account.description,
                value: account.iban,
                key: account.iban,
              };
            }),
          }}
        />
      ) : (
        <div className="w-1/2">
          <Field
            key={`${name}.iban`}
            name={`${name}.iban`}
            component={FormikInput}
            content={{
              name: `${name}.iban`,
              value: "",
              mandatory: true,
              label: "iban",
              type: "STRING",
            }}
          />
        </div>
      )}
    </div>
  );
}

export function CheckPaymentDataForm({
  field: { name, value },
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  form: { getFieldHelpers },
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  ...props
}: FieldProps) {
  function stripSpaces(event) {
    const helpers = getFieldHelpers(`${name}.checkNumber`);
    const strip = (event.target.value as string).replaceAll(" ", "");
    helpers.setTouched(true);
    helpers.setValue(strip, true);
  }

  return (
    <div
      className="mt-4 border-2 border-background rounded-lg p-4 flex flex-col"
      data-qa="CHECK-form"
    >
      <div className="grid grid-cols-2 lg:grid-cols-3 gap-8">
        <Field
          key={`${name}.checkNumber`}
          name={`${name}.checkNumber`}
          component={FormikInput}
          onBlur={stripSpaces}
          content={{
            name: `${name}.checkNumber`,
            value: value?.checkNumber,
            mandatory: true,
            label: "checkNumber",
            type: "STRING",
          }}
        />
      </div>
    </div>
  );
}

export default function PaymentMethodForm({
  field,
  form: { getFieldMeta, setFieldValue },
  ...props
}: FieldProps) {
  const contractBranch = (props as any).contractBranch as string;
  const premiumToPay = (props as any).premiumToPay as Money;
  const totalPremium = (props as any).totalPremium as Money;
  const shouldEndInCustomerArea = (props as any)
    .shouldEndInCustomerArea as Money;
  const availablePaymentMethods = (props as any)
    .availablePaymentMethods as string[];
  const bankAccounts = (props as any).bankAccounts as BankAccount[];

  const isOtpEnabled = false; // Forced to false
  //config.OTP_SIGN !== "disabled";
  const issuingInReservedArea = false; // Forced to false
  //config.SEND_PAYMENT_AND_SIGN_TO_CUSTOMER_AREA === "enabled";

  const [methods, setMethods] = useState(
    getPaymentMethods(availablePaymentMethods)
  );

  const [type, setType] = useState<string>();

  useEffect(() => {
    setType(field.value?.type);
  }, [field.value]);

  useEffect(() => {
    if (methods && methods.length == 1) {
      setType(methods[0].method);
      setFieldValue(`${field.name}.type`, methods[0].method, true);
      if (
        methods[0].method === PaymentMethodEnum.ACCOUNT_DEBIT &&
        bankAccounts &&
        bankAccounts.length === 1
      ) {
        setFieldValue(
          `${field.name}.paymentData.iban`,
          bankAccounts[0].iban,
          true
        );
      }
    }
  }, [methods]);

  useEffect(() => {
    const filtered = shouldEndInCustomerArea
      ? getPaymentMethods(availablePaymentMethods)
      : getPaymentMethods(availablePaymentMethods).filter(
          (payment) => payment.method !== PaymentMethodEnum.EXTERNAL_PROVIDER
        );
    setMethods(filtered);
    if (type && !filtered.map((e) => e.method as string).includes(type)) {
      updateType("");
    }
  }, [shouldEndInCustomerArea]);

  function updateType(value: string) {
    setType(value);
    setFieldValue(`${field.name}.type`, value, true);
    if (value != PaymentMethodEnum.ACCOUNT_DEBIT) {
      setFieldValue(`${field.name}.paymentData.iban`, undefined, false);
    }
  }

  function displayPaymentDataForm() {
    switch (type) {
      case PaymentMethodEnum.SDD:
        return (
          <Field
            name={`${field.name}.paymentData`}
            component={SDDPaymentDataForm}
          />
        );
      case PaymentMethodEnum.CHECK:
        return (
          <Field
            name={`${field.name}.paymentData`}
            component={CheckPaymentDataForm}
          />
        );
      case PaymentMethodEnum.ACCOUNT_DEBIT:
        return (
          <Field
            name={`${field.name}.paymentData`}
            component={AccountDebitPaymentDataForm}
            bankAccounts={bankAccounts}
          />
        );
      default:
        return <></>;
    }
  }

  return (
    <div
      className={isOtpEnabled || issuingInReservedArea ? "mt-4" : ""}
      data-qa="paymentMethods"
    >
      <div className="flex flex-col">
        <div className="flex justify-between items-center mb-4">
          <h4
            className="text-title-text text-2xl"
            data-qa="paymentMethods-title"
          >
            {premiumToPay.amount > 0 ? (
              <FormattedMessage id="paymentMethod" />
            ) : (
              <FormattedMessage id="paymentMethodRefund" />
            )}
          </h4>
        </div>
        {getFieldMeta(field.name).touched &&
          getFieldMeta(`${field.name}.type`).error && (
            <YogaMessage type="error" position="inner" className="mb-2">
              {getFieldMeta(`${field.name}.type`).error}
            </YogaMessage>
          )}

        <div className="lg:flex">
          <div
            id={`${field.name}.type`}
            data-qa="paymentMethods"
            className={classnames(
              "flex flex-col border-2 border-background rounded-lg p-4 gap-2 w-full"
            )}
          >
            <RadioGroup
              value={type}
              onChange={updateType}
              className="flex flex-col gap-4"
            >
              <div
                className={classnames("grid grid-cols-1 gap-x-4 gap-y-4", {
                  "lg:grid-cols-2": methods?.length > 1,
                })}
              >
                {methods.map(({ icon, method }) => (
                  <RadioGroup.Option
                    data-qa={"payment-method-" + method}
                    disabled={
                      method === PaymentMethodEnum.CASH &&
                      ((contractBranch === "MOTOR" &&
                        config.MOTOR_CASH_LIMITS != null &&
                        totalPremium.amount > config.MOTOR_CASH_LIMITS) ||
                        (contractBranch === "NO_MOTOR" &&
                          config.NO_MOTOR_CASH_LIMITS != null &&
                          totalPremium.amount > config.NO_MOTOR_CASH_LIMITS) ||
                        (contractBranch === "LIFE" &&
                          config.LIFE_CASH_LIMITS != null &&
                          totalPremium.amount > config.LIFE_CASH_LIMITS))
                    }
                    key={method}
                    value={method}
                    className={({ checked, disabled }) =>
                      `lg:mt-0 font-bold cursor-pointer w-full border-2 rounded-lg px-4 inline-flex items-center ${
                        checked
                          ? "text-white bg-primary border-primary py-4"
                          : disabled
                          ? "cursor-not-allowed bg-background-disabled border-action-disabled text-action-disabled py-2"
                          : "bg-box-background border-primary py-4"
                      }`
                    }
                  >
                    {React.createElement(icon, {
                      className: "w-6 h-6 mr-2 flex-shrink-0",
                    })}
                    <div data-qa="payment-method-content">
                      <p data-qa="payment-method-name">
                        <FormattedMessage id={method || EMPTY} />
                      </p>

                      {method === PaymentMethodEnum.CASH &&
                        contractBranch === "MOTOR" &&
                        config.MOTOR_CASH_LIMITS != null &&
                        totalPremium.amount > config.MOTOR_CASH_LIMITS && (
                          <p
                            className="text-xs uppercase"
                            data-qa="payment-method-message"
                          >
                            {config.MOTOR_CASH_LIMITS > 0 ? (
                              <>
                                <FormattedMessage id={"cashLimit"} />{" "}
                                <FormattedNumber
                                  value={config.MOTOR_CASH_LIMITS}
                                  style="currency"
                                  currency={totalPremium.currency}
                                />
                              </>
                            ) : (
                              <>
                                <FormattedMessage id={"cashLimitZero"} />
                              </>
                            )}
                          </p>
                        )}

                      {method === PaymentMethodEnum.CASH &&
                        contractBranch === "NO_MOTOR" &&
                        config.NO_MOTOR_CASH_LIMITS != null &&
                        totalPremium.amount > config.NO_MOTOR_CASH_LIMITS && (
                          <p
                            className="text-xs uppercase"
                            data-qa="payment-method-message"
                          >
                            {config.NO_MOTOR_CASH_LIMITS > 0 ? (
                              <>
                                <FormattedMessage id={"cashLimit"} />{" "}
                                <FormattedNumber
                                  value={config.NO_MOTOR_CASH_LIMITS}
                                  style="currency"
                                  currency={totalPremium.currency}
                                />
                              </>
                            ) : (
                              <>
                                <FormattedMessage id={"cashLimitZero"} />
                              </>
                            )}
                          </p>
                        )}

                      {method === PaymentMethodEnum.CASH &&
                        contractBranch === "LIFE" &&
                        config.LIFE_CASH_LIMITS != null &&
                        totalPremium.amount > config.LIFE_CASH_LIMITS && (
                          <p
                            className="text-xs uppercase"
                            data-qa="payment-method-message"
                          >
                            {config.LIFE_CASH_LIMITS > 0 ? (
                              <>
                                <FormattedMessage id={"cashLimit"} />{" "}
                                <FormattedNumber
                                  value={config.LIFE_CASH_LIMITS}
                                  style="currency"
                                  currency={totalPremium.currency}
                                />
                              </>
                            ) : (
                              <>
                                <FormattedMessage id={"cashLimitZero"} />
                              </>
                            )}
                          </p>
                        )}
                    </div>
                  </RadioGroup.Option>
                ))}
              </div>
            </RadioGroup>
          </div>
        </div>

        {displayPaymentDataForm()}
      </div>
    </div>
  );
}
