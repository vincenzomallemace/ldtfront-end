import classNames from "classnames";
import { config } from "commons/Configuration";
import { geoValidationError, transformObjectToDotNotation } from "commons/FormUtils";
import YogaCard from "commons/components/YogaCard";
import { YogaMessage } from "commons/components/YogaMessage";
import { UserContext } from "commons/contexts/UserProvider";
import { FormikInputCheck } from "commons/formik/FormikInputCheck";
import { FormikInputText } from "commons/formik/FormikInputText";
import { FormikInputTextArea } from "commons/formik/FormikInputTextArea";
import { FormikToggleSwitch } from "commons/formik/FormikToggleSwitch";
import useScrollIntoView from "commons/hooks/useScrollIntoView";
import { mandatoryLocationParams } from "commons/models/Suggestion";
import { KeyValue, Money } from "commons/models/YogaModels";
import { ManagementNode } from "commons/models/nodes/ManagementNode";
import { partyService } from "commons/services/PartyService";
import { RoleType } from "contracts/enums/RoleType";
import { Contract, STATUS } from "contracts/models/Contract";
import { BankAccount } from "customers/models/BankAccount";
import { Party } from "customers/models/Party";
import { Field, Form, Formik, FormikProps, useFormikContext } from "formik";
import { isValidIBAN } from "ibantools";
import { OtpSignatureForm } from "offers/forms/OtpSignatureForm";
import useFinancialAdvice from "offers/hooks/useFinancialAdvice";
import { Payment, PaymentMethodEnum } from "payments/Payment";
import PayerCard from "payments/components/PayerCard";
import useContractAuthorization from "payments/hooks/useContractAuthorization";
import usePaymentMethods from "payments/hooks/usePaymentMethods";
import { useContext, useEffect, useRef, useState } from "react";
import { FormattedMessage, useIntl } from "react-intl";
import { formatPhoneNumberIntl, isValidPhoneNumber } from "react-phone-number-input";
import * as Yup from "yup";
import PaymentMethodFormV2 from "./PaymentMethodFormV2";

interface SignatureAndPaymentFormParams {
  contract: Contract;
  policyholder: Party;
  customerArea: {
    enabled: boolean;
    emailAlreadyUsed?: boolean;
    setEmailAlreadyUsed?: (v: boolean) => void;
  };
  premium: {
    total: Money;
    toPay: Money;
  };
  payment: {
    current: Payment;
  };
  addendum: {
    enabled: boolean;
    update?: (b: boolean) => void;
  };
  currentPayer: Party;
  setCurrentPayer: (p: Party) => void;
  onSubmit: (values: any, party?: Party) => void | Promise<any>;
}

const ScrollToFieldError = ({ reset = () => {} }: { reset: () => void }) => {
  const { submitCount, isValid, errors, validateForm } = useFormikContext();

  useEffect(() => {
    reset();
    validateForm();
    if (isValid) return;
    const fieldNames = transformObjectToDotNotation(errors);
    const contractErrorElement = document.getElementById("contract.errors");
    const element = document.getElementById(fieldNames[0]);
    if (contractErrorElement) {
      contractErrorElement.scrollIntoView({
        behavior: "smooth",
        block: "center",
      });
    } else if (element) {
      element.scrollIntoView({ behavior: "smooth", block: "center" });
    }

    // Formik doesn't (yet) provide a callback for a client-failed submission,
    // thus why this is implemented through a hook that listens to changes on
    // the submit count.
  }, [submitCount]);

  return null;
};

export function SignatureAndPaymentForm({
  contract,
  policyholder,
  premium,
  customerArea: { emailAlreadyUsed, setEmailAlreadyUsed },
  payment: { current: lastPayment },
  addendum: { enabled: showAddendum, update: updateOnAddendum },
  onSubmit,
  currentPayer,
  setCurrentPayer,
}: SignatureAndPaymentFormParams) {
  const intl = useIntl();
  const { canAddAddendum } = useContractAuthorization();

  const { paymentMethods, updatePaymentMethodParams } = usePaymentMethods(contract.productCode, contract.contractId);

  const { financialAdvice } = useFinancialAdvice(contract.quotationId, true);
  const [financialAdviceBankAccount, setFinancialAdviceBankAccount] = useState<BankAccount[]>(undefined);

  useEffect(() => {
    if (financialAdvice) {
      if (financialAdvice?.bankAccount) {
        setFinancialAdviceBankAccount([financialAdvice.bankAccount]);
      } else setFinancialAdviceBankAccount([]);
    }
  }, [financialAdvice]);

  const { user } = useContext(UserContext);

  const requiredMessage = intl.formatMessage({ id: "required" });
  const requiredGeo = geoValidationError(intl);
  const lengthMessage = intl.formatMessage({ id: "lengthError" }, { number: "16" });
  const selectIban = intl.formatMessage({ id: "selectIban" });
  const selectLocationMessage = intl.formatMessage({ id: "selectLocation" });
  const selectPaymentMethodMessage = intl.formatMessage({
    id: "selectPaymentMethod",
  });
  const invalidPhoneMessage = intl.formatMessage({ id: "invalidPhoneNumber" });
  const [initialValues, setInitialValues] = useState<Object>();
  const [validationSchema, setValidationSchema] = useState({});
  const [taxIdConsistent, setTaxIdConsistent] = useState(true);
  const [isAnUpdate, setIsAnUpdate] = useState(false);
  const [shouldEndInCustomerArea, setShouldEndInCustomerArea] = useState(contract?.completeIssueInCustomerArea);
  const [availableBankAccounts, setAvailableBankAccounts] = useState<BankAccount[]>(undefined);
  const [initialPaymentData, setInitialPaymentData] = useState<KeyValue<string>>(undefined);

  const formRef = useRef<FormikProps<any>>(null);

  const isOtpEnabled = config.OTP_SIGN !== "disabled";

  const isIndividualCompanyReferent = config.INDIVIDUAL_COMPANY_REFERENT === "enabled";
  const issuingInReservedArea = false; // Forced to false
  /*showCustomerArea &&
  config.SEND_PAYMENT_AND_SIGN_TO_CUSTOMER_AREA === "enabled";*/

  const { scroll } = useScrollIntoView({ id: "taxIdInconsistent" });
  const reset = () => {
    setTaxIdConsistent(true);
  };

  useEffect(() => {
    if (!shouldEndInCustomerArea && setEmailAlreadyUsed) {
      setEmailAlreadyUsed(false);
    }
  }, [shouldEndInCustomerArea]);

  async function handleSubmit(values: any) {
    if (
      (isOtpEnabled && policyholder.legalEntity && values.otpSignature.policyholderOtpSignatureEnabled) ||
      (isIndividualCompanyReferent &&
        policyholder.legalEntity &&
        (policyholder.companyType === "Ditta Individuale" || policyholder.companyType === "Impresa familiare") &&
        !values.otpSignature.policyholderOtpSignatureEnabled)
    ) {
      const party = Object.assign(
        {},
        { ...values.otpSignature },
        {
          birthCountyCode: values.otpSignature.birthPlaceComplete && values.otpSignature.birthPlaceComplete.countyCode,
          birthPlace: values.otpSignature.birthPlaceComplete && values.otpSignature.birthPlaceComplete.name,
        }
      );
      let validLocation = true;
      if (party.locationComplete?.country === "Italia") {
        mandatoryLocationParams.forEach((element) => {
          if (!party.locationComplete[element]) {
            validLocation = false;
          }
        });
      }
      if (validLocation) {
        party.location = values.otpSignature.locationComplete;
        party.hidden = false;
        party.locationComplete = null;
        party.questionnaireCode = null;
        party.policyholderOtpSignatureEnabled = null;
        party.policyholderLegalEntity = null;
        party.customerReference = values.otpSignature.customerReference ?? user?.attributes.name;
        if (party.revenue) {
          party.revenue = {
            amount: party.revenue,
            currency: "EUR",
          };
        } else {
          party.revenue = null;
        }
        let updateNodes: ManagementNode[] = party.managementNodes ? party.managementNodes : [];
        if (updateNodes.filter((node) => node?.code === contract.managementNode.code).length === 0) {
          updateNodes.push(contract.managementNode);
        }
        party.managementNodes = updateNodes;
        if (party.mobilePhoneNumber) {
          const prefix = formatPhoneNumberIntl(party.mobilePhoneNumber).split(" ")[0];
          party.mobilePhoneNumber = party.mobilePhoneNumber.replace(prefix, "");
          party.mobilePhoneNumberPrefix = prefix.replace("+", "00");
        }
        const response = await partyService.checkTaxId(party as Party, true);
        const checkTaxId = response.data;
        if (!checkTaxId) {
          setTaxIdConsistent(false);
          scroll();
        } else {
          onSubmit(values, party);
        }
      }
    } else {
      onSubmit(values, null);
    }
  }

  useEffect(() => {
    if (contract && canAddAddendum != undefined && financialAdviceBankAccount != undefined) {
      const thereIsPayer = Object.keys(contract?.parties).includes(RoleType.PAYER);
      let initialPayerType;

      if (thereIsPayer) {
        let role = Object.keys(contract?.parties).find(
          (type) => type != RoleType.PAYER && contract.parties[type][0].partyId === contract.parties[RoleType.PAYER][0].partyId
        );
        initialPayerType = role ? role : RoleType.POLICYHOLDER;
      } else {
        initialPayerType = RoleType.POLICYHOLDER;
      }

      let initialPayer: Party = contract.parties[initialPayerType][0];

      let initialValues: {
        paymentMethod?: { type: string; paymentData: {}; bankAccounts: [] };
        otpSignature?: {};
        addendum?: { hasAddendum: boolean; addendum: string };
        payerType: string;
      } = {
        payerType: initialPayerType,
      };
      let validationSchema = Yup.object();

      if (issuingInReservedArea) {
        validationSchema = validationSchema.shape({
          reservedAreaEmail: Yup.string().when("completeIssueInCustomerArea", {
            is: true,
            then: Yup.string()
              .required(requiredMessage)
              .email(intl.formatMessage({ id: "invalidEmail" })),
          }),
        });

        Object.assign(initialValues, {
          completeIssueInCustomerArea: contract?.completeIssueInCustomerArea,
          reservedAreaEmail: policyholder?.email ?? "",
        });
      }

      if (isOtpEnabled) {
        validationSchema = addOtpSignatureForm(initialValues, validationSchema);
      }

      if (canAddAddendum) {
        Object.assign(initialValues, {
          addendum: {
            hasAddendum: contract?.hasAddendum,
            addendum: contract?.addendum,
          },
        });
        validationSchema = validationSchema.shape({
          addendum: Yup.object().shape({
            hasAddendum: Yup.boolean().nullable(),
            addendum: Yup.string().when("hasAddendum", {
              is: true,
              then: Yup.string().ensure().required(requiredMessage),
              otherwise: Yup.string().nullable(),
            }),
          }),
        });
      }

      const paymentMethodSchema = getPaymentMethodSchema();
      Object.assign(initialValues, {
        paymentMethod: getPaymentMethod(initialPayer),
      });

      setInitialPaymentData({
        ...lastPayment?.paymentData,
        iban: lastPayment?.paymentData?.iban || financialAdviceBankAccount[0]?.iban || undefined,
      });

      validationSchema = validationSchema.shape(paymentMethodSchema);
      setCurrentPayer(initialPayer);
      setAvailableBankAccounts(financialAdviceBankAccount.length > 0 ? financialAdviceBankAccount : initialPayer.bankAccounts);
      setInitialValues(initialValues);
      setValidationSchema(validationSchema);
    }
  }, [lastPayment, canAddAddendum, contract, financialAdviceBankAccount]);

  function addOtpSignatureForm(initialValues: { otpSignature?: {} }, validationSchema) {
    Object.assign(initialValues, {
      otpSignature: {
        policyholderOtpSignatureEnabled: policyholder.otpSignatureEnabled !== null ? policyholder.otpSignatureEnabled : false,
        name: "",
        surnameOrCompanyName: "",
        gender: "",
        birthDate: "",
        birthCountry: "",
        birthPlace: "",
        email: policyholder.legalEntity === false ? policyholder.email : "",
        mobilePhoneNumber:
          policyholder.legalEntity === false
            ? policyholder.mobilePhoneNumber
              ? policyholder.mobilePhoneNumberPrefix
                ? policyholder.mobilePhoneNumberPrefix.replace("00", "+") + policyholder.mobilePhoneNumber
                : "+39" + policyholder.mobilePhoneNumber
              : null
            : null,
        taxId:
          policyholder.legalEntity &&
          policyholder.companyType !== "Ditta Individuale" &&
          policyholder.companyType !== "Impresa familiare" &&
          policyholder.linkedParties &&
          policyholder.linkedParties["LEGAL-REPRESENTATIVE"] &&
          policyholder.linkedParties["LEGAL-REPRESENTATIVE"][0]
            ? policyholder.linkedParties["LEGAL-REPRESENTATIVE"][0].taxId
            : policyholder.legalEntity && (policyholder.companyType === "Ditta Individuale" || policyholder.companyType === "Impresa familiare")
            ? policyholder.taxId
            : "",
        location: "",
        locationComplete: null,
        policyholderLegalEntity: policyholder.legalEntity,
        iban: "",
      },
    });
    if (
      config.INDIVIDUAL_COMPANY_REFERENT === "enabled" &&
      policyholder.legalEntity &&
      (policyholder.companyType === "Ditta Individuale" || policyholder.companyType === "Impresa familiare")
    ) {
      validationSchema = validationSchema.shape({
        otpSignature: Yup.object().shape({
          policyholderOtpSignatureEnabled: Yup.boolean().defined(),
          name: Yup.string().required(requiredMessage),
          surnameOrCompanyName: Yup.string().required(requiredMessage),
          gender: Yup.string().required(requiredMessage),
          birthDate: Yup.date().required(requiredMessage),
          birthCountry: Yup.string().when("taxId", {
            is: (taxId: string) => !taxId || taxId?.length < 12 || (taxId?.length >= 12 && taxId.charAt(11).toUpperCase() === "Z"),
            then: Yup.string().required(requiredGeo),
            otherwise: Yup.string().nullable(),
          }),
          birthPlace: Yup.string().when("taxId", {
            is: (taxId: string) => !taxId || taxId?.length < 12 || (taxId?.length >= 12 && taxId.charAt(11).toUpperCase() !== "Z"),
            then: Yup.string().required(requiredGeo),
            otherwise: Yup.string().nullable(),
          }),
          email: Yup.string().when("policyholderOtpSignatureEnabled", {
            is: true,
            then: Yup.string()
              .required(requiredMessage)
              .email(intl.formatMessage({ id: "invalidEmail" })),
            otherwise: Yup.string()
              .nullable()
              .email(intl.formatMessage({ id: "invalidEmail" })),
          }),
          mobilePhoneNumber: Yup.string().when("policyholderOtpSignatureEnabled", {
            is: true,
            then: Yup.string()
              .nullable()
              .test("phoneRequired", requiredMessage, (val) => val != null && val != "")
              .test("phoneValid", invalidPhoneMessage, (val) => isValidPhoneNumber(val ?? "")),
            otherwise: Yup.string()
              .nullable()
              .test("phoneValid", invalidPhoneMessage, (val) => !val || isValidPhoneNumber(val ?? "")),
          }),
          taxId: Yup.string().test("len", lengthMessage, (val) => val?.length === 16),
          location: Yup.string().required(selectLocationMessage),
          iban: Yup.string()
            .nullable()
            .test("iban", intl.formatMessage({ id: "ibanFormatError" }), (v) => !v || isValidIBAN(v)),
        }),
      });
    } else {
      validationSchema = validationSchema.shape({
        otpSignature: Yup.object().shape({
          policyholderOtpSignatureEnabled: Yup.boolean().defined(),
          name: Yup.string().when(["policyholderOtpSignatureEnabled", "policyholderLegalEntity"], {
            is: (policyholderOtpSignatureEnabled: boolean, policyholderLegalEntity: boolean) =>
              policyholderOtpSignatureEnabled === true && policyholderLegalEntity === true,
            then: Yup.string().required(requiredMessage),
            otherwise: Yup.string().nullable(),
          }),
          surnameOrCompanyName: Yup.string().when(["policyholderOtpSignatureEnabled", "policyholderLegalEntity"], {
            is: (policyholderOtpSignatureEnabled: boolean, policyholderLegalEntity: boolean) =>
              policyholderOtpSignatureEnabled === true && policyholderLegalEntity === true,
            then: Yup.string().required(requiredMessage),
            otherwise: Yup.string().nullable(),
          }),
          gender: Yup.string().when(["policyholderOtpSignatureEnabled", "policyholderLegalEntity"], {
            is: (policyholderOtpSignatureEnabled: boolean, policyholderLegalEntity: boolean) =>
              policyholderOtpSignatureEnabled === true && policyholderLegalEntity === true,
            then: Yup.string().required(requiredMessage),
            otherwise: Yup.string().nullable(),
          }),
          birthDate: Yup.date().when(["policyholderOtpSignatureEnabled", "policyholderLegalEntity"], {
            is: (policyholderOtpSignatureEnabled: boolean, policyholderLegalEntity: boolean) =>
              policyholderOtpSignatureEnabled === true && policyholderLegalEntity === true,
            then: Yup.date().required(requiredMessage),
            otherwise: Yup.date().nullable(),
          }),
          birthCountry: Yup.string().when(["policyholderOtpSignatureEnabled", "policyholderLegalEntity", "taxId"], {
            is: (policyholderOtpSignatureEnabled: boolean, policyholderLegalEntity: boolean, taxId: string) =>
              policyholderOtpSignatureEnabled === true &&
              policyholderLegalEntity === true &&
              (!taxId || taxId?.length < 12 || (taxId?.length >= 12 && taxId.charAt(11).toUpperCase() === "Z")),
            then: Yup.string().required(requiredGeo),
            otherwise: Yup.string().nullable(),
          }),
          birthPlace: Yup.string().when(["policyholderOtpSignatureEnabled", "policyholderLegalEntity", "taxId"], {
            is: (policyholderOtpSignatureEnabled: boolean, policyholderLegalEntity: boolean, taxId: string) =>
              policyholderOtpSignatureEnabled === true &&
              policyholderLegalEntity === true &&
              (!taxId || taxId?.length < 12 || (taxId?.length >= 12 && taxId.charAt(11).toUpperCase() !== "Z")),
            then: Yup.string().required(requiredGeo),
            otherwise: Yup.string().nullable(),
          }),
          email: Yup.string().when("policyholderOtpSignatureEnabled", {
            is: true,
            then: Yup.string()
              .required(requiredMessage)
              .email(intl.formatMessage({ id: "invalidEmail" })),
            otherwise: Yup.string().nullable(),
          }),
          mobilePhoneNumber: Yup.string().when("policyholderOtpSignatureEnabled", {
            is: true,
            then: Yup.string()
              .nullable()
              .test("phoneRequired", requiredMessage, (val) => val != null && val != "")
              .test("phoneValid", invalidPhoneMessage, (val) => isValidPhoneNumber(val ?? "")),
            otherwise: Yup.string().nullable(),
          }),
          taxId: Yup.string().when(["policyholderOtpSignatureEnabled", "policyholderLegalEntity"], {
            is: (policyholderOtpSignatureEnabled: boolean, policyholderLegalEntity: boolean) =>
              policyholderOtpSignatureEnabled === true && policyholderLegalEntity === true,
            then: Yup.string().test("len", lengthMessage, (val) => val?.length === 16),
            otherwise: Yup.string().nullable(),
          }),
          location: Yup.string().when(["policyholderOtpSignatureEnabled", "policyholderLegalEntity"], {
            is: (policyholderOtpSignatureEnabled: boolean, policyholderLegalEntity: boolean) =>
              policyholderOtpSignatureEnabled === true && policyholderLegalEntity === true,
            then: Yup.string().required(selectLocationMessage),
            otherwise: Yup.string().nullable(),
          }),
          iban: Yup.string()
            .nullable()
            .test("iban", intl.formatMessage({ id: "ibanFormatError" }), (v) => !v || isValidIBAN(v)),
        }),
      });
    }
    return validationSchema;
  }

  function getPaymentMethodSchema() {
    const validationSchema = {
      paymentMethod: Yup.object({
        type: Yup.string().required(selectPaymentMethodMessage),
        paymentData: Yup.object()
          .when(["type", "bankAccounts"], {
            is: (type: PaymentMethodEnum, bankAccounts: BankAccount[]) =>
              type === PaymentMethodEnum.ACCOUNT_DEBIT && bankAccounts && bankAccounts.length > 1,
            then: (schema) =>
              schema.shape({
                iban: Yup.string()
                  .required(selectIban)
                  .test("iban", intl.formatMessage({ id: "ibanFormatError" }), (v) => v != null && isValidIBAN(v)),
              }),
          })
          .when(["type", "bankAccounts"], {
            is: (type: PaymentMethodEnum, bankAccounts: BankAccount[] = []) => type === PaymentMethodEnum.ACCOUNT_DEBIT && bankAccounts.length == 0,
            then: (schema) =>
              schema.shape({
                iban: Yup.string()
                  .required(requiredMessage)
                  .test("iban", intl.formatMessage({ id: "ibanFormatError" }), (v) => v != null && isValidIBAN(v)),
              }),
          }),
      }),
    };
    return validationSchema;
  }

  function getPaymentMethod(currentPayer: Party, values?: any) {
    let method = lastPayment?.paymentMethod || undefined;

    let type = financialAdviceBankAccount.length > 0 ? PaymentMethodEnum.ACCOUNT_DEBIT : values?.paymentMethod?.type || undefined;

    if ((contract.contractStatus && contract.contractStatus === STATUS.TO_AUTHORIZE) || premium.toPay.amount === 0) {
      method = PaymentMethodEnum.LATER;
    }
    return {
      paymentId: lastPayment?.paymentId || undefined,
      type: type || method,
      paymentData: {
        //...lastPayment?.paymentData,
        iban: lastPayment?.paymentData?.iban || financialAdviceBankAccount[0]?.iban || undefined,
      },
      bankAccounts: currentPayer?.bankAccounts,
    };
  }

  useEffect(() => {
    if (currentPayer != undefined) {
      formRef.current.setFieldValue("paymentMethod", getPaymentMethod(currentPayer, formRef?.current?.values), false);
      formRef.current?.setFieldError("paymentMethod.paymentData.iban", undefined);
      if (financialAdviceBankAccount.length == 0) setAvailableBankAccounts(currentPayer.bankAccounts);
    }
  }, [currentPayer]);

  return (
    <>
      {initialValues && validationSchema && (
        <Formik initialValues={initialValues} innerRef={formRef} onSubmit={handleSubmit} validationSchema={validationSchema} enableReinitialize>
          {({ values, setFieldValue }) => (
            <Form id="signatureAndPayment">
              <div className="flex flex-col gap-y-8">
                {showAddendum && canAddAddendum && (
                  <YogaCard uniformPadding>
                    <fieldset name="addendumForm" className="flex flex-col gap-y-4 ">
                      <div className="flex items-center justify-between w-full truncate">
                        <h4 className="text-title-text truncate" data-qa="addendum-title">
                          <FormattedMessage id="insertAddendumTitle" />
                        </h4>

                        <label
                          htmlFor="hasAddendum"
                          className="flex items-center text-body-text text-base font-bold gap-4 cursor-pointer"
                          data-qa="hasAddendum"
                        >
                          <span>
                            <Field
                              name="addendum.hasAddendum"
                              component={FormikToggleSwitch}
                              content={{
                                name: "addendum.hasAddendum",
                                type: "BOOLEAN",
                                updateOnChange: true,
                              }}
                              onUpdate={() => {
                                updateOnAddendum && updateOnAddendum(values?.addendum?.hasAddendum);
                              }}
                              ignoreDirty={true}
                            />
                          </span>
                        </label>
                      </div>
                      {values["addendum"]?.hasAddendum && (
                        <Field
                          name="addendum.addendum"
                          component={FormikInputTextArea}
                          content={{
                            name: "addendum.addendum",
                            label: "",
                            type: "TEXTAREA",
                            updateOnChange: true,
                          }}
                          placeholder={intl.formatMessage({
                            id: "addendumTextareaPlaceholder",
                          })}
                        />
                      )}
                    </fieldset>
                  </YogaCard>
                )}
                <PayerCard contract={contract} currentPayer={currentPayer} setCurrentPayer={setCurrentPayer} />

                {(isIndividualCompanyReferent || isOtpEnabled || contract.contractStatus !== STATUS.TO_AUTHORIZE) &&
                  (issuingInReservedArea ||
                    (showAddendum && canAddAddendum) ||
                    isIndividualCompanyReferent ||
                    isOtpEnabled ||
                    premium.toPay.amount !== 0) && (
                    <YogaCard uniformPadding>
                      {/* ISSUE IN CUSTOMER AREA */}
                      {contract.contractStatus !== STATUS.TO_AUTHORIZE && issuingInReservedArea && (
                        <div data-qa="completeIssueInCustomerArea" className="border-2 border-background rounded-lg p-4">
                          {emailAlreadyUsed && (
                            <YogaMessage prefix="emailAlreadyUsed" type="error" position="inner" className="mb-4">
                              <p id="emailAlreadyUsed">
                                {intl.formatMessage({
                                  id: "emailAlreadyUsed",
                                })}
                              </p>
                            </YogaMessage>
                          )}
                          <div className="lg:flex lg:justify-between lg:items-center">
                            <div className={classNames("flex items-center mr-2", shouldEndInCustomerArea && "lg:w-1/2")}>
                              <Field name="completeIssueInCustomerArea">
                                {(fieldProps) => (
                                  <FormikInputCheck
                                    {...fieldProps}
                                    content={{
                                      name: "completeIssueInCustomerArea",
                                      type: "CHECKMARK",
                                      label: "completeIssueInCustomerArea",
                                    }}
                                    onUpdate={() => {
                                      if (!shouldEndInCustomerArea) {
                                        setFieldValue("otpSignature.policyholderOtpSignatureEnabled", true);
                                      }
                                      setShouldEndInCustomerArea(!shouldEndInCustomerArea);
                                    }}
                                    centerItem={true}
                                    infoLabel="endIssuingLabel"
                                    data-qa="completeIssueInCustomerArea"
                                  />
                                )}
                              </Field>
                            </div>
                            {shouldEndInCustomerArea && (
                              <div className="lg:w-1/2 mt-4 lg:mt-0">
                                <FormikInputText
                                  disabled={!!policyholder.profile}
                                  content={{
                                    name: "reservedAreaEmail",
                                    type: "STRING",
                                    label: "reservedAreaEmail",
                                  }}
                                  dataQa="reservedAreaEmail"
                                />
                              </div>
                            )}
                          </div>
                        </div>
                      )}

                      {/* OTP / REFERENT */}
                      {(isIndividualCompanyReferent || isOtpEnabled) && (
                        <Field
                          name="otpSignature"
                          component={OtpSignatureForm}
                          policyHolder={policyholder}
                          key="otpSignature"
                          taxIdConsistent={taxIdConsistent}
                          setIsAnUpdate={setIsAnUpdate}
                          isAnUpdate={isAnUpdate}
                          isOtpEnabled={isOtpEnabled}
                          isIndividualCompanyReferent={isIndividualCompanyReferent}
                          contractStatus={contract.contractStatus}
                          managementNodes={[contract.managementNode]}
                        />
                      )}
                      {/* PAYMENT METHODS */}
                      {paymentMethods?.length > 0 && contract.contractStatus !== STATUS.TO_AUTHORIZE && premium.toPay.amount !== 0 && (
                        <Field name="paymentMethod">
                          {(fieldProps) => (
                            <PaymentMethodFormV2
                              {...fieldProps}
                              paymentMethods={paymentMethods}
                              payer={currentPayer}
                              totalPremium={premium.total}
                              premiumToPay={premium.toPay}
                              bankAccounts={financialAdviceBankAccount.length > 0 ? financialAdviceBankAccount : availableBankAccounts}
                              contractId={contract.contractId}
                              updateParameters={updatePaymentMethodParams}
                              initialPaymentData={initialPaymentData}
                            />
                          )}
                        </Field>
                      )}

                      <ScrollToFieldError reset={reset} />
                    </YogaCard>
                  )}
              </div>
            </Form>
          )}
        </Formik>
      )}
    </>
  );
}
