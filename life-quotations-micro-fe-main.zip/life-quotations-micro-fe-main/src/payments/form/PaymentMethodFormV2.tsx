import { RadioGroup } from "@headlessui/react";
import classnames from "classnames";
import { fromYogaParamToFormParam } from "commons/FormUtils";
import { YogaMessage } from "commons/components/YogaMessage";
import { FormikInput } from "commons/formik/FormikInput";
import { KeyValue, Money } from "commons/models/YogaModels";
import { BankAccount } from "customers/models/BankAccount";
import { Field, FieldProps } from "formik";
import { getSelectedMethod, /*PaymentMethodEnum,*/ setIconPaymentMethods } from "payments/Payment";
import PaymentMethodConfig from "payments/models/PaymentMethod";
import React, { Fragment, useContext, useEffect, useState } from "react";
import { FormattedMessage, FormattedNumber, useIntl } from "react-intl";
import { YogaParam } from "commons/models/YogaParam";
import { Party } from "customers/models/Party";
import { CONTRACT_PARAM } from "commons/formik/FormikDynamicSelect";
import { validateParameters } from "commons/formik/Utils";
import { nawService } from "commons/services/NAWService";
import { Context } from "commons/contexts/Context";

export function AccountDebitPaymentDataForm({ field: { name, value }, ...props }: FieldProps) {
  const bankAccounts = (props as any).bankAccounts as BankAccount[];

  return (
    <div className="border-2 border-background rounded-lg p-4 flex flex-col" data-qa="account-debit-form">
      {bankAccounts && bankAccounts.length > 0 ? (
        <Field key={`${name}.iban`} name={`${name}.iban`}>
          {(fieldProps: FieldProps) => (
            <FormikInput
              {...fieldProps}
              data-qa={`${name}.iban`}
              content={{
                name: `${name}.iban`,
                value: value?.iban,
                mandatory: true,
                type: "LIST",
                subtype: "RADIO",
                availableObjectValues: bankAccounts.map((account) => {
                  return {
                    description: account.description,
                    code: account.iban,
                  };
                }),
              }}
            />
          )}
        </Field>
      ) : (
        <div className="grid grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-4">
          <Field
            key={`${name}.iban`}
            name={`${name}.iban`}
            component={FormikInput}
            content={{
              name: `${name}.iban`,
              value: "",
              mandatory: true,
              label: "iban",
              type: "STRING",
            }}
          />
        </div>
      )}
    </div>
  );
}

interface PaymentMethodFormV2Props extends FieldProps {
  contractId: string;
  paymentMethods: PaymentMethodConfig[];
  payer?: Party;
  bankAccounts?: BankAccount[];
  premiumToPay: Money;
  totalPremium: Money;
  updateParameters: (contractId: string, paymentMethod: PaymentMethodConfig, payer: Party) => Promise<PaymentMethodConfig>;
  initialPaymentData: KeyValue<string>;
}

interface PaymentMethodParametersFormProps extends FieldProps<KeyValue<any>> {
  parameters: KeyValue<YogaParam>;
  "data-qa"?: string;
  updateParameters: (values: any) => any;
  partialUpdateParameters: (values: any) => any;
}

export function PaymentMethodParameters({
  parameters,
  field,
  "data-qa": dataQa,
  updateParameters,
  partialUpdateParameters,
}: PaymentMethodParametersFormProps) {
  let isTagChanged = false;
  let prevTag = undefined;
  return (
    <div className="border-2 border-background rounded-lg p-4" data-qa={dataQa}>
      <div className="grid grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-4">
        {Object.values(parameters)
          .filter((param) => param.visible)
          .map((param) => {
            isTagChanged = param.tags[0] !== prevTag;
            prevTag = param.tags[0];

            return (
              <Fragment key={`${field.name}.${param.code}-div`}>
                {isTagChanged ? (
                  <div className="inline-flex w-full items-center col-span-full">
                    <h4 key={prevTag} data-qa={prevTag} className="shrink-0 mr-3">
                      <span className="text-base font-bold">
                        <FormattedMessage id={prevTag} />
                      </span>
                    </h4>
                    <hr className="flex-1" />
                  </div>
                ) : (
                  <></>
                )}

                <Field
                  key={`${field.name}.${param.code}`}
                  name={`${field.name}.${param.code}`}
                  component={FormikInput}
                  content={{
                    ...fromYogaParamToFormParam(param),
                    name: `${field.name}.${param.code}`,
                  }}
                  onUpdate={updateParameters}
                  onPartialUpdate={partialUpdateParameters}
                  fieldName={param.code}
                  disabled={param.disabled}
                  paramType={param.dynamicList?.fromTable == "naw" ? "external" : CONTRACT_PARAM}
                  parameters={parameters}
                  autoselect={true}
                />
              </Fragment>
            );
          })}
      </div>
    </div>
  );
}

export default function PaymentMethodFormV2({
  contractId,
  paymentMethods,
  payer,
  //bankAccounts,
  premiumToPay,
  field: { name, value },
  form: { getFieldMeta, setFieldValue, setFieldError }, // resetForm },
  updateParameters,
  initialPaymentData,
}: PaymentMethodFormV2Props) {
  // const shouldEndInCustomerArea = (props as any)
  // .shouldEndInCustomerArea as Money;
  const intl = useIntl();
  const [methods, setMethods] = useState<PaymentMethodConfig[]>(undefined);
  const [type, setType] = useState<string>();
  const [errorIban, setErrorIban] = useState<string>();
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState<PaymentMethodConfig>(undefined);
  const [runOnUpdate, setRunOnUpdate] = useState(false);
  const { changeLoading } = useContext(Context);
  /*const [extraData, setExtraData] = useState<{ iban: string }>({
    iban: undefined,
  });*/
  const [first, setFirst] = useState(true);

  // TODO: Remove me
  console.log(errorIban);

  useEffect(() => {
    if (paymentMethods) {
      setMethods(setIconPaymentMethods(paymentMethods));
      if (type) {
        const paymentMethod = getSelectedMethod(paymentMethods, type);
        setSelectedPaymentMethod(paymentMethod);
        setFirst(false);

        // Set data
        let updatedData = {};
        if (first) {
          updatedData = initialPaymentData;
          // Add values in selected paymentMethod
          Object.values(paymentMethod.parameters).forEach((p) => {
            if (updatedData[p.code] != undefined) {
              p.value = updatedData[p.code];
            }
          });
          if (Object.values(updatedData).includes(undefined) == false) {
            // Get new values
            updateParameters(contractId, paymentMethod, payer);
          }
        } else {
          updatedData = Object.values(paymentMethod.parameters).reduce((a, p) => {
            a[p.code] = p.value;
            return a;
          }, {});
        }

        // Set iban if there is only one
        /*if (type === PaymentMethodEnum.ACCOUNT_DEBIT && bankAccounts && bankAccounts.length === 1) {
          updatedData["iban"] = bankAccounts[0].iban ?? "";
        } else if (type === PaymentMethodEnum.ACCOUNT_DEBIT && extraData["iban"] != undefined) {
          updatedData["iban"] = extraData["iban"];
        }*/

        setFieldValue(`${name}.paymentData`, updatedData, false);
      }
    }
  }, [paymentMethods, type]);

  useEffect(() => {
    let defaultType = undefined;
    if (value?.type) {
      defaultType = value.type;
    } else if (methods && methods.length == 1) {
      setFieldValue(`${name}.type`, methods[0].code, false);
      defaultType = methods[0].code;
    }
    setType(defaultType);
  }, [value, methods]);

  useEffect(() => {
    if (payer) {
      setRunOnUpdate(false);
      //setExtraData({ iban: undefined });
      const paymentMethod = getSelectedMethod(paymentMethods, type);
      updateParameters(contractId, paymentMethod, payer);
    }
  }, [payer]);

  // useEffect(() => {
  //   const filtered = shouldEndInCustomerArea
  //     ? mergePaymentMethods(paymentMethods)
  //     : mergePaymentMethods(paymentMethods).filter(
  //         (payment) => payment.code !== PaymentMethodEnum.EXTERNAL_PROVIDER
  //       );
  //   setMethods(filtered);
  //   if (type && !filtered.map((e) => e.code).includes(type)) {
  //     updateType("");
  //   }
  // }, [shouldEndInCustomerArea]);

  async function onSelectedType(selectedType: string, payer: Party) {
    setType(selectedType);
    const paymentMethod = getSelectedMethod(paymentMethods, selectedType);
    setSelectedPaymentMethod(paymentMethod);
    resetValues(selectedType);
    setRunOnUpdate(false);
    await updateParameters(contractId, paymentMethod, payer);
  }

  function resetValues(selectedType: string) {
    // resetForm(); // questa annulla tutte le modifiche e riporta formik ad initialValues!

    setFieldValue(`${name}.type`, selectedType, false); // It was true
    setFieldValue(`${name}.paymentData`, {}, false);
    setFieldError(`${name}.paymentData`, "");

    //if (selectedType != PaymentMethodEnum.ACCOUNT_DEBIT) {
    setFieldValue(`${name}.paymentData.iban`, undefined, false);
    //}
  }

  function displayPaymentDataForm() {
    switch (type) {
      //case PaymentMethodEnum.ACCOUNT_DEBIT:
      //  return <Field name={`${name}.paymentData`} component={AccountDebitPaymentDataForm} bankAccounts={bankAccounts} />;
      default:
        return <></>;
    }
  }

  /*
    function validateParameters(editedValues) {
    let errors = {};
    if (selectedPaymentMethod.parameters) {
      Object.values(selectedPaymentMethod.parameters).forEach(({ code, visible, mandatory, validations, type }) => {
        const value = editedValues ? editedValues[code] : null;
        if (visible && mandatory && (value === null || value === undefined || value === "")) {
          errors[code] = intl.formatMessage({ id: "required" });
        } else if (code === "codiceIban" && errorIban && errorIban.length > 0) {
          errors[code] = errorIban;
        }
        if (visible && validations && type === "STRING" && validations.regExp) {
          const confRegex = new RegExp(validations.regExp);
          if (value && !confRegex.test(value as string)) {
            errors[code] = intl.formatMessage({
              id: "form.validateRegExpError",
            });
          }
        }
      });
    }
    return Object.keys(errors).length > 0 ? errors : undefined;
  }
  * */

  function validatePaymentMethodParameters(editedValues) {
    let errors: { [code: string]: { value: string } };
    if (selectedPaymentMethod.parameters) {
      const tempEditedValues = Object.entries(editedValues).reduce((acc, [code, value]) => {
        acc[code] = { value: value };
        return acc;
      }, {});
      errors = validateParameters(Object.values(selectedPaymentMethod.parameters), tempEditedValues, intl);
      // Object.values(selectedPaymentMethod.parameters).forEach(({ code, visible, mandatory }) => {
      //   const value = editedValues ? editedValues[code] : null;
      //   if (visible && mandatory && (value === null || value === undefined || value === "")) {
      //     errors[code] = intl.formatMessage({ id: "required" });
      //   }
      // });

      // Validazione iban da naw
      Object.values(selectedPaymentMethod.parameters).forEach(({ code }) => {
        if (code === "codiceIban" && errorIban && errorIban.length > 0) {
          errors[code] = { value: errorIban };
        }
      });

      errors =
        errors &&
        Object.entries(errors).reduce((acc, [errorCode, objWithValue]) => {
          acc[errorCode] = objWithValue.value;
          return acc;
        }, {});
    }
    return errors && Object.keys(errors).length > 0 ? errors : undefined;
  }

  const onUpdatePaymentMethodParams = async (values) => {
    if (!runOnUpdate) {
      setRunOnUpdate(true);
      return;
    }
    const paymentMethod = paymentMethods.filter((paymentMethod) => paymentMethod.code == values.paymentMethod.type)[0];
    if (!paymentMethod) {
      return;
    }
    // Add values in selected paymentMethod
    Object.values(paymentMethod.parameters).forEach((p) => {
      if (values.paymentMethod.paymentData[p.code] != undefined) {
        p.value = values.paymentMethod.paymentData[p.code];
      }
    });

    /*if (values?.paymentMethod?.paymentData?.iban != undefined) {
      setExtraData({ iban: values?.paymentMethod?.paymentData?.iban });
    }*/

    // Get new values
    await updateParameters(contractId, paymentMethod, payer);
  };

  function partialUpdateParameters(parameter: any) {
    if (parameter && parameter.codiceIban != undefined) {
      setErrorIban(undefined);
      setFieldValue(`paymentMethod.paymentData.banca`, "", true);
      setFieldValue(`paymentMethod.paymentData.filiale`, "", true);
      // La validazione viene fatta configurando il metodo di pagamento da DSL
      /*if (parameter.codiceIban.length > 0 && parameter.codiceIban.length < 27) {
        setErrorIban("Il codice IBAN deve essere di 27 caratteri");
      } else */
      if (parameter.codiceIban.length >= 27) {
        checkIban(parameter.codiceIban);
      }
    }
  }

  function checkIban(iban: string) {
    changeLoading(1);
    nawService
      .ibanDetails(iban)
      .then((res) => {
        // setErrorIban('TEST')
        changeLoading(-1);
        if (res.data && res.data.errori && res.data.errori.length > 0 && res.data.errori[0].descErrore) {
          console.log(res.data.errori.descErrore);
          setErrorIban(res.data.errori[0].descErrore);
        } else {
          // console.log(paymentMethods)
          // console.log(selectedPaymentMethod)
          if (res.data && res.data.banca) {
            const bancaFromNaw = res.data.banca.codice + " " + res.data.banca.descrizione;
            setFieldValue(`paymentMethod.paymentData.banca`, bancaFromNaw, true);
          }
          if (res.data && res.data.filiale) {
            const filialeFromNaw = res.data.filiale.codice + " " + res.data.filiale.descrizione;
            setFieldValue(`paymentMethod.paymentData.filiale`, filialeFromNaw, true);
          }
        }
        validateParameters;
      })
      .catch((e) => {
        changeLoading(-1);
        console.log(e);
        setErrorIban("Iban errato");
        validateParameters;
      });
  }

  return (
    <div data-qa="paymentMethods-card">
      {/* <YogaLoader loading={isIbanCheck} /> */}
      <div className="flex flex-col">
        <div className="flex justify-between items-center mb-4">
          <h4 className="text-title-text text-2xl" data-qa="paymentMethods-title">
            {premiumToPay.amount > 0 ? <FormattedMessage id="paymentMethod" /> : <FormattedMessage id="paymentMethodRefund" />}
          </h4>
        </div>
        {getFieldMeta(name).touched && getFieldMeta(`${name}.type`).error && (
          <YogaMessage type="error" position="inner" className="mb-2">
            {getFieldMeta(`${name}.type`).error}
          </YogaMessage>
        )}

        <div className="flex flex-col gap-y-4">
          <div
            id={`${name}.type`}
            data-qa="paymentMethods"
            className={classnames("flex flex-col border-2 border-background rounded-lg p-4 gap-2 w-full")}
          >
            <RadioGroup value={type} onChange={(selected) => onSelectedType(selected, payer)} className="flex flex-col gap-4">
              <div
                className={classnames("grid grid-cols-1 gap-x-4 gap-y-4", {
                  "lg:grid-cols-2": methods?.length > 1,
                })}
              >
                {methods
                  ?.filter((m) => m.visible)
                  // @ts-ignore
                  .map(({ icon, code: method, description, amountLimit }) => (
                    <RadioGroup.Option
                      data-qa={"payment-method-" + method}
                      disabled={amountLimit && premiumToPay.amount > amountLimit}
                      key={method}
                      value={method}
                      className={({ checked, disabled }) =>
                        `lg:mt-0 font-bold cursor-pointer w-full border-2 rounded-lg px-4 inline-flex items-center ${
                          checked
                            ? "text-white bg-primary border-primary py-4"
                            : disabled
                            ? "cursor-not-allowed bg-background-disabled border-action-disabled text-action-disabled py-2"
                            : "bg-box-background border-primary py-4"
                        }`
                      }
                    >
                      {React.createElement(icon, {
                        className: "w-6 h-6 mr-2 flex-shrink-0",
                      })}
                      <div data-qa="payment-method-content">
                        <p data-qa="payment-method-name">
                          <FormattedMessage id={description} />
                        </p>

                        {amountLimit && premiumToPay.amount > amountLimit && (
                          <p className="text-xs uppercase" data-qa="payment-method-message">
                            {amountLimit > 0 ? (
                              <>
                                <FormattedMessage id={"cashLimit"} />{" "}
                                <FormattedNumber value={amountLimit} style="currency" currency={premiumToPay.currency} />
                              </>
                            ) : (
                              <>
                                <FormattedMessage id={"cashLimitZero"} />
                              </>
                            )}
                          </p>
                        )}
                      </div>
                    </RadioGroup.Option>
                  ))}
              </div>
            </RadioGroup>
          </div>

          {displayPaymentDataForm()}

          {selectedPaymentMethod?.parameters && Object.keys(selectedPaymentMethod.parameters).length > 0 && (
            <Field name={`${name}.paymentData`} validate={validatePaymentMethodParameters}>
              {(fieldprops) => (
                <PaymentMethodParameters
                  {...fieldprops}
                  parameters={selectedPaymentMethod.parameters}
                  data-qa={`${selectedPaymentMethod.code}-parameters`}
                  updateParameters={onUpdatePaymentMethodParams}
                  partialUpdateParameters={partialUpdateParameters}
                />
              )}
            </Field>
          )}
        </div>
      </div>
    </div>
  );
}
