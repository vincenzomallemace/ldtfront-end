import { Context } from "commons/contexts/Context";
import { useContext, useEffect, useState } from "react";
import { lifeProductService } from "commons/services/LifeProductService";
import { Product } from "offers/models/Product";

export default function useLifeProductIncompleteOnly(
  productInstanceId?: string
) {
  const context = useContext(Context);

  const [error, setError] = useState<string>(undefined);
  const [productId, setProductId] = useState<string>(productInstanceId);
  const [product, setProduct] = useState<Product>(undefined);

  useEffect(() => {
    const fetchData = async () => {
      context.changeLoading(1);
      let res;
      if (productId) {
        res = await lifeProductService.getIncompleteLifeProduct(productId);
        let product = res.data;
        if (product) {
          if (
            // product.status === "PURCHASED" ||
            product.status === "EXPIRED"
          ) {
            setError("No available");
          } else {
            setProduct(product);
          }
        }
      }
    };
    fetchData()
      .catch((e: any) => {
        setError(e.response?.data?.message);
      })
      .finally(() => {
        context.changeLoading(-1);
      });
  }, [productId]);

  return {
    error,
    setProductId,
    product,
    setProduct,
  };
}
