import { Context } from "commons/contexts/Context";
import PaymentMethodConfig from "payments/models/PaymentMethod";
import { paymentMethodsService } from "payments/services/PaymentMethodsService";
import { useContext, useEffect, useState } from "react";
import { Party } from "customers/models/Party";

export default function usePaymentMethods(
  productCode: string,
  contractId: string
) {
  const { changeLoading } = useContext(Context);
  const [paymentMethods, setPaymentMethods] = useState<
    Array<PaymentMethodConfig> | undefined
  >(undefined);
  const [defaultPaymentMethods, setDefaultPaymentMethods] = useState<
    Array<PaymentMethodConfig> | undefined
  >(undefined);

  useEffect(() => {
    const fetchData = async () => {
      changeLoading(1);
      if (productCode) {
        const response =
          await paymentMethodsService.getByProductCodeAndContractId(
            productCode,
            contractId
          );
        if (response.data && response.data.length) {
          const allPaymentMethods = response.data;
          setDefaultPaymentMethods(allPaymentMethods);
          setPaymentMethods(allPaymentMethods);
        }
      }
    };
    fetchData().finally(() => {
      changeLoading(-1);
    });
  }, [productCode]);

  const updatePaymentMethodParams = async (
    contractId: string,
    paymentMethod: PaymentMethodConfig,
    payer: Party
  ): Promise<PaymentMethodConfig> => {
    if (contractId == undefined || paymentMethod == undefined) {
      return null;
    }
    changeLoading(1);
    let updated: PaymentMethodConfig = undefined;
    try {
      const res = await paymentMethodsService.updateParameters(
        contractId,
        paymentMethod,
        payer
      );
      updated = res.data;

      let allPaymentMethods = JSON.parse(JSON.stringify(defaultPaymentMethods));
      let pIndex = allPaymentMethods.findIndex((p) => p.code == updated?.code);
      if (pIndex != -1) {
        allPaymentMethods.splice(pIndex, 1, updated);
      }
      setPaymentMethods(allPaymentMethods);
    } catch (e) {
      console.error(e);
    } finally {
      changeLoading(-1);
    }
    return updated;
  };

  return {
    paymentMethods,
    updatePaymentMethodParams,
  };
}
