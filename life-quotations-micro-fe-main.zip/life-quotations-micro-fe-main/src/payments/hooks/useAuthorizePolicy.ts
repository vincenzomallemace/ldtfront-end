import { Contract, STATUS } from "contracts/models/Contract";
import { contractService } from "commons/services/ContractService";
import { useMemo, useState } from "react";

const useAuthorizePolicy = () => {
  const [contract, setContract] = useState<Contract>(undefined);

  const canIssue = useMemo(() => {
    if (!contract) {
      return false;
    }
    return contract.contractStatus === STATUS.AUTHORIZED;
  }, [contract]);

  const issueAuthorized = async () => {
    await contractService.issueAuthorized(contract.contractId);
  };

  const toAuthorize = useMemo(
    () => contract && contract.contractStatus === STATUS.TO_AUTHORIZE,
    [contract]
  );

  return { canIssue, issueAuthorized, toAuthorize, setContract };
};

export default useAuthorizePolicy;
