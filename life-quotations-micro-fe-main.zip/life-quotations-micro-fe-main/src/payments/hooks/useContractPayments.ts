import { contractService } from "commons/services/ContractService";
import { Contract } from "contracts/models/Contract";
import { useContext, useEffect, useState } from "react";
import { Context } from "commons/contexts/Context";
import { Payment } from "payments/Payment";

export default function useContractPayments() {
  const context = useContext(Context);
  const [contract, setContract] = useState<Contract>(undefined);
  const [payments, setPayments] = useState<Payment[] | undefined>(undefined);

  useEffect(() => {
    if (contract) {
      context.changeLoading(1);

      contractService
        .getPayments(contract.contractId, false)
        .then((result) => {
          setPayments(result.data);
        })
        .finally(() => {
          context.changeLoading(-1);
        });
    }
  }, [contract]);

  return { payments, setContract };
}
