import { Context } from "commons/contexts/Context";
import { UserContext } from "commons/contexts/UserProvider";
import { Role } from "commons/models/Role";
import { contractService } from "commons/services/ContractService";
import { useContext, useEffect, useMemo, useState } from "react";

export default function useContractAuthorization() {
  const [authorization, setAuthorization] = useState<Role>();
  const [authorizationError, setAuthorizationError] = useState<
    Error | undefined
  >();
  const { role } = useContext(UserContext);
  const { changeLoading } = useContext(Context);

  const canIssue: boolean = useMemo(() => {
    return (
      authorization?.permissions?.filter(
        (perm) => perm.code === "issuePolicy" && perm.category === "contract"
      ).length === 1
    );
  }, [authorization]);

  const canPayImmediately: boolean = useMemo(() => {
    return (
      authorization?.permissions.filter(
        (perm) =>
          perm.code === "registerImmediatePayment" &&
          perm.category === "accounting"
      ).length === 1
    );
  }, [authorization]);

  const canAuthorize: boolean = useMemo(() => {
    return (
      authorization?.permissions.filter(
        (perm) =>
          perm.code === "authorizeContract" && perm.category === "contract"
      ).length === 1
    );
  }, [authorization]);

  const canAddAddendum: boolean = false; // Forced to false
  /*useMemo(() => {
    if (!authorization) {
      return undefined;
    } else
      return (
        authorization?.permissions.filter(
          (perm) =>
            perm.code === "addendumManagement" && perm.category === "contract"
        ).length === 1
      );
  }, [authorization]);*/

  const roleGroup: string = useMemo(() => {
    return authorization?.code;
  }, [authorization]);

  useEffect(() => {
    if (role) {
      changeLoading(1);
      const fetchData = async () => {
        const result = await contractService.getPermissionsByRole(role);
        setAuthorization(result.data);
      };

      fetchData()
        .catch((e) => {
          setAuthorizationError(e);
        })
        .finally(() => {
          changeLoading(-1);
        });
    }
  }, [role]);

  return {
    authorization,
    canIssue,
    canAuthorize,
    canPayImmediately,
    canAddAddendum,
    authorizationError,
    roleGroup,
  };
}
