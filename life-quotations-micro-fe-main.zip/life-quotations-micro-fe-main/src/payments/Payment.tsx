import {
  CashIcon,
  ClockIcon,
  CreditCardIcon,
  CurrencyEuroIcon,
  DeviceMobileIcon,
  DotsCircleHorizontalIcon,
  LibraryIcon,
  TicketIcon,
} from "@heroicons/react/outline";
import { Money } from "commons/models/YogaModels";
import React from "react";
import PaymentMethodConfig from "./models/PaymentMethod";

export interface Payment {
  paymentId?: string;
  contractId: string;
  status?: PaymentStatus;
  type?: string;
  paymentMethod?: PaymentMethodEnum;
  policyholderId: string;
  effectInstant?: Date;
  expirationInstant?: Date;
  paymentInstant?: Date;
  amount?: Money;
  paymentData?: { [key: string]: string };
  operationId?: string;
}

export enum PaymentMethodEnum {
  POS = "POS",
  CASH = "CASH",
  RESERVED_AREA = "RESERVED_AREA",
  SDD = "SDD",
  ACCOUNT_DEBIT = "ACCOUNT_DEBIT",
  LATER = "LATER",
  CHECK = "CHECK",
  OTHER = "OTHER",
  TRANSFER = "TRANSFER",
  EXTERNAL_PROVIDER = "EXTERNAL_PROVIDER",
  GIORGIO = "GIORGIO",
}

export enum PaymentStatus {
  PAID = "PAID",
  TO_PAY = "TO_PAY",
  PAYING = "PAYING",
  REJECTED = "REJECTED",
  WAITING = "WAITING",
  CANCELED = "CANCELED",
}

export enum PaymentCurrency {
  EUR = "EUR",
  USD = "USD",
  GBP = "GBP",
  JPY = "JPY",
}

export interface PaymentMethod {
  icon: (props: React.ComponentProps<"svg">) => JSX.Element;
  method: PaymentMethodEnum;
  type: string;
}

const PAYMENT_METHODS: PaymentMethod[] = [
  {
    icon: DeviceMobileIcon,
    method: PaymentMethodEnum.EXTERNAL_PROVIDER,
    type: "future",
  },
  { icon: CurrencyEuroIcon, method: PaymentMethodEnum.SDD, type: "future" },
  {
    icon: CurrencyEuroIcon,
    method: PaymentMethodEnum.ACCOUNT_DEBIT,
    type: "future",
  },
  { icon: ClockIcon, method: PaymentMethodEnum.LATER, type: "future" },
  {
    icon: LibraryIcon,
    method: PaymentMethodEnum.TRANSFER,
    type: "immediate",
  },
  { icon: CashIcon, method: PaymentMethodEnum.CASH, type: "immediate" },
  { icon: CreditCardIcon, method: PaymentMethodEnum.POS, type: "immediate" },
  { icon: TicketIcon, method: PaymentMethodEnum.CHECK, type: "immediate" },
  {
    icon: DotsCircleHorizontalIcon,
    method: PaymentMethodEnum.OTHER,
    type: "immediate",
  },
];

export const getPaymentMethods = (availablePaymentMethods?: string[]) => {
  return availablePaymentMethods
    ? PAYMENT_METHODS.filter((p) => availablePaymentMethods?.includes(p.method))
    : PAYMENT_METHODS;
};

export const setIconPaymentMethods = (
  availablePaymentMethods: PaymentMethodConfig[]
): PaymentMethodConfig[] => {
  return availablePaymentMethods
    .map((conf) => {
      const fePaymentMethod = PAYMENT_METHODS.find(
        (v) => v.method === conf.code
      );
      return {
        ...conf,
        icon: fePaymentMethod?.icon ?? DotsCircleHorizontalIcon,
      };
    })
    .sort(
      (a, b) => a.order - b.order || a.description.localeCompare(b.description)
    );
};

export const getSelectedMethod = (
  methods: PaymentMethodConfig[],
  selectedType: string
) => methods.find((method) => method.code === selectedType);
