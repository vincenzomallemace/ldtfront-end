import { UserContext } from "commons/contexts/UserProvider";
import { useContext, useEffect } from "react";
import { useNavigate } from "react-router-dom";

const Logout = () => {
  const navigate = useNavigate();
  const { signOut } = useContext(UserContext);

  useEffect(() => {
    signOut();
    navigate("/");
  }, []);

  return <div>signing out ...</div>;
};

export default Logout;
