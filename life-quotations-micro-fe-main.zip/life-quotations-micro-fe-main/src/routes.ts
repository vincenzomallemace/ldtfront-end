import AdditionalDataPage from "offers/AdditionalDataPage";
import ConfirmIssuePage from "contracts/ConfirmIssuePage";
import PolicyholderPage from "offers/PolicyholderPage";
import QuotationPage from "offers/QuotationPage";
import SummaryPage from "contracts/SummaryPage";
import TechnicalDataPage from "offers/TechnicalDataPage";
import FinancialAdviceInitPage from "offers/FinancialAdviceInitPage";
import FinancialAdvicePage from "offers/FinancialAdvicePage";
import BeneficiariesPage from "contracts/BeneficiariesPage";
import SignatureAndPaymentPage from "payments/SignatureAndPaymentPage";
import DueDiligenceQuestionnairePage from "questionnaires/DueDiligenceQuestionnairePage";
import { Route } from "models/Route";
import ThirdPartyPage from "contracts/ThirdPartyPage";
import DetailPage from "contracts/DetailPage";
import OutcomeDetailPage from "contracts/OutcomeDetailPage";

export const routes: Route[] = [
  {
    path: "advices",
    component: FinancialAdviceInitPage,
    title: "financialAdvice",
    sequence: -1,
  },
  {
    path: "advices/:financialAdviceId",
    component: FinancialAdvicePage,
    title: "financialOfferListPageTitle",
    sequence: 0,
  },
  {
    path: "offers/policyholder",
    component: PolicyholderPage,
    title: "policyholder",
    sequence: -2,
  },
  {
    path: "offers/:productInstanceId/additionalData",
    component: AdditionalDataPage,
    title: "policyholderAndAsset",
    sequence: 1,
  },
  {
    path: "offers/:productInstanceId/technicalData",
    component: TechnicalDataPage,
    title: "technicalData",
    sequence: 2,
  },
  {
    path: "offers/:productInstanceId/quotation",
    component: QuotationPage,
    title: "investmentLines",
    sequence: 3,
  },
  {
    path: "offers/:productId/beneficiaries",
    component: BeneficiariesPage,
    title: "beneficiariesAndThirdReferent",
    sequence: 4,
  },
  {
    path: "offers/:productId/thirdParty",
    title: "thirdParty",
    component: ThirdPartyPage,
    sequence: 5,
  },
  {
    path: "offers/:productId/signatureAndPayment",
    component: SignatureAndPaymentPage,
    title: "payment",
    sequence: 6,
  },
  {
    path: "offers/:contractId/dueDiligence/:questId",
    component: DueDiligenceQuestionnairePage,
    title: "dueDiligenceQuestionnaire",
    sequence: 7,
  },
  {
    path: "offers/:contractId/summary",
    component: SummaryPage,
    title: "proposalSummary",
    sequence: 8,
  },
  {
    path: "offers/:contractId/confirm",
    component: ConfirmIssuePage,
    title: "proposalIssueConfirm",
    sequence: 9,
  },
  {
    path: "offers/:contractId/:sign/outcome",
    component: OutcomeDetailPage,
    title: "outcomeDetail",
    sequence: 10,
  },
  {
    path: "offers/:contractId/detail",
    component: DetailPage,
    title: "detailPage",
    sequence: -3,
  },
];
