import { DocumentAttributes } from "documents/models/DocumentAttributes";
import { useEffect, useState } from "react";
import { documentService } from "commons/services/DocumentService";

interface UseMultipleDocumentMetadataReturn {
  contentDocuments: DocumentAttributes[];
  setContentDocuments: (contentDocuments: DocumentAttributes[]) => void;
  setDocumentIds: (documentIds: string[]) => void;
  contentDocumentsError?: boolean;
}

export default function useMultipleDocumentMetadata(): UseMultipleDocumentMetadataReturn {
  const [contentDocuments, setContentDocuments] =
    useState<DocumentAttributes[]>();
  const [contentDocumentsError, setContentDocumentsError] = useState(false);
  const [documentIds, setDocumentIds] = useState<string[]>();

  useEffect(() => {
    const fetchData = async () => {
      const result = await documentService.getDocumentsByIds(documentIds);
      setContentDocuments(result.data);
    };
    if (documentIds && documentIds.length > 0) {
      fetchData().catch(() => {
        setContentDocumentsError(true);
        setContentDocuments(undefined);
      });
    } else {
      setContentDocuments(undefined);
    }
  }, [documentIds]);

  return {
    contentDocuments,
    setContentDocuments,
    setDocumentIds,
    contentDocumentsError,
  };
}
