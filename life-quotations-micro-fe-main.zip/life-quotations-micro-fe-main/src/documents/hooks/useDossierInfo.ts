import { dossierService } from "commons/services/DossierService";
import { DossierInfo } from "documents/models/DossierInfo";

export default function useDossierInfo() {
  async function getInfo(contractId: string) {
    const result = await dossierService.getDossierDocumentsByEntityId(
      contractId
    );
    if (result) {
      const dossierInfo = result?.data as DossierInfo;
      return dossierInfo;
    }
  }

  async function getHistory(contractId: string, operationId: string) {
    const result = await dossierService.getDossierHistory(
      contractId,
      operationId
    );
    if (result) {
      const dossierInfo = result?.data as DossierInfo;
      return dossierInfo;
    }
  }

  return {
    getInfo,
    getHistory,
  };
}
