import { useEffect, useState } from "react";
import { DocumentAttributes } from "documents/models/DocumentAttributes";
import { InputDocument } from "documents/models/InputDocument";
import { dossierService } from "commons/services/DossierService";
import { documentService } from "commons/services/DocumentService";
import useInterval from "commons/hooks/useInterval";

export default function useDossierDocumentMetadata(
  dossierId: string,
  inputDocument: InputDocument,
  groupCode: string = null
) {
  const [file, setFile] = useState<File>();
  const [documentAttributes, setDocumentAttributes] =
    useState<DocumentAttributes>();
  const [errorMessage, setErrorMessage] = useState<string>();
  const [documentId, setDocumentId] = useState<string>();
  const [pollingData, setPollingData] = useState({
    error: false,
    terminated: false,
    polling: false,
  });

  let counterRetries = 0;
  const maxRetries = 2;
  const delay = 5000;

  const handleError = (e) => {
    let message = e.response?.data?.message ?? e.response?.data ?? "";
    setErrorMessage(message);
  };

  useEffect(() => {
    if (documentAttributes && file) {
      const request = groupCode
        ? dossierService.uploadToGroup(
            dossierId,
            groupCode,
            inputDocument.code,
            documentAttributes
          )
        : dossierService.uploadToDossier(
            dossierId,
            inputDocument.code,
            documentAttributes
          );

      request
        .then((res) => {
          const documentId = res && (res.data as string);
          if (documentId) {
            setDocumentId(documentId);
            documentService
              .put(documentId, file)
              .then(() => {
                setPollingData({
                  error: false,
                  terminated: true,
                  polling: false,
                });
              })
              .catch((err) => {
                let statusCode = err.response.status;
                if (statusCode == 504) {
                  setPollingData({
                    error: false,
                    terminated: false,
                    polling: true,
                  });
                } else {
                  handleError(err);
                }
              });
          }
        })
        .catch(handleError);
    }
  }, [documentAttributes, file]);

  useInterval(
    async () => {
      if (counterRetries > maxRetries) {
        counterRetries = 0;
        setPollingData({ error: true, terminated: true, polling: false });
        return;
      }
      try {
        const documentResult = await documentService.get(documentId);
        if (documentResult) {
          const updatedDocument: DocumentAttributes = documentResult.data;
          if (updatedDocument?.storagePath?.length > 0) {
            setPollingData({ error: false, terminated: true, polling: false });
          }
        }
      } catch (e) {
        // @ts-ignore
        console.error(e.response?.data?.message ?? e.response?.data);
        setPollingData({ error: true, terminated: true, polling: false });
        handleError(e);
      } finally {
        counterRetries++;
      }
    },
    pollingData.polling ? delay : null
  );
  return {
    setDocumentAttributes,
    setFile,
    errorMessage,
    pollingData,
  };
}
