import { useEffect, useState } from "react";
import { dossierService } from "commons/services/DossierService";
import {
  Dossier,
  DossierState,
  DossierUtils,
  SignData,
} from "documents/models/Dossier";
import useInterval from "commons/hooks/useInterval";
import { KeyValue } from "commons/models/YogaModels";
import { DocumentAttributes } from "documents/models/DocumentAttributes";
import { documentService } from "commons/services/DocumentService";
import { OutputDocument } from "documents/models/OutputDocument";

export default function useDossier(
  entityId: string,
  withInputDocuments: boolean = false,
  withOutputDocuments: boolean = false
) {
  const [dossier, setDossier] = useState<Dossier>(undefined);
  const [isDossierValid, setIsDossierValid] = useState<boolean>(false);
  const [error, setError] = useState<Error | undefined>(undefined);
  const [isPollingDossier, setPollingDossier] = useState<boolean>(false);
  const [startPolling, setStartPolling] = useState<boolean>(false);
  const [isPollingTerminated, setIsPollingTerminated] =
    useState<boolean>(false);
  const [dossierSignature, setDossierSignature] = useState({
    start: false,
    documentCodes: [],
    waitSentByEmail: false,
  });
  const [isPollingDossierSignature, setPollingDossierSignature] =
    useState<boolean>(false);
  const [pollingDossierTerminated, setPollingDossierTerminated] = useState<{
    success: boolean;
    sentByEmail: boolean;
  }>();

  const [areInputDocuments, setAreInputDocuments] =
    useState<boolean>(undefined);
  const [inputDocuments, setInputDocuments] =
    useState<DocumentAttributes[]>(undefined);
  const [areOutputDocuments, setAreOutputDocuments] =
    useState<boolean>(undefined);
  const [outputDocuments, setOutputDocuments] =
    useState<KeyValue<OutputDocument>>(undefined);
  const [outputDocumentsAttributes, setOutputDocumentsAttributes] =
    useState<KeyValue<DocumentAttributes>>(undefined);

  const [isPollingDocumentsTerminated, setIsPollingDocumentsTerminated] =
    useState<boolean>(false);
  const [isPollingDocuments, setIsPollingDocuments] = useState<boolean>(false);
  const [areDocumentsSigned, setAreDocumentsSigned] = useState<boolean>(false);

  const [isPollingSignData, setPollingSignData] = useState<boolean>(false);
  const [isPollingSignDataTerminated, setIsPollingSignDataTerminated] =
    useState<boolean>(false);
  const [signData, setSignData] = useState<KeyValue<SignData>>(undefined);

  const maxRetries = 5;
  const maxRetriesDocument = 5;
  const delay = 5000;

  const [counterRetries, setCounterRetries] = useState<number>(0);
  const [counterRetriesDocuments, setCounterRetriesDocuments] =
    useState<number>(0);
  const [checkDossier, setCheckDossier] = useState<boolean>(false);

  const getDossier = async (): Promise<void> => {
    return new Promise((resolve, reject) => {
      dossierService
        .getDossierByEntityId(entityId)
        .then((responseDossier) => {
          const dossier: Dossier = responseDossier && responseDossier.data;
          if (dossier && dossier?.state == DossierState.READY) {
            dossierService
              .checkEntityDossierValidity(entityId)
              .then((responseDossierValidity) => {
                const isDossierValid =
                  responseDossierValidity &&
                  responseDossierValidity.data &&
                  responseDossierValidity.data["dossierValid"];
                setDossier(dossier);
                setIsDossierValid(isDossierValid);
                setPollingDossier(false);
                setIsPollingTerminated(true);
                setStartPolling(false);
                setAreDocumentsSigned(
                  DossierUtils.areOutputDocumentsAllSigned(dossier)
                );
                resolve();
              })
              .catch((e) => {
                console.error(e);
                reject();
              });
          } else {
            reject();
          }
        })
        .catch((e) => {
          console.error(e);
          reject();
        });
    });
  };

  useEffect(() => {
    if (startPolling) {
      getDossier().catch(() => {
        setPollingDossier(true);
      });
    }
  }, [startPolling]);

  useInterval(
    async () => {
      if (counterRetries > maxRetries) {
        setIsPollingTerminated(true);
        setPollingDossier(false);
        return;
      }

      getDossier()
        .then(() => {
          setCounterRetries(0);
        })
        .catch(() => {
          setCounterRetries(counterRetries + 1);
        });
    },
    // Delay in milliseconds or null to stop it
    isPollingDossier ? delay : null
  );

  useEffect(() => {
    if (dossierSignature && dossierSignature.start) {
      setDossierSignature({ ...dossierSignature, start: false });
      // Reset the counterRetries
      setCounterRetries(0);
      setPollingDossierSignature(true);
    }
  }, [dossierSignature]);

  useInterval(
    async () => {
      if (counterRetries > maxRetries) {
        setCounterRetries(0);
        setPollingDossierSignature(false);
        setPollingDossierTerminated({
          success: false,
          sentByEmail: dossierSignature.waitSentByEmail,
        });
        return;
      }
      try {
        let result = await dossierService.getDossier(dossier.dossierId);

        if (result) {
          let dossier = result?.data as Dossier;
          setDossier(dossier);

          let areAllOutputDocumentsSigned =
            DossierUtils.areOutputDocumentsAllSigned(dossier);

          let allSignedDocuments =
            (dossier &&
              dossier.outputDocuments &&
              Object.values(dossier.outputDocuments)
                .filter((d) => d.signRequired && d.signed)
                .map((d) => d.code)) ||
            [];

          let areDocumentsSigned =
            allSignedDocuments &&
            dossierSignature.documentCodes.length >= 0 &&
            dossierSignature.documentCodes.every((c) =>
              allSignedDocuments.includes(c)
            );

          let allSentByEmailDocuments =
            (dossier && dossier.signData && Object.values(dossier.signData))
              .filter((s) => s.sentByEmail)
              .flatMap((s) => Object.keys(s.documents)) || [];

          let haveBeenSentByEmail =
            allSentByEmailDocuments &&
            dossierSignature.waitSentByEmail &&
            dossierSignature.documentCodes.length >= 0 &&
            dossierSignature.documentCodes.every((c) =>
              allSentByEmailDocuments.includes(c)
            );

          if (
            areDocumentsSigned ||
            haveBeenSentByEmail ||
            areAllOutputDocumentsSigned
          ) {
            let resultDocuments = await documentService.getContentDocuments(
              entityId,
              {}
            );
            const documents = resultDocuments.data as DocumentAttributes[];
            setOutputDocuments(getOutputDocuments(dossier, documents));
            setOutputDocumentsAttributes(
              getOutputDocumentsAttributes(documents)
            );

            setPollingDossierSignature(false);
            setAreDocumentsSigned(areAllOutputDocumentsSigned);
            setPollingDossierTerminated({
              success: true,
              sentByEmail: dossierSignature.waitSentByEmail,
            });
          }
        }
      } catch (e) {
        console.error(e);
      } finally {
        setCounterRetries(counterRetries + 1);
      }
    },
    // Delay in milliseconds or null to stop it
    isPollingDossierSignature ? delay : null
  );

  const areValidOutputDocuments = (
    dossier: Dossier,
    areOutputDocuments: boolean
  ): boolean =>
    DossierUtils.areOutputDocumentsReady(dossier) &&
    withOutputDocuments &&
    areOutputDocuments;

  useEffect(() => {
    const fetchData = async () => {
      if (
        isPollingTerminated &&
        dossier &&
        ((inputDocuments == undefined && withInputDocuments) ||
          (outputDocuments == undefined && withOutputDocuments))
      ) {
        documentService
          .getContentDocuments(entityId, {})
          .then((result) => {
            let documents = result.data as DocumentAttributes[];

            const areInputDocuments = DossierUtils.hasInputDocuments(dossier);
            const areMandatoryInputDocuments =
              DossierUtils.hasMandatoryInputDocuments(dossier);
            setAreInputDocuments(areInputDocuments);
            let inputDocuments = getInputDocuments(dossier, documents);

            if (
              withInputDocuments &&
              areInputDocuments &&
              inputDocuments &&
              inputDocuments.length > 0
            ) {
              setInputDocuments(inputDocuments);
            } else if (
              areMandatoryInputDocuments &&
              withInputDocuments &&
              (!inputDocuments || inputDocuments.length == 0)
            ) {
              setIsPollingDocuments(true);
            } else {
              setInputDocuments([]);
            }

            const areOutputDocuments = DossierUtils.hasOutputDocuments(dossier);
            setAreOutputDocuments(areOutputDocuments);
            let outputDocuments = getOutputDocuments(dossier, documents);

            if (areValidOutputDocuments(dossier, areOutputDocuments)) {
              setOutputDocuments(outputDocuments);
              setOutputDocumentsAttributes(
                getOutputDocumentsAttributes(documents)
              );
            } else if (
              withOutputDocuments &&
              (!outputDocuments ||
                Object.values(outputDocuments).length == 0 ||
                !DossierUtils.areOutputDocumentsReady(dossier))
            ) {
              setIsPollingDocuments(true);
            } else {
              setOutputDocuments({});
              setOutputDocumentsAttributes({});
            }
          })
          .catch((e) => {
            console.error(e);
          });
      }
    };

    fetchData().catch((e) => {
      console.error(e);
    });
  }, [isPollingTerminated]);

  const getInputDocuments = (
    dossier: Dossier,
    documents: DocumentAttributes[]
  ): DocumentAttributes[] => {
    let inputDocumentsData = documents.filter((doc) => !doc.output);
    // Rename the documents with the name found in the dossier
    inputDocumentsData.forEach((doc) => {
      let foundDocs = Object.values(dossier.inputDocuments).filter(
        (doc1) =>
          doc1.documentId == doc.documentId ||
          (doc1.multipleDocumentIds &&
            doc1.multipleDocumentIds.includes(doc.documentId))
      );
      if (foundDocs.length > 0) {
        doc.name = foundDocs[0].name;
      } else {
        Object.values(dossier.groups).forEach((group) => {
          Object.values(group.inputDocuments).forEach((doc1) => {
            if (
              doc1.documentId == doc.documentId ||
              (doc1.multipleDocumentIds &&
                doc1.multipleDocumentIds.includes(doc.documentId))
            ) {
              doc.name = doc1.name;
            }
          });
        });
      }
    });
    return inputDocumentsData;
  };

  const getOutputDocuments = (
    dossier: Dossier,
    documents: DocumentAttributes[]
  ) => {
    const getValueFromMap = (
      documentsMap: KeyValue<DocumentAttributes>,
      documentId: string,
      attribute: string
    ) => {
      let value = null;
      if (documentsMap && Object.keys(documentsMap).includes(documentId)) {
        value = documentsMap[documentId][attribute];
      }
      return value;
    };
    const outputDocumentsMap = documents
      .filter((doc) => doc.output)
      .reduce(
        (a, document) => ({
          ...a,
          [document.documentId]: document,
        }),
        {}
      );

    let outputDocumentsData = undefined;

    if (outputDocumentsMap && Object.values(outputDocumentsMap).length > 0) {
      outputDocumentsData = Object.values(dossier.outputDocuments).reduce(
        (a, document) => ({
          ...a,
          [document.documentId]: {
            signed: document.signed,
            signRequired: document.signRequired,
            contentType: getValueFromMap(
              outputDocumentsMap,
              document.documentId,
              "contentType"
            ),
            title: getValueFromMap(
              outputDocumentsMap,
              document.documentId,
              "title"
            ),
            documentId: document.documentId,
            lastUpdateInstant: getValueFromMap(
              outputDocumentsMap,
              document.documentId,
              "lastUpdateInstant"
            ),
            code: getValueFromMap(
              outputDocumentsMap,
              document.documentId,
              "code"
            ),
          },
        }),
        {}
      );
    }

    return outputDocumentsData;
  };

  const getOutputDocumentsAttributes = (
    documentAttributes: DocumentAttributes[]
  ) =>
    documentAttributes
      .filter((d) => d.output == true)
      .reduce((a, document) => ({ ...a, [document.code]: document }), {});

  useInterval(
    async () => {
      if (counterRetriesDocuments > maxRetriesDocument) {
        if (checkDossier) {
          setCounterRetriesDocuments(0);
          setIsPollingDocumentsTerminated(true);
          setIsPollingDocuments(false);
        } else {
          setCheckDossier(true);
        }
        return;
      }
      try {
        const dossierResult = await dossierService.getDossierByEntityId(
          entityId
        );
        if (dossierResult) {
          const dossier: Dossier = dossierResult.data;
          if (dossier?.state == DossierState.READY) {
            setDossier(dossier);
            let result = await documentService.getContentDocuments(
              entityId,
              {}
            );
            let documents = result.data as DocumentAttributes[];

            const areInputDocuments = DossierUtils.hasInputDocuments(dossier);
            const areMandatoryInputDocuments =
              DossierUtils.hasMandatoryInputDocuments(dossier);
            setAreInputDocuments(areInputDocuments);
            let inputDocuments = getInputDocuments(dossier, documents);
            const validInputDocuments =
              !areMandatoryInputDocuments ||
              (withInputDocuments &&
                areInputDocuments &&
                inputDocuments &&
                inputDocuments.length > 0);

            if (validInputDocuments) {
              setInputDocuments(inputDocuments);
            }

            const areOutputDocuments = DossierUtils.hasOutputDocuments(dossier);
            setAreOutputDocuments(areOutputDocuments);
            let outputDocuments = getOutputDocuments(dossier, documents);

            let validOutputDocuments = areValidOutputDocuments(
              dossier,
              areOutputDocuments
            );

            if (validOutputDocuments) {
              setOutputDocuments(outputDocuments);
              setOutputDocumentsAttributes(
                getOutputDocumentsAttributes(documents)
              );
            }

            if (validInputDocuments && validOutputDocuments) {
              setIsPollingDocuments(false);
              setIsPollingDocumentsTerminated(true);
              setCounterRetriesDocuments(0);
            }
          }
        }
      } catch (e) {
        // @ts-ignore
        setError(e.response?.data?.message);
      } finally {
        setCounterRetriesDocuments(counterRetriesDocuments + 1);
      }
    },
    isPollingDocuments ? delay : null
  );

  useInterval(
    async () => {
      if (counterRetriesDocuments > maxRetriesDocument) {
        setCounterRetriesDocuments(0);
        setIsPollingSignDataTerminated(true);
        setPollingSignData(false);
        return;
      }
      try {
        const dossierResult = await dossierService.getDossierByEntityId(
          entityId
        );
        if (dossierResult) {
          const dossier: Dossier = dossierResult.data;
          if (dossier?.state == DossierState.READY) {
            setDossier(dossier);
            if (DossierUtils.haveAllUrlsSignData(dossier)) {
              let result = await documentService.getContentDocuments(
                entityId,
                {}
              );
              let documents = result.data as DocumentAttributes[];
              setOutputDocuments(getOutputDocuments(dossier, documents));
              setOutputDocumentsAttributes(
                getOutputDocumentsAttributes(documents)
              );
              setSignData(dossier.signData);
              setPollingSignData(false);
              setIsPollingSignDataTerminated(true);
              setCounterRetriesDocuments(0);
            }
          }
        }
      } catch (e) {
        // @ts-ignore
        setError(e.response?.data?.message);
      } finally {
        setCounterRetriesDocuments(counterRetriesDocuments + 1);
      }
    },
    isPollingSignData ? delay : null
  );

  useEffect(() => {
    const sendCheckDossierDocuments = async () => {
      await dossierService.checkDossierDocuments(dossier?.dossierId, true);
      setCounterRetriesDocuments(0);
      setIsPollingDocumentsTerminated(false);
      setIsPollingDocuments(true);
    };

    if (checkDossier) {
      sendCheckDossierDocuments().catch(console.error);
    }
  }, [checkDossier]);

  return {
    dossier,
    isDossierValid,
    error,
    setStartPolling,
    isPollingTerminated,
    setDossier,
    setDossierSignature,
    setPollingSignData,
    isPollingDossierSignature,
    isPollingDocuments,
    isPollingDocumentsTerminated,
    isPollingSignDataTerminated,
    isPollingSignData,
    pollingDossierTerminated,
    inputDocuments,
    areInputDocuments,
    outputDocuments,
    outputDocumentsAttributes,
    areOutputDocuments,
    areDocumentsSigned,
    signData,
  };
}
