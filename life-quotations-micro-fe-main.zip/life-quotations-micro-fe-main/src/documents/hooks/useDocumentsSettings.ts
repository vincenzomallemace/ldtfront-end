import { useEffect, useState } from "react";
import { documentService } from "commons/services/DocumentService";
import { KeyValue } from "commons/models/YogaModels";

interface UseDocumentsSettingsReturn {
  settings: any;
  setSettings: (settings: any) => void;
  settingsError?: boolean;
}

export default function useDocumentsSettings(): UseDocumentsSettingsReturn {
  const [settings, setSettings] = useState({});
  const [settingsError, setSettingsError] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      const result = await documentService.getSettings();
      const data = result.data;

      if (data["allowedMimeTypesWithExtensions"]) {
        Object.entries(
          data["allowedMimeTypesWithExtensions"] as KeyValue<string[]>
        ).forEach(([mimeType, extensions]) => {
          let checkedExtensions = extensions.map((extension) => {
            if (extension.startsWith(".")) {
              return extension;
            } else {
              return "." + extension;
            }
          });
          data["allowedMimeTypesWithExtensions"][mimeType] = checkedExtensions;
        });
      }

      setSettings(data);
    };
    fetchData().catch(() => {
      setSettingsError(true);
    });
  }, []);

  return {
    settings,
    setSettings,
    settingsError,
  };
}
