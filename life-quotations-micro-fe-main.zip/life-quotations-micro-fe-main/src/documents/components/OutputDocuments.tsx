import { Loader } from "@aws-amplify/ui-react";
import { PencilIcon } from "@heroicons/react/outline";
import { XCircleIcon } from "@heroicons/react/solid";
import classNames from "classnames";
import { config } from "commons/Configuration";
import YogaLoader from "commons/components/Loader";
import { YogaButton } from "commons/components/YogaButton";
import YogaCard from "commons/components/YogaCard";
import { YogaMessage } from "commons/components/YogaMessage";
import useContractDossier from "commons/hooks/useContractDossier";
import { ConfirmModal } from "commons/modals/ConfirmModal";
import { KeyValue } from "commons/models/YogaModels";
import { Fragment, useEffect, useState } from "react";
import { FormattedMessage } from "react-intl";
import DocumentBox from "./DocumentBox";

interface OutputDocumentsProps {
  user: any;
  contractId: string;
  signatureEnabled: boolean;
  holoSign?: boolean;
  onChangeCheck?: (value: boolean) => void;
  setPageDossierId: (value: string) => void;
}

export default function OutputDocuments({
  /* user, */
  contractId,
  signatureEnabled,
  setPageDossierId,
  holoSign = false,
  onChangeCheck,
}: OutputDocumentsProps) {
  const {
    dossier,
    setStartPolling,
    documents,
    setDossierSignature,
    isPollingTerminated,
    isPollingDossierSignature,
  } = useContractDossier(contractId, true);
  /*   const { changeLoading } = useContext(Context); */

  const [documentsData, setDocumentsData] = useState<KeyValue<any>>();
  const [isSignModalOpen, setIsSignModalOpen] = useState<boolean>();
  const [documentErrors, setDocumentErrors] = useState<KeyValue<boolean>>();

  const externalDocsNeeded = config.EXTERNAL_POLICY_DOCS_NEEDED === "enabled";

  const isOtpEnabled = config.OTP_SIGN === "enabled";

  const [checks, setChecks] = useState<boolean[][]>();

  const handleChecks = (tag: number, index, value: boolean) => {
    setChecks((old) => {
      // const array = old;
      // array[tag][index] = value;

      // const areAllTrue = array.every((tagRow) => tagRow.every((val) => val));
      // onChangeCheck(areAllTrue);
      // return array;
      const array = old!.map((row) => [...row]);
      array[tag][index] = value;
      const areAllTrue = array.every((tagRow) => tagRow.every((val) => val));
      onChangeCheck(areAllTrue);
      return array;
    });
  };

  useEffect(() => {
    setStartPolling(true);
  }, []);

  useEffect(() => {
    if ((dossier || !externalDocsNeeded) && documents) {
      const documentsMap = dossier
        ? documents.reduce(
            (a, document) => ({
              ...a,
              [document.documentId]: {
                ...document,
                signRequired:
                  dossier.outputDocuments[document.code].signRequired,
                signed: dossier.outputDocuments[document.code].signed,
              },
            }),
            {}
          )
        : documents.reduce(
            (a, document) => ({
              ...a,
              [document.documentId]: document,
            }),
            {}
          );

      const documentsData = externalDocsNeeded
        ? Object.values(dossier.outputDocuments).reduce(
            (a, document) => ({
              ...a,
              [document.outputDocumentId]: {
                signed: document.signed,
                signRequired: document.signRequired,
                contentType:
                  documentsMap[document.outputDocumentId].contentType,
                title: documentsMap[document.outputDocumentId].title,
                documentId: document.outputDocumentId,
                tags: document.tags,
                output: documentsMap[document.outputDocumentId].output,
              },
            }),
            {}
          )
        : documentsMap;

      const documentsInTags = Object.values(documentsData)
        .filter((document: any) => document.output)
        .reduce((previous: { [tag: string]: any }, current: any) => {
          let tag = "noTags";
          if (current.tags && current.tags.length) {
            tag = current.tags[0];
          }
          if (!previous[tag]) {
            previous[tag] = [];
          }
          previous[tag] = previous[tag].concat(current);
          return previous;
        }, {});

      const checks = Object.values(documentsInTags).map((tag) =>
        new Array(tag.length).fill(false)
      );
      setDocumentsData(documentsInTags);
      setChecks(checks);
      let documentErrors = Object.keys(documentsData).reduce(
        (a, key) => ({
          ...a,
          [key]: false,
        }),
        {}
      );
      setDocumentErrors(documentErrors);

      if (dossier) {
        setPageDossierId(dossier.dossierId);
      }
    }
  }, [dossier, documents]);

  function onClose() {
    setIsSignModalOpen(false);
    setDossierSignature(true);
  }

  let areDocumentsSigned =
    dossier &&
    dossier.outputDocuments &&
    Object.values(dossier.outputDocuments)
      .filter((document) => document.signRequired)
      .every((document) => document.signed);

  /* const download = async (document: DocumentAttributes) => {
    if (document.contentType && document.documentId) {
      try {
        changeLoading(1);
        return await downloadDocumentFilename(
          document.contentType,
          document.documentId,
          user,
          document.title
        );
      } finally {
        changeLoading(-1);
      }
    }
    return Promise.reject();
  }; */

  /* const downloadAll = () => {
    if (!documents) {
      return;
    }
    documents.forEach(download);
  }; */

  const customCheckbox = (tagIndex: number, index: number) => {
    if (
      holoSign &&
      checks &&
      checks.length > tagIndex &&
      checks[tagIndex] &&
      checks[tagIndex].length > index
    ) {
      return (
        <div className="items-center cursor-pointer">
          <label className="container">
            <input
              key={Math.random()}
              type="checkbox"
              defaultChecked={checks[tagIndex][index]}
              onChange={(e) => handleChecks(tagIndex, index, e.target.checked)}
            />
            <span className="h-8 w-8 ml-auto mr-4 flex-shrink-0 checkmark" />
          </label>
        </div>
      );
    }
    return undefined;
  };

  return (
    <>
      <YogaLoader loading={isPollingDossierSignature} />
      <YogaCard
        uniformPadding
        data-qa="documents-card"
        error={(!documents || documents.length == 0) && isPollingTerminated}
        className={classNames("border-background")}
      >
        {documents && documents.length > 0 && (
          <div className="flex flex-col gap-y-4" data-qa="documents-container">
            <div
              className="flex items-center justify-between"
              data-qa="documents-header"
            >
              <div
                data-qa="documents-title"
                className="text-title-text font-bold"
              >
                <FormattedMessage id="downloadableDocuments" />
              </div>
              <div className="flex items-center gap-x-2.5" data-qa="buttons">
                {/* {dossier.outputDocuments &&
                  Object.keys(dossier.outputDocuments).length > 1 && (
                    <YogaButton
                      position="inner"
                      data-qa="download-all-documents-button"
                      outline
                      action={downloadAll}
                    >
                      <DownloadIcon className="w-5 mr-2 -ml-1 flex-shrink-0" />
                      <FormattedMessage id="downloadDocuments" />
                    </YogaButton>
                  )} */}

                {signatureEnabled &&
                  isOtpEnabled &&
                  externalDocsNeeded &&
                  !areDocumentsSigned && (
                    <YogaButton
                      position="inner"
                      action={() => setIsSignModalOpen(true)}
                      data-qa="digital-sign-button"
                      outline
                    >
                      <PencilIcon className="w-5 mr-2 -ml-1 flex-shrink-0" />
                      <FormattedMessage id="digitalSign" />
                    </YogaButton>
                  )}
              </div>
            </div>
            {documentsData &&
              Object.values(documentsData).map((documentArray: any[]) =>
                documentArray.map((document) => {
                  return (
                    documentErrors[document.documentId] && (
                      <div
                        id={`document-${document.documentId}-error-message`}
                        key={`document-${document.documentId}-error-message`}
                        data-qa={`document-${document.documentId}-error-message`}
                      >
                        <YogaMessage type="error" position="inner">
                          <p>
                            <FormattedMessage
                              id="documentError"
                              values={{ title: document.title }}
                            />
                          </p>
                        </YogaMessage>
                      </div>
                    )
                  );
                })
              )}
            {documentsData && Object.keys(documentsData).length > 0 && (
              <div className="">
                {Object.entries(documentsData).map(
                  ([tag, documents], tagIndex) => (
                    <div
                      key={`${tag}-section`}
                      data-qa={`${tag}-section`}
                      className="p-4 rounded-lg bg-box-background border-2 border-background shadow"
                    >
                      {tag !== "noTags" && (
                        <div
                          data-qa={`${tag}-title`}
                          className="mb-4 font-medium"
                        >
                          <FormattedMessage id={tag} />
                        </div>
                      )}
                      <div
                        data-qa={`${tag}-documents`}
                        className="grid grid-cols-2 lg:grid-cols-3 gap-4"
                      >
                        {Object.values(documents).map(
                          (document: any, index: number) => (
                            <Fragment key={document.documentId}>
                              <DocumentBox
                                key={document.documentId}
                                document={document}
                                dossierId={dossier?.dossierId}
                                setDocumentErrors={setDocumentErrors}
                                documentErrors={documentErrors}
                                holoSign={holoSign}
                                border={checks[tagIndex][index]}
                                CheckComponent={() =>
                                  customCheckbox(tagIndex, index)
                                }
                              />
                            </Fragment>
                          )
                        )}
                      </div>
                    </div>
                  )
                )}
              </div>
            )}
          </div>
        )}

        {(!documents || documents.length == 0) && !isPollingTerminated && (
          <div className="flex items-center" data-qa="documentsLoading">
            <Loader
              className="w-6 h-6 mr-2 flex-shrink-0"
              emptyColor="var(--box-background)"
              filledColor="var(--title-text)"
              fr={undefined}
            />
            <FormattedMessage id="documentsLoading" />
          </div>
        )}
        {(!documents || documents.length == 0) && isPollingTerminated && (
          <div
            className="flex text-title-text items-center"
            data-qa="documentsError"
          >
            <XCircleIcon className="w-6 h-6 mr-2 text-error flex-shrink-0" />
            <FormattedMessage id="documentsError" />
          </div>
        )}
        {holoSign && <FormattedMessage id="outputDocumentHoloMessage" />}
      </YogaCard>
      {isSignModalOpen && (
        <ConfirmModal
          isOpen={isSignModalOpen}
          onClose={onClose}
          showCancelButton={false}
          largeModal={true}
          title="signatureModalTitle"
        >
          <iframe width="100%" height="100%" src={dossier.signLink} />
        </ConfirmModal>
      )}
    </>
  );
}
