import { DocumentCardSkeleton } from "./DocumentCardSkeleton";
import { DossierUtils } from "documents/models/Dossier";
import YogaCard from "commons/components/YogaCard";
import { FormattedMessage } from "react-intl";
import DossierGroupUploader from "./DossierGroupUploader";
import { InputDocument } from "documents/models/InputDocument";
import React, { useEffect, useState } from "react";
import useDossier from "documents/hooks/useDossier";
import useDocumentsSettings from "documents/hooks/useDocumentsSettings";
import useMultipleDocumentMetadata from "documents/hooks/useMultipleDocumentMetadata ";
import { KeyValue } from "commons/models/YogaModels";
import { DocumentAttributes } from "documents/models/DocumentAttributes";
import { DossierFileChecker } from "./DossierFileChecker";

interface DocumentsCheckProps {
  contractId: string;
  contractNumber: string;
  setIsDossierLoaded: (value: boolean) => void;
  setIsDossierValid: (value: boolean) => void;
  setPageDossierId: (value: string) => void;
  onChangeCheck: (value: boolean) => void;
}

export const DocumentsCheck = ({
  contractId,
  contractNumber,
  setIsDossierLoaded,
  setIsDossierValid,
  setPageDossierId,
  onChangeCheck,
}: DocumentsCheckProps) => {
  const { dossier, setStartPolling, isPollingTerminated, isDossierValid } =
    useDossier(contractId, true, false);

  const { contentDocuments, setDocumentIds } = useMultipleDocumentMetadata();
  const { settings } = useDocumentsSettings();
  const [documentsMap, setDocumentsMap] =
    useState<KeyValue<DocumentAttributes>>();

  const [checks, setChecks] = useState<number>(0);
  const [nOfMandatories, setNofMandatories] = useState<number>(0);
  useEffect(() => {
    if (contractId) {
      setStartPolling(true);
    }
  }, [contractId]);

  useEffect(() => {
    setIsDossierValid(isDossierValid);
    console.log("is valid? ", isDossierValid);
  }, [isDossierValid]);

  useEffect(() => {
    if (isPollingTerminated) {
      setIsDossierLoaded(!!dossier);
    }
  }, [isPollingTerminated]);

  useEffect(() => {
    if (dossier) {
      let docsIds = DossierUtils.getDocumentIds(dossier.inputDocuments);
      let groupsDocsIds = DossierUtils.sortGroups(dossier).flatMap((g) => {
        return DossierUtils.getDocumentIds(g.inputDocuments);
      });
      setDocumentIds(docsIds.concat(groupsDocsIds));
      const mandatoryLength = Object.values(dossier.inputDocuments).filter(
        (val) => val.mandatory && val.visible
      ).length;
      setNofMandatories(mandatoryLength);
      setPageDossierId(dossier.dossierId);
    } else {
      setDocumentIds([]);
    }
  }, [dossier]);

  useEffect(() => {
    setDocumentsMap(
      contentDocuments?.reduce(
        (a, document) => ({
          ...a,
          [document.documentId]: document,
        }),
        {}
      )
    );
  }, [contentDocuments]);

  const handleChecks = (value: boolean) => {
    setChecks((old) => {
      let previous = old;
      if (value) {
        previous += 1;
      } else {
        previous -= 1;
      }

      onChangeCheck(previous === nOfMandatories);
      return previous;
    });
  };

  function interceptRestricUserAccess(input: InputDocument): InputDocument{ 
    if(input.restrictUserAccess){
      input.mandatory = true
    }
    return input
  }

  return (
    <>
      {dossier && !DossierUtils.hasInputDocuments(dossier) && (
        <YogaCard
          uniformPadding
          data-qa="input-documents-not-visible"
          id="input-documents-not-visible"
        >
          <div className="text-action-disabled">
            <FormattedMessage id="noDocumentsToCheck" />
          </div>
        </YogaCard>
      )}
      {!dossier && <DocumentCardSkeleton />}
      {dossier && DossierUtils.hasInputDocuments(dossier) && (
        <YogaCard uniformPadding data-qa="check-documents" id="check-documents">
          <div className="flex flex-col gap-y-4">
            <>
              <div className="font-bold">
                <FormattedMessage id="documentsToCheck" />
              </div>
              {DossierUtils.sortGroups(dossier).map((group) => (
                <DossierGroupUploader
                  documentsMap={documentsMap}
                  settings={settings}
                  dossierId={dossier.dossierId}
                  entityId={contractId}
                  entityNumber={contractNumber}
                  group={group}
                  key={group.code}
                  action={() => {
                    setStartPolling(true);
                  }}
                />
              ))}
              {checks !== undefined && (
                <div className="grid grid-cols-2 lg:grid-cols-2 gap-x-8 lg:gap-y-4 gap-y-8">
                  {DossierUtils.sortInputDocuments(dossier.inputDocuments).map(
                    (inputDocument: InputDocument) => {
                      return (
                        <DossierFileChecker
                          inputDocument={interceptRestricUserAccess(inputDocument)}
                          fireAction={(value) => handleChecks(value)}
                          key={inputDocument.code}
                        />
                      );
                    }
                  )}
                </div>
              )}
            </>
          </div>
        </YogaCard>
      )}
    </>
  );
};
