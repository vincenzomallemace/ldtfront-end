import YogaCard from "commons/components/YogaCard";
import { AdviceDocument } from "documents/models/AdviceInformation";
import { DocumentTextIcon } from "@heroicons/react/outline";
import { FormattedMessage } from "react-intl";
import { Loader } from "@aws-amplify/ui-react";
import { useEffect, useState } from "react";
import classNames from "classnames";

interface AdviceDocumentsProps {
  documents: AdviceDocument[];
  holoSign?: boolean;
  error?: boolean;
  onChangeCheck?: (value: boolean) => void;
}

export default function AdviceDocuments({
  documents,
  holoSign = false,
  error,
  onChangeCheck,
}: AdviceDocumentsProps) {
  const [checks, setChecks] = useState<boolean[]>();

  const handleChecks = (index: number, value: boolean) => {
    setChecks((old) => {
      const array = old.map((val, i) => (index === i ? value : val));
      onChangeCheck(!array.some((b) => !b));
      return array;
    });
  };

  useEffect(() => {
    if (!documents) {
      return;
    }
    if (documents.length === 0) {
      onChangeCheck(true);
      return;
    }
    if (!checks || checks.length === 0) {
      setChecks(new Array(documents.length).fill(false));
    }
  }, [documents, checks]);

  return (
    <>
      <YogaCard uniformPadding data-qa="advice-documents-card">
        <div className="flex flex-col gap-y-4">
          <div className="inline-flex" data-qa="documents-header">
            <div data-qa="advice-documents-title" className="font-bold">
              <FormattedMessage id="adviceDocuments" />
            </div>
            <p>
              {" "}
              &nbsp;-{" "}
              <i>
                <FormattedMessage id="adviceDocumentsDescription" />
              </i>
            </p>
          </div>
          {documents &&
            documents.length > 0 &&
            checks &&
            checks.length === documents.length && (
              <div
                className="grid grid-cols-2 lg:grid-cols-3 gap-x-8 lg:gap-y-4 gap-y-8"
                data-qa="documents-grid"
              >
                {documents.map((d, index) => (
                  <div
                    key={index}
                    data-qa={"document-" + index}
                    // className="flex flex-row justify-between border-2 border-title-text rounded-lg p-4 items-center"
                    className={classNames("flex flex-row justify-between border-2 rounded-lg p-4 items-center", {
                      "border-title-text":
                        !holoSign,
                      "border-error": holoSign && !checks[index],
                      "border-success": holoSign && checks[index],
                    })}
                    //className="flex flex-row cursor-pointer justify-between border-2 border-primary rounded-lg p-4 items-center"
                  >
                    <div
                      className="flex flex-row items-center"
                      data-qa="document"
                    >
                      <DocumentTextIcon className="h-6 w-6 flex-shrink-0 mr-2 text-title-text" />
                      <div className="text-body-text font-light text-sm shrink flex-1 mr-2">
                        {d.descrizioneModelloPdf}
                      </div>
                    </div>
                    {holoSign && (
                      <div className="items-center cursor-pointer">
                        <label className="container">
                          <input
                            type="checkbox"
                            checked={checks[index]}
                            onChange={(e) =>
                              handleChecks(index, e.target.checked)
                            }
                          />
                          <span className="h-8 w-8 ml-auto mr-4 flex-shrink-0 checkmark" />
                        </label>
                      </div>
                    )}
                  </div>
                ))}{" "}
              </div>
            )}
          {documents && documents.length == 0 && (
            <div
              className="flex text-title-text items-center"
              data-qa="documentsLoading"
            >
              <FormattedMessage id="noResults" />
            </div>
          )}
          {error && (
            <>
              <FormattedMessage id="errorPageTitle" />
            </>
          )}
          {error === undefined && (
            <div
              className="flex text-title-text items-center"
              data-qa="documentsLoading"
            >
              <Loader
                className="w-6 h-6 mr-2 flex-shrink-0"
                emptyColor="var(--box-background)"
                filledColor="var(--title-text)"
                fr={undefined}
              />
              <FormattedMessage id="documentsLoading" />
            </div>
          )}
        </div>
      </YogaCard>
    </>
  );
}
