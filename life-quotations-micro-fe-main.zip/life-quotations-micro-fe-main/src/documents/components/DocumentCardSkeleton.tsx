import { FormattedMessage } from "react-intl";
import YogaCard from "commons/components/YogaCard";
import YogaSkeleton from "commons/components/YogaSkeleton";

export function DocumentCardSkeleton() {
  return (
    <YogaCard
      data-qa="skeleton-input-documents"
      className="mb-8 h-full flex flex-col"
    >
      <FormattedMessage id="documentsLoading" />
      <DocumentSkeleton />
      <DocumentSkeleton />
    </YogaCard>
  );
}

function DocumentSkeleton() {
  return (
    <div data-qa="input-document" className="rounded-xl w-full mt-4">
      <YogaSkeleton position="inner" className="h-14" />
    </div>
  );
}
