import { Loader } from "@aws-amplify/ui-react";
import { DocumentTextIcon, DownloadIcon } from "@heroicons/react/outline";
import classNames from "classnames";
import { KeyValue } from "commons/models/YogaModels";
import { downloadDocumentOfDossier } from "documents/DocumentUtils";
import { useEffect, useState } from "react";
import { FormattedMessage } from "react-intl";

interface DocumentBoxProps {
  document: any;
  dossierId: string;
  setDocumentErrors: any;
  documentErrors: KeyValue<boolean>;
  holoSign?: boolean;
  border?: boolean;
  CheckComponent?: () => JSX.Element;
}

export default function DocumentBox({
  document,
  dossierId,
  setDocumentErrors,
  documentErrors,
  holoSign,
  border,
  CheckComponent,
}: DocumentBoxProps) {
  const [documentDownloading, setDocumentDowloading] = useState<boolean>(false);

  useEffect(() => {
    if (documentDownloading) {
      setDocumentErrors({ ...documentErrors, [document.documentId]: false });
      downloadDocumentOfDossier(
        document.contentType,
        document.documentId,
        dossierId
      )
        .then(() => {
          setDocumentErrors({
            ...documentErrors,
            [document.documentId]: false,
          });
        })
        .catch(() => {
          setDocumentErrors({ ...documentErrors, [document.documentId]: true });
        })
        .finally(() => setDocumentDowloading(false));
    }
  }, [documentDownloading]);

  return (
    <div
      data-qa={"document-" + document.documentId}
      key={document.documentId}
      className={holoSign ? 
        classNames(
          "flex justify-between rounded-lg px-4 py-3 items-center bg-box-background ring-2",
          border && "ring-success",
          !border && "ring-error"
        ) :
        classNames(
        "flex justify-between rounded-lg px-4 py-3 items-center bg-box-background ring-2",
        !document.signRequired && "ring-body-text",
        document.signRequired && document.signed && "ring-success",
        // document.signRequired && !document.signed && "ring-draft"
        document.signRequired && !document.signed && "ring-body-text"
      )}
      /*onClick={() => setDocumentDowloading(true)}*/
    >
      <div className="flex items-center" data-qa="document">
        <div className="flex gap-2 items-center">
          <DocumentTextIcon className="h-6 w-6 flex-shrink-0 text-title-text" />
          <p data-qa="document-title" className="font-light text-sm">
            <FormattedMessage id={document.title} />
          </p>
          {document.signRequired && !document.signed && (
            <p
              className="text-draft text-xs font-bold"
              data-qa="document-sign-status"
            >
              {/* <FormattedMessage id="signRequired" /> */}
            </p>
          )}
          {document.signRequired && document.signed && (
            <p
              className="text-success text-xs font-bold"
              data-qa="document-sign-status"
            >
              <FormattedMessage id="digitallySigned" />
            </p>
          )}
        </div>
      </div>
      {documentDownloading && (
        <Loader
          className="w-8 h-8 flex-shrink-0"
          emptyColor="var(--box-background)"
          filledColor="var(--title-text)"
          fr={undefined}
        />
      )}
      {!documentDownloading && (
        <DownloadIcon
          className="w-8 flex-shrink-0 text-primary cursor-pointer"
          onClick={() => setDocumentDowloading(true)}
        />
      )}
      {CheckComponent && <CheckComponent />}
    </div>
  );
}
