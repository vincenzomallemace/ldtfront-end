import { DocumentTextIcon, CheckCircleIcon, TrashIcon, UploadIcon } from "@heroicons/react/solid";
import classnames from "classnames";
import { ConfirmModal } from "commons/modals/ConfirmModal";
import { KeyValue } from "commons/models/YogaModels";
import { documentPreview } from "documents/DocumentUtils";
import { DocumentAttributes } from "documents/models/DocumentAttributes";
import { InputDocument } from "documents/models/InputDocument";
import { useState, useEffect } from "react";
import { DropzoneState, useDropzone } from "react-dropzone";
import { useIntl, FormattedMessage } from "react-intl";

interface DocumentInputBoxProps {
  inputDocument: InputDocument;
  settings: KeyValue<any>;
}

export default function DocumentInputBox({ inputDocument, settings }: DocumentInputBoxProps) {
  const [file, setFile] = useState<File>(undefined);
  const [content, setContent] = useState<DocumentAttributes>(undefined);
  const [inputDoc, setInputDoc] = useState<InputDocument>(inputDocument);
  const dropzone = useDropzone({
    onDrop: (acceptedFiles: File[]) => {
      acceptedFiles.forEach((tmp: File) => {
        // to replace
        setContent(
          fileToDocumentAttributes(tmp, "123", "contract", "io", {
            output: true,
          })
        );
        setFile(tmp);
        setInputDoc({ ...inputDoc, documentId: "valid" });

        console.log("loaded file: ", file);
      });
    },
    // to replace
    accept: settings.allowedMimeTypesWithExtensions,
    noClick: true,
    noKeyboard: true,
    maxFiles: settings.maxFiles,
    maxSize: settings.documentSizeMax,
  });

  function onDelete() {
    setFile(undefined);
    setContent(undefined);
    setInputDoc({ ...inputDoc, documentId: undefined });
    console.log("deleted");
  }
  return (
    <>
      <SingleDocument dropzone={dropzone} inputDocument={inputDoc} content={content} deleteDocument={onDelete} />
    </>
  );
}

const SingleDocument = ({
  dropzone,
  inputDocument,
  content,
  deleteDocument,
  disallowUpload = false,
}: //removeOnlyTemporary = false,
{
  dropzone: DropzoneState;
  inputDocument: InputDocument;
  content: DocumentAttributes;
  disallowUpload?: boolean;
  removeOnlyTemporary?: boolean;
  deleteDocument: () => void;
}) => {
  const intl = useIntl();
  const { getInputProps, open } = dropzone;

  const [contentDocument, setContentDocument] = useState<DocumentAttributes>(content);

  /*const [isMouseOver, setMouseOver] = useState(false);*/
  const [isModalOpen, setIsModalOpen] = useState(false);
  /*const [canDelete, setCanDelete] = useState(false);*/

  useEffect(() => {
    setContentDocument(content);
  }, [content]);

  /*useEffect(() => {
    if (!isMouseOver && !isModalOpen) {
      setCanDelete(false);
      return;
    }
    setCanDelete(removeOnlyTemporary ? content?.temporary : true);
  }, [isMouseOver, isModalOpen, contentDocument]);

  const onMouseEnter = () => {
    setMouseOver(true);
  };
  const onMouseLeave = () => {
    setMouseOver(false);
  };*/

  const confirmDeleteDocument = () => {
    setIsModalOpen(true);
  };

  const onDelete = () => {
    setIsModalOpen(false);
    deleteDocument();
  };

  return (
    <>
      <div
        data-qa="input-document-uploader"
        /*onMouseEnter={onMouseEnter}
        onMouseLeave={onMouseLeave}*/
        className={classnames("border-2 rounded-lg flex flex-1 flex-col", {
          "border-title-text": !inputDocument.documentId && !inputDocument.mandatory,
          "border-error": inputDocument.mandatory && !inputDocument.documentId,
          "border-success": inputDocument.documentId,
        })}
        key={inputDocument.code}
        id={inputDocument.code}
      >
        <div className="flex flex-1 items-center">
          <input {...getInputProps()} data-qa="drop-input" className="text-primary" />
          <div className="flex w-full">
            <div
              className={classnames("flex gap-2 items-center justify-between w-full mx-4", {
                "my-4": !inputDocument.description,
                "my-2": inputDocument.description,
              })}
            >
              <div className="flex gap-2 items-center">
                <DocumentTextIcon className="w-6 h-6 flex-shrink-0" />
                <div>
                  <div className="felx items-center">
                    <span data-qa="input-document-name" className="text-body-text font-bold shrink flex-1 mr-2">
                      {intl.formatMessage({ id: inputDocument.name })}
                    </span>
                    {inputDocument.mandatory && (
                      <span
                        className={classnames("font-bold uppercase text-xs justify-center flex-none", {
                          "text-error": !inputDocument.documentId,
                          "text-action-disabled": inputDocument.documentId,
                        })}
                        data-qa="input-document-mandatory"
                      >
                        <FormattedMessage id="mandatory" />
                      </span>
                    )}
                  </div>
                  {contentDocument && (
                    <div className="flex items-center mt-1">
                      <div data-qa="document-preview" className="uppercase text-xs w-40 lg:w-48 xl:w-[330px] font-bold truncate underline">
                        <a
                          className="cursor-pointer"
                          title={contentDocument.title}
                          onClick={() => documentPreview(contentDocument.contentType, contentDocument.documentId, contentDocument.title!!)}
                        >
                          {contentDocument.title}
                        </a>
                      </div>
                      <div onClick={() => confirmDeleteDocument()} className="cursor-pointer" data-qa="remove-document-button">
                        {/*isMouseOver &&
                    doc.documentId == mouseOverDocId ? (
                    */}
                        <TrashIcon className="h-5 w-5 ml-auto mr-4 flex-shrink-0 text-error" />
                        {/*) : (
                      <div className="h-5 w-5 ml-auto mr-4" />
                    )
                    }*/}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>

          {inputDocument.documentId ? (
            <div className="items-center">
              {/*!canDelete ? (*/}
              <div data-qa="check-document">
                <CheckCircleIcon className="h-8 w-8 ml-auto mr-4 flex-shrink-0  text-success" />
              </div>
              {/*) : (
                <div
                  onClick={confirmDeleteDocument}
                  className="cursor-pointer"
                  data-qa="remove-document-button"
                >
                  <TrashIcon className="h-8 w-8 ml-auto mr-4 flex-shrink-0 text-error" />
                </div>
              )*/}
            </div>
          ) : (
            <>
              {!disallowUpload && (
                <div data-qa="upload-document-button" className="ml-auto mr-4 flex-shrink-0 cursor-pointer">
                  <UploadIcon className="h-8 w-8 " onClick={open} />
                </div>
              )}
            </>
          )}
        </div>

        {inputDocument.description && (
          <div className="mx-3 px-2 mb-2 rounded-md bg-background">
            <span data-qa="description">
              <FormattedMessage id={inputDocument.description} />
            </span>
          </div>
        )}
      </div>

      <ConfirmModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} onConfirm={onDelete} title="deleteDocument">
        <FormattedMessage id="confirmDeleteDocument" values={{ name: intl.formatMessage({ id: inputDocument.name }) }} />
      </ConfirmModal>
    </>
  );
};

interface Options {
  output: boolean;
  temporary?: boolean;
  viewers?: string[];
  maxSize?: number;
}

const fileToDocumentAttributes = (
  file: File,
  contentId: string,
  entityType: string,
  owner: string,
  { output, temporary = false, viewers, maxSize }: Options
): DocumentAttributes => {
  return {
    code: "",
    contentLength: file.size,
    contentType: file.type,
    entityId: contentId,
    entityType: entityType,
    title: file.name,
    owner,
    viewers,
    output,
    temporary: temporary,
    maxSize: maxSize,
    status: "READY",
  };
};
