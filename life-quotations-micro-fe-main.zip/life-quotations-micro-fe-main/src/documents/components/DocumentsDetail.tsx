import { Loader } from "@aws-amplify/ui-react";
import { XCircleIcon } from "@heroicons/react/solid";
import { config } from "commons/Configuration";
import YogaCard from "commons/components/YogaCard";
import { YogaMessage } from "commons/components/YogaMessage";
import { KeyValue } from "commons/models/YogaModels";
import { DocumentAttributes } from "documents/models/DocumentAttributes";
import { Dossier } from "documents/models/Dossier";
import { Fragment, useEffect, useState } from "react";
import { FormattedMessage } from "react-intl";
import DocumentBox from "./DocumentBox";

export default function DocumentsDetail({
  dossier,
  documents,
  isPollingTerminated,
  dossierError,
}: {
  dossier: Dossier;
  documents: DocumentAttributes[];
  isPollingTerminated: boolean;
  dossierError: Error;
}) {
  const [documentsData, setDocumentsData] = useState<KeyValue<any>>();
  const [documentErrors, setDocumentErrors] = useState<KeyValue<boolean>>();

  const externalDocsNeeded = config.EXTERNAL_POLICY_DOCS_NEEDED === "enabled";

  useEffect(() => {
    if ((dossier || !externalDocsNeeded) && documents) {
      const documentsMap = dossier
        ? documents.reduce(
            (a, document) => ({
              ...a,
              [document.documentId]: {
                ...document,
                signRequired:
                  dossier.outputDocuments[document.code].signRequired,
                signed: dossier.outputDocuments[document.code].signed,
              },
            }),
            {}
          )
        : documents.reduce(
            (a, document) => ({
              ...a,
              [document.documentId]: document,
            }),
            {}
          );

      const documentsData = externalDocsNeeded
        ? Object.values(dossier.outputDocuments).reduce(
            (a, document) => ({
              ...a,
              [document.outputDocumentId]: {
                signed: document.signed,
                signRequired: document.signRequired,
                contentType:
                  documentsMap[document.outputDocumentId].contentType,
                title: documentsMap[document.outputDocumentId].title,
                documentId: document.outputDocumentId,
                tags: document.tags,
                output: documentsMap[document.outputDocumentId].output,
              },
            }),
            {}
          )
        : documentsMap;

      const documentsInTags = Object.values(documentsData)
        .filter((document: any) => document.output)
        .reduce((previous: { [tag: string]: any }, current: any) => {
          let tag = "noTags";
          if (current.tags && current.tags.length) {
            tag = current.tags[0];
          }
          if (!previous[tag]) {
            previous[tag] = [];
          }
          previous[tag] = previous[tag].concat(current);
          return previous;
        }, {});
      setDocumentsData(documentsInTags);

      let documentErrors = Object.keys(documentsData).reduce(
        (a, key) => ({
          ...a,
          [key]: false,
        }),
        {}
      );
      setDocumentErrors(documentErrors);
    }
  }, [dossier, documents]);

  return (
    <YogaCard
      data-qa="documents-card"
      className="bg-body-text border-body-text"
    >
      {documents && documents.length > 0 && (
        <div className="flex flex-col gap-y-4" data-qa="documents-container">
          {documentsData &&
            Object.values(documentsData).map((documentArray: any[]) =>
              documentArray.map((document) => {
                return (
                  documentErrors[document.documentId] && (
                    <div
                      id={`document-${document.documentId}-error-message`}
                      key={`document-${document.documentId}-error-message`}
                      data-qa={`document-${document.documentId}-error-message`}
                    >
                      <YogaMessage type="error" position="inner">
                        <p>
                          <FormattedMessage
                            id="documentError"
                            values={{ title: document.title }}
                          />
                        </p>
                      </YogaMessage>
                    </div>
                  )
                );
              })
            )}
          {documentsData && Object.keys(documentsData).length > 0 && (
            <>
              {Object.entries(documentsData).map(([tag, documents]) => (
                <div
                  key={`${tag}-section`}
                  data-qa={`${tag}-section`}
                  className="p-4 rounded-lg bg-box-background"
                >
                  {tag !== "noTags" && (
                    <h4 data-qa={`${tag}-title`} className="mb-4">
                      <FormattedMessage id={tag} />
                    </h4>
                  )}
                  <div
                    data-qa={`${tag}-documents`}
                    className="grid grid-cols-1 lg:grid-cols-3 gap-4"
                  >
                    {Object.values(documents).map((document: any) => (
                      <Fragment key={document.documentId}>
                        <DocumentBox
                          key={document.documentId}
                          document={document}
                          dossierId={dossier?.dossierId}
                          setDocumentErrors={setDocumentErrors}
                          documentErrors={documentErrors}
                        />
                      </Fragment>
                    ))}
                  </div>
                </div>
              ))}
            </>
          )}
        </div>
      )}
      {(!documents || documents.length == 0) && !isPollingTerminated && (
        <div
          className="flex text-white text-xl font-bold items-center"
          data-qa="documentsLoading"
        >
          <Loader
            className="w-6 h-6 mr-2 flex-shrink-0"
            emptyColor="var(--box-background)"
            filledColor="var(--title-text)"
            fr={undefined}
          />
          <FormattedMessage id="documentsLoading" />
        </div>
      )}
      {(!documents || documents.length == 0) &&
        isPollingTerminated &&
        dossierError && (
          <div
            className="flex text-title-text text-xl font-bold items-center"
            data-qa="documentsError"
          >
            <XCircleIcon className="w-6 h-6 mr-2 text-error flex-shrink-0" />
            <FormattedMessage id="documentsError" />
          </div>
        )}

      {(!documents || documents.length == 0) && isPollingTerminated && (
        <YogaCard inner data-qa="investmentLine-card">
          <div className="flex items-center">
            <FormattedMessage id="notDocumentsToShow" />
          </div>
        </YogaCard>
      )}
    </YogaCard>
  );
}
