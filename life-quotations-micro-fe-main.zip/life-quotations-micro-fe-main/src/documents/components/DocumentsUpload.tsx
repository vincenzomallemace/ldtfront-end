import { DocumentCardSkeleton } from "./DocumentCardSkeleton";
import { DossierUtils } from "documents/models/Dossier";
import YogaCard from "commons/components/YogaCard";
import { FormattedMessage } from "react-intl";
import DossierGroupUploader from "./DossierGroupUploader";
import { InputDocument } from "documents/models/InputDocument";
import { DossierFileUploader } from "./DossierFileUploader";
import React, { useEffect, useState } from "react";
import useDossier from "documents/hooks/useDossier";
import useDocumentsSettings from "documents/hooks/useDocumentsSettings";
import useMultipleDocumentMetadata from "documents/hooks/useMultipleDocumentMetadata ";
import { KeyValue } from "commons/models/YogaModels";
import { DocumentAttributes } from "documents/models/DocumentAttributes";

interface DocumentsUploadProps {
  contractId: string;
  contractNumber: string;
  setIsDossierValid: (value: boolean) => void;
  setIsDossierLoaded: (value: boolean) => void;
  setPageDossierId: (value: string) => void;
}

export const DocumentsUpload = ({ contractId, contractNumber, setIsDossierValid, setIsDossierLoaded, setPageDossierId }: DocumentsUploadProps) => {
  const {
    dossier,
    setStartPolling,
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    setDossierSignature,
    isPollingTerminated,
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    isPollingDossierSignature,
    isDossierValid,
  } = useDossier(contractId, true, false);
  const { contentDocuments, setDocumentIds } = useMultipleDocumentMetadata();
  const { settings } = useDocumentsSettings();
  const [documentsMap, setDocumentsMap] = useState<KeyValue<DocumentAttributes>>();

  useEffect(() => {
    if (contractId) {
      setStartPolling(true);
    }
  }, [contractId]);

  useEffect(() => {
    setIsDossierValid(isDossierValid);
  }, [isDossierValid]);

  useEffect(() => {
    if (isPollingTerminated) {
      setIsDossierLoaded(!!dossier);
    }
  }, [isPollingTerminated]);

  useEffect(() => {
    if (dossier) {
      let docsIds = DossierUtils.getDocumentIds(dossier.inputDocuments);
      let groupsDocsIds = DossierUtils.sortGroups(dossier).flatMap((g) => {
        return DossierUtils.getDocumentIds(g.inputDocuments);
      });
      setDocumentIds(docsIds.concat(groupsDocsIds));

      setPageDossierId(dossier.dossierId);
    } else {
      setDocumentIds([]);
    }
  }, [dossier]);

  useEffect(() => {
    setDocumentsMap(
      contentDocuments?.reduce(
        (a, document) => ({
          ...a,
          [document.documentId]: document,
        }),
        {}
      )
    );
  }, [contentDocuments]);

  return (
    <>
      {dossier && !DossierUtils.hasInputDocuments(dossier) && (
        <YogaCard uniformPadding data-qa="input-documents-not-visible" id="input-documents-not-visible">
          <div className="text-action-disabled">
            <FormattedMessage id="noDocumentsToUpload" />
          </div>
        </YogaCard>
      )}
      {!dossier && <DocumentCardSkeleton />}
      {dossier && DossierUtils.hasInputDocuments(dossier) && (
        <YogaCard uniformPadding data-qa="input-documents" id="input-documents">
          <div className="flex flex-col gap-y-4">
            <div className="font-bold">
              <FormattedMessage id="inputDocumentTitle" />
            </div>
            {DossierUtils.sortGroups(dossier).map((group) => (
              <DossierGroupUploader
                documentsMap={documentsMap}
                settings={settings}
                dossierId={dossier.dossierId}
                entityId={contractId}
                entityNumber={contractNumber}
                group={group}
                key={group.code}
                action={() => {
                  setStartPolling(true);
                }}
              />
            ))}
            <div className="grid grid-cols-2 lg:grid-cols-2 gap-4">
              {DossierUtils.sortInputDocuments(dossier.inputDocuments).map((inputDocument: InputDocument) => {
                return (
                  <DossierFileUploader
                    documentsMap={documentsMap}
                    settings={settings}
                    inputDocument={inputDocument}
                    entityId={contractId}
                    entityType={"contract"}
                    entityNumber={contractNumber}
                    dossierId={dossier.dossierId}
                    fireAction={() => {
                      setStartPolling(true);
                    }}
                    key={inputDocument.code}
                    multiple={inputDocument.multipleInput}
                  />
                );
              })}
            </div>
          </div>
          <FormattedMessage id="uploadDocumentMessage" />
        </YogaCard>
      )}
    </>
  );
};
