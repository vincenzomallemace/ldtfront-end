import { DocumentDuplicateIcon, DocumentTextIcon, InformationCircleIcon, UploadIcon } from "@heroicons/react/outline";
import { CheckCircleIcon, TrashIcon } from "@heroicons/react/solid";
import { Context } from "commons/contexts/Context";
import { CustomerContext } from "commons/contexts/CustomerContext";
import { UserContext } from "commons/contexts/UserProvider";
import classnames from "classnames";
import { YogaMessage } from "commons/components/YogaMessage";
import { ConfirmModal } from "commons/modals/ConfirmModal";
import { DetailsModal } from "commons/modals/DetailsModal";
import { KeyValue } from "commons/models/YogaModels";
import { documentPreview } from "documents/DocumentUtils";
import useDossierDocumentMetadata from "documents/hooks/useDossierDocumentMetadata";
import { DocumentAttributes } from "documents/models/DocumentAttributes";
import { InputDocument } from "documents/models/InputDocument";
import { useContext, useEffect, useState } from "react";
import { DropzoneState, useDropzone } from "react-dropzone";
import { FormattedMessage, useIntl } from "react-intl";
import { dossierService } from "commons/services/DossierService";

interface DossierFileUploaderProps {
  entityId: string;
  entityType: string;
  entityNumber: string;
  documentsMap?: KeyValue<DocumentAttributes>;
  dossierId: string;
  group?: string;
  inputDocument: InputDocument;
  settings: KeyValue<any>;
  multiple?: boolean;
  temporary?: boolean;
  disallowUpload?: boolean;
  removeOnlyTemporary?: boolean;
  fireAction: (b: boolean) => void;
}

export function DossierFileUploader({
  documentsMap = null,
  settings,
  entityId,
  entityType,
  entityNumber,
  dossierId,
  group,
  inputDocument,
  multiple = false,
  disallowUpload = false,
  removeOnlyTemporary = false,
  temporary = false,
  fireAction,
}: DossierFileUploaderProps) {
  const intl = useIntl();
  const { changeLoading } = useContext(Context);
  const user = useContext(UserContext);
  const { selectedCustomers } = useContext(CustomerContext);

  const [customer] = selectedCustomers.length > 0 ? selectedCustomers : [];

  const { setDocumentAttributes, setFile, errorMessage, pollingData } = useDossierDocumentMetadata(dossierId, inputDocument, group);

  const [isModalSizeErrorOpen, setIsModalSizeErrorOpen] = useState(false);
  const [isModalTypeErrorOpen, setIsModalTypeErrorOpen] = useState(false);
  const [isModalGenericErrorOpen, setIsModalGenericErrorOpen] = useState(false);

  const [content, setContentDocument] = useState<DocumentAttributes>();
  const [contents, setContentDocuments] = useState<DocumentAttributes[]>();

  useEffect(() => {
    if (documentsMap) {
      if (!multiple) setContentDocument(documentsMap[inputDocument.documentId]);
      else setContentDocuments(inputDocument.multipleDocumentIds.map((id) => documentsMap[id]).filter((e) => !!e));
    } else {
      setContentDocument(undefined);
      setContentDocuments(undefined);
    }
  }, [documentsMap]);

  useEffect(() => {
    if (errorMessage) {
      changeLoading(-1);
      fireAction(false);
      if (errorMessage.includes("size")) {
        setIsModalSizeErrorOpen(true);
      } else if (errorMessage.includes("type")) {
        setIsModalTypeErrorOpen(true);
      } else if (errorMessage.includes("not found")) {
        setIsModalGenericErrorOpen(true);
      }
    }
  }, [errorMessage]);

  useEffect(() => {
    if (pollingData.terminated && pollingData.error) {
      changeLoading(-1);
      console.error("Error on uploading document");
      fireAction(false);
    } else if (pollingData.terminated && !pollingData.error) {
      changeLoading(-1);
      fireAction(true);
    }
  }, [pollingData]);

  interface Options {
    output: boolean;
    temporary?: boolean;
    viewers?: string[];
    maxSize?: number;
  }

  const fileToDocumentAttributes = (
    file: File,
    contentId: string,
    entityType: string,
    entytyNumber: string,
    owner: string,
    { output, temporary = false, viewers, maxSize }: Options
  ): DocumentAttributes => {
    return {
      code: "",
      contentLength: file.size,
      contentType: file.type,
      entityId: contentId,
      entityType: entityType,
      entityNumber: entityNumber,
      title: file.name,
      owner,
      viewers,
      output,
      temporary: temporary,
      maxSize: maxSize,
      status: "READY",
    };
  };

  const saveFiles = async (contentId: string, file: File) => {
    if (file) {
      changeLoading(1);
      setFile(file);
      setDocumentAttributes(
        fileToDocumentAttributes(file, contentId, entityType, entityNumber, user.user?.username ?? "", {
          output: false,
          viewers: customer ? [customer.partyId] : [],
          maxSize: inputDocument.maxSize,
          temporary: temporary,
        })
      );
    }
  };

  const deleteDocument = async (id?: string) => {
    changeLoading(1);
    if (group) await dossierService.removeDocumentFromGroup(dossierId, group, inputDocument.code, id);
    else await dossierService.removeDocumentFromDossier(dossierId, inputDocument.code, id);
    fireAction(true);
    changeLoading(-1);
  };

  const dropzone = useDropzone({
    onDrop: (acceptedFiles: File[]) => {
      acceptedFiles.forEach((file: File) => {
        saveFiles(entityId, file);
      });
    },
    accept: settings.allowedMimeTypesWithExtensions,
    noClick: true,
    noKeyboard: true,
    maxSize: settings.documentSizeMax,
    maxFiles: 10,
  });

  const getMaxSize = (size: number): string => {
    let sizeString =
      size / 1048576 >= 1
        ? `${(size / 1048576).toFixed(2)}`.replace(/[.,]00$/, "") + ` MB`
        : `${(size / 1024).toFixed(2)}`.replace(/[.,]00$/, "") + ` kB`;
    return sizeString;
  };

  return (
    <>
      <div {...dropzone.getRootProps()}>
        {!multiple ? (
          <SingleDocument
            // disallowUpload={disallowUpload}
            disallowUpload={inputDocument.restrictUserAccess? true : disallowUpload}
            removeOnlyTemporary={removeOnlyTemporary}
            dropzone={dropzone}
            inputDocument={inputDocument}
            content={content}
            deleteDocument={deleteDocument}
          />
        ) : (
          <MultipleDocument
            // disallowUpload={disallowUpload}
            disallowUpload={inputDocument.restrictUserAccess? true : disallowUpload}
            removeOnlyTemporary={removeOnlyTemporary}
            dropzone={dropzone}
            inputDocument={inputDocument}
            contents={contents}
            deleteDocument={deleteDocument}
          />
        )}
      </div>

      <DetailsModal isOpen={isModalSizeErrorOpen} onClose={() => setIsModalSizeErrorOpen(false)} title="uploaderErrorTitle">
        <YogaMessage type="error" position="inner">
          <FormattedMessage
            id="uploaderErrorMessage"
            values={{
              name: intl.formatMessage({ id: inputDocument.name }),
              maxSize: intl.formatMessage({
                id: getMaxSize(inputDocument.maxSize),
              }),
            }}
          />
        </YogaMessage>
      </DetailsModal>

      <DetailsModal isOpen={isModalTypeErrorOpen} onClose={() => setIsModalTypeErrorOpen(false)} title="uploaderErrorTitle">
        <YogaMessage type="error" position="inner">
          <FormattedMessage id="file-invalid-type" />
        </YogaMessage>
      </DetailsModal>

      <DetailsModal isOpen={isModalGenericErrorOpen} onClose={() => setIsModalGenericErrorOpen(false)} title="uploaderErrorTitle">
        <YogaMessage type="error" position="inner">
          <FormattedMessage id="uploaderGenericErrorMessage" />
        </YogaMessage>
      </DetailsModal>
    </>
  );
}

const SingleDocument = ({
  dropzone,
  inputDocument,
  content,
  deleteDocument,
  disallowUpload = false,
}: /*removeOnlyTemporary = false,*/
{
  dropzone: DropzoneState;
  inputDocument: InputDocument;
  content: DocumentAttributes;
  disallowUpload?: boolean;
  removeOnlyTemporary?: boolean;
  deleteDocument: () => void;
}) => {
  const intl = useIntl();
  const { getInputProps, open } = dropzone;

  const [contentDocument, setContentDocument] = useState<DocumentAttributes>(content);

  /*const [isMouseOver, setMouseOver] = useState(false);*/
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isModalInfoOpen, setIsModalInfoOpen] = useState(false);
  /*const [canDelete, setCanDelete] = useState(false);*/

  useEffect(() => {
    setContentDocument(content);
  }, [content]);

  /*useEffect(() => {
    if (!isMouseOver && !isModalOpen) {
      setCanDelete(false);
      return;
    }
    setCanDelete(removeOnlyTemporary ? content?.temporary : true);
  }, [isMouseOver, isModalOpen, contentDocument]);

  const onMouseEnter = () => {
    setMouseOver(true);
  };
  const onMouseLeave = () => {
    setMouseOver(false);
  };*/

  const confirmDeleteDocument = () => {
    setIsModalOpen(true);
  };

  const onDelete = () => {
    setIsModalOpen(false);
    deleteDocument();
  };

  return (
    <>
      <div
        data-qa="input-document-uploader"
        /*onMouseEnter={onMouseEnter}
        onMouseLeave={onMouseLeave}*/
        className={classnames("border-2 rounded-lg flex flex-1 flex-col", {
          "border-title-text": !inputDocument.documentId && !inputDocument.mandatory,
          "border-error": inputDocument.mandatory && !inputDocument.documentId,
          "border-success": inputDocument.documentId,
        })}
        key={inputDocument.code}
        id={inputDocument.code}
      >
        <div className="flex flex-1 items-center">
          <input {...getInputProps()} data-qa="drop-input" className="text-primary" />
          <div className="flex w-full">
            <div
              className={classnames("flex gap-2 items-center justify-between w-full mx-4", {
                "my-4": !inputDocument.description,
                "my-2": inputDocument.description,
              })}
            >
              <div className="flex gap-2 items-center">
                <DocumentTextIcon className="w-6 h-6 flex-shrink-0" />
                <div>
                  <div className="flex items-center">
                    <span data-qa="input-document-name" className="text-body-text font-light shrink flex-1 mr-2">
                      {intl.formatMessage({ id: inputDocument.name })}
                    </span>
                    {inputDocument.mandatory && (
                      <span
                        className={classnames("font-bold uppercase text-xs justify-center flex-none", {
                          "text-error": !inputDocument.documentId,
                          "text-action-disabled": inputDocument.documentId,
                        })}
                        data-qa="input-document-mandatory"
                      >
                        <FormattedMessage id="mandatory" />
                      </span>
                    )}
                  </div>
                  {contentDocument && (
                    <div className="flex items-center mt-1">
                      <div
                        data-qa="document-preview"
                        className="uppercase text-xs max-w-[128px] lg:max-w-[176px] xl:max-w-[300px] font-bold truncate mr-4  underline"
                      >
                        <a
                          className="cursor-pointer"
                          title={contentDocument.title}
                          onClick={() => documentPreview(contentDocument.contentType, contentDocument.documentId, contentDocument.title!!)}
                        >
                          {contentDocument.title}
                        </a>
                      </div>
                      <div onClick={() => confirmDeleteDocument()} className="cursor-pointer" data-qa="remove-document-button">
                        {/*isMouseOver &&
                        doc.documentId == mouseOverDocId ? (
                        */}
                        <TrashIcon className="h-5 w-5 ml-auto mr-4 flex-shrink-0 text-error" />
                        {/*) : (
                          <div className="h-5 w-5 ml-auto mr-4" />
                        )
                        }*/}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>

          {inputDocument.documentId ? (
            <div className="items-center">
              {/*!canDelete ? (*/}
              <div data-qa="check-document">
                <CheckCircleIcon className="h-8 w-8 ml-auto mr-4 flex-shrink-0  text-success" />
              </div>
              {/*) : (
                <></>
                <div
                  onClick={confirmDeleteDocument}
                  className="cursor-pointer"
                  data-qa="remove-document-button"
                >
                  <TrashIcon className="h-8 w-8 ml-auto mr-4 flex-shrink-0 text-error" />
                </div>
              )*/}
            </div>
          ) : (
            <>
              {!disallowUpload ? (
                <div data-qa="upload-document-button" className="ml-auto mr-4 flex-shrink-0 cursor-pointer text-primary">
                  <UploadIcon className="h-8 w-8 " onClick={open} />
                </div>
              ) : 
              (
                <>
                {inputDocument && inputDocument.restrictUserAccess &&
                  <div data-qa="upload-document-button" className="ml-auto mr-4 flex-shrink-0 cursor-pointer text-primary">
                    <InformationCircleIcon className="h-8 w-8 " onClick={() => setIsModalInfoOpen(true)} />
                  </div>
                  }
                </>
              )
            }
            </>
          )}
        </div>

        {inputDocument.description && (
          <div className="mx-3 px-2 mb-2 rounded-md bg-background">
            <span data-qa="description">
              <FormattedMessage id={inputDocument.description} />
            </span>
          </div>
        )}
      </div>
      {/* {inputDocument && inputDocument.restrictUserAccess && <FormattedMessage id="disabledUploadDocumentMessage" />} */}

      <ConfirmModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} onConfirm={onDelete} title="deleteDocument">
        <FormattedMessage id="confirmDeleteDocument" values={{ name: intl.formatMessage({ id: inputDocument.name }) }} />
      </ConfirmModal>
      <DetailsModal
              data-qa={`${name}-modal`}
              isOpen={isModalInfoOpen}
              onClose={() => {
                setIsModalInfoOpen(false);
              }}
              title="disabledUploadDocumentTitle"
            >
              <FormattedMessage id="disabledUploadDocumentMessage"/>
      </DetailsModal>
    </>
  );
};

const MultipleDocument = ({
  dropzone,
  inputDocument,
  contents,
  disallowUpload = false,
  removeOnlyTemporary = false,
  deleteDocument,
}: {
  dropzone: DropzoneState;
  inputDocument: InputDocument;
  contents: DocumentAttributes[];
  disallowUpload?: boolean;
  removeOnlyTemporary?: boolean;
  deleteDocument: (id?: string) => void;
}) => {
  const intl = useIntl();
  const { open } = dropzone;

  //const [isMouseOver, setMouseOver] = useState(false);
  //const [mouseOverDocId, setMouseOverDocId] = useState<string>();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isModalInfoOpen, setIsModalInfoOpen] = useState(false);
  const [docIdToDelete, setDocIdToDelete] = useState<string>();
  const [docTitleToDelete, setDocTitleToDelete] = useState<string>();

  const canDelete = (doc: DocumentAttributes) => (removeOnlyTemporary ? doc.temporary : true);

  // const onMouseEnter = (docId: string) => {
  //   setMouseOver(true);
  //   setMouseOverDocId(docId);
  // };
  // const onMouseLeave = () => {
  //   setMouseOver(false);
  //   setMouseOverDocId(undefined);
  // };

  const confirmDeleteDocument = (document: DocumentAttributes) => {
    setIsModalOpen(true);
    setDocIdToDelete(document.documentId);
    setDocTitleToDelete(document.title);
  };

  const onDelete = () => {
    setIsModalOpen(false);
    deleteDocument(docIdToDelete);
    setDocIdToDelete(undefined);
    setDocTitleToDelete(undefined);
  };

  return (
    <>
      <div
        data-qa="input-document-multiple-uploader"
        className={classnames("border-2 rounded-lg flex flex-col flex-1", {
          "border-title-text": !inputDocument.multipleDocumentIds.length && !inputDocument.mandatory,
          "border-error": inputDocument.mandatory && !inputDocument.multipleDocumentIds.length,
          "border-success": inputDocument.multipleDocumentIds.length,
        })}
        key={inputDocument.code}
        id={inputDocument.code}
      >
        <div className="flex flex-1 items-center">
          <input {...dropzone.getInputProps()} data-qa="drop-input" className="text-primary" />
          <div className="flex w-full">
            <div
              className={classnames("flex gap-2 items-center justify-between w-full mx-4", {
                "my-4": !inputDocument.description,
                "my-2": inputDocument.description,
              })}
            >
              <div className="flex gap-2 items-center">
                <DocumentDuplicateIcon className="w-6 h-6 flex-shrink-0" />
                <div>
                  <div className="flex items-center">
                    <span data-qa="input-document-name" className="text-body-text font-light text-sm shrink mr-2">
                      {intl.formatMessage({ id: inputDocument.name })}
                    </span>
                    {inputDocument.mandatory && (
                      <span
                        className={classnames("font-bold uppercase text-xs justify-center flex-none", {
                          "text-error": !inputDocument.multipleDocumentIds.length,
                          "text-action-disabled": inputDocument.multipleDocumentIds.length,
                        })}
                        data-qa="input-document-mandatory"
                      >
                        <FormattedMessage id="mandatory" />
                      </span>
                    )}
                  </div>
                  {contents &&
                    contents.length > 0 &&
                    contents.map((doc) => {
                      return (
                        <div
                          key={doc.documentId}
                          className="flex items-center mt-1"
                          //onMouseEnter={() => onMouseEnter(doc.documentId)}
                          //onMouseLeave={onMouseLeave}
                        >
                          <div
                            data-qa="document-preview"
                            className="uppercase text-xs max-w-[128px] lg:max-w-[176px] xl:max-w-[300px] font-bold truncate mr-4  underline"
                          >
                            <a
                              className="cursor-pointer"
                              title={doc.title}
                              onClick={() => documentPreview(doc.contentType, doc.documentId, doc.title!!)}
                            >
                              {doc.title}
                            </a>
                          </div>
                          {canDelete(doc) ? (
                            <div onClick={() => confirmDeleteDocument(doc)} className="cursor-pointer" data-qa="remove-document-button">
                              {/*isMouseOver &&
                              doc.documentId == mouseOverDocId ? (
                              */}
                              <TrashIcon className="h-5 w-5 ml-auto mr-4 flex-shrink-0 text-error" />
                              {/*) : (
                                <div className="h-5 w-5 ml-auto mr-4" />
                              )
                              }*/}
                            </div>
                          ) : (
                            <div className="h-5 w-5 ml-auto mr-4" />
                          )}
                        </div>
                      );
                    })}
                </div>
              </div>
            </div>
          </div>

          {!disallowUpload ? (
            <div data-qa="upload-document-button" className="ml-auto mr-4 flex-shrink-0 cursor-pointer text-primary">
              <UploadIcon className="h-8 w-8 " onClick={open} />
            </div>
          ): 
          (
            <>
            {inputDocument && inputDocument.restrictUserAccess &&
              <div data-qa="upload-document-button" className="ml-auto mr-4 flex-shrink-0 cursor-pointer text-primary">
                <InformationCircleIcon className="h-8 w-8 " onClick={() => setIsModalInfoOpen(true)} />
              </div>
              }
            </>
          )
        }
        </div>

        {/*inputDocument.description && (
          <div className="mx-3 px-2 mb-2 rounded-md bg-background">
            <span data-qa="description">
              <FormattedMessage id={inputDocument.description} />
            </span>
          </div>
        )*/}
      </div>
      {/* {inputDocument && inputDocument.restrictUserAccess && <FormattedMessage id="disabledUploadDocumentMessage" />} */}
      <ConfirmModal
        isOpen={isModalOpen}
        onClose={() => {
          setIsModalOpen(false);
          setDocIdToDelete(undefined);
          setDocTitleToDelete(undefined);
        }}
        onConfirm={onDelete}
        title="deleteDocument"
      >
        <FormattedMessage id="confirmDeleteDocumentTitle" values={{ name: inputDocument.name, title: docTitleToDelete }} />
      </ConfirmModal>
      <DetailsModal
              data-qa={`${name}-modal`}
              isOpen={isModalInfoOpen}
              onClose={() => {
                setIsModalInfoOpen(false);
              }}
              title="disabledUploadDocumentTitle"
            >
              <FormattedMessage id="disabledUploadDocumentMessage"/>
      </DetailsModal>
    </>
  );
};
