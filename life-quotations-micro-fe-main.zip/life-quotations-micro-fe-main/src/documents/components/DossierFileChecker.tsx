import { DocumentTextIcon } from "@heroicons/react/outline";
import classnames from "classnames";
import { InputDocument } from "documents/models/InputDocument";
import { useState } from "react";
import { FormattedMessage, useIntl } from "react-intl";

interface DossierFileCheckerProps {
  inputDocument: InputDocument;
  fireAction: (b: boolean) => void;
}

export function DossierFileChecker({
  inputDocument,
  fireAction,
}: DossierFileCheckerProps) {
  return (
    <>
      <SingleDocument
        inputDocument={inputDocument}
        fireAction={(value) => fireAction(value)}
      />
    </>
  );
}

const SingleDocument = ({
  inputDocument,
  fireAction,
}: {
  inputDocument: InputDocument;
  fireAction: (value: boolean) => void;
}) => {
  const intl = useIntl();
  const [check, setCheck] = useState<boolean>(false);

  return (
    <div
      data-qa="check-document-uploader"
      className={classnames("border-2 rounded-lg flex flex-1 flex-col", {
        "border-title-text":
          !check && !inputDocument.mandatory,
        "border-error": inputDocument.mandatory && !check,
        "border-success": check,
      })}
      key={inputDocument.code}
      id={inputDocument.code}
    >
      <div className="flex flex-1 flex-row justify-between items-center">
        <div className="flex w-full">
          <div
            className={classnames(
              "flex gap-2 items-center justify-between w-full mx-4",
              {
                "my-4": !inputDocument.description,
                "my-2": inputDocument.description,
              }
            )}
          >
            <div className="flex gap-2 items-center">
              <DocumentTextIcon className="w-6 h-6 flex-shrink-0" />
              <div>
                <div className="flex items-center">
                  <span
                    data-qa="input-document-name"
                    className="text-body-text font-light text-sm shrink flex-1 mr-2"
                  >
                    {intl.formatMessage({ id: inputDocument.name })}
                  </span>
                  {inputDocument.mandatory && (
                    <span
                      className={classnames(
                        "font-bold uppercase text-xs justify-center flex-none",
                        {
                          "text-error": !inputDocument.documentId,
                          "text-action-disabled": inputDocument.documentId,
                        }
                      )}
                      data-qa="input-document-mandatory"
                    >
                      <FormattedMessage id="mandatory" />
                    </span>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>

        {inputDocument.inputDocumentId && (
          <div className="items-center cursor-pointer mr-4">
            <label className="container">
              <input
                type="checkbox"
                checked={check}
                onChange={(e) => {
                  if (inputDocument.mandatory) {
                    fireAction(e.target.checked);
                  }
                  setCheck(e.target.checked);
                }}
              />
              <span className="h-8 w-8 ml-auto mr-4 flex-shrink-0 checkmark" />
            </label>
          </div>
        )}
      </div>

      {inputDocument.description && (
        <div className="mx-3 px-2 mb-2 rounded-md bg-background">
          <span data-qa="description">
            <FormattedMessage id={inputDocument.description} />
          </span>
        </div>
      )}
    </div>
  );
};
