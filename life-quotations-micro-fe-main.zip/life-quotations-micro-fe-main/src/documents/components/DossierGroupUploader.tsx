import classNames from "classnames";
import { DossierFileUploader } from "./DossierFileUploader";
import { KeyValue } from "commons/models/YogaModels";
import { DocumentAttributes } from "documents/models/DocumentAttributes";
import { DossierUtils } from "documents/models/Dossier";
import { Group } from "documents/models/Group";
import { FormattedMessage } from "react-intl";

const DossierGroupUploader = ({
  documentsMap = null,
  settings,
  dossierId,
  entityId,
  entityNumber,
  group,
  temporary = false,
  alwaysValid = false,
  disallowUpload = false,
  removeOnlyTemporary = false,
  action,
}: {
  documentsMap?: KeyValue<DocumentAttributes>;
  settings: KeyValue<any>;
  dossierId: string;
  entityId: string;
  entityNumber: string;
  group: Group;
  temporary?: boolean;
  alwaysValid?: boolean;
  disallowUpload?: boolean;
  removeOnlyTemporary?: boolean;
  action: () => void;
}) => {
  const isValid = DossierUtils.isGroupValid(group);
  return (
    <div
      key={group.code}
      className={classNames(
        "flex flex-col gap-y-4 p-2 border-2 border-solid rounded-lg",
        {
          "border-background": alwaysValid || isValid,
          "border-error": !alwaysValid && !isValid,
        }
      )}
    >
      <div className="flex flex-row gap-2 items-center">
        <FormattedMessage id="inputDocumentTitle" />
        <span
          className={classNames(
            "font-bold uppercase text-xs justify-center flex-none",
            {
              "text-action-disabled": alwaysValid || isValid,
              "text-error": !alwaysValid && !isValid,
            }
          )}
          data-qa="input-document-mandatory"
        >
          <FormattedMessage id="mandatory" />
        </span>
      </div>
      <div className="flex flex-row flex-wrap gap-4">
        {Object.values(group.inputDocuments)
          .filter((document) => document.visible)
          .map((input) => (
            <DossierFileUploader
              documentsMap={documentsMap}
              settings={settings}
              entityId={entityId}
              entityType={"contract"}
              entityNumber={entityNumber}
              dossierId={dossierId}
              group={group.code}
              inputDocument={input}
              fireAction={action}
              key={input.code}
              temporary={temporary}
              disallowUpload={disallowUpload}
              removeOnlyTemporary={removeOnlyTemporary}
              multiple={input.multipleInput}
            />
          ))}
      </div>
    </div>
  );
};

export default DossierGroupUploader;
