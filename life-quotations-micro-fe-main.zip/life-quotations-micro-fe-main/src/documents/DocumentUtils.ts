import axios from "axios";
import { getApiContext } from "commons/Configuration";
import { documentService } from "commons/services/DocumentService";

export async function downloadDocument(
  contentType: string,
  documentId?: string
) {
  if (documentId) {
    const response = await documentService.downloadContentDocument(documentId);
    const blob = new Blob([response.data], {
      type: contentType,
    });
    const fileURL = URL.createObjectURL(blob);
    const openFileWindow = window.open();
    if (openFileWindow) {
      openFileWindow.location.href = fileURL;
    }
  }
}

export async function documentPreview(
  contentType: string,
  documentId?: string,
  title?: string
) {
  if (documentId) {
    const response = await documentService.downloadContentDocument(documentId);
    const blob = new Blob([response.data], {
      type: contentType,
    });
    const fileURL = URL.createObjectURL(blob);
    const openFileWindow = window.open(fileURL, "_blank");
    if (openFileWindow) {
      openFileWindow.location.href = fileURL;
      openFileWindow.document.title = title;
      openFileWindow.document.close();
    }
  }
}

export async function downloadDocumentOfDossier(
  contentType: string,
  documentId?: string,
  dossierId?: string
) {
  if (documentId) {
    const response = await documentService.downloadDocumentOfDossier(
      dossierId,
      documentId
    );
    const blob = new Blob([response.data], {
      type: contentType,
    });
    const fileURL = URL.createObjectURL(blob);
    const openFileWindow = window.open();
    if (openFileWindow) {
      openFileWindow.location.href = fileURL;
    }
  }
}

export async function downloadDocumentFilename(
  contentType: string,
  documentId?: string,
  user?: any,
  filename?: string
) {
  if (documentId) {
    const api: string =
      `${getApiContext()}/v1/documents` + (user != undefined ? "" : "/public");
    const response = await axios.get(`${api}/${documentId}/content`, {
      responseType: "blob",
    });
    const blob = new Blob([response.data], {
      type: contentType,
    });
    const fileURL = URL.createObjectURL(blob);

    const anchor = document.createElement("a");
    anchor.style.display = "none";
    anchor.href = fileURL;
    anchor.download = `${filename || "unknown"}`;
    document.body.appendChild(anchor);
    anchor.click();

    URL.revokeObjectURL(anchor.href);
  }
}
