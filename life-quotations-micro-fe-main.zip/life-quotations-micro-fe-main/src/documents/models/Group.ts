import { KeyValue } from "commons/models/YogaModels";
import { InputDocument } from "./InputDocument";

export interface Group {
  code: string;
  name: string;
  visible: boolean;
  inputDocuments: KeyValue<InputDocument>;
}
