export interface InputDocument {
  inputDocumentId: string;
  name: string;
  code: string;
  mandatory: boolean;
  documentId?: string;
  multipleDocumentIds?: string[];
  multipleInput: boolean;
  visible: boolean;
  maxSize?: number;
  description: string;
  restrictUserAccess: boolean;
}
