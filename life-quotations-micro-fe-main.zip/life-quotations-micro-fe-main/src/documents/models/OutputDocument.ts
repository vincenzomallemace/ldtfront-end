export interface OutputDocument {
  outputDocumentId: string;
  name: string;
  code: string;
  signRequired?: boolean;
  signed?: boolean;
  documentId?: string;
  visible: boolean;
  status?: OutputDocumentStatus;
  tags?: string[];
}

export enum OutputDocumentStatus {
  SIGNING = "SIGNING",
  SIGNED = "SIGNED",
}
