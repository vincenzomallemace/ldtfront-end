import { Contract } from "contracts/models/Contract";
import { DossierInfo } from "./DossierInfo";

export interface NAWSaveProposalInfo {
    contract: Contract;
    dossierInfo: DossierInfo;
  }