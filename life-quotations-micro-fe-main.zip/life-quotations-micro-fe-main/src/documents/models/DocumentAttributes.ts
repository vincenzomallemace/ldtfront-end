export interface DocumentAttributes {
  code: string;
  contentLength?: number;
  contentType: string;
  creationInstant?: Date;
  documentId?: string;
  lastUpdateInstant?: Date;
  title: string;
  entityId: string;
  entityType: string;
  operationId?: string;
  link?: string;
  storagePath?: string;
  viewers?: string[];
  owner: string;
  entityStatus?: string;
  output: boolean;
  managementNode?: string;
  temporary?: boolean;
  legacyId?: string;
  status?: string;
  maxSize?: number;
  entityNumber?: string;
  static?: boolean;

  name?: string;
  field?: string;
}
