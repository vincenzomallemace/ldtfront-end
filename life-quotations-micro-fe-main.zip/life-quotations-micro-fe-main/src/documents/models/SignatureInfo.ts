export interface SignatureInfoResponse {
    signInfo?: SignatureInfo;
  }

  export class SignatureInfo {
    dossierId: string;
    folderId: string;
    folderName: string;
    folderExpiration: string;
    timestamp: string;
    state: string;
    praticaId: string;
    documents: any[];
  }