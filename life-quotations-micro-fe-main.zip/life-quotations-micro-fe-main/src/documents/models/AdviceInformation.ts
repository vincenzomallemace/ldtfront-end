export interface Adviceinformation {
  numeroProposta: number;
  ndgUtente: number;
  matricolaUtente: string;
  ndgPatrimonio: number;
  ndgOrdinante: number;
  dataCrezione: number;
  dataScadenza: number;
  dataConsegna: number;
  dataAccettazione: number;
  tipoOrdinante: string;
  statoProposta: string;
  tipologiaAccettazione: string;
  coordinateIBAN: string;
  intestatarioIBAN: string;
  tipoIntestazioneIBAN: string;
  codiceModelloPdfGenerico: string;
  numeroProtocolloPdfGenerico: string;
  descrizioneModelloPdfGenerico: string;
  ordinePolizza: OrdinePolizzaAdvice[];
  //tipoModelloPdf: TipoModelloPdfAdvice[];
  areaComuneServiziCad: AreaComuneServiziCadAdvice;
  sottostanti: SottostantiAdvice;
}

export interface OrdinePolizzaAdvice {
  progressivoOperazione: number;
  codiceIAC: number;
  tipoOperazione: string;
  codiceProdotto: string;
  codiceLinea: string;
  tipoLinea: string;
  metatitolo: string;
  codiceAgenzia: string;
  numeroPolizza: string;
  codiceRapporto: string;
  controvaloreIniziale: number;
  controvaloreFinale: number;
  controvaloreOperazione: number;
  progressivoOperazioneCollegato: number;
  codiceSconto: string;
  codiceModelloPdf: string;
  numeroProtocolloPdf: string;
  descrizioneModelloPdf: string;
}

export interface AreaComuneServiziCadAdvice {
  tipoSegnalazioneInterfacciaNonConforme: string;
  chiaveMemorizzazioneStato: string;
  identificativoServizioGeneranteErrore: string;
  jobName: string;
  identificativoInterfaccia: string;
  attivazioneDisattivazioneDecodificaMessaggio: string;
  attivazioneDisattivazioneControlli: string;
  sysidCics: string;
  switchGestioneIstituto: string;
  dataSessioneContabile: string;
  identificativoLicenza: string;
  carattereNullo: string;
  ulterioriElementi: string;
  decodificaMessaggio: string;
  programmaGeneranteErrore: string;
  clientServizio: string;
  indicatoreAttivazioneDebug: string;
  indicatoreRichiestaRollback: string;
  indicatoreRichiestaSyncpoint: string;
  oraSistema: string;
  dataSistema: string;
  codiceProfilo: string;
  codiceTerminale: string;
  identificativoServizio: string;
  tipoConnessioneElaborativa: number;
  sessioneTransazioneCityTp: number;
  livelloServizioGeneranteErrore: number;
  identificativoMetodoGeneranteErrore: number;
  codiceLingua: number;
  contatoreLocale: number;
  livelloChiamataServizio: number;
  codiceMessaggio: number;
  esitoServizio: number;
  livelloSicurezzaAttivo: number;
  contatoreRipartenzaMetodo: number;
  tipoGestioneAreaOutput: number;
  codiceDipendenza: number;
  identificativoMetodo: number;
}

export interface SottostantiAdvice {
  defOrdine: DefOrdineAdvice[];
  id: number;
}

export interface DefOrdineAdvice {
  inquiryPropostaPolizzaTabSottostanti: InquiryPropostaPolizzaTabSottostantiAdvice[];
  progressivoOperazione: number;
}

export interface InquiryPropostaPolizzaTabSottostantiAdvice {
  codFondo: string;
  tipoSottostante: string;
  metatitoloSottostante: string;
  percentualeIniziale: number;
  percentualeDisinvestimento: number;
  percentualeInvestimento: number;
}

export interface AdviceDocument {
  codiceModelloPdf: string;
  numeroProtocolloPdf: string;
  descrizioneModelloPdf: string;
}

export interface AdviceData {
  ndgOperatore: number;
  ndgPatrimonio: number;
  ndgOrdinante: number;
  tipoOperazione: string;
  matricolaOperatore: string;
  codiceModelloPdfGenerico: string;
  numeroProtocolloPdfGenerico: string;
  descrizioneModelloPdfGenerico: string;
  adviceDocument: AdviceDocument[];
}
