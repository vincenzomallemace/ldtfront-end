import { KeyValue } from "commons/models/YogaModels";
import { Group } from "./Group";
import { InputDocument } from "./InputDocument";
import { OutputDocument } from "./OutputDocument";

export interface Dossier {
  dossierId: string;
  creationInstant: Date;
  code: string;
  entityId: string;
  entityCode: string;
  entityType: string;
  signLink: string;
  inputDocuments: KeyValue<InputDocument>;
  outputDocuments: KeyValue<OutputDocument>;
  groups?: KeyValue<Group>;
  state: DossierState;
  signData?: KeyValue<SignData>;
  signCompleted?: boolean;
}

export enum TYPE {
  CONTRACT = "contract",
  FNOL = "fnol",
  QUOTATION = "quotation",
}

export enum DossierState {
  READY = "READY",
  PENDING = "PENDING",
  ERROR = "ERROR",
}

export interface SignData {
  taxId: string;
  url?: string;
  documents: KeyValue<string>;
  sentByEmail?: boolean;
}

const isGroupValid = (group: Group) =>
  Object.values(group.inputDocuments).some(
    (e) => e.visible && (e.documentId || e.multipleDocumentIds.length > 0)
  );

const hasInputDocuments = (dossier: Dossier): boolean => {
  if (
    dossier &&
    dossier.inputDocuments &&
    Object.values(dossier.inputDocuments).filter((doc) => doc.visible).length >
      0
  ) {
    return true;
  }
  return (
    dossier &&
    dossier.groups &&
    Object.values(dossier.groups)
      .filter((group) => group.visible)
      .flatMap((group) => Object.values(group.inputDocuments))
      .some((document) => document.visible)
  );
};

const hasMandatoryInputDocuments = (dossier: Dossier): boolean => {
  if (
    dossier &&
    dossier.inputDocuments &&
    Object.values(dossier.inputDocuments).filter(
      (doc) => doc.visible && doc.mandatory
    ).length > 0
  ) {
    return true;
  }
  return (
    dossier &&
    dossier.groups &&
    Object.values(dossier.groups)
      .filter((group) => group.visible)
      .flatMap((group) => Object.values(group.inputDocuments))
      .some((document) => document.visible && document.mandatory)
  );
};

const hasOutputDocuments = (dossier: Dossier): boolean =>
  dossier &&
  dossier.outputDocuments &&
  Object.values(dossier.outputDocuments).filter((doc) => doc.visible).length >
    0;

const areOutputDocumentsReady = (dossier: Dossier): boolean =>
  dossier &&
  dossier.outputDocuments &&
  Object.values(dossier.outputDocuments)
    .filter((doc) => doc.visible)
    .every((doc) => !!doc.documentId);

const areOutputDocumentsAllSigned = (dossier: Dossier): boolean =>
  dossier &&
  dossier.outputDocuments &&
  Object.values(dossier.outputDocuments)
    .filter((document) => document.signRequired)
    .every((document) => document.signed);

const haveAllUrlsSignData = (dossier: Dossier): boolean =>
  dossier &&
  dossier.signData &&
  Object.values(dossier.signData).length > 0 &&
  Object.values(dossier.signData).every((s) => !!s.url);

const getSingleDocsIds = (inputDocuments: InputDocument[]) => {
  let singles = inputDocuments.filter((i) => !i.multipleInput);
  return singles.map((s) => s.documentId).filter((id) => !!id);
};

const getMultiDocsIds = (inputDocuments: InputDocument[]) => {
  let multi = inputDocuments.filter((i) => i.multipleInput);
  return multi.flatMap((m) => m.multipleDocumentIds).filter((id) => !!id);
};

const getDocumentIds = (inputDocuments: KeyValue<InputDocument>) => {
  let inputDocs = sortInputDocuments(inputDocuments);
  let singleDocIds = getSingleDocsIds(inputDocs);
  let multiIds = getMultiDocsIds(inputDocs);
  return singleDocIds.concat(multiIds);
};

const sortInputDocuments = (inputDocuments: KeyValue<InputDocument>) =>
  inputDocuments
    ? Object.values(inputDocuments)
        .filter((doc) => doc.visible)
        .sort((x) => (x.mandatory ? -1 : 1))
    : [];

const sortGroups = (dossier: Dossier) =>
  dossier
    ? Object.values(dossier.groups || {}).filter((group) => group.visible)
    : [];

export const DossierUtils = {
  isGroupValid,
  hasInputDocuments,
  hasMandatoryInputDocuments,
  hasOutputDocuments,
  areOutputDocumentsReady,
  areOutputDocumentsAllSigned,
  haveAllUrlsSignData,
  getDocumentIds,
  sortInputDocuments,
  sortGroups,
};
