import { DocumentAttributes } from "documents/models/DocumentAttributes";
import { Dossier, DossierState } from "documents/models/Dossier";

export interface DossierInfo {
  state: DossierState;
  documents: DocumentInfo[];
  dossier: Dossier;
}

export interface DocumentInfo {
  code: string;
  name: string;
  attributes?: DocumentAttributes;
  acknowledgmentRequired: boolean;
  acknowledge: boolean;
}
