import { ArrowCircleRightIcon, SaveIcon } from "@heroicons/react/outline";
import { config, CTX } from "commons/Configuration";
import { toYupObjectByCode } from "commons/FormUtils";
import ErrorPage from "commons/components/ErrorPage";
import Messages from "commons/components/Messages";
import { StickyBar } from "commons/components/StickyBar";
import { YogaButton } from "commons/components/YogaButton";
import YogaCard from "commons/components/YogaCard";
import { YogaScrollToFieldError } from "commons/components/YogaScrollToFieldError";
import YogaSkeleton from "commons/components/YogaSkeleton";
import ParametersForm from "commons/formik/form/ParametersForm";
import { KeyValue } from "commons/models/YogaModels";
import { YogaParam } from "commons/models/YogaParam";
import { Field, Form, Formik, FormikProps, FormikValues } from "formik";
import { useContext, useEffect, useMemo, useRef, useState } from "react";
import { FormattedMessage, useIntl } from "react-intl";
import { useNavigate, useParams } from "react-router-dom";
import * as yup from "yup";
import useLifeProductIncomplete from "./hooks/useLifeProductIncomplete";
import { Product } from "./models/Product";
import { EMPTY, scrollToTop } from "commons/Utils";
import { ExtendedSelect } from "commons/components/ExtendedSelect";
import { lifeProductService } from "commons/services/LifeProductService";
import { toast } from "react-toastify";
import { Context } from "commons/contexts/Context";
import PartitionOptionForm from "./forms/PartitionOptionForm";
import { PartitionOption } from "./models/PartitionOption";
import { AVAILABLE_PARTITION_OPTION_TYPE, AvailablePartitionOption } from "./models/AvailablePartitionOption";

export default function TechnicalDataPage() {
  const { productInstanceId: productId } = useParams<string>();
  const navigate = useNavigate();

  const { product, setProduct, updateProductParameters, updateProduct, productError } = useLifeProductIncomplete(productId);
  const { initialValues, validationSchema } = useTechnicalDataForm(product);
  const { changeLoading } = useContext(Context);

  const intl = useIntl();

  const formRef = useRef<FormikProps<any>>(null);

  /*useEffect(() => {
    scrollToProductMessages();
  }, [product?.messages]);*/

  const availablePartitionOptions = useMemo(() => {
    if (product && product.availablePartitionOptions) {
      return product.availablePartitionOptions.filter((opt) => opt.visible);
    }
  }, [product]);

  async function updateOnChange(parameters: KeyValue<YogaParam>) {
    // It ensures that formik has been initialized correctly
    if (initialValues["parameters"] && Object.keys(initialValues["parameters"]).length == Object.keys(parameters).length) {
      if (formRef.current?.values?.partitionOption) {
        const partitionOption = formRef.current.values.partitionOption;
        updateProductParameters(parameters, partitionOption);
      } else updateProductParameters(parameters);
    }
  }

  const agreements = {
    isAvailable: () => {
      return product.availableAgreements && product.availableAgreements.length > 0;
    },
    getAvailable: () => {
      return product.availableAgreements.map((e) => {
        return agreements._transform(e);
      });
    },
    selected: () => {
      return agreements._transform(product.agreement);
    },
    onUpdate: (selected: { value: string; label: string }) => {
      if (product.agreement != selected?.value) {
        changeLoading(1);
        product.agreement = selected?.value;
        const updatedProduct: Product = JSON.parse(JSON.stringify(product));
        updatedProduct.parameters = formRef.current.values.parameters;
        updatedProduct.partitionOption = formRef.current.values.partitionOption;
        lifeProductService.updateProductIncomplete(product.productId, updatedProduct).then((response) => {
          setProduct(response.data);
          changeLoading(-1);
        });
      }
    },
    _transform: (value: string) => {
      return {
        value: value,
        label: intl.formatMessage({ id: value || EMPTY }),
      };
    },
  };

  async function goNext(values: FormikValues) {
    changeLoading(1);
    try {
      let updatedProduct = JSON.parse(JSON.stringify(product));
      if (product.availablePartitionOptions?.length > 0) {
        updatedProduct = (await lifeProductService.addPartitionOption(productId, values.partitionOption)).data;
      }
      updatedProduct.parameters = values.parameters;
      updateProduct(updatedProduct, false).then((areErrors) => {
        if (!areErrors) {
          updateProduct(updatedProduct, true).then((areErrors) => {
            if (!areErrors) {
              navigate(`${CTX}/offers/${productId}/quotation`);
            } else scrollToTop();
          });
        } else scrollToTop();
      });
    } finally {
      changeLoading(-1);
    }
  }

  function saveDraft(values: KeyValue<any>) {
    changeLoading(1);
    const paramsVisible = Object.values(values.parameters).some((param: YogaParam) => param.visible);
    const arePartitionOptionsAvaiable = product.availablePartitionOptions?.length > 0;

    if (paramsVisible)
      Object.entries(values.parameters)
        .filter(([, param]: [string, YogaParam]) => param.visible)
        .forEach(([key, param]: [string, YogaParam]) => (product.parameters[key] = param));
    if (arePartitionOptionsAvaiable) {
      product.partitionOption = values.partitionOption as PartitionOption;
    }
    lifeProductService
      .saveProductIncompleteDraft(product.productId, product)
      .then((result) => {
        setProduct(result.data);
        toast.success(
          intl.formatMessage(
            {
              id: "proposalDrafted",
            },
            { number: result.data.quotationNumber }
          )
        );
      })
      .catch((e) => {
        console.error(e);
        toast.error(
          product.quotationNumber
            ? intl.formatMessage(
                {
                  id: "proposalDraftedErrorWithNumber",
                },
                { number: product.quotationNumber }
              )
            : intl.formatMessage({
                id: "proposalDraftedError",
              })
        );
      })
      .finally(() => changeLoading(-1));
  }

  return (
    <>
      {productError ? (
        <ErrorPage />
      ) : (
        <>
          {product ? (
            <>
              <StickyBar
                //backFunction={() => saveDraft(formRef.current.values)}
                breadcrumb={
                  <div className="flex flex-col truncate">
                    <div data-qa="technical-data-page-title" className="truncate">
                      <FormattedMessage id="technicalData" />
                    </div>
                    <div className="inline-flex flex-wrap gap-x-4 items-center" data-qa="extra-info">
                      {/*product.quotationNumber && (
                        <span className="text-base font-normal truncate" data-qa="product-quotationNumber">
                          N. {product.quotationNumber}
                        </span>
                      )*/}
                      <span className="text-base font-normal truncate" data-qa="policyholder-title">
                        {product.policyHolder?.surnameOrCompanyName}&nbsp;
                        {product.policyHolder?.name}
                      </span>
                      <span className="text-base font-normal truncate" data-qa="product-description">
                        {product.description}
                      </span>
                    </div>
                  </div>
                }
              >
                <div className="self-end text-right flex-1 flex gap-x-4">
                  {config.SAVE_DRAFT_LIFE_PROPOSAL && (
                    <YogaButton
                      kind="default"
                      type="button"
                      outline
                      className="flex gap-2 items-center"
                      data-qa="save-draft-button"
                      action={() => saveDraft(formRef.current.values)}
                    >
                      <SaveIcon className="w-5 -ml-1 shrink-0" />
                      <FormattedMessage id="saveDraft" />
                    </YogaButton>
                  )}
                  <YogaButton
                    kind="default"
                    form="productTechnicalData"
                    className="flex gap-2 items-center"
                    //action={() => saveDraft(formRef.current.values)}
                  >
                    <ArrowCircleRightIcon className="w-5 mr-2 -ml-1" />
                    <span className="hidden lg:block">
                      <FormattedMessage id="continue" />
                    </span>
                  </YogaButton>
                </div>
              </StickyBar>
              <div className="px-3">
                <Messages messages={product.messages} entity="product" />

                <Formik initialValues={initialValues} validationSchema={validationSchema} innerRef={formRef} onSubmit={goNext} enableReinitialize>
                  {() => (
                    <Form id="productTechnicalData">
                      {(agreements.isAvailable() || availablePartitionOptions?.length > 0) && (
                        <YogaCard data-qa="semi-static-data-card" className="flex flex-col gap-y-4 mb-8">
                          {agreements.isAvailable() && (
                            <div className="yoga-form-input w-full grid grid-cols-2 lg:grid-cols-3 gap-x-8">
                              <label className="block text-body-text text-base" data-qa="agreement-label">
                                <FormattedMessage id="agreement" />
                                <ExtendedSelect
                                  id="agreement"
                                  values={agreements.getAvailable()}
                                  selected={agreements.selected()}
                                  onUpdate={agreements.onUpdate}
                                  options={{ clearable: true }}
                                />
                              </label>
                            </div>
                          )}
                          {availablePartitionOptions?.length > 0 && (
                            <div data-qa="partition-option-container">
                              <div className="mb-2 flex gap-x-4 items-center">
                                <h4 data-qa="partition-option-title" className="shrink-0">
                                  <FormattedMessage id="partitionOptions" />
                                </h4>
                                <span className="line"></span>
                              </div>

                              <Field name="partitionOption" component={PartitionOptionForm} availablePartitionOptions={availablePartitionOptions} />
                            </div>
                          )}
                        </YogaCard>
                      )}
                      {Object.values(product.parameters).some((param: YogaParam) => param.visible) && (
                        <YogaCard data-qa="parameters-card">
                          <Field name="parameters">
                            {(fieldProps) => <ParametersForm {...fieldProps} parameters={product.parameters} onUpdateOnChange={updateOnChange} />}
                          </Field>
                        </YogaCard>
                      )}

                      <YogaScrollToFieldError />
                    </Form>
                  )}
                </Formik>
              </div>
            </>
          ) : (
            <YogaSkeleton position="outer" />
          )}
        </>
      )}
    </>
  );
}

function useTechnicalDataForm(product?: Product) {
  const [initialValues, setInitialValues] = useState({});
  const [validationSchema, setValidationSchema] = useState(yup.object());
  const intl = useIntl();

  const requiredMessage = intl.formatMessage({ id: "required" });

  const maxInvestmentValue = intl.formatMessage({ id: "maxInvestmentValue" });
  const minInvestmentValue = (min: number) => {
    return intl.formatMessage({ id: "minInvestmentValue" }, { min: min });
  };

  const investmentSchema = (min: number = 0) => yup.number().min(min, minInvestmentValue(min)).max(100, maxInvestmentValue).required(requiredMessage);

  useEffect(() => {
    if (product) {
      let internalInitialValues = {
        parameters: { ...product.parameters },
      };
      let internalValidationSchema = yup.object({
        parameters: yup.object().shape(toYupObjectByCode(Object.values(product.parameters), intl)),
      });
      const partitionOptionSchema = yup.object({
        partitionOption: yup.object({
          code: yup.string().required(requiredMessage),
          unitLinkedInvestment: yup
            .number()
            .when("minInvestment", (minInvestment) => (minInvestment > 0 ? investmentSchema(minInvestment) : investmentSchema(0))),
        }),
      });

      if (product.availablePartitionOptions?.length > 0) {
        let partitionOptionValues = {};
        if (product.availablePartitionOptions.length == 1) {
          const option: AvailablePartitionOption = product.availablePartitionOptions[0];
          Object.assign(partitionOptionValues, {
            code: option.code,
            name: option.name,
            minInvestment: option.minUnitLinkedInvestment,
          });
          if (option.type !== AVAILABLE_PARTITION_OPTION_TYPE.FREE) {
            Object.assign(partitionOptionValues, {
              unitLinkedInvestment: product.partitionOption?.unitLinkedInvestment ?? option.minUnitLinkedInvestment,
              segregatedInvestment: product.partitionOption?.segregatedInvestment ?? 100 - option.minUnitLinkedInvestment,
            });
          } else {
            Object.assign(partitionOptionValues, {
              unitLinkedInvestment: product.partitionOption?.unitLinkedInvestment ?? "",
              segregatedInvestment: product.partitionOption?.segregatedInvestment ?? "",
            });
          }
        } else
          Object.assign(partitionOptionValues, {
            code: product.partitionOption?.code || "",
            name: product.partitionOption?.name || "",
            unitLinkedInvestment: product.partitionOption?.unitLinkedInvestment ?? "",
            segregatedInvestment: product.partitionOption?.segregatedInvestment ?? "",
            minInvestment: product.partitionOption?.code
              ? product.availablePartitionOptions.find((opt) => opt.code == product.partitionOption.code).minUnitLinkedInvestment
              : "",
          });

        Object.assign(internalInitialValues, {
          partitionOption: {
            ...partitionOptionValues,
          },
        });
        internalValidationSchema = internalValidationSchema.concat(partitionOptionSchema);
      }

      setInitialValues(internalInitialValues);
      setValidationSchema(internalValidationSchema);
    }
  }, [product]);

  return {
    initialValues,
    validationSchema,
  };
}
