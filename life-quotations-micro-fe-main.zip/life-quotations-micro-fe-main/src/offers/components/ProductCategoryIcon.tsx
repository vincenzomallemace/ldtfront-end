import { RoundSvgIcon } from "commons/components/RoundSvgIcon";
import {
  BriefcaseIcon,
  DotsHorizontalIcon,
  HeartIcon,
  HomeIcon,
  OfficeBuildingIcon,
  ShieldCheckIcon,
  UserGroupIcon,
  CameraIcon,
  ChartBarIcon,
} from "@heroicons/react/outline";
import {
  BriefcaseIcon as BriefcaseIconSolid,
  DotsHorizontalIcon as DotsHorizontalIconSolid,
  HeartIcon as HeartIconSolid,
  HomeIcon as HomeIconSolid,
  OfficeBuildingIcon as OfficeBuildingIconSolid,
  ShieldCheckIcon as ShieldCheckIconSolid,
} from "@heroicons/react/solid";
import { materialIcon } from "assets/icons";

interface Props {
  className?: string;
  category?: string;
  size?: string;
  style?: string;
}

{
  /* size and style props are needed only when materialIcon is used, otherwise it takes it from the className */
}
export function ProductCategoryIcon({ category = "OTHER", className = "", size = "text-2xl", style = "round" }: Props) {
  const solid = style === "round";
  const productCategoryIcons = {
    MOBILITY: materialIcon("directions_car", style, size),
    HOME_FAMILY: solid ? HomeIconSolid : HomeIcon,
    HEALTHCARE: solid ? HeartIconSolid : HeartIcon,
    WELFARE: solid ? ShieldCheckIconSolid : ShieldCheckIcon,
    PROFESSIONAL: solid ? BriefcaseIconSolid : BriefcaseIcon,
    BUSINESS: solid ? OfficeBuildingIconSolid : OfficeBuildingIcon,
    OTHER: solid ? DotsHorizontalIconSolid : DotsHorizontalIcon,
    INVESTMENT: materialIcon("trending_up", style),
    SERVICE: UserGroupIcon,
    DEVICE: CameraIcon,
    UNIT_LINKED: ChartBarIcon,
  };
  const SvgIcon = productCategoryIcons[category] || productCategoryIcons.OTHER;
  return <RoundSvgIcon className={className} SvgIcon={SvgIcon} />;
}
