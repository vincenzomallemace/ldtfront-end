import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
} from "@aws-amplify/ui-react";
import { ArrowDownIcon, ArrowUpIcon } from "@heroicons/react/outline";
import { FinancialAsset } from "models/FinancialAdvice";
import { useEffect, useState } from "react";
import { FormattedMessage } from "react-intl";

export default function FundsTable({
  funds,
  investmentLine,
}: {
  funds: FinancialAsset[];
  investmentLine: string;
}) {
  const [data, setData] = useState(undefined);
  const [sortedBy, setSortedBy] = useState("investmentPercentage");
  const [sortedState, setSortedState] = useState(-1);

  useEffect(() => {
    if (funds) {
      const sortedFunds = funds.sort(
        (a, b) => b["investmentPercentage"] - a["investmentPercentage"]
      );
      setData(sortedFunds);
    }
  }, [funds]);

  const sortBy = (key: string) => {
    let newSortedState = 1;
    if (sortedBy === key) {
      if (sortedState === 1) {
        newSortedState = -1;
      } else {
        newSortedState = 0;
      }
    }
    const sortedData =
      newSortedState == 0
        ? funds
        : [...data].sort((a, b) => {
            if (a[key] < b[key]) {
              return -1 * newSortedState;
            }
            if (a[key] > b[key]) {
              return 1 * newSortedState;
            }
            return 0;
          });

    setData(sortedData);
    setSortedBy(newSortedState == 0 ? null : key);
    setSortedState(newSortedState);
  };

  function displayArrow(key: string) {
    if (key == sortedBy) {
      switch (sortedState) {
        case 1:
          return (
            <ArrowUpIcon
              className="h-4 w-4 shrink-0"
              data-qa={`ascending-order-by-${sortedBy}`}
            />
          );
        case -1:
          return (
            <ArrowDownIcon
              className="h-4 w-4 shrink-0"
              data-qa={`descending-order-by-${sortedBy}`}
            />
          );
      }
    } else return <div className="h-4 w-4 shrink-0"></div>;
  }

  return (
    <div className="block w-full">
      {data && (
        <Table
          className="table-fixed"
          data-qa={`investmentLine-${investmentLine}-funds-table`}
        >
          <TableHead>
            <TableRow>
              <TableCell as="th" className="w-2/5">
                <div className="flex items-center">
                  <span
                    className="cursor-pointer"
                    onClick={() => sortBy("description")}
                    data-qa="description-label"
                  >
                    <FormattedMessage id="description" />
                  </span>
                  {displayArrow("description")}
                </div>
              </TableCell>
              <TableCell as="th" className="w-2/5">
                <div className="flex items-center">
                  <span
                    className="cursor-pointer"
                    onClick={() => sortBy("isinCode")}
                    data-qa="isinCode-label"
                  >
                    <FormattedMessage id="isin" />
                  </span>
                  {displayArrow("isinCode")}
                </div>
              </TableCell>
              <TableCell as="th" className="w-1/5">
                <div className="flex items-center justify-end">
                  <span
                    className="cursor-pointer"
                    onClick={() => sortBy("investmentPercentage")}
                    data-qa="investmentPercentage-label"
                  >
                    <FormattedMessage id="investment" />
                  </span>
                  {displayArrow("investmentPercentage")}
                </div>
              </TableCell>
              {/* <TableCell as="th"></TableCell> */}
            </TableRow>
          </TableHead>
          <TableBody>
            {data.map((fund, index) => (
              <TableRow key={`investmentLine-${investmentLine}-fund[${index}]`}>
                <TableCell
                  as="td"
                  className="truncate"
                  data-qa={`investmentLine-${investmentLine}-fund[${index}]-description`}
                >
                  {fund.description || "-"}
                </TableCell>
                <TableCell
                  as="td"
                  data-qa={`investmentLine-${investmentLine}-fund[${index}]-code`}
                >
                  {fund.isinCode || "-"}
                </TableCell>
                <TableCell
                  as="td"
                  data-qa={`investmentLine-${investmentLine}-fund[${index}]-investmentPercentage`}
                >
                  <div className="flex justify-end">
                    <span>
                      {fund.investmentPercentage
                        ? `${fund.investmentPercentage}%`
                        : "-"}
                    </span>
                    <div className="h-4 w-4"></div>
                  </div>
                </TableCell>
                {/* <TableCell className="w-4">
                  <SearchIcon className="h-8 w-8" />
                </TableCell> */}
              </TableRow>
            ))}
          </TableBody>
        </Table>
      )}
    </div>
  );
}
