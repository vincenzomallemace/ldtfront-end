import { Menu, Transition } from "@headlessui/react";
import { ChevronDownIcon, ChevronUpIcon } from "@heroicons/react/outline";
import FormattedMoney from "commons/components/FormattedMoney";
import { Money } from "commons/models/YogaModels";
import { Premium } from "models/PremiumComponents";
import { Fragment } from "react";
import { FormattedMessage } from "react-intl";

export function PremiumDropDown({ premium, entity }: { premium: Premium; entity: string }) {
  interface PremiumElement {
    label: string;
    amount: Money;
  }

  const premiumElements: PremiumElement[] = [
    { label: "investmentAmount", amount: premium.investment },
    // { label: "commissionFees", amount: premium.commissionFees },
    // { label: "dues", amount: premium.dues },
    // { label: "bonus", amount: premium.bonus },
  ];

  function showAmount(premiumElement: PremiumElement) {
    if (premiumElement.label == "bonus" && premiumElement.amount.amount == 0) return false;
    else return true;
  }

  return (
    <Menu as="div" className="relative">
      {({ open }) => (
        <>
          <Menu.Button
            className="flex items-center rounded-md bg-title-text px-4 py-2 text-white gap-x-4 ml-auto"
            data-qa={`${entity}-premium-dropDown-button`}
          >
            <span data-qa="investment-title" className="leading-none">
              <FormattedMessage id="premium" />
            </span>
            <span className="text-xl font-bold leading-none" data-qa="investment-amount">
              <FormattedMoney money={premium.gross} />
            </span>
            {open && <ChevronUpIcon className="h-6 w-6" />}
            {!open && <ChevronDownIcon className="h-6 w-6" />}
          </Menu.Button>
          <Transition
            as={Fragment}
            enter="transition ease-out duration-100"
            enterFrom="transform opacity-0 scale-95"
            enterTo="transform opacity-100 scale-100"
            leave="transition ease-in duration-75"
            leaveFrom="transform opacity-100 scale-100"
            leaveTo="transform opacity-0 scale-95"
          >
            <Menu.Items
              className="absolute right-0 mt-2 p-4 w-96 origin-top-right rounded-lg bg-white shadow-lg flex flex-col gap-y-2 z-10"
              data-qa="premium-components-container"
            >
              {premiumElements.map((element) => (
                <Fragment key={element.label}>
                  {showAmount(element) && (
                    <div className="flex flex-row gap-x-4 items-center justify-between text-body-text" data-qa={`${element.label}-section`}>
                      <span data-qa={`${element.label}-title`} className="leading-none">
                        <FormattedMessage id={element.label} />
                      </span>
                      <span className="text-xl font-bold leading-none" data-qa={`${element.label}-amount`}>
                        <FormattedMoney money={element.amount} />
                      </span>
                    </div>
                  )}
                </Fragment>
              ))}
            </Menu.Items>
          </Transition>
        </>
      )}
    </Menu>
  );
}
