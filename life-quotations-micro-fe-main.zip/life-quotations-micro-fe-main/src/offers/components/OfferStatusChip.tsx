import classNames from "classnames";
import { ChipProps, YogaChip } from "commons/components/YogaChip";
import { FinancialAdviceOffer } from "commons/services/LifeProductService";
import { HTMLAttributes } from "react";
import { FormattedMessage } from "react-intl";

interface OfferStatusChipProps extends HTMLAttributes<any> {
  offer: FinancialAdviceOffer;
}
export default function OfferStatusChip({
  offer,
  className,
}: OfferStatusChipProps) {
  const statusChipProps: {
    [status: string]: ChipProps;
  } = {
    INCOMPLETE: { type: "default", style: "offerStatus" },
    DRAFT: { type: "warning", style: "offerStatus" },
    VALID_PROPOSAL: { type: "success", style: "offerStatus" },
    COMPLETED_PROPOSAL: { type: "default", style: "offerStatus" },
    PROPOSAL_TO_SIGN: { type: "default", style: "offerStatus" },
  };
  return (
    <>
      {offer.product.status && (
        <div
          className={classNames(
            className,
            offer.product.status === "INCOMPLETE" && "hidden"
          )}
        >
          <YogaChip {...statusChipProps[offer.product.status]} size="small">
            <FormattedMessage id={offer.product.status} />
          </YogaChip>
        </div>
      )}
    </>
  );
}
