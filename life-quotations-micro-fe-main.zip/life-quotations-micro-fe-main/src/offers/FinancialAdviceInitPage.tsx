import { ArrowCircleRightIcon } from "@heroicons/react/outline";
import { StickyBar } from "commons/components/StickyBar";
import { YogaButton } from "commons/components/YogaButton";
import YogaCard from "commons/components/YogaCard";
import { FormattedMessage, useIntl } from "react-intl";
import { Field, Form, Formik } from "formik";
import * as Yup from "yup";
import { FormikInput } from "commons/formik/FormikInput";
import { v4 as uuidv4 } from "uuid";
import { config, CTX } from "commons/Configuration";
import { useContext, useEffect, useState } from "react";
import { Context } from "commons/contexts/Context";
import { financialAdvicesService } from "offers/services/FinancialAdvicesService";
import { FinancialAdvice } from "models/FinancialAdvice";
import { useLocation, useNavigate } from "react-router-dom";
import { UserContext } from "commons/contexts/UserProvider";
import { ManagementNode } from "commons/models/nodes/ManagementNode";

export default function FinancialAdviceInitPage() {
  const intl = useIntl();
  const { changeLoading } = useContext(Context);
  const navigate = useNavigate();
  const { search } = useLocation();
  const partyId =
    new URLSearchParams(search).get("partyId") ?? "TRNMRT75R56E379X";

  const { rootManagementNodes } = useContext(UserContext);
  const [initialValues, setInitialValues] = useState<{
    financialAdvice: string;
  }>(undefined);

  const requiredMessage = intl.formatMessage({ id: "required" });

  useEffect(() => {
    let managementNodeDefault = {
      id: "32322f8b-715b-4c87-b10f-d28631a903eb",
      code: "6001",
      description: "ZURICH BANK",
    } as ManagementNode;

    if (
      rootManagementNodes &&
      rootManagementNodes.length &&
      rootManagementNodes[0]
    ) {
      managementNodeDefault = rootManagementNodes[0];
    }

    const financialAdviceExample: FinancialAdvice = setFinancialAdviceExample(
      managementNodeDefault
    );

    setInitialValues({
      financialAdvice: JSON.stringify(financialAdviceExample, null, 2),
    });
  }, [rootManagementNodes]);

  const validationSchema = Yup.object({
    financialAdvice: Yup.string().required(requiredMessage),
  });

  const setFinancialAdviceExample = (
    managementNodeDefault: ManagementNode
  ): FinancialAdvice => {
    let financialAdvice = JSON.parse(
      JSON.stringify(config.FINANCIAL_ADVICE_TEMPLATE ?? {})
    ) as FinancialAdvice;
    if (!financialAdvice.financialAdviceId) {
      financialAdvice.financialAdviceId = uuidv4();
    }
    if (!financialAdvice.contractHolder?.partyId) {
      financialAdvice.contractHolder = {
        ...financialAdvice.contractHolder,
        partyId: partyId,
      };
    }
    financialAdvice.financialOffers?.forEach((financialOffer) => {
      if (!financialOffer.financialOfferId) {
        financialOffer.financialOfferId = uuidv4();
      }
      if (!financialOffer.managementNode) {
        financialOffer.managementNode = managementNodeDefault;
      }
    });

    return financialAdvice;
  };

  const createFinancialAdvice = async (value: any) => {
    const advice = JSON.parse(value.financialAdvice) as FinancialAdvice;
    changeLoading(1);

    const result = await financialAdvicesService.create(advice);
    const financialAdvice = result.data;

    changeLoading(-1);
    navigate(`${CTX}/advices/${financialAdvice.financialAdviceId}`);
  };

  const retrieveAnAdvice = async (financialAdviceId: string) => {
    changeLoading(1);
    const result = await financialAdvicesService.get(financialAdviceId);
    changeLoading(-1);
    if (result && result.data) {
      return result.data as FinancialAdvice;
    }
    return null;
  };

  return (
    <>
      <StickyBar
        hasBackButton={false}
        breadcrumb={
          <>
            <FormattedMessage id="financialAdvice" />
          </>
        }
      >
        <YogaButton kind="default" form="financialAdvice">
          <ArrowCircleRightIcon className="w-5 mr-2 -ml-1" />
          <FormattedMessage id="continue" />
        </YogaButton>
      </StickyBar>

      <div className="px-3">
        <YogaCard>
          <div className="flex flex-col gap-y-8">
            {initialValues && validationSchema && (
              <Formik
                initialValues={initialValues}
                onSubmit={createFinancialAdvice}
                validationSchema={validationSchema}
              >
                {({ setFieldValue }) => (
                  <Form id="financialAdvice">
                    <div className="flex flex-col gap-y-4">
                      <div className="yoga-form-input self-start">
                        <label
                          htmlFor="financialAdviceIdSearch"
                          className="block text-body-text text-base"
                          data-qa="financialAdviceIdSearch-label"
                        >
                          <FormattedMessage id="financialAdviceIdSearch" />
                          <input
                            className="h-12 focus:outline-none focus:border-primary rounded-lg tracking-wider py-3 px-4 text-base w-full shadow-inner border-2 border-title-text bg-box-background text-body-text"
                            type="text"
                            id="financialAdviceIdSearch"
                            data-qa="financialAdviceIdSearch-input"
                            onBlur={async (event) => {
                              const retrieved = await retrieveAnAdvice(
                                event.target.value
                              );
                              if (retrieved) {
                                setFieldValue(
                                  "financialAdvice",
                                  JSON.stringify(retrieved, null, 2)
                                );
                              }
                            }}
                          />
                        </label>
                      </div>
                      <Field
                        placeholder={intl.formatMessage({
                          id: "financialAdvice",
                        })}
                        key="financialAdvice"
                        name="financialAdvice"
                        component={FormikInput}
                        content={{
                          name: "financialAdvice",
                          value: "",
                          mandatory: true,
                          label: "",
                          type: "TEXTAREA",
                        }}
                        rows={30}
                        fieldName="financialAdvice"
                      />
                    </div>
                  </Form>
                )}
              </Formik>
            )}
          </div>
        </YogaCard>
      </div>
    </>
  );
}
