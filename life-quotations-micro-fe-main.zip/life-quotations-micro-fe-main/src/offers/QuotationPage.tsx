import { ArrowCircleRightIcon, SaveIcon } from "@heroicons/react/outline";
import { CTX, config } from "commons/Configuration";
import { Accordion } from "commons/components/Accordion";
import Messages, { scrollToProductMessages } from "commons/components/Messages";
import { StickyBar } from "commons/components/StickyBar";
import { YogaButton } from "commons/components/YogaButton";
import YogaCard from "commons/components/YogaCard";
import { Context } from "commons/contexts/Context";
import { lifeProductService } from "commons/services/LifeProductService";
import { useContext, useMemo, useRef } from "react";
import { FormattedMessage, useIntl } from "react-intl";
import { useNavigate, useParams } from "react-router-dom";
import { toast } from "react-toastify";
import FundsTable from "./components/FundsTable";
import { PremiumDropDown } from "./components/PremiumDropDown";
import useLifeProductIncomplete from "./hooks/useLifeProductIncomplete";
import { Asset } from "./models/Asset";
import { UnitLinked } from "./models/UnitLinked";
import { Field, Form, Formik, FormikProps } from "formik";
import { FormikInputCheck } from "commons/formik/FormikInputCheck";
import { ContractualOption } from "./models/ContractualOption";
import { KeyValue } from "commons/models/YogaModels";
import { YogaParam } from "commons/models/YogaParam";
import { Product } from "./models/Product";
import ParametersForm from "commons/formik/form/ParametersForm";
import * as yup from "yup";
import { toYupObjectByCode } from "commons/FormUtils";
//import classNames from "classnames";
//import FormattedMoney from "commons/components/FormattedMoney";
import { YogaScrollToFieldError } from "commons/components/YogaScrollToFieldError";

export default function QuotationPage() {
  const { productInstanceId } = useParams();
  const { product, updateProduct, setProduct } = useLifeProductIncomplete(productInstanceId);
  const { changeLoading } = useContext(Context);
  const navigate = useNavigate();
  const intl = useIntl();
  const formRef = useRef<FormikProps<KeyValue<ContractualOption>>>(null);

  const validationSchema = useMemo(() => {
    return (
      product?.contractualOptions &&
      yup.object().shape(
        Object.fromEntries(
          Object.entries(product.contractualOptions)
            .filter(([, value]) => value.selected)
            .map(([key, value]) => [
              key,
              yup.object().shape({
                parameters: yup.object().shape(toYupObjectByCode(Object.values(value.parameters), intl)),
              }),
            ])
        )
      )
    );
  }, [product?.contractualOptions]);

  const asset: Asset = useMemo(() => {
    if (product) {
      return Object.values(product?.assets).reduce((acc, asset) => {
        acc = acc.concat(Object.values(asset).filter((instance) => instance.selected));
        return acc;
      }, [])[0];
    }
  }, [product]);

  const unitLinked: UnitLinked = useMemo(() => {
    if (product) {
      const selectedInstances: Asset[] = Object.values(product?.assets).reduce((acc, asset) => {
        acc = acc.concat(Object.values(asset).filter((instance) => instance.selected));
        return acc;
      }, []);

      return selectedInstances.reduce((acc: UnitLinked, instance) => {
        acc = Object.values(instance.unitLinked).find((unitLinked) => Object.values(unitLinked.lines).some((line) => line.selected));
        return acc;
      }, undefined);
    }
  }, [product]);

  const investmentLine = useMemo(() => {
    if (unitLinked) return Object.values(unitLinked?.lines).find((line) => line.selected);
  }, [unitLinked]);

  const contractualOptions = useMemo(() => {
    if (product && product.contractualOptions) {
      return Object.values(product.contractualOptions).filter((opt) => opt.visible);
    }
  }, [product]);

  async function update(values: KeyValue<ContractualOption>) {
    // before saving the data, check and reset the parameters of the disabled options
    Object.values(values)
      .filter((value) => !value.selected)
      .forEach((value) => Object.values(value.parameters).forEach((parameter) => (parameter.value = parameter.defaultValue)));

    const updated: Product = JSON.parse(JSON.stringify(product));
    updated.contractualOptions = values;

    return updateProduct(updated, false);
  }

  function updateOnChangeParameters(code: string, parameters: KeyValue<YogaParam>) {
    // to avoid duplicate calls check if the values have actually changed
    const changed = Object.values(parameters).reduce((changed, parameter) => changed || parameter.value !== parameter.defaultValue, false);

    if (changed) {
      const productClone: Product = JSON.parse(JSON.stringify(product));
      productClone.contractualOptions[code].parameters = parameters;
      updateProduct(productClone, false);
    }
  }

  async function createProposal(values: KeyValue<ContractualOption>) {
    changeLoading(1);
    let hasErrors = false;
    if (values && Object.keys(values).length > 0) {
      hasErrors = await update(values); //lifeProductService.addContractualOptions(productInstanceId, values);
    }
    if (!hasErrors) {
      await lifeProductService.confirmProductSync(product.productId).then(() => navigate(`${CTX}/offers/${product.productId}/beneficiaries`));
      // .then(() => {
      //     saveDraft()
      //     navigate(`${CTX}/offers/${product.productId}/beneficiaries`)
      //   });
    } else {
      scrollToProductMessages();
    }
    changeLoading(-1);
  }

  function saveDraft() {
    changeLoading(1);
    product.contractualOptions = formRef.current.values;
    lifeProductService
      .saveProductIncompleteDraft(product.productId, product)
      .then((result) => {
        setProduct(result.data);
        toast.success(
          intl.formatMessage(
            {
              id: "proposalDrafted",
            },
            { number: result.data.quotationNumber }
          )
        );
      })
      .catch((e) => {
        console.error(e);
        toast.error(
          product.quotationNumber
            ? intl.formatMessage(
                {
                  id: "proposalDraftedErrorWithNumber",
                },
                { number: product.quotationNumber }
              )
            : intl.formatMessage({
                id: "proposalDraftedError",
              })
        );
      })
      .finally(() => changeLoading(-1));
  }

  return (
    <>
      {product && (
        <>
          <StickyBar
            //backFunction={() => saveDraft}
            breadcrumb={
              <div className="flex flex-col">
                <div data-qa="quotation-page-title" className="truncate">
                  <FormattedMessage id="investmentLines" />
                </div>
                <div className="inline-flex flex-wrap gap-x-4 items-center" data-qa="extra-info">
                  {/*product.quotationNumber && (
                    <span
                      className="text-base font-normal truncate"
                      data-qa="product-quotationNumber"
                    >
                      N. {product.quotationNumber}
                    </span>
                  )*/}
                  <span className="text-base font-normal truncate" data-qa="policyholder-title">
                    {product.policyHolder?.surnameOrCompanyName}&nbsp;
                    {product.policyHolder?.name}
                  </span>
                  <span className="text-base font-normal truncate" data-qa="product-description">
                    {product.description}
                  </span>
                </div>
              </div>
            }
          >
            <div className="self-end text-right flex-1 flex gap-x-4">
              {config.SAVE_DRAFT_LIFE_PROPOSAL && (
                <YogaButton kind="default" type="button" outline className="flex gap-2 items-center" data-qa="save-draft-button" action={saveDraft}>
                  <SaveIcon className="w-5 -ml-1 shrink-0" />
                  <FormattedMessage id="saveDraft" />
                </YogaButton>
              )}
              <YogaButton kind="default" form="contractual-options-form" type="submit" data-qa="continue-button" className="flex gap-2 items-center">
                <ArrowCircleRightIcon className="w-5 mr-2 -ml-1" />
                <span className="hidden lg:block">
                  <FormattedMessage id="continue" />
                </span>
              </YogaButton>
            </div>
          </StickyBar>

          <div className="px-3">
            <Messages messages={product.messages} entity="product" />
            <div className="flex flex-col gap-y-8">
              {/* <div className="flex flex-col gap-y-4">
                <YogaCard className="flex gap-x-2 justify-between lg:justify-normal" data-qa="partition-data-card">
                  <div
                    data-qa="investment-date-container"
                    className={classNames(
                      "w-full lg:w-1/3 flex gap-x-2 items-center",
                      product.partitionOption?.unitLinkedInvestment !== 0 && product.partitionOption?.segregatedInvestment !== 0
                        ? "flex-row lg:items-start lg:flex-col"
                        : "flex-row"
                    )}
                  >
                    <span data-qa="investment-date-label">
                      <FormattedMessage id="investmentDate"/>
                    </span>
                    <span data-qa="investment-date" className="text-xl font-bold">
                      <FormattedDate value={unitLinked.investmentInstant} year="numeric" month="2-digit" day="2-digit"/>
                    </span>
                  </div>
                  {product.partitionOption &&
                    product.partitionOption.unitLinkedInvestment !== 0 &&
                    product.partitionOption.segregatedInvestment !== 0 && (
                      <>
                        <div data-qa="partition-option-container" className="hidden flex-grow lg:flex flex-col">
                          <span data-qa="partition-option-label">
                            <FormattedMessage id="partition"/>
                          </span>
                          <div data-qa="partition-option" className="text-xl font-bold flex gap-x-4">
                            <span>
                              <FormattedMessage id="unitLinkedPercentage" values={{percentage: product.partitionOption.unitLinkedInvestment}}/>
                            </span>
                            <span>
                              <FormattedMessage id="segregatedFundPercentage" values={{percentage: product.partitionOption.segregatedInvestment}}/>
                            </span>
                          </div>
                        </div>

                        <div
                          data-qa="total-premium-container"
                          className="w-full lg:w-max flex lg:flex-col gap-x-2 items-center justify-end lg:justify-normal lg:items-end"
                        >
                          <span data-qa="total-premium-label">
                            <FormattedMessage id="totalPremium"/>
                          </span>
                          <span data-qa="total-premium" className="text-xl font-bold">
                            <FormattedMoney money={asset.premium.uniqueOrAnnual.gross}/>
                          </span>
                        </div>
                      </>
                    )}
                </YogaCard>
                {product.partitionOption &&
                  product.partitionOption.unitLinkedInvestment !== 0 &&
                  product.partitionOption.segregatedInvestment !== 0 && (
                    <YogaCard className="flex lg:hidden items-center" data-qa="partition-card">
                      <span>
                        <FormattedMessage id="partition"/>
                      </span>
                      <div className="flex w-full items-center justify-between ml-2 text-xl font-bold">
                        <span data-qa="unit-linked-percentage">
                          <FormattedMessage id="unitLinkedPercentage" values={{percentage: product.partitionOption.unitLinkedInvestment}}/>
                        </span>
                        <span data-qa="segregated-fund-percentage">
                          <FormattedMessage id="segregatedFundPercentage" values={{percentage: product.partitionOption.segregatedInvestment}}/>
                        </span>
                      </div>
                    </YogaCard>
                  )}
              </div>*/}

              {(!product.partitionOption || product.partitionOption?.unitLinkedInvestment > 0) && (
                <YogaCard data-qa="unit-linked-card">
                  <div className="flex flex-row items-center gap-x-4 justify-between mb-4 ">
                    <div className="text-2xl font-bold text-title-text" data-qa="unit-linked-card-title">
                      <FormattedMessage id="unitLinked" />
                    </div>
                    <PremiumDropDown premium={unitLinked?.premium.uniqueOrAnnual} entity="unit-linked" />
                  </div>

                  <div className="bg-body-text text-box-background border-body-text p-4 rounded-lg" data-qa="investment-line-card">
                    <div className="text-xl font-bold" data-qa="investment-line-card-title">
                      <FormattedMessage id="investmentLine" />
                    </div>

                    <Accordion
                      name="investment-line"
                      className="mt-2 flex flex-col border-background rounded-lg border-collapse bg-box-background overflow-hidden w-full text-body-text"
                      titleContainerClasses="px-4 py-3.5"
                      accordionTitle={
                        <div className="inline-flex items-center">
                          <h4 className="text-body-text text-xl">
                            <FormattedMessage id={investmentLine.name} />
                          </h4>
                        </div>
                      }
                    >
                      {unitLinked.lines[investmentLine.code]?.funds ? (
                        <FundsTable funds={unitLinked.lines[investmentLine.code].funds} investmentLine={investmentLine.code} />
                      ) : (
                        <></>
                      )}
                    </Accordion>
                  </div>
                </YogaCard>
              )}

              {product.partitionOption?.segregatedInvestment > 0 && (
                <YogaCard className="w-full flex items-center justify-between" data-qa="segregated-fund-card">
                  <span className="text-2xl font-bold" data-qa="segregated-fund-card-title">
                    <FormattedMessage id="segregatedFund" />
                  </span>
                  {asset.segregatedFund?.premium?.uniqueOrAnnual && (
                    <PremiumDropDown premium={asset.segregatedFund.premium.uniqueOrAnnual} entity="segregated-fund" />
                  )}
                </YogaCard>
              )}

              <Formik
                initialValues={product.contractualOptions}
                validationSchema={validationSchema}
                enableReinitialize
                innerRef={formRef}
                onSubmit={(values) => createProposal(values)}
              >
                <Form id="contractual-options-form">
                  {contractualOptions && contractualOptions.length > 0 && (
                    <YogaCard data-qa="contractual-options-card">
                      <h4 className="text-2xl font-bold text-title-text mb-4">
                        <FormattedMessage id="contractualOptions" />
                      </h4>
                      <div className="flex flex-col gap-y-4" data-qa="contractual-options-container">
                        {contractualOptions
                          .sort((a, b) => (a.name > b.name ? 1 : -1))
                          .map((opt) => (
                            <div
                              key={`contractual-option-${opt.code}`}
                              className="border-2 border-background rounded-lg p-1.5"
                              data-qa={`contractual-option-${opt.code}`}
                            >
                              <Field name={`${opt.code}.selected`}>
                                {(fieldProps) => (
                                  <FormikInputCheck
                                    {...fieldProps}
                                    content={{ label: opt.name, name: `${opt.code}.selected`, updateOnChange: true }}
                                    infoLabel={opt.description}
                                    dataQa={`${opt.code}.selected`}
                                    disabled={opt.selected && opt.mandatory}
                                    onUpdate={update}
                                    notShowErrorMessage
                                  />
                                )}
                              </Field>
                              {opt.selected && opt.parameters && Object.values(opt.parameters).some((param: YogaParam) => param.visible) && (
                                <div data-qa="parameters-card" className="mt-4">
                                  <Field name={`${opt.code}.parameters`}>
                                    {(fieldProps) => (
                                      <ParametersForm
                                        {...fieldProps}
                                        parameters={opt.parameters}
                                        onUpdateOnChange={(parameters: KeyValue<YogaParam>) => updateOnChangeParameters(opt.code, parameters)}
                                      />
                                    )}
                                  </Field>
                                </div>
                              )}
                            </div>
                          ))}
                      </div>
                    </YogaCard>
                  )}
                  <YogaScrollToFieldError />
                </Form>
              </Formik>
            </div>
          </div>
        </>
      )}
    </>
  );
}
