export type PaymentFrequency =
  | "YEARLY"
  | "HALF_YEARLY"
  | "QUARTERLY"
  | "MONTHLY"
  | "SINGLE"
  | "BIMONTHLY"
  | "FOUR_MONTHLY";

export enum PaymentCurrency {
  EUR = "EUR",
  USD = "USD",
  GBP = "GBP",
  JPY = "JPY",
}
