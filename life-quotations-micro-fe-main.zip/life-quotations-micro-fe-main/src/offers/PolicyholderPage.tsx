import { ArrowCircleRightIcon } from "@heroicons/react/solid";
import classnames from "classnames";
import { CTX } from "commons/Configuration";
import { geoValidationError, valuesOf } from "commons/FormUtils";
import { StickyBar } from "commons/components/StickyBar";
import { YogaButton } from "commons/components/YogaButton";
import YogaCard from "commons/components/YogaCard";
import { YogaMessage } from "commons/components/YogaMessage";
import { Context } from "commons/contexts/Context";
import { CustomerContext } from "commons/contexts/CustomerContext";
import { UserContext } from "commons/contexts/UserProvider";
import { getLocationSchema } from "commons/models/Location";
import { mandatoryLocationParams } from "commons/models/Suggestion";
import { KeyValue } from "commons/models/YogaModels";
import { ManagementNode } from "commons/models/nodes/ManagementNode";
import { partyService } from "commons/services/PartyService";
import ConsentSelect from "customers/components/ConsentSelect";
import { PartyType } from "customers/enums/PartyType";
import { newLegalPolicyholderForm, newPhysicalPolicyholderForm } from "customers/forms/NewPolicyholderForm";
import { PolicyholderForm } from "customers/forms/PolicyholderForm";
import useConsentsList from "customers/hooks/useConsentsList";
import { Consent, ConsentType } from "customers/models/Consent";
import { Party } from "customers/models/Party";
import { Field, Form, Formik } from "formik";
import { isValidIBAN } from "ibantools";
import { useContext, useEffect, useMemo, useState } from "react";
import { FormattedMessage, useIntl } from "react-intl";
import { formatPhoneNumberIntl, isValidPhoneNumber } from "react-phone-number-input";
import { useNavigate } from "react-router-dom";
import * as Yup from "yup";

export default function PolicyholderPage() {
  const { user, rootManagementNodes } = useContext(UserContext);
  const intl = useIntl();
  const { changeLoading } = useContext(Context);
  const navigate = useNavigate();
  const { selectedCustomers, setSelectedCustomers, setPolicyholderAnonymous } = useContext(CustomerContext);
  const requiredMessage = intl.formatMessage({ id: "required" });
  const requiredGeo = geoValidationError(intl);
  const vatNumberLengthMessage = intl.formatMessage({ id: "lengthError" }, { number: "11" });
  const taxCodeLengthMessage = intl.formatMessage({ id: "lengthError" }, { number: "16" });
  //const selectLocationMessage = intl.formatMessage({ id: "selectLocation" });
  const invalidPhoneMessage = intl.formatMessage({ id: "invalidPhoneNumber" });
  const [taxIdErrorType, setTaxIdErrorType] = useState("");
  const [isAnUpdate, setIsAnUpdate] = useState(false);
  const [consentsErrors, setConsentsErrors] = useState<KeyValue<boolean>>();

  const [initialValues, setInitialValues] = useState<Object>();

  const validationSchema = Yup.object({
    legalEntity: Yup.string().required(requiredMessage),
    taxId: Yup.string().when(["legalEntity", "companyType"], {
      is: (legalEntity: string, companyType: string) =>
        legalEntity === "legal" && companyType !== "Ditta Individuale" && companyType !== "Impresa familiare",
      then: Yup.string().test("len11", vatNumberLengthMessage, (val) => val?.length === 11),
      otherwise: Yup.string().test("len16", taxCodeLengthMessage, (val) => val?.length === 16),
    }),
    companyType: Yup.string().when("legalEntity", {
      is: "legal",
      then: Yup.string().required(requiredMessage),
      otherwise: Yup.string().nullable(),
    }),
    vatNumber: Yup.string().when("legalEntity", {
      is: "legal",
      then: Yup.string().test("len11", vatNumberLengthMessage, (val) => val?.length === 11),
      otherwise: Yup.string().nullable(),
    }),
    surnameOrCompanyName: Yup.string().required(requiredMessage),
    name: Yup.string().when("legalEntity", {
      is: "legal",
      then: Yup.string().nullable(),
      otherwise: Yup.string().required(requiredMessage),
    }),
    birthDate: Yup.string().when("legalEntity", {
      is: "legal",
      then: Yup.string().nullable(),
      otherwise: Yup.string().required(requiredMessage),
    }),
    birthCountry: Yup.string().when(["legalEntity", "taxId"], {
      is: (legalEntity: string, taxId: string) =>
        legalEntity !== "legal" && (!taxId || taxId?.length < 12 || (taxId?.length >= 12 && taxId.charAt(11).toUpperCase() === "Z")),
      then: Yup.string().required(requiredGeo),
      otherwise: Yup.string().nullable(),
    }),
    birthPlace: Yup.string().when(["legalEntity", "taxId"], {
      is: (legalEntity: string, taxId: string) =>
        legalEntity !== "legal" && (!taxId || taxId?.length < 12 || (taxId?.length >= 12 && taxId.charAt(11).toUpperCase() !== "Z")),
      then: Yup.string().required(requiredGeo),
      otherwise: Yup.string().nullable(),
    }),
    gender: Yup.string().when("legalEntity", {
      is: "legal",
      then: Yup.string().nullable(),
      otherwise: Yup.string().required(requiredMessage),
    }),
    email: Yup.string()
      .nullable()
      .email(intl.formatMessage({ id: "invalidEmail" })),
    mobilePhoneNumber: Yup.string()
      .nullable()
      .test("phoneValid", invalidPhoneMessage, (val) => val == null || val == "" || isValidPhoneNumber(val ?? "")),
    location: getLocationSchema(intl),
    domicile: Yup.object({
      label: Yup.string().ensure().nullable(),
    }).when("domicileIsNotResidence", {
      is: true,
      then: getLocationSchema(intl),
      otherwise: Yup.object().nullable(),
    }),
    domicileIsNotResidence: Yup.boolean().default(false).nullable(),
    iban: Yup.string()
      .nullable()
      .test("iban", intl.formatMessage({ id: "ibanFormatError" }), (v) => !v || isValidIBAN(v)),
  });

  const { consents, setConsents, setCurrentPartyConsents } = useConsentsList(selectedCustomers[0]?.consents, ConsentType.POLICYHOLDER_IN_ISSUE);

  const managementNodesToUse = useMemo(() => {
    let updateNodes: ManagementNode[] = [];
    rootManagementNodes.forEach((rootNode) => {
      if (updateNodes.filter((node) => node?.code === rootNode.code).length === 0) {
        updateNodes.push(rootNode);
      }
    });

    return updateNodes;
  }, [rootManagementNodes]);

  useEffect(() => {
    if (selectedCustomers?.length) {
      const selected: any = Object.assign({}, selectedCustomers[0]);
      selected.location = selectedCustomers[0].location;
      selected.legalEntity = selectedCustomers[0].legalEntity === false ? "physical" : "legal";
      selected.mobilePhoneNumber = selected.mobilePhoneNumber
        ? selected.mobilePhoneNumberPrefix
          ? selected.mobilePhoneNumberPrefix.replace("00", "+") + selected.mobilePhoneNumber
          : "+39" + selected.mobilePhoneNumber
        : null;
      selected.revenue = selected.revenue?.amount.toString() ?? "";
      selected.birthPlaceComplete = {
        geoId: "",
        name: selectedCustomers[0].birthPlace ?? "",
        countyCode: selectedCustomers[0].birthCountyCode ?? "",
      };
      selected.birthPlace = selectedCustomers[0].birthPlace
        ? selectedCustomers[0].birthCountyCode
          ? `${selectedCustomers[0].birthPlace} (${selectedCustomers[0].birthCountyCode})`
          : selectedCustomers[0].birthPlace
        : "";
      selected.domicile = selectedCustomers[0].domicileIsNotResidence ? selectedCustomers[0].domicile : selectedCustomers[0].location;

      setIsAnUpdate(!!selected.partyId);
      setInitialValues(selected);
    } else {
      setInitialValues(
        Object.assign(valuesOf([...newPhysicalPolicyholderForm]), {
          location: null,
          companyType: "",
          vatNumber: "",
          domicileIsNotResidence: false,
        })
      );
    }
  }, [selectedCustomers]);

  useEffect(() => {
    if (consents && !consentsErrors) {
      setConsentsErrors(
        Object.values(consents).reduce(
          (a, consent) => ({
            ...a,
            [consent.consentId]: false,
          }),
          {}
        )
      );
    }
  }, [consents]);

  const createOrUpdateParty = async (party: Party) => {
    changeLoading(1);
    let partyId = party.partyId;
    if (isAnUpdate) {
      await partyService.update(party.partyId, party, true);
    } else {
      const result = await partyService.create(party);
      partyId = result.data;
    }
    setSelectedCustomers([party]);
    setPolicyholderAnonymous(null);
    changeLoading(-1);

    navigate(`${CTX}/advices?partyId=${partyId}`);
  };

  const createCustomer = async (customer: any) => {
    let consentsErrors = Object.values(consents).reduce(
      (a, consent) => ({
        ...a,
        [consent.consentId]: (consent.mandatory && consent.value != true) || consent.value == null,
      }),
      {}
    );

    if (Object.values(consentsErrors).every((error) => error == false)) {
      const party = Object.assign(
        {},
        { ...customer },
        {
          birthCountyCode: customer.birthPlaceComplete && customer.birthPlaceComplete.countyCode,
          birthPlace: customer.birthPlaceComplete && customer.birthPlaceComplete.name,
        }
      );
      let validLocation = true;
      if (party.location.country === "Italia") {
        mandatoryLocationParams.forEach((element) => {
          if (!party.location[element]) {
            validLocation = false;
          }
        });
      }
      if (validLocation) {
        party.location = customer.location;
        party.domicile = customer.domicileIsNotResidence ? customer.domicile : customer.location;
        party.domicileIsNotResidence = customer.domicileIsNotResidence;
        party.hidden = false;
        party.questionnaireCode = null;
        party.customerReference = customer.customerReference ?? user?.attributes.name;
        party.legalEntity = customer.legalEntity === "legal";
        if (Object.values(consents).length) {
          party.lastConsentsUpdateInstant = new Date();
          party.consents = Object.values(consents);
        }
        if (party.revenue) {
          party.revenue = {
            amount: party.revenue,
            currency: "EUR",
          };
        } else {
          party.revenue = null;
        }
        let updateNodes: ManagementNode[] = party.managementNodes ? party.managementNodes : [];
        managementNodesToUse.forEach((rootNode) => {
          if (updateNodes.filter((node) => node?.code === rootNode.code).length === 0) {
            updateNodes.push(rootNode);
          }
        });
        party.managementNodes = updateNodes;
        if (party.mobilePhoneNumber) {
          const prefix = formatPhoneNumberIntl(party.mobilePhoneNumber).split(" ")[0];
          party.mobilePhoneNumber = party.mobilePhoneNumber.replace(prefix, "");
          party.mobilePhoneNumberPrefix = prefix.replace("+", "00");
        } else {
          party.mobilePhoneNumber = null;
          party.mobilePhoneNumberPrefix = null;
        }
        if (party.legalEntity && party.companyType !== "Ditta Individuale" && party.companyType !== "Impresa familiare") {
          createOrUpdateParty(party);
        } else {
          const dataConsistency = !party.legalEntity;

          await partyService.checkTaxId(party as Party, dataConsistency).then(async (response) => {
            const checkTaxId = response.data;
            if (!checkTaxId && dataConsistency) {
              setTaxIdErrorType(PartyType.PHYSICAL_PERSON);
            } else if (!checkTaxId && !dataConsistency) {
              setTaxIdErrorType(PartyType.LEGAL_ENTITY);
            } else {
              setTaxIdErrorType("");
            }
            if (checkTaxId) {
              createOrUpdateParty(party);
            }
          });
        }
      }
    } else {
      setConsentsErrors(consentsErrors);
      document.getElementById("privacyConsents")?.scrollIntoView({ behavior: "smooth", block: "center" });
    }
  };

  function onConsentChange(consentToEdit: Consent, v: boolean) {
    let newConsent = {
      ...consents[consentToEdit.name],
      value: v,
    };

    let newConsents = { ...consents, [consentToEdit.name]: newConsent };

    setConsents(newConsents);
  }

  return (
    <>
      <StickyBar
        hasBackButton={false}
        breadcrumb={
          <>
            <FormattedMessage id="policyholder" />
          </>
        }
      >
        <YogaButton kind="default" form="policyholderForm">
          <ArrowCircleRightIcon className="w-5 mr-2 -ml-1" />
          <FormattedMessage id="continue" />
        </YogaButton>
      </StickyBar>

      <div className="px-3">
        <YogaCard uniformPadding data-qa="policyholder-form">
          <div className="flex flex-col gap-y-8">
            <div>
              {taxIdErrorType === PartyType.PHYSICAL_PERSON && (
                <YogaMessage type="error" position="inner" className="mb-4">
                  <p>
                    <FormattedMessage id="taxCodeInconsistent" />
                  </p>
                </YogaMessage>
              )}
              {taxIdErrorType === PartyType.LEGAL_ENTITY && (
                <YogaMessage type="error" position="inner" className="mb-4">
                  <p>
                    <FormattedMessage id="incorrectTaxCode" />
                  </p>
                </YogaMessage>
              )}
              {initialValues && validationSchema && (
                <Formik initialValues={initialValues} onSubmit={createCustomer} validationSchema={validationSchema} enableReinitialize>
                  <Form id="policyholderForm">
                    <Field
                      component={PolicyholderForm}
                      mustResetSessionStorage={false}
                      taxIdInconsistent={taxIdErrorType !== ""}
                      resetTaxIdInconsistent={() => {
                        setTaxIdErrorType("");
                      }}
                      setIsAnUpdate={setIsAnUpdate}
                      isAnUpdate={isAnUpdate}
                      updateConsents={setCurrentPartyConsents}
                      legalParams={[...newLegalPolicyholderForm]}
                      physicalParams={[...newPhysicalPolicyholderForm]}
                      managementNodes={managementNodesToUse}
                    />
                  </Form>
                </Formik>
              )}
            </div>

            {consents && consentsErrors && Object.values(consents).length > 0 && (
              <div id="privacyConsents" className="flex flex-col border-2 border-background rounded-lg border-collapse">
                <h4 className="p-4">
                  <FormattedMessage id="privacyConsents" />
                </h4>
                {Object.values(consents).map((consent) => {
                  return (
                    <div
                      className="flex p-4 border-t-2 border-background border-collapse items-center w-full justify-between"
                      key={`consent-${consent.consentId}`}
                      data-qa="consent"
                    >
                      <label
                        htmlFor={`toggle-consent-${consent.consentId}`}
                        className={classnames("flex items-center w-full")}
                        data-qa="consent-label"
                      >
                        <div className="mr-4 w-full" data-qa="consent-text">
                          <FormattedMessage id={consent.text} />
                        </div>
                        <ConsentSelect
                          id={`consent-${consent.consentId}`}
                          checked={consents[consent.name].value}
                          mandatory={consent.mandatory}
                          name={consent.name}
                          onChange={(v) => onConsentChange(consent, v)}
                          error={consentsErrors[consent.consentId]}
                        />
                      </label>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </YogaCard>
      </div>
    </>
  );
}
