import ErrorPage from "commons/components/ErrorPage";
import useCustomerContext from "commons/contexts/CustomerContext";
import { Party } from "customers/models/Party";
import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { AdditionalDataForm } from "./forms/AdditionalDataForm";
import useLifeProductIncomplete from "./hooks/useLifeProductIncomplete";
import usePartyParameters from "customers/hooks/usePartyParameters";
import { RoleType } from "contracts/enums/RoleType";

export default function AdditionalDataPage() {
  const { setSelectedCustomers } = useCustomerContext();
  const [policyholder, setPolicyholder] = useState<Party | undefined>();
  const { productInstanceId: productId } = useParams<string>();

  const { product, setProduct, productError, updateProduct } = useLifeProductIncomplete(productId);

  const { updateParams: updatePolicyholderParams } = usePartyParameters(
    RoleType.POLICYHOLDER,
    product?.code,
    product?.productId,
    product?.type ?? "LIFE"
  );

  useEffect(() => {
    if (product) {
      const policyholder = product.policyHolder;
      setSelectedCustomers(policyholder);
      setPolicyholder(policyholder);
    }
  }, [product]);

  return (
    <>
      {productError ? (
        <ErrorPage />
      ) : (
        <>
          {product && policyholder && (
            <AdditionalDataForm
              product={product}
              setProduct={setProduct}
              policyholder={policyholder}
              updateProduct={updateProduct}
              updatePolicyholderParams={updatePolicyholderParams}
            />
          )}
        </>
      )}
    </>
  );
}
