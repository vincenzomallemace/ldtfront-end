import { KeyValue } from "commons/models/YogaModels";
import { YogaParam } from "commons/models/YogaParam";
import { FinancialAsset } from "models/FinancialAdvice";
import { PremiumComponents } from "models/PremiumComponents";

export interface UnitLinked {
  code: string;
  name: string;
  lines: KeyValue<Line>;
  premium: PremiumComponents;
  selected: boolean;
  investmentInstant: Date;
}

export interface ContractUnitLinked {
  code: string;
  name: string;
  investmentLines: KeyValue<Line>;
  premium: PremiumComponents;
  parameters?: KeyValue<YogaParam>;
  investmentInstant: Date;
}
export interface Line {
  code: string;
  name: string;
  selected: boolean;
  funds?: FinancialAsset[];
  type?: string;
}

export enum InvestmentLineType {
  FREE = "FREE",
  GUIDED = "GUIDED",
}
