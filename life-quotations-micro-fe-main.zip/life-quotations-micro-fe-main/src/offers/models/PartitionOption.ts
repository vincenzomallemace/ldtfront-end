export interface PartitionOption {
  code: string;
  name: string;
  unitLinkedInvestment: number;
  segregatedInvestment: number;
}
