export class Premium {
  net: number;
  taxes: number;
  gross: number;
}
