import { config } from "commons/Configuration";
import { FormInputParam } from "commons/models/YogaParam";

export const newPartyNaturalPersonFormInternal: FormInputParam[] = [
  {
    name: "taxId",
    label: "taxCode",
    type: "STRING",
    updatePartially: true,
    mandatory: true,
  },
  {
    name: "surnameOrCompanyName",
    label: "surnameOrCompanyName",
    type: "STRING",
    mandatory: true,
  },
  {
    name: "name",
    label: "name",
    type: "STRING",
    mandatory: true,
  },
  {
    name: "birthDate",
    label: "birthDate",
    type: "DATE",
    mandatory: true,
  },
  {
    name: "birthCountry",
    label: "birthCountry",
    type: "COUNTRY",
    mandatory: true,
  },
  {
    name: "birthPlace",
    label: "birthPlace",
    type: "CITY",
    mandatory: true,
  },
  {
    availableValues: ["male", "female"],
    name: "gender",
    label: "gender",
    type: "LIST",
    mandatory: true,
  },
  {
    name: "email",
    label: "email",
    type: "STRING",
  },
  {
    name: "mobilePhoneNumber",
    label: "mobilePhoneNumber",
    type: "PHONE",
    value: undefined,
  },
];

export const newPartyNaturalPersonForm: FormInputParam[] =
  config.DISPLAY_PARTY_IBAN !== "disabled"
    ? newPartyNaturalPersonFormInternal.concat([
        {
          name: "iban",
          value: "",
          mandatory: false,
          label: "iban",
          type: "STRING",
        },
      ])
    : newPartyNaturalPersonFormInternal;
