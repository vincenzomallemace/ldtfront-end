import { Premium } from "./Premium";

export class Balance {
  total: Premium;
}
