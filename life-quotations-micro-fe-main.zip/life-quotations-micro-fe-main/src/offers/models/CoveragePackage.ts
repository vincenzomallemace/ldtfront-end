export interface CoveragePackage {
  code: string;
  description: string;
  coverages: string[];
  selected: boolean;
  assetCode?: string;
  risk: string;
}
