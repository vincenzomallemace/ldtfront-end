import { Asset } from "./Asset";
import { CoveragePackage } from "./CoveragePackage";
import { KeyValue, Money } from "commons/models/YogaModels";
import { YogaParam } from "commons/models/YogaParam";
import { Party } from "customers/models/Party";
import { Complement } from "./Complement";
import { ManagementNode } from "commons/models/nodes/ManagementNode";
import { Balance } from "./Balance";
import { PaymentCurrency, PaymentFrequency } from "offers/enums/PaymentFrequency";
import { PremiumComponents } from "models/PremiumComponents";
import { ContractualOption } from "./ContractualOption";
import { AvailablePartitionOption } from "./AvailablePartitionOption";
import { PartitionOption } from "./PartitionOption";

export interface Product {
  tacitRenewal: any;
  editTacitRenewal: any;
  quotationExpirationInstant: Date;
  productId: string;
  description: string;
  code: string;
  type: string;
  creationInstant: Date;
  version: string;
  currency: string;
  paymentFrequency: PaymentFrequency;
  availablePaymentFrequencies: PaymentFrequency[];
  availableAgreements?: string[];
  agreement?: string;
  amount: Money;
  installmentAmount: Money;
  subscriptionInstallmentAmount: Money;
  subscriptionInstallmentExpirationDate?: Date;
  lastUpdateInstant?: Date;
  quotationCompleted: boolean;
  policyDuration: number;
  effectiveDateInstant: Date;
  expirationDateInstant: Date;
  parameters: KeyValue<YogaParam>;
  assets: { [assetCode: string]: KeyValue<Asset> };
  coveragePackages: KeyValue<CoveragePackage>;
  policyHolder?: Party;
  messages: KeyValue<string[]>;
  quotationStatus?: QuotationStatus;
  quotationValidity: number;
  authorizationValidity?: number;
  searchLabel?: string;
  monoAsset?: boolean;
  category?: string;
  quotationNumber?: string;
  managementNode?: ManagementNode;
  indexable?: boolean;
  indexed?: boolean;
  complements?: { [complementCode: string]: KeyValue<Complement> };
  status?: string;
  visibleInCustomerArea?: boolean;
  canSendQuotationToCustomerArea?: boolean;
  channel?: string;
  balance: Balance;
  premium?: PremiumComponents;
  contractualOptions?: KeyValue<ContractualOption>;
  availablePartitionOptions?: AvailablePartitionOption[];
  partitionOption?: PartitionOption;
}

type QuotationStatus = "SUCCESS" | "ERROR";

export const isExpiring = (quotation: Product) => {
  const now = new Date();
  const quotationExpirationDate = new Date(quotation.quotationExpirationInstant);
  quotationExpirationDate.setDate(quotationExpirationDate.getDate() - 10);
  return now > quotationExpirationDate;
};

export const isExpired = (quotation: Product) => {
  const now = new Date();
  const quotationExpirationDate = new Date(quotation.quotationExpirationInstant);
  return now > quotationExpirationDate;
};

export const getPremiumGross = (product?: Product) => {
  const amount = product ? product.premium.subscriptionInstallment.gross.amount : 0;
  const currency = product ? product.premium.subscriptionInstallment.gross.currency : PaymentCurrency.EUR;
  return { amount: amount, currency: currency };
};

export const areProductErrors = (product?: Product): boolean =>
  product &&
  product.messages &&
  (("failures" in product.messages && product.messages["failures"].length > 0) ||
    ("errors" in product.messages && product.messages["errors"].length > 0));
