import { KeyValue, Money, YuidEntity } from "commons/models/YogaModels";
import { YogaParam } from "commons/models/YogaParam";
import { Coverage } from "./Coverage";
import Vehicle from "./Vehicle";
import { ProductParty } from "customers/models/ProductParty";
import { UnitLinked } from "./UnitLinked";
import { PremiumComponents } from "models/PremiumComponents";
import { SegregatedFund } from "./SegregatedFund";

export interface Asset extends YuidEntity {
  name: string;
  code: string;
  type: string;
  selected: boolean;
  insuredPersonRequired: boolean;
  locationRequired: boolean;
  amount: Money;
  coverages: KeyValue<Coverage>;
  parameters: KeyValue<YogaParam>;
  min: number;
  max: number;
  label: string;
  order: number;
  assetOrder: number;
  messages: KeyValue<string[]>;
  messagesBefore: KeyValue<string[]>;
  vehicle?: Vehicle;
  parties?: KeyValue<ProductParty[]>;
  unitLinked?: KeyValue<UnitLinked>;
  segregatedFund?: SegregatedFund;
  premium?: PremiumComponents;
}
