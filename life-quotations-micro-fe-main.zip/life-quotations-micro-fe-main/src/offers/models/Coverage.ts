import {
  KeyValue,
  Money,
  ParentYuidEntity,
  YuidEntity,
} from "commons/models/YogaModels";
import { YogaParam } from "commons/models/YogaParam";
import { PremiumComponents } from "models/PremiumComponents";
export interface Coverage extends YuidEntity, ParentYuidEntity {
  name: string;
  description?: string;
  code: string;
  selected: boolean;
  mandatory: boolean;
  discountable?: boolean;
  discount?: number;
  amount: Money;
  order: number;
  visible: boolean;
  parameters: KeyValue<YogaParam>;
  messages: KeyValue<string[]>;
  premium?: PremiumComponents;
}
