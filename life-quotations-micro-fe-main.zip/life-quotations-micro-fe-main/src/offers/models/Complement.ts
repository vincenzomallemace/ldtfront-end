import { KeyValue, Money, YuidEntity } from "commons/models/YogaModels";
import { YogaParam } from "commons/models/YogaParam";

export interface Complement extends YuidEntity {
  name: string;
  description: string;
  code: string;
  type: string;
  parameters: KeyValue<YogaParam>;
  min: number;
  max: number;
  order: number;
  selected: boolean;
  visible: boolean;
  amount: Money;
}
