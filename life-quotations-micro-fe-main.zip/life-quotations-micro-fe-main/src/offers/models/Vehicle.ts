import { Money } from "commons/models/YogaModels";

export default interface Vehicle {
  vehicleId?: string;
  vehicleIdNotAvailable?: boolean;
  type?: string;
  description?: string;
  registrationDate?: Date;
  powerSupply?: { code: string; description: string };
  insuranceStatus?: InsuranceStatus;
  atr?: Atr;
}

export interface InsuranceStatus {
  code: String;
  description?: String;
  atrMode?: AtrMode;
}

export interface Atr {
  sourceTaxId?: String;
  sourceVehicleId?: String;
  expirationDate?: Date;
  sourceCompany?: { code: string; description: string };
  sourcePolicyNumber?: String;
  tariffType?: { code: string; description: string };
  sourceCU?: number;
  assignedCU?: number;
  numberUnpaidDeductibles?: number;
  amountUnpaidDeductibles?: Money;
  claimHistoryReport?: ClaimHistoryReport;
}

enum AtrMode {
  NO_ATR = "NO_ATR",
  FULL_ATR = "FULL_ATR",
}

export interface ClaimHistoryReport {
  years: ClaimHistoryReportYear[];
}

export interface ClaimHistoryReportYear {
  year: number;
  isInsured: boolean;
  values?: ClaimHistoryReportValues[];
}

export interface ClaimHistoryReportValues {
  responsibility: ClaimResponsibilityType;
  damageTo: ClaimDamageTo;
  value?: number;
}

export enum ClaimResponsibilityType {
  MAIN = "MAIN",
  EQUAL = "EQUAL",
}

export enum ClaimDamageTo {
  PROPERTIES = "PROPERTIES",
  PERSONS = "PERSONS",
  PERSONS_AND_PROPERTIES = "PERSONS_AND_PROPERTIES",
}
