export interface AvailablePartitionOption {
  code: string;
  name: string;
  visible: boolean;
  type: AVAILABLE_PARTITION_OPTION_TYPE;
  minUnitLinkedInvestment: number;
}

export enum AVAILABLE_PARTITION_OPTION_TYPE {
  FREE = "FREE",
  CHECKED = "CHECKED",
  FIXED = "FIXED",
}
