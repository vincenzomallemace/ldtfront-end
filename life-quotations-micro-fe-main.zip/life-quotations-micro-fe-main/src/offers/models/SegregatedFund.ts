import { PremiumComponents } from "models/PremiumComponents";

export interface SegregatedFund {
  premium: PremiumComponents;
}
