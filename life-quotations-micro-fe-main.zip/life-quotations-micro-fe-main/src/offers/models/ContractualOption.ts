import { KeyValue } from "commons/models/YogaModels";
import { YogaParam } from "commons/models/YogaParam";

export interface ContractualOption {
  name: string;
  description?: string;
  code: string;
  selected: boolean;
  mandatory: boolean;
  visible: boolean;
  parameters?: KeyValue<YogaParam>;
}
export interface ContractContractualOption {
  name: string;
  description?: string;
  code: string;
  visible: boolean;
  parameters?: KeyValue<YogaParam>;
}
