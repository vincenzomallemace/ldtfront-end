import classnames from "classnames";
import YogaLoader from "commons/components/Loader";
import { YogaMessage } from "commons/components/YogaMessage";
import { FormikInput } from "commons/formik/FormikInput";
import { FormikToggleSwitch } from "commons/formik/FormikToggleSwitch";
import { FormInputParam } from "commons/models/YogaParam";
import { ManagementNode } from "commons/models/nodes/ManagementNode";
import { partyService } from "commons/services/PartyService";
import { STATUS } from "contracts/models/Contract";
import PartyFromAnotherNodeModal from "customers/components/PartyFromAnotherNodeModal";
import {
  newLegalRepresentativeForm,
  newOtpForm,
  newReferentForm,
} from "customers/forms/NewLegalRepresentativeForm";
import { Party } from "customers/models/Party";
import { Field, FieldProps, useField } from "formik";
import { useEffect, useState } from "react";
import { FormattedMessage } from "react-intl";
import { AssetInsuredLocationForm } from "./AssetInsuredLocationForm";

export function OtpSignatureForm({
  field: { name, value },
  form,
  ...props
}: FieldProps) {
  const [policyholderOtpSignatureEnabled] = useField(
    `${name}.policyholderOtpSignatureEnabled`
  );
  const paramPolicyholderOtpSignatureEnabled: FormInputParam = {
    name: name + ".policyholderOtpSignatureEnabled",
    type: "BOOLEAN",
    value: policyholderOtpSignatureEnabled.value,
  };
  const policyHolder = (props as any).policyHolder as Party;
  const contractStatus = (props as any).contractStatus as string;
  const taxIdConsistent = (props as any).taxIdConsistent as boolean;
  const managementNodes = (props as any).managementNodes as ManagementNode[];
  const params = newOtpForm.map((p) =>
    Object.assign({}, p, { name: name + "." + p.name })
  );
  const legalRepresentativeParams = newLegalRepresentativeForm.map((p) =>
    Object.assign({}, p, { name: name + "." + p.name })
  );
  const referentParams = newReferentForm.map((p) =>
    Object.assign({}, p, { name: name + "." + p.name })
  );
  const [isRetrievingInsured, setIsRetrievingInsured] = useState(false);
  const setIsAnUpdate = (props as any).setIsAnUpdate as (value: boolean) => any;
  const isAnUpdate = (props as any).isAnUpdate as Boolean;
  const isOtpEnabled = (props as any).isOtpEnabled as Boolean;
  const isIndividualCompanyReferent = (props as any)
    .isIndividualCompanyReferent as Boolean;

  const [retrievedParty, setRetrievedParty] = useState<Party>();

  const [partyToRetrieve, setPartyToRetrieve] = useState(null);
  const [notVisibleNodeModal, setNotVisibleNodeModal] = useState(false);
  const [canRetrieve, setCanRetrieve] = useState(true);

  async function confirmRetrievedParty(party: any) {
    if (
      form.values.otpSignature.taxId.toUpperCase() ===
        party.taxId.toUpperCase() &&
      form.values.otpSignature.taxId !== party.taxId
    ) {
      setCanRetrieve(false);
    }
    form.setFieldValue("otpSignature.taxId", party.taxId);
    form.setFieldValue("otpSignature.name", party.name);
    form.setFieldValue(
      "otpSignature.surnameOrCompanyName",
      party.surnameOrCompanyName
    );
    form.setFieldValue("otpSignature.gender", party.gender);
    form.setFieldValue("otpSignature.birthDate", party.birthDate);
    form.setFieldValue(
      "otpSignature.birthPlace",
      party.birthPlace
        ? party.birthCountyCode
          ? `${party.birthPlace} (${party.birthCountyCode})`
          : party.birthPlace
        : ""
    );
    form.setFieldValue("otpSignature.birthPlaceComplete", {
      geoId: "",
      name: party.birthPlace ?? "",
      countyCode: party.birthCountyCode ?? "",
    });
    form.setFieldValue("otpSignature.birthCountry", party.birthCountry ?? "");
    form.setFieldValue("otpSignature.email", party.email ?? "");
    form.setFieldValue(
      "otpSignature.mobilePhoneNumber",
      party.mobilePhoneNumber
        ? party.mobilePhoneNumberPrefix
          ? party.mobilePhoneNumberPrefix.replace("00", "+") +
            party.mobilePhoneNumber
          : "+39" + party.mobilePhoneNumber
        : null
    );
    form.setFieldValue("otpSignature.location", party.location?.label ?? "");
    form.setFieldValue("otpSignature.locationComplete", party.location ?? null);
    form.setFieldValue("otpSignature.profile", party.profile);
    form.setFieldValue(
      "otpSignature.customerReference",
      party.customerReference
    );
    form.setFieldValue("otpSignature.managementNodes", party.managementNodes);
    form.setFieldValue("otpSignature.partyId", party.partyId);
    form.setFieldValue(
      "otpSignature.questionnaireCode",
      party.questionnaireCode
    );
    form.setFieldValue("otpSignature.questionnaire", party.questionnaire);
    form.setFieldValue("otpSignature.tags", party.tags);
    form.setFieldValue("otpSignature.legacyData", party.legacyData);
    form.setFieldValue("otpSignature.consents", party.consents);
    form.setFieldValue(
      "otpSignature.lastConsentsUpdateInstant",
      party.lastConsentsUpdateInstant
    );
    form.setFieldValue(
      "otpSignature.otpSignatureEnabled",
      party.otpSignatureEnabled
    );
    form.setFieldValue("otpSignature.linkedParties", party.linkedParties);
    form.setFieldValue("otpSignature.legalEntity", party.legalEntity);
    form.setFieldValue("otpSignature.iban", party.iban ?? "");
    form.setFieldValue("otpSignature.bankAccounts", party.bankAccounts ?? []);
    form.setFieldValue("otpSignature.parameters", party.parameters ?? {});
    form.validateForm();
    setIsAnUpdate(!!party.surnameOrCompanyName);
    setRetrievedParty(party);
  }

  async function retrieveInsured(id: string) {
    if (isRetrievingInsured) {
      return;
    }
    setIsRetrievingInsured(true);
    await partyService
      .getPartyByTaxId(id, false)
      .then((result) => {
        const party = result.data;
        const notVisible = result.headers["x-not-visible-on-node"];
        if (notVisible === "true") {
          setPartyToRetrieve(party);
          setNotVisibleNodeModal(true);
        } else {
          confirmRetrievedParty(party);
        }
      })
      .catch(() => {
        value.taxId = id;
        value.name = "";
        value.surnameOrCompanyName = "";
        value.birthDate = "";
        value.birthPlace = "";
        value.birthCountryCode = "";
        value.birthCountry = "";
        value.gender = "";
        value.email = "";
        value.mobilePhoneNumber = null;
        value.location = "";
        value.locationComplete = null;
        value.profile = null;
        value.customerReference = null;
        value.managementNodes = null;
        value.partyId = value.taxId;
        value.questionnaireCode = null;
        value.questionnaire = null;
        value.tags = null;
        value.legacyData = null;
        value.consents = null;
        value.lastConsentsUpdateInstant = "";
        value.otpSignatureEnabled = false;
        value.linkedParties = null;
        value.legalEntity = false;
        value.iban = "";
        value.bankAccounts = [];
        value.parameters = {};
        setIsAnUpdate(false);
      })
      .finally(() => {
        setIsRetrievingInsured(false);
      });
  }

  useEffect(() => {
    if (value?.taxId.length === 16) {
      if (canRetrieve) {
        retrieveInsured(value?.taxId);
      } else {
        setCanRetrieve(true);
      }
    } else if (value?.taxId.length === 0) {
      if (policyHolder.legalEntity) {
        resetPartyForm();
      }
      setIsAnUpdate(false);
    }
  }, [value?.taxId]);

  function resetPartyForm() {
    value.taxId = "";
    value.name = "";
    value.surnameOrCompanyName = "";
    value.birthDate = "";
    value.birthPlace = "";
    value.birthCountryCode = "";
    value.birthCountry = "";
    value.gender = "";
    value.email = "";
    value.mobilePhoneNumber = null;
    value.location = "";
    value.locationComplete = null;
    value.profile = null;
    value.customerReference = null;
    value.managementNodes = null;
    value.partyId = "";
    value.questionnaireCode = null;
    value.questionnaire = null;
    value.tags = null;
    value.legacyData = null;
    value.consents = null;
    value.lastConsentsUpdateInstant = "";
    value.otpSignatureEnabled = false;
    value.linkedParties = null;
    value.legalEntity = false;
    value.iban = "";
    value.bankAccounts = [];
    value.parameters = {};
  }

  return (
    <>
      <YogaLoader loading={isRetrievingInsured} />
      {(isOtpEnabled ||
        (isIndividualCompanyReferent &&
          (policyHolder.companyType === "Ditta Individuale" ||
            policyHolder.companyType === "Impresa familiare"))) && (
        <div
          className={classnames(
            "border-2 border-background rounded-lg p-4",
            contractStatus !== STATUS.TO_AUTHORIZE && "mt-4"
          )}
          key="otp-signature"
          data-qa="otp-signature"
        >
          <div className="flex items-center justify-between w-full truncate">
            <h4
              className="text-title-text truncate"
              data-qa="otp-signature-title"
            >
              <div className="flex flex-col truncate">
                <div className="truncate">
                  {isOtpEnabled ? (
                    <FormattedMessage id="otpSignature" />
                  ) : (
                    <FormattedMessage id="legalRepresentative" />
                  )}
                </div>
              </div>
            </h4>

            {isOtpEnabled && (
              <label
                htmlFor="otpSignatureEnabled"
                className="flex items-center text-body-text text-base font-bold gap-4 cursor-pointer"
                data-qa="otpSignatureEnabled"
              >
                <span>
                  <FormikToggleSwitch
                    content={paramPolicyholderOtpSignatureEnabled}
                    disabled={
                      form.values["completeIssueInCustomerArea"] === true
                    }
                    form={form}
                    values={form.values}
                  />
                </span>
              </label>
            )}
          </div>
          {isOtpEnabled &&
            paramPolicyholderOtpSignatureEnabled.value === false && (
              <div>
                <YogaMessage type="info" position="inner" className="mt-2">
                  <p data-qa="otpDisabledMessage">
                    <FormattedMessage id="otpDisabledMessage" />
                  </p>
                </YogaMessage>
              </div>
            )}

          {isIndividualCompanyReferent &&
            policyholderOtpSignatureEnabled.value &&
            form.values[name] &&
            policyHolder.legalEntity && (
              <>
                {isAnUpdate && (
                  <div id="updatePartyMessage">
                    <YogaMessage
                      type="warning"
                      position="inner"
                      className="mb-2 mt-2"
                    >
                      <p data-qa="updatePartyMessage">
                        <FormattedMessage id="updatePartyMessage" />
                      </p>
                    </YogaMessage>
                  </div>
                )}
                {!taxIdConsistent && (
                  <div id="taxIdInconsistent">
                    <YogaMessage
                      type="error"
                      position="inner"
                      className="mb-4 mt-2"
                    >
                      <p data-qa="taxCodeInconsistent">
                        <FormattedMessage id="taxCodeInconsistent" />
                      </p>
                    </YogaMessage>
                  </div>
                )}
                <div className="mt-4 " data-qa="otpSignatureForm">
                  {isOtpEnabled && (
                    <div
                      className="inline-flex w-full items-center mb-4"
                      data-qa="otpSignatureForm-title"
                    >
                      <span className="text-title-text font-bold">
                        <FormattedMessage id="legalRepresentative" />
                      </span>
                      <span className="ml-[10px] flex-1 h-[2px] bg-background"></span>
                    </div>
                  )}
                  <div className="grid grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-4">
                    {legalRepresentativeParams.map((p) => (
                      <Field
                        key={`${name}.${p.name}`}
                        name={`${name}.${p.name}`}
                        component={FormikInput}
                        content={p}
                        hidden={
                          (p.name === `${name}` + ".birthCountry" &&
                            value?.taxId?.charAt(11).toUpperCase() !== "Z") ||
                          (p.name === `${name}` + ".birthPlace" &&
                            value?.taxId?.charAt(11).toUpperCase() === "Z")
                        }
                        disabled={
                          (p.name !== `${name}` + ".taxId" &&
                            value?.taxId.length !== 16) ||
                          isRetrievingInsured == true ||
                          (p.name === `${name}` + ".taxId" &&
                            (policyHolder.companyType === "Ditta Individuale" ||
                              policyHolder.companyType ===
                                "Impresa familiare")) ||
                          (p.name === `${name}` + ".email" &&
                            retrievedParty?.profile)
                        }
                        maxLength={
                          p.name === `${name}` + ".taxId" ? 16 : undefined
                        }
                        values={form.values}
                      />
                    ))}
                  </div>
                  <Field
                    name={name}
                    key={`${name} + ".location"`}
                    component={AssetInsuredLocationForm}
                    disabled={
                      value?.taxId.length !== 16 || isRetrievingInsured == true
                    }
                  />
                </div>
              </>
            )}

          {!policyholderOtpSignatureEnabled.value &&
            form.values[name] &&
            policyHolder.legalEntity &&
            (policyHolder.companyType === "Ditta Individuale" ||
              policyHolder.companyType === "Impresa familiare") &&
            isIndividualCompanyReferent && (
              <>
                {isAnUpdate && (
                  <div id="updatePartyMessage">
                    <YogaMessage
                      type="warning"
                      position="inner"
                      className="mt-2"
                    >
                      <p data-qa="updatePartyMessage">
                        <FormattedMessage id="updatePartyMessage" />
                      </p>
                    </YogaMessage>
                  </div>
                )}
                <div
                  className={classnames("py-4", isOtpEnabled && "mt-4")}
                  data-qa="otpSignatureForm"
                >
                  {isOtpEnabled && (
                    <div
                      className="inline-flex w-full items-center mb-4"
                      data-qa="otpSignatureForm-title"
                    >
                      <span className="text-title-text font-bold">
                        <FormattedMessage id="legalRepresentative" />
                      </span>
                      <span className="ml-[10px] flex-1 h-[2px] bg-background"></span>
                    </div>
                  )}
                  <div className="grid grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-4">
                    {referentParams.map((p) => (
                      <Field
                        key={`${name}.${p.name}`}
                        name={`${name}.${p.name}`}
                        component={FormikInput}
                        content={p}
                        hidden={
                          (p.name === `${name}` + ".birthCountry" &&
                            value?.taxId?.charAt(11).toUpperCase() !== "Z") ||
                          (p.name === `${name}` + ".birthPlace" &&
                            value?.taxId?.charAt(11).toUpperCase() === "Z")
                        }
                        disabled={
                          (p.name !== `${name}` + ".taxId" &&
                            value?.taxId.length !== 16) ||
                          isRetrievingInsured == true ||
                          (p.name === `${name}` + ".taxId" &&
                            (policyHolder.companyType === "Ditta Individuale" ||
                              policyHolder.companyType === "Impresa familiare"))
                        }
                        maxLength={
                          p.name === `${name}` + ".taxId" ? 16 : undefined
                        }
                        values={form.values}
                      />
                    ))}
                  </div>
                  <Field
                    name={name}
                    key={`${name} + ".location"`}
                    component={AssetInsuredLocationForm}
                    disabled={
                      value?.taxId.length !== 16 || isRetrievingInsured == true
                    }
                  />
                </div>
              </>
            )}

          {policyholderOtpSignatureEnabled.value &&
            form.values[name] &&
            !policyHolder.legalEntity && (
              <>
                <div id="updatePartyMessage">
                  <YogaMessage type="warning" position="inner" className="mt-2">
                    <p data-qa="updatePartyMessage">
                      <FormattedMessage id="updatePartyMessage" />
                    </p>
                  </YogaMessage>
                </div>
                <div className="mt-4 " data-qa="otpSignatureForm">
                  <div className="grid grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-4">
                    {params.map((p) => (
                      <Field
                        key={`${name}.${p.name}`}
                        name={`${name}.${p.name}`}
                        component={FormikInput}
                        content={p}
                        values={form.values}
                        disabled={
                          p.name === `${name}` + ".email" &&
                          !!policyHolder.profile
                        }
                      />
                    ))}
                  </div>
                </div>
              </>
            )}
        </div>
      )}
      <PartyFromAnotherNodeModal
        isOpen={notVisibleNodeModal}
        onClose={() => {
          value.taxId = "";
          setNotVisibleNodeModal(false);
        }}
        onConfirm={() => {
          confirmRetrievedParty(partyToRetrieve);
          setNotVisibleNodeModal(false);
        }}
        partyToRetrieve={partyToRetrieve}
        newManagementNodes={managementNodes}
      ></PartyFromAnotherNodeModal>
    </>
  );
}
