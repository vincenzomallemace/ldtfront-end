import { LocationAutocomplete } from "commons/components/LocationAutocomplete";
import { config } from "commons/Configuration";
import { FormikInput } from "commons/formik/FormikInput";
import { FormInputParam } from "commons/models/YogaParam";
import { Location } from "commons/models/Location";
import {
  Suggestion,
  mandatoryLocationParams,
  suggestionToLocation,
} from "commons/models/Suggestion";
import { Field, FieldProps } from "formik";
import { useEffect, useState } from "react";

export function AssetInsuredLocationForm({
  field: { name },
  form,
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  meta,
  ...props
}: FieldProps) {
  const disabled = (props as any).disabled as boolean;
  const params: FormInputParam[] = [
    {
      name: name + ".location",
      type: "STRING",
      label: "location",
      mandatory: true,
    },
  ];
  const locationField = form.getFieldProps<Location>(`${name}.location`);
  const [startLocation, setStartLocation] = useState<Location>(
    locationField?.value
  );

  useEffect(() => {
    setStartLocation(locationField?.value || null);
  }, [locationField?.value]);

  function setLocation(suggestion?: Suggestion) {
    if (suggestion) {
      let location = suggestionToLocation(suggestion);
      form.setFieldValue(`${name}.location`, location);
    } else {
      form.setFieldValue(`${name}.location`, null);
    }
  }

  return (
    <>
      {config.GEOLOCATION == "disabled" ? (
        <div className="w-full">
          {params.map((p) => (
            <Field
              key={`${name}.location.label`}
              name={`${name}.location.label`}
              component={FormikInput}
              content={p}
              values={form.values}
            />
          ))}
        </div>
      ) : (
        <div className="w-full">
          <LocationAutocomplete
            id={`${name}.location`}
            label="residentialAddressOrRegisteredAddressMandatory"
            onSelectLocation={setLocation}
            startLocation={startLocation}
            error={
              form.getFieldMeta(`${name}.location`).touched
                ? form.getFieldMeta(`${name}.location`).error
                : undefined
            }
            disabled={disabled}
            mandatoryLocationParams={mandatoryLocationParams}
          />
        </div>
      )}
    </>
  );
}
