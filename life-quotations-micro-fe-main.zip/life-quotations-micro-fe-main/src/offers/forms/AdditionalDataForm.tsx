import { ArrowCircleRightIcon, SaveIcon } from "@heroicons/react/outline";
import { config, CTX } from "commons/Configuration";
import { getISODate } from "commons/DateUtils";
import { getBirthPlace, getMobilePhoneAndPrefix, paramsToMap, setMobilePhoneAndPrefix } from "commons/FormUtils";
import { Accordion } from "commons/components/Accordion";
import Messages from "commons/components/Messages";
import { StickyBar } from "commons/components/StickyBar";
import { YogaButton } from "commons/components/YogaButton";
import YogaCard from "commons/components/YogaCard";
import { Context } from "commons/contexts/Context";
import { validateParameters } from "commons/formik/Utils";
import { KeyValue } from "commons/models/YogaModels";
import { YogaParam } from "commons/models/YogaParam";
import { ManagementNode } from "commons/models/nodes/ManagementNode";
import { lifeProductService } from "commons/services/LifeProductService";
import { partyService } from "commons/services/PartyService";
import { RoleType } from "contracts/enums/RoleType";
import { AdditionalPartyDetailsForm, PartyMainDetails } from "customers/components/PartyDetail";
import FormikConsentForm from "customers/forms/FormikConsentForm";
import { PartyParametersForm } from "customers/forms/PartyParametersForm";
import useConsentsListNew from "customers/hooks/useConsentsListNew";
import { ConsentType, getConsentsSchema, mergePartyConsents } from "customers/models/Consent";
import { Party } from "customers/models/Party";
import { ProductParty } from "customers/models/ProductParty";
import { Profile } from "customers/models/Profile";
import { Field, FieldArray, FieldProps, Form, Formik, FormikProps, useFormikContext } from "formik";
import { isValidIBAN } from "ibantools";
import { Asset } from "offers/models/Asset";
import { Product } from "offers/models/Product";
import { Fragment, useContext, useEffect, useMemo, useRef, useState } from "react";
import { FormattedMessage, useIntl } from "react-intl";
import { formatPhoneNumberIntl, isValidPhoneNumber } from "react-phone-number-input";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import * as Yup from "yup";
import * as yup from "yup";
import LifeInsuredPersonForm, { getProductPartySchema } from "./LifeInsuredPersonForm";
import { getLocationSchema } from "commons/models/Location";
import { scrollToTop } from "commons/Utils";
import usePartyParameters from "customers/hooks/usePartyParameters";

interface AdditionalDataFormParams {
  product: Product;
  setProduct: (p: Product) => any;
  policyholder: Party;
  updateProduct: (update: Product, quote: Boolean) => Promise<boolean>;
  updatePolicyholderParams: (partyId: string, newVals: KeyValue<YogaParam>) => Promise<YogaParam[]>;
}

export function AdditionalDataForm({ product, setProduct, policyholder, updateProduct, updatePolicyholderParams }: AdditionalDataFormParams) {
  const form = useRef<FormikProps<any>>();

  const [initialValues, setInitialValues] = useState(undefined);
  const [taxIdChecks, setTaxIdChecks] = useState<string[]>(undefined);
  const { defaultConsents: defaultPolicyholderConsents } = useConsentsListNew(ConsentType.POLICYHOLDER_IN_ISSUE);
  const { defaultConsents: defaultInsuredConsents } = useConsentsListNew(ConsentType.INSURED_IN_ISSUE);

  const { changeLoading } = useContext(Context);

  const [partyParams, setPartyParams] = useState<YogaParam[]>();

  const { updateParams: updateInsuredPersonParams, defaultParams: defaultInsuredPersonParams } = usePartyParameters(
    RoleType.INSURED_PERSON,
    product.code,
    product.productId,
    product.type ?? "LIFE"
  );

  const isPolicyholderPhysical = useMemo(() => {
    return !policyholder.legalEntity;
  }, [policyholder]);

  const intl = useIntl();
  const navigate = useNavigate();

  //const selectLocationMessage = intl.formatMessage({ id: "selectLocation" });
  const invalidPhoneMessage = intl.formatMessage({ id: "invalidPhoneNumber" });

  const validationSchema = useMemo(() => {
    if (product) {
      let schema = yup.object();
      let assetSchema = yup.object();
      Object.entries(product.assets).forEach(([assetCode, assetMap]) => {
        let withPartySchema = yup.object();
        Object.keys(assetMap).map((assetId) => {
          withPartySchema = withPartySchema.shape({
            [assetId]: yup.object({
              parties: yup.object({
                INSURED_PERSON: yup.array(getProductPartySchema(intl)),
              }),
            }),
          });
        });
        assetSchema = assetSchema.shape({ [assetCode]: withPartySchema });
      });
      schema = schema.shape({
        /*email: Yup.string()
          .nullable()
          .email(intl.formatMessage({ id: "invalidEmail" })),*/
        mobilePhoneNumber: Yup.string()
          .nullable()
          .test("phoneValid", invalidPhoneMessage, (val) => {
            if (val) return isValidPhoneNumber(val);
            return true;
          }),
        location: getLocationSchema(intl),
        domicile: Yup.object().when("domicileIsNotResidence", {
          is: true,
          then: getLocationSchema(intl),
        }),
        iban: Yup.string()
          .nullable()
          .test("iban", intl.formatMessage({ id: "ibanFormatError" }), (v) => !v || isValidIBAN(v)),
        consents: getConsentsSchema(intl),
        assets: assetSchema,
      });
      return schema;
    } else {
      return yup.object();
    }
  }, [product]);

  /*useEffect(() => {
    scrollToProductMessages();
  }, [product?.messages]);*/

  useEffect(() => {
    if (defaultPolicyholderConsents != undefined && defaultInsuredConsents != undefined && defaultInsuredPersonParams != undefined) {
      const fetchData = async () => {
        let initialPolicyholderParams = await updatePolicyholderParams(policyholder.partyId, policyholder.parameters);
        setPartyParams(initialPolicyholderParams);

        let phone;
        let phonePrefix;
        if (policyholder.mobilePhoneNumber)
          [phone, phonePrefix] = getMobilePhoneAndPrefix(policyholder.mobilePhoneNumber, policyholder.mobilePhoneNumberPrefix);

        let policyholderAdditionalDetails = {
          legalEntity: policyholder.legalEntity,
          //email: policyholder.email,
          mobilePhoneNumber: phonePrefix + phone || "",
          atecoCode: policyholder.atecoCode,
          employeesNumber: policyholder.employeesNumber,
          revenue: policyholder.revenue?.amount.toString() ?? "",
          iban: policyholder.iban,
          location: policyholder.location,
          domicileIsNotResidence: policyholder.domicileIsNotResidence,
          domicile: !policyholder.domicileIsNotResidence
            ? { label: "" }
            : policyholder.domicile?.label !== policyholder.location?.label && policyholder.domicile?.label !== null
            ? policyholder.domicile
            : { label: "" },
        };
        let currInitialValues = {
          ...policyholderAdditionalDetails,
          parameters: paramsToMap(initialPolicyholderParams),
          consents: mergePartyConsents(defaultPolicyholderConsents, policyholder.consents),
          assets: setAssets(product.assets ?? {}),
        };
        setInitialValues(currInitialValues);
      };
      fetchData().catch((e) => {
        console.error(e);
      });
    }
  }, [defaultPolicyholderConsents, defaultInsuredConsents, defaultInsuredPersonParams]);

  const setAssets = (assets: {
    [assetCode: string]: KeyValue<Asset>;
  }): {
    [assetCode: string]: KeyValue<Asset>;
  } => {
    // Set insured asset persons

    for (const assetCode in assets) {
      const assetMap = assets[assetCode];

      for (const assetId in assetMap) {
        const asset = assetMap[assetId];
        // There are not parties or an insured person
        if (!asset.parties || !asset.parties[RoleType.INSURED_PERSON]) {
          assets[assetCode][assetId].parties = Object.assign({}, asset.parties, {
            [RoleType.INSURED_PERSON]: [
              {
                policyholderIsInsuredPerson: !policyholder.legalEntity,
                taxId: "",
                surnameOrCompanyName: "",
                name: "",
                birthDate: undefined,
                birthCountry: "",
                birthCountryCode: "",
                birthPlace: "",
                gender: undefined,
                //email: "",
                mobilePhoneNumber: undefined,
                iban: "",
                location: { label: "" },
                domicileIsNotResidence: false,
                domicile: { label: "" },
                consents: defaultInsuredConsents,
                parameters: paramsToMap(defaultInsuredPersonParams),
              },
            ],
          });
          // There are parties and an insured person
        } else if (asset.parties && asset.parties[RoleType.INSURED_PERSON]) {
          let parties: ProductParty[] = [];
          for (const party of asset.parties[RoleType.INSURED_PERSON]) {
            if (party.policyholderIsInsuredPerson) {
              parties.push({
                policyholderIsInsuredPerson: true,
                taxId: "",
                surnameOrCompanyName: "",
                name: "",
                partyId: "",
              });
            } else {
              // eslint-disable-next-line @typescript-eslint/no-unused-vars
              let phone: string;
              let phonePrefix: string;
              if (party.mobilePhoneNumber) [phone, phonePrefix] = getMobilePhoneAndPrefix(party.mobilePhoneNumber, party.mobilePhoneNumberPrefix);
              let birthData = getBirthPlace(party);
              parties.push(
                Object.assign(party, {
                  location: party.location ?? null,
                  mobilePhoneNumber: phonePrefix + phone || "",
                  ...birthData,
                })
              );
            }
          }
          asset.parties[RoleType.INSURED_PERSON] = parties;
        }
      }
    }
    return assets;
  };

  const addPolicyholder = async (values: any): Promise<Product> => {
    let mobilePhoneNumber: string;
    let mobilePhoneNumberPrefix: string;
    if (values.mobilePhoneNumber) {
      const prefix = formatPhoneNumberIntl(values.mobilePhoneNumber).split(" ")[0];
      mobilePhoneNumber = values.mobilePhoneNumber.replace(prefix, "");
      mobilePhoneNumberPrefix = prefix.replace("+", "00");
    }

    let updatedPolicyholder: Party = Object.assign(policyholder);

    //updatedPolicyholder.email = values.email;
    updatedPolicyholder.mobilePhoneNumber = mobilePhoneNumber;
    updatedPolicyholder.mobilePhoneNumberPrefix = mobilePhoneNumberPrefix;
    updatedPolicyholder.atecoCode = values.atecoCode;
    updatedPolicyholder.employeesNumber = values.employeesNumber;
    updatedPolicyholder.revenue = values.revenue ? { amount: values.revenue, currency: "EUR" } : null;
    updatedPolicyholder.iban = values.iban;
    updatedPolicyholder.location = values.location;
    updatedPolicyholder.domicileIsNotResidence = values.domicileIsNotResidence;
    updatedPolicyholder.domicile = !values.domicileIsNotResidence
      ? values.location?.label !== null
        ? values.location
        : null
      : values.domicile.label !== null
      ? values.domicile
      : null;
    updatedPolicyholder.parameters = values.parameters;
    updatedPolicyholder.consents = values.consents;

    product.policyHolder = updatedPolicyholder;

    const updated = (await lifeProductService.addPolicyholderToProduct(product?.productId, product?.policyHolder)).data;

    return updated;
  };

  const ScrollToFieldError = () => {
    const { submitCount, errors } = useFormikContext();

    const transformObjectToDotNotation = (obj, prefix = "", result: string[] = []) => {
      Object.keys(obj).forEach((key) => {
        const value = obj[key];
        if (!value) return;

        const nextKey = prefix ? `${prefix}.${key}` : key;
        if (typeof value === "object") {
          transformObjectToDotNotation(value, nextKey, result);
        } else {
          result.push(nextKey);
        }
      });

      return result;
    };

    useEffect(() => {
      if (submitCount > 0) {
        if (errors) {
          const fieldNames = transformObjectToDotNotation(errors);
          const errorToScroll = document.getElementById(fieldNames[0]);
          errorToScroll?.scrollIntoView({
            behavior: "smooth",
            block: "center",
          });
        }

        const addressErrorElement = document.getElementById("incompleteAddressError");
        if (addressErrorElement) {
          addressErrorElement.scrollIntoView({
            behavior: "smooth",
            block: "center",
          });
          return;
        }
      }
      // Formik doesn't (yet) provide a callback for a client-failed submission,
      // thus why this is implemented through a hook that listens to changes on
      // the submit count.
    }, [submitCount, errors]);

    return null;
  };

  const addParty = async (assetCode: string, assetId: string, party: ProductParty) => {
    if (party.mobilePhoneNumber) {
      const prefix = formatPhoneNumberIntl(party.mobilePhoneNumber).split(" ")[0];
      party.mobilePhoneNumber = party.mobilePhoneNumber.replace(prefix, "");
      party.mobilePhoneNumberPrefix = prefix.replace("+", "00");
    }
    await lifeProductService.addInsuredPerson(product.productId, assetCode, assetId, party);
  };

  const buildParty = (values: any) => {
    const profile = values.profile as Profile;
    if (profile) {
      profile.email = values.email as string;
    }
    let updateNodes: ManagementNode[] = values.managementNodes ? values.managementNodes : [];
    if (updateNodes.filter((node) => node?.code === product.managementNode?.code).length === 0) {
      updateNodes.push(product.managementNode);
    }
    let [number, numberPrefix] = setMobilePhoneAndPrefix(values.mobilePhoneNumber);
    const birthData = getBirthPlace(values);
    const party: ProductParty = {
      partyId: values.partyId,
      taxId: values.taxId as string,
      surnameOrCompanyName: values.surnameOrCompanyName as string,
      name: values.name as string,
      legalEntity: false,
      location: values.location?.label !== null ? values.location : null,
      domicileIsNotResidence: values.domicileIsNotResidence,
      domicile: !values.domicileIsNotResidence
        ? values.location?.label !== null
          ? values.location
          : null
        : values.domicile.label !== null
        ? values.domicile
        : null,
      birthDate: (values.birthDate as Date) ? new Date(getISODate(values.birthDate as Date)) : undefined,
      birthCountry: birthData.birthCountry,
      birthCountryCode: birthData.birthCountryCode,
      birthPlace: birthData.birthPlaceComplete.name,
      birthPlaceCode: birthData.birthPlaceCode,
      birthCountyCode: birthData.birthCountyCode,
      gender: values.gender as string,
      mobilePhoneNumber: number,
      mobilePhoneNumberPrefix: numberPrefix,
      //email: values.email as string,
      profile: profile,
      iban: values.iban,
      bankAccounts: values.bankAccounts,
      customerReference: values.customerReference,
      managementNodes: updateNodes,
      questionnaireCode: values.questionnaireCode,
      questionnaire: values.questionnaire,
      tags: values.tags,
      legacyData: values.legacyData,
      consents: values.consents,
      lastConsentsUpdateInstant: values.lastConsentsUpdateInstant,
      otpSignatureEnabled: values.otpSignatureEnabled,
      linkedParties: values.linkedParties,
      parameters: values.parameters ?? {},
      policyholderIsInsuredPerson: false,
    };
    return party;
  };

  const handleSubmit = async (values: any) => {
    changeLoading(1);

    let taxIdErrors: string[] = [];

    try {
      for (const [assetCode, assetMap] of Object.entries(values.assets)) {
        for (const [assetId, asset] of Object.entries(assetMap)) {
          for (let index = 0; index < asset.parties["INSURED_PERSON"].length; index++) {
            const party = asset.parties["INSURED_PERSON"][index];
            const taxIdValid = await handleInsured(assetCode, assetId, party);
            if (!taxIdValid) {
              taxIdErrors.push(`assets.${assetCode}.${assetId}.parties.INSURED_PERSON.${index}`);
            }
          }
        }
      }
      setTaxIdChecks(taxIdErrors);

      if (taxIdErrors.length > 0) {
        const element = document.getElementById(taxIdErrors[0]);
        element?.scrollIntoView({
          behavior: "smooth",
          block: "center",
        });
      } else {
        const updatedProduct = await addPolicyholder(values);
        setProduct(updatedProduct);

        if (updatedProduct && !updatedProduct.messages["errors"]) {
          let visibleParams = Object.values(updatedProduct.parameters).some((param: YogaParam) => param.visible);
          let hasAvailablegreements = updatedProduct.availableAgreements.length > 0;
          if (visibleParams || hasAvailablegreements) {
            updateProduct(updatedProduct, false).then((areErrors) => {
              if (!areErrors) {
                navigate(`${CTX}/offers/${product.productId}/technicalData`);
              } else {
                scrollToTop();
              }
            });
          } else {
            updateProduct(updatedProduct, false).then((areErrors) => {
              if (!areErrors) {
                updateProduct(updatedProduct, true).then((areErrors) => {
                  if (!areErrors) {
                    navigate(`${CTX}/offers/${product.productId}/quotation`);
                  } else {
                    scrollToTop();
                  }
                });
              } else {
                scrollToTop();
              }
            });
          }
        } else {
          document.getElementById("life-quotation-mfe")?.scrollIntoView({ behavior: "smooth", block: "center" });
        }
      }
    } finally {
      changeLoading(-1);
    }
  };

  async function handleInsured(assetCode: string, assetId: string, party: any) {
    const policyholderIsInsuredPerson = party.policyholderIsInsuredPerson;
    if (!policyholderIsInsuredPerson) {
      const newParty = buildParty(party);
      let result = await partyService.checkTaxId(newParty, true);
      if (result.data === true) {
        await addParty(assetCode, assetId, newParty);
        return true;
      } else {
        return false;
      }
    } else {
      const policyholderParty: ProductParty = {
        policyholderIsInsuredPerson: true,
        partyId: policyholder.partyId,
        taxId: policyholder.taxId,
        name: policyholder.name,
        surnameOrCompanyName: policyholder.surnameOrCompanyName,
      };
      await addParty(assetCode, assetId, policyholderParty);
      return true;
    }
  }

  function saveDraft(values: any) {
    changeLoading(1);

    let updatedProduct: Product = JSON.parse(JSON.stringify(product));
    let number;
    let numberPrefix;
    if (values.mobilePhoneNumber) {
      [number, numberPrefix] = setMobilePhoneAndPrefix(values.mobilePhoneNumber);
      updatedProduct.policyHolder.mobilePhoneNumber = number;
      updatedProduct.policyHolder.mobilePhoneNumberPrefix = numberPrefix;
    }

    //updatedProduct.policyHolder.email = values.email;
    updatedProduct.policyHolder.atecoCode = values.atecoCode || null;
    updatedProduct.policyHolder.employeesNumber = values.employeesNumber || null;
    updatedProduct.policyHolder.revenue = values.revenue ? { amount: values.revenue, currency: "EUR" } : null;
    updatedProduct.policyHolder.iban = values.iban;
    updatedProduct.policyHolder.location = values.location.label != null ? values.location : null;
    updatedProduct.policyHolder.domicileIsNotResidence = values.domicileIsNotResidence;
    updatedProduct.policyHolder.domicile = values.domicile.label != null ? values.domicile : null;
    updatedProduct.policyHolder.parameters = values.parameters;
    updatedProduct.policyHolder.consents = values.consents;
    //updatedProduct.assets = values.assets;
    for (const [assetCode, assetMap] of Object.entries(values.assets)) {
      for (const [assetId, asset] of Object.entries(assetMap)) {
        for (let index = 0; index < asset.parties["INSURED_PERSON"].length; index++) {
          const party = asset.parties["INSURED_PERSON"][index];
          const policyholderIsInsuredPerson = party.policyholderIsInsuredPerson;
          if (!policyholderIsInsuredPerson) {
            const newParty = buildParty(party);
            if (typeof newParty.location == "string") {
              newParty.location = null;
            }
            updatedProduct.assets[assetCode][assetId].parties["INSURED_PERSON"][0] = newParty;
          } else {
            const policyholderParty: ProductParty = {
              policyholderIsInsuredPerson: true,
              partyId: policyholder.partyId,
              taxId: policyholder.taxId,
              name: policyholder.name,
              surnameOrCompanyName: policyholder.surnameOrCompanyName,
            };
            updatedProduct.assets[assetCode][assetId].parties["INSURED_PERSON"][0] = policyholderParty;
          }
        }
      }
    }

    lifeProductService
      .saveProductIncompleteDraft(product.productId, updatedProduct)
      .then((result) => {
        product.quotationNumber = result.data.quotationNumber;
        // setProduct(result.data);
        toast.success(
          intl.formatMessage(
            {
              id: "proposalDrafted",
            },
            { number: result.data.quotationNumber }
          )
        );
      })
      .catch((e) => {
        console.error(e);
        toast.error(
          product.quotationNumber
            ? intl.formatMessage(
                {
                  id: "proposalDraftedErrorWithNumber",
                },
                { number: product.quotationNumber }
              )
            : intl.formatMessage({
                id: "proposalDraftedError",
              })
        );
      })
      .finally(() => changeLoading(-1));
  }

  const validatePolicyholderParameters = (editedValues) => {
    return validateParameters(partyParams, editedValues, intl);
  };

  const onUpdatePolicyholderParams = async (values) => {
    const helpers = form.current.getFieldHelpers("parameters");
    const updated = await updatePolicyholderParams(policyholder.partyId, values.parameters);
    setPartyParams(updated);
    helpers.setValue(paramsToMap(updated), false);
  };

  return (
    <>
      {product && policyholder && initialValues && validationSchema && (
        <>
          <Formik innerRef={form} initialValues={initialValues} validationSchema={validationSchema} onSubmit={handleSubmit}>
            {({ values }) => (
              <Form id="productAddictionalData">
                <StickyBar
                  //backFunction={() => saveDraft(values)}
                  breadcrumb={
                    <div className="flex flex-col truncate">
                      <div data-qa="additional-data-page-title" className="truncate">
                        <FormattedMessage id="policyholderAndAsset" />
                      </div>
                      <div className="inline-flex flex-wrap gap-x-4 items-center" data-qa="extra-info">
                        {/*product.quotationNumber && (
                          <span className="text-base font-normal truncate" data-qa="product-quotationNumber">
                            N. {product.quotationNumber}
                          </span>
                        )*/}
                        <span className="text-base font-normal truncate" data-qa="product-description">
                          {product.description}
                        </span>
                      </div>
                    </div>
                  }
                >
                  <div className="self-end text-right flex-1 flex gap-x-4">
                    {config.SAVE_DRAFT_LIFE_PROPOSAL && (
                      <YogaButton
                        kind="default"
                        type="button"
                        outline
                        className="flex gap-2 items-center"
                        data-qa="save-draft-button"
                        action={() => saveDraft(values)}
                      >
                        <SaveIcon className="w-5 -ml-1 shrink-0" />
                        <FormattedMessage id="saveDraft" />
                      </YogaButton>
                    )}
                    <YogaButton
                      kind="default"
                      form="productAddictionalData"
                      className="flex gap-2 items-center"
                      //action={() => saveDraft(values)}
                    >
                      <ArrowCircleRightIcon className="w-5 mr-2 -ml-1" />
                      <span className="hidden lg:block">
                        <FormattedMessage id="continue" />
                      </span>
                    </YogaButton>
                  </div>
                </StickyBar>
                <div className="px-3">
                  <Messages messages={product?.messages} entity="product" />

                  <div className="flex flex-col gap-y-8">
                    <YogaCard data-qa="policyholder-form" uniformPadding>
                      <h4 className="mb-4">
                        <FormattedMessage id="policyholder" />
                      </h4>
                      <PartyMainDetails party={policyholder} />

                      <Field>{(fieldProps: FieldProps) => <AdditionalPartyDetailsForm {...fieldProps} policyholder={policyholder} />}</Field>

                      {partyParams && partyParams.length > 0 && (
                        <Field name="parameters" validate={validatePolicyholderParameters}>
                          {(fieldProps) => (
                            <PartyParametersForm
                              {...fieldProps}
                              className="mt-2"
                              partyParameters={partyParams}
                              updateParameters={onUpdatePolicyholderParams}
                            />
                          )}
                        </Field>
                      )}

                      {values.consents.length > 0 && (
                        <Accordion
                          name="consents"
                          open={true}
                          className="flex flex-col border-2 border-background rounded-lg border-collapse mt-4"
                          titleContainerClasses="p-4"
                          accordionTitle={
                            <div className="inline-flex items-center">
                              <h4 className="text-title-text">
                                <FormattedMessage id="privacyConsents" />
                              </h4>
                            </div>
                          }
                        >
                          <div id="privacyConsents">
                            <FieldArray
                              name={`consents`}
                              render={() => (
                                <div id="privacyConsents" className="flex flex-col">
                                  {values.consents?.map((consent, index) => (
                                    <Field key={`consent-${consent.consentId}`} name={`consents.${index}`}>
                                      {(fieldProps) => <FormikConsentForm consent={consent} {...fieldProps} />}
                                    </Field>
                                  ))}
                                </div>
                              )}
                            />
                          </div>
                        </Accordion>
                      )}
                    </YogaCard>
                    {Object.entries(product.assets).map(([assetCode, assetMap]) => (
                      <Fragment key={assetCode}>
                        {Object.entries(assetMap).map(([assetId, asset]) => (
                          <FieldArray
                            key={`assets.${assetCode}.${assetId}.parties.INSURED_PERSON`}
                            name={`assets.${assetCode}.${assetId}.parties.INSURED_PERSON.`}
                            render={() => (
                              <div data-qa="parties">
                                {asset.parties["INSURED_PERSON"].map((party, index) => (
                                  <YogaCard
                                    uniformPadding
                                    key={`${party.partyId}-card`}
                                    id={`assets.${assetCode}.${assetId}.parties.INSURED_PERSON.${index}`}
                                  >
                                    <Field
                                      name={`assets.${assetCode}.${assetId}.parties.INSURED_PERSON.${index}`}
                                      key={`assets.${assetCode}.${assetId}.parties.INSURED_PERSON.${index}.`}
                                    >
                                      {(fieldProps) => (
                                        <LifeInsuredPersonForm
                                          {...fieldProps}
                                          isPolicyholderPhysical={isPolicyholderPhysical}
                                          defaultConsents={defaultInsuredConsents}
                                          product={product}
                                          taxIdChecks={taxIdChecks}
                                          setTaxIdChecks={setTaxIdChecks}
                                          updatePartyParams={updateInsuredPersonParams}
                                          defaultParams={defaultInsuredPersonParams}
                                        />
                                      )}
                                    </Field>
                                  </YogaCard>
                                ))}
                              </div>
                            )}
                          />
                        ))}
                      </Fragment>
                    ))}
                  </div>
                  <ScrollToFieldError />
                </div>
              </Form>
            )}
          </Formik>
        </>
      )}
    </>
  );
}
