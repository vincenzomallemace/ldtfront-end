import { geoValidationError, getBirthPlace, getMobilePhoneAndPrefix, paramsToMap } from "commons/FormUtils";
import { Accordion } from "commons/components/Accordion";
import YogaLoader from "commons/components/Loader";
import { YogaMessage } from "commons/components/YogaMessage";
import { FormikInput } from "commons/formik/FormikInput";
import { getLocationSchema } from "commons/models/Location";
import { getDate, initialPartiesFromProduct, initialPartyParametersFromProduct, validateParameters } from "commons/formik/Utils";
import { KeyValue } from "commons/models/YogaModels";
import { YogaParam, YogaParamValueType } from "commons/models/YogaParam";
import { partyService } from "commons/services/PartyService";
import PartyFromAnotherNodeModal from "customers/components/PartyFromAnotherNodeModal";
import FormikConsentForm from "customers/forms/FormikConsentForm";
import { PartyParametersForm } from "customers/forms/PartyParametersForm";
import { Consent, getConsentsSchema, mergePartyConsents } from "customers/models/Consent";
import { Party } from "customers/models/Party";
import { Field, FieldArray, FieldProps } from "formik";
import { isValidIBAN } from "ibantools";
import { newPartyNaturalPersonForm } from "offers/models/NewPartyForm";
import { Product } from "offers/models/Product";
import { useEffect, useState } from "react";
import { FormattedMessage, IntlShape, useIntl } from "react-intl";
import { isValidPhoneNumber } from "react-phone-number-input";
import * as Yup from "yup";
import { RoleType } from "contracts/enums/RoleType";

interface LifeInsuredPersonFormProps extends FieldProps {
  product: Product;
  defaultConsents: Consent[];
  taxIdChecks: string[];
  setTaxIdChecks: any;
  isPolicyholderPhysical: boolean;
  updatePartyParams: (partyId: string, newVals: KeyValue<YogaParam>) => Promise<YogaParam[]>;
  defaultParams: YogaParam[];
}

export default function LifeInsuredPersonForm({
  product,
  defaultConsents,
  taxIdChecks,
  setTaxIdChecks,
  isPolicyholderPhysical,
  updatePartyParams,
  defaultParams,
  field: { name, value },
  form,
}: LifeInsuredPersonFormProps) {
  const intl = useIntl();

  const [canRetrieve, setCanRetrieve] = useState(true);
  const [updatePartyMessage, setUpdatePartyMessage] = useState(false);
  const [partyToRetrieve, setPartyToRetrieve] = useState(null);
  const [notVisibleNodeModal, setNotVisibleNodeModal] = useState(false);
  const [retrievedParty, setRetrievedParty] = useState<Party>();
  const [isRetrievingInsured, setIsRetrievingInsured] = useState(false);
  //const [domicileOpen, setDomicileOpen] = useState(false);

  const [partiesById, setPartiesById] = useState<KeyValue<Party>>(initialPartiesFromProduct(product, RoleType.INSURED_PERSON));
  const [partyParams, setPartyParams] = useState<YogaParam[]>();
  const [partyParamsById, setPartyParamsById] = useState<KeyValue<YogaParam[]>>(
    initialPartyParametersFromProduct(product, RoleType.INSURED_PERSON, defaultParams)
  );

  const params = newPartyNaturalPersonForm.filter((f) => f.name !== "email").map((p) => Object.assign({}, p, { name: name + "." + p.name }));

  const fieldDisabled = value.taxId?.length !== 16 || isRetrievingInsured == true;

  useEffect(() => {
    if (!isPolicyholderPhysical) {
      setPartyParams(defaultParams);
    }
  }, [isPolicyholderPhysical]);

  useEffect(() => {
    if (value?.taxId?.length === 16) {
      if (value.taxId === product?.policyHolder?.taxId && !product.policyHolder.legalEntity) {
        value.policyholderIsInsuredPerson = true;
      } else {
        if (canRetrieve) {
          retrieveInsured(value?.taxId);
        } else {
          setCanRetrieve(true);
        }
      }
    }
  }, [value?.taxId]);

  useEffect(() => {
    if (!value.policyholderIsInsuredPerson && value.taxId === product.policyHolder.taxId) {
      form.setFieldValue(`${name}.taxId`, "", false);
      form.setFieldValue(`${name}.name`, "", false);
      form.setFieldValue(`${name}.surnameOrCompanyName`, "", false);
    }
    // Set consents and parameters whent click on toggle
    if (!value.policyholderIsInsuredPerson && value.taxId == "") {
      form.setFieldValue(`${name}.consents`, defaultConsents, false);
      form.setFieldValue(`${name}.parameters`, paramsToMap(defaultParams), false);
      setPartyParams(defaultParams);
    }
  }, [value.policyholderIsInsuredPerson]);

  useEffect(() => {
    if (!value.domicileIsNotResidence) form.setFieldValue(`${name}.domicile`, { label: "" }, false);
  }, [value.domicileIsNotResidence]);

  async function confirmRetrievedParty(party: Party) {
    if (value.taxId.toUpperCase() === party.taxId.toUpperCase() && value.taxId !== party.taxId) {
      setCanRetrieve(false);
    }
    // It loads a party from the entity
    if (party.partyId in partiesById) {
      party = partiesById[party.partyId];
    }
    setPartiesById({ ...partiesById, [party.partyId]: party });

    let [number, numberPrefix] = getMobilePhoneAndPrefix(party.mobilePhoneNumber, party.mobilePhoneNumberPrefix);

    value.taxId = party.taxId;
    value.name = party.name;
    value.surnameOrCompanyName = party.surnameOrCompanyName;
    value.gender = party.gender;
    value.birthDate = party.birthDate;

    const birthData = getBirthPlace(party);
    value.birthCountry = birthData.birthCountry;
    value.birthCountryCode = birthData.birthCountryCode;
    value.birthPlace = birthData.birthPlace;
    value.birthPlaceCode = birthData.birthPlaceCode;
    value.birthCountyCode = birthData.birthCountyCode;
    value.birthPlaceComplete = birthData.birthPlaceComplete;

    value.email = party.email || "";
    value.mobilePhoneNumber = number ? numberPrefix + number : "";
    value.location = party.location?.label ? party.location : { label: null };
    value.profile = party.profile;
    value.customerReference = party.customerReference;
    value.managementNodes = party.managementNodes;
    value.partyId = party.partyId;
    value.questionnaireCode = party.questionnaireCode;
    value.questionnaire = party.questionnaire;
    value.tags = party.tags;
    value.legacyData = party.legacyData;
    value.consents = party.consents;
    value.lastConsentsUpdateInstant = party.lastConsentsUpdateInstant;
    value.otpSignatureEnabled = party.otpSignatureEnabled;
    value.linkedParties = party.linkedParties;
    value.iban = party.iban ?? "";
    value.bankAccounts = party.bankAccounts ?? [];
    value.domicileIsNotResidence = party.domicileIsNotResidence;
    value.domicile = !party.domicileIsNotResidence
      ? { label: "" }
      : party.domicile?.label !== party.location?.label && party.domicile?.label !== null
      ? party.domicile
      : { label: "" };
    value.consents = mergePartyConsents(defaultConsents, party?.consents);

    if (defaultParams?.length > 0) {
      let params: YogaParam[] = [];
      if (partyParamsById[party.partyId]) {
        params = partyParamsById[party.partyId];
      } else {
        params = await updatePartyParams(party.partyId, party.parameters);
        setPartyParamsById({ ...partyParamsById, [party.partyId]: params });
      }

      Object.assign(value.parameters, paramsToMap(params));
      setPartyParams(params);
    }

    form.validateForm();
    setUpdatePartyMessage(!!party.surnameOrCompanyName);
    setRetrievedParty(party);
    //setDomicileOpen(value.domicileIsNotResidence);
  }

  function onPartialUpdate(values: KeyValue<YogaParamValueType>, updateOnChange: boolean) {
    if (updateOnChange) {
      let field = Object.keys(values).length ? Object.keys(values)[0] : "";
      if (field == `${name}.taxId` && !value?.taxId) {
        emptyFieldValue();
        if (taxIdChecks?.includes(name)) {
          let newTaxIdChecks: string[] = [...taxIdChecks];
          newTaxIdChecks.splice(newTaxIdChecks.indexOf(name), 1);
          setTaxIdChecks(newTaxIdChecks);
        }
        setUpdatePartyMessage(false);
      }
    }
  }

  const validateInsuredPersonParameters = (editedValues) => {
    if (value?.policyholderIsInsuredPerson) {
      return;
    }
    if (/*value?.partyId &&*/ partyParams) return validateParameters(partyParams, editedValues, intl);
    else return;
  };

  const onUpdateInsuredPersonParameters = async () => {
    if (defaultParams?.length > 0 && value?.partyId) {
      const helpers = form.getFieldHelpers(`${name}.parameters`);
      const updated = await updatePartyParams(value.partyId, value.parameters);
      setPartyParamsById({ ...partyParamsById, [value.partyId]: updated });
      setPartyParams(updated);
      helpers.setValue(paramsToMap(updated), false);
    }
  };

  async function retrieveInsured(id: string) {
    if (isRetrievingInsured) {
      return;
    }
    setIsRetrievingInsured(true);
    await partyService
      .getPartyByTaxId(id, false)
      .then((result) => {
        const party = result.data;
        const notVisible = result.headers["x-not-visible-on-node"];
        if (notVisible === "true") {
          setPartyToRetrieve(party);
          setNotVisibleNodeModal(true);
        } else {
          confirmRetrievedParty(party);
        }
      })
      .catch(() => {
        emptyFieldValue();
      })
      .finally(() => {
        setIsRetrievingInsured(false);
      });
  }

  const emptyFieldValue = async () => {
    value.policyholderIsInsuredPerson = false;
    value.name = "";
    value.surnameOrCompanyName = "";
    value.birthDate = undefined;
    value.birthCountryCode = "";
    value.birthCountry = "";
    value.birthPlace = "";
    value.gender = "";
    value.email = "";
    value.mobilePhoneNumber = "";
    value.location = { label: "" };
    value.profile = null;
    value.customerReference = null;
    value.managementNodes = null;
    value.partyId = value.taxId;
    value.questionnaireCode = null;
    value.questionnaire = null;
    value.tags = null;
    value.legacyData = null;
    value.consents = null;
    value.lastConsentsUpdateInstant = null;
    value.otpSignatureEnabled = false;
    value.linkedParties = null;
    value.iban = "";
    value.bankAccounts = [];
    value.domicileIsNotResidence = false;
    value.domicile = { label: "" };
    value.consents = defaultConsents;

    const paramsMap = paramsToMap(defaultParams);
    if (value.parameters == undefined) value.parameters = paramsMap;
    else Object.assign(value.parameters, paramsMap);

    setPartyParams(defaultParams);

    //setDomicileOpen(false);
    setUpdatePartyMessage(false);
  };

  return (
    <>
      <YogaLoader loading={isRetrievingInsured} />
      <div className="flex items-center justify-between w-full truncate">
        <h4 className="text-title-text truncate" data-qa="insured-title">
          <div className="flex flex-col truncate">
            <div className="truncate font-medium">
              <h4>
                <FormattedMessage id="insured" />
              </h4>
            </div>
          </div>
        </h4>

        {isPolicyholderPhysical && (
          <label
            htmlFor="policyholderIsInsuredPerson"
            className="flex items-center text-body-text text-base font-bold gap-4 cursor-pointer"
            data-qa="policyholderIsInsuredPerson"
          >
            <span className="text-title-text text-xl font-medium">
              <FormattedMessage id="policyholderIsInsuredPerson" />
            </span>
            <span>
              <Field
                key={`${name}.policyholderIsInsuredPerson`}
                name={`${name}.policyholderIsInsuredPerson`}
                component={FormikInput}
                content={{
                  type: "SWITCH",
                  name: `${name}.policyholderIsInsuredPerson`,
                  updateOnChange: true,
                }}
              />
            </span>
          </label>
        )}
      </div>

      {!value.policyholderIsInsuredPerson && (
        <>
          <div className="mt-8">
            <div data-qa="messages-container" className="flex flex-col gap-y-4 mb-4">
              <YogaMessage type="info" position="inner" id="insertDataMessage">
                <p data-qa="insertDataMessage">
                  <FormattedMessage id="insertDataMessagePhysical" />
                </p>
              </YogaMessage>
              {updatePartyMessage && (
                <YogaMessage type="warning" position="inner" id={`${name}-updatePartyMessage`}>
                  <p data-qa="updatePartyMessage">
                    <FormattedMessage id="updatePartyMessage" />
                  </p>
                </YogaMessage>
              )}
              {taxIdChecks?.includes(name) && (
                <YogaMessage type="error" position="inner" id={`${name}-taxIdInconsistent`}>
                  <p data-qa="taxCodeInconsistent">
                    <FormattedMessage id="taxCodeInconsistent" />
                  </p>
                </YogaMessage>
              )}
            </div>
            <div className="grid grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-4 items-start" data-qa="insured-person-input-data">
              {params.map((p) => (
                <Field
                  key={p.name}
                  name={p.name}
                  content={getDate(p, value?.birthDate)}
                  component={FormikInput}
                  hidden={
                    (p.name === `${name}` + ".birthCountry" && value?.taxId?.charAt(11).toUpperCase() !== "Z") ||
                    (p.name === `${name}` + ".birthPlace" && value?.taxId?.charAt(11).toUpperCase() === "Z")
                  }
                  disabled={
                    (p.name !== `${name}` + ".taxId" && value?.taxId?.length !== 16) ||
                    isRetrievingInsured == true ||
                    (p.name === `${name}` + ".email" && retrievedParty?.profile)
                  }
                  maxLength={p.name === `${name}` + ".taxId" ? 16 : undefined}
                  onPartialUpdate={onPartialUpdate}
                  values={form.values}
                  fieldName={p.name}
                />
              ))}
              <div className="col-span-2">
                <Field
                  name={`${name}.location`}
                  component={FormikInput}
                  disabled={value?.taxId?.length !== 16 || isRetrievingInsured == true}
                  content={{
                    name: `${name}.location`,
                    type: "LOCATION",
                    label: "residentialAddressOrRegisteredAddress",
                  }}
                />
              </div>
            </div>
            {/*<Accordion
              name="domicile-data"
              open={domicileOpen}
              className="flex flex-col gap-2 w-full py-4"
              accordionTitle={
                <div className="inline-flex items-center w-full">
                  <h4 className="text-title-text whitespace-nowrap">
                    <FormattedMessage id="domicileData" />
                  </h4>
                  <span className="middle-border-accordion"></span>
                </div>
              }
              key="domicile-section"
            >*/}
            <div className="grid grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-4">
              <div>
                <Field
                  name={`${name}.domicileIsNotResidence`}
                  component={FormikInput}
                  label="domicileDataLabel"
                  disabled={value?.taxId?.length !== 16 || isRetrievingInsured == true}
                  content={{
                    name: `${name}.domicileIsNotResidence`,
                    label: "domicileDataLabelPhysical",
                    type: "BOOLEAN",
                  }}
                />
              </div>
              {value.domicileIsNotResidence && (
                <div className="col-span-2">
                  <Field
                    name={`${name}.domicile`}
                    component={FormikInput}
                    disabled={value?.taxId?.length !== 16 || isRetrievingInsured == true}
                    content={{
                      name: `${name}.domicile`,
                      type: "LOCATION",
                      label: "domicile",
                    }}
                  />
                </div>
              )}
            </div>
            {/*}</Accordion>*/}
            {!value.policyholderIsInsuredPerson && partyParams && partyParams.length > 0 && (
              <Field name={`${name}.parameters`} validate={validateInsuredPersonParameters}>
                {(fieldProps) => (
                  <PartyParametersForm
                    {...fieldProps}
                    className="mt-2"
                    partyParameters={partyParams}
                    updateParameters={onUpdateInsuredPersonParameters}
                    disabled={fieldDisabled}
                  />
                )}
              </Field>
            )}
            {value.consents?.length > 0 && (
              <Accordion
                name={`${name}.consents`}
                open={true}
                className="flex flex-col border-2 border-background rounded-lg border-collapse mt-4"
                titleContainerClasses="p-4"
                accordionTitle={
                  <div className="inline-flex items-center">
                    <h4 className="text-title-text">
                      <FormattedMessage id="privacyConsents" />
                    </h4>
                  </div>
                }
              >
                <div id="privacyConsents">
                  <FieldArray
                    name={`${name}.consents`}
                    render={() => (
                      <div id="privacyConsents" className="flex flex-col">
                        {value.consents?.map((consent, index) => (
                          <Field key={`${name}.consent.${index}`} name={`${name}.consents.${index}`}>
                            {(fieldProps) => (
                              <FormikConsentForm
                                disabled={value?.taxId?.length !== 16 || isRetrievingInsured == true}
                                consent={consent}
                                {...fieldProps}
                              />
                            )}
                          </Field>
                        ))}
                      </div>
                    )}
                  />
                </div>
              </Accordion>
            )}
          </div>

          <PartyFromAnotherNodeModal
            isOpen={notVisibleNodeModal}
            onClose={() => {
              value.taxId = "";
              setNotVisibleNodeModal(false);
            }}
            onConfirm={() => {
              confirmRetrievedParty(partyToRetrieve);
              setNotVisibleNodeModal(false);
            }}
            partyToRetrieve={partyToRetrieve}
            newManagementNodes={[product?.managementNode]}
          />
        </>
      )}
    </>
  );
}

export const getProductPartySchema = (intl: IntlShape) => {
  const requiredMessage = intl.formatMessage({ id: "required" });
  const requiredGeo = geoValidationError(intl);
  const lengthMessage = intl.formatMessage({ id: "lengthError" }, { number: "16" });
  //const selectLocationMessage = intl.formatMessage({ id: "selectLocation" });
  const invalidPhoneMessage = intl.formatMessage({
    id: "invalidPhoneNumber",
  });

  return Yup.object().shape({
    policyholderIsInsuredPerson: Yup.boolean().defined(),
    taxId: Yup.string()
      .ensure()
      .when("policyholderIsInsuredPerson", {
        is: false,
        then: (schema) => schema.test("len", lengthMessage, (val) => val?.length === 16),
        otherwise: (schema) => schema.nullable(),
      }),
    name: Yup.string()
      .ensure()
      .when("policyholderIsInsuredPerson", {
        is: false,
        then: (schema) => schema.required(requiredMessage),
        otherwise: (schema) => schema.nullable(),
      }),
    surnameOrCompanyName: Yup.string()
      .ensure()
      .when("policyholderIsInsuredPerson", {
        is: false,
        then: (schema) => schema.required(requiredMessage),
        otherwise: (schema) => schema.nullable(),
      }),
    gender: Yup.string()
      .ensure()
      .when("policyholderIsInsuredPerson", {
        is: false,
        then: (schema) => schema.required(requiredMessage),
        otherwise: (schema) => schema.nullable(),
      }),
    birthDate: Yup.date().when("policyholderIsInsuredPerson", {
      is: false,
      then: (schema) => schema.required(requiredMessage).typeError(requiredMessage),
      otherwise: (schema) => schema.nullable(),
    }),
    birthCountry: Yup.string()
      .ensure()
      .when(["policyholderIsInsuredPerson", "taxId"], {
        is: (policyholderIsInsuredPerson: boolean, taxId: string = "") =>
          policyholderIsInsuredPerson === false && (!taxId || taxId?.length < 12 || (taxId?.length >= 12 && taxId.charAt(11).toUpperCase() === "Z")),
        then: (schema) => schema.required(requiredGeo),
        otherwise: (schema) => schema.nullable(),
      }),
    birthPlace: Yup.string()
      .ensure()
      .when(["policyholderIsInsuredPerson", "taxId"], {
        is: (policyholderIsInsuredPerson: boolean, taxId: string = "") =>
          policyholderIsInsuredPerson === false && (!taxId || taxId?.length < 12 || (taxId?.length >= 12 && taxId.charAt(11).toUpperCase() !== "Z")),
        then: (schema) => schema.required(requiredGeo),
        otherwise: (schema) => schema.nullable(),
      }),
    email: Yup.string()
      .ensure()
      .when("policyholderIsInsuredPerson", {
        is: false,
        then: (schema) => schema.email(intl.formatMessage({ id: "invalidEmail" })),
        otherwise: (schema) => schema.nullable(),
      }),
    mobilePhoneNumber: Yup.string()
      .ensure()
      .when("policyholderIsInsuredPerson", {
        is: false,
        then: (schema) =>
          schema.nullable().test("phoneValid", invalidPhoneMessage, (val) => val == null || val == "" || isValidPhoneNumber(val ?? "")),
        otherwise: (schema) => schema.nullable(),
      }),
    location: Yup.object().when("policyholderIsInsuredPerson", {
      is: false,
      then: getLocationSchema(intl),
    }),
    domicile: Yup.object().when(["policyholderIsInsuredPerson", "domicileIsNotResidence"], {
      is: (policyholderIsInsuredPerson, domicileIsNotResidence) => !policyholderIsInsuredPerson && domicileIsNotResidence,
      then: getLocationSchema(intl),
    }),
    iban: Yup.string()
      .nullable()
      .test("iban", intl.formatMessage({ id: "ibanFormatError" }), (v) => !v || isValidIBAN(v)),
    consents: Yup.array().when("policyholderIsInsuredPerson", {
      is: false,
      then: getConsentsSchema(intl),
    }),
  });
};
