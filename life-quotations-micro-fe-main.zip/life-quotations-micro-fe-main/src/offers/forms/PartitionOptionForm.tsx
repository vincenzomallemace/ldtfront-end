import { FormikInputNumeric } from "commons/formik/FormikInputNumeric";
import { FormikSelect } from "commons/formik/FormikSelect";
import { hasErrorsOnTouched } from "commons/formik/Utils";
import { Field, FieldProps, useField } from "formik";
import { AVAILABLE_PARTITION_OPTION_TYPE, AvailablePartitionOption } from "offers/models/AvailablePartitionOption";
import { PartitionOption } from "offers/models/PartitionOption";
import { useEffect, useState } from "react";

interface PartitionOptionProps extends FieldProps<PartitionOption> {
  availablePartitionOptions: AvailablePartitionOption[];
}

export default function PartitionOptionForm({ field: { name, value }, form, availablePartitionOptions }: PartitionOptionProps) {
  const partitionsForSelect = availablePartitionOptions.reduce((acc, curr) => [...acc, { value: curr.code, label: curr.name }], []);

  const [first, setFirst] = useState(true);
  const [, unitLinkedInv] = useField(`${name}.unitLinkedInvestment`);

  function getOptionType(code: string) {
    return availablePartitionOptions.find((option) => option.code == code)?.type;
  }

  useEffect(() => {
    if (typeof value?.unitLinkedInvestment == "string") {
      form.setFieldValue(`${name}.segregatedInvestment`, "");
    } else if (value?.unitLinkedInvestment >= 0 && value?.unitLinkedInvestment <= 100) {
      form.setFieldValue(`${name}.segregatedInvestment`, 100 - value.unitLinkedInvestment);
    }
  }, [value?.unitLinkedInvestment]);

  useEffect(() => {
    if (value) {
      if (value.code) {
        const option = availablePartitionOptions.find((opt) => opt.code == value.code);
        if (!(first && option.type == AVAILABLE_PARTITION_OPTION_TYPE.CHECKED)) {
          form.setFieldValue(`${name}.name`, option.name);
          if (option.type == AVAILABLE_PARTITION_OPTION_TYPE.FIXED || option.type == AVAILABLE_PARTITION_OPTION_TYPE.CHECKED) {
            form.setFieldValue(`${name}.unitLinkedInvestment`, option.minUnitLinkedInvestment);
          }
          form.setFieldValue(`${name}.minInvestment`, option.minUnitLinkedInvestment);
        }
      } else {
        form.setFieldValue(`${name}.name`, "");
        form.setFieldValue(`${name}.minInvestment`, 0);
      }
      setFirst(false);
    }
  }, [value?.code]);

  return (
    <div data-qa="partition-option-form" className="grid grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-4 items-end">
      <div className="col-span-2">
        <Field
          name={`${name}.code`}
          data-qa={`${name}.code`}
          component={FormikSelect}
          content={{ name: `${name}.code`, label: "option", availableValues: partitionsForSelect, disableBinarySelect: true }}
          disabled={availablePartitionOptions.length == 1}
        />
      </div>
      <div className="col-span-2 lg:col-span-1 flex flex-col w-full">
        <div className="flex gap-x-0.5 items-center w-full">
          <Field
            name={`${name}.unitLinkedInvestment`}
            component={FormikInputNumeric}
            content={{
              name: `${name}.unitLinkedInvestment`,
              label: "unitLinked",
            }}
            notShowErrorMessage
            disabled={value?.code == "" || getOptionType(value?.code) == AVAILABLE_PARTITION_OPTION_TYPE.FIXED}
            percentage
          />
          <Field
            name={`${name}.segregatedInvestment`}
            component={FormikInputNumeric}
            content={{
              name: `${name}.segregatedInvestment`,
              label: "segregatedFund",
            }}
            notShowErrorMessage
            disabled
            percentage
          />
        </div>
        {hasErrorsOnTouched(form) && (
          <div className="h-6">
            {(unitLinkedInv.touched || form.submitCount > 0) && unitLinkedInv.error && (
              <span className="text-base text-error" data-qa={`error-message-${name}.unitLinkedInvestment`}>
                {unitLinkedInv.error}
              </span>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
