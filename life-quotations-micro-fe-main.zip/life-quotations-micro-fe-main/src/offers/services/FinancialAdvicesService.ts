import axios, { AxiosResponse } from "axios";
import { getApiContext } from "commons/Configuration";
import { FinancialAdviceOffer } from "commons/services/LifeProductService";
import { FinancialAdvice } from "models/FinancialAdvice";

const api = `${getApiContext()}/v1/financial-advices`;

export const financialAdvicesService = {
  create(financialAdvice: FinancialAdvice): Promise<AxiosResponse<FinancialAdvice>> {
    return axios.post(`${api}/test`, financialAdvice);
  },
  get(financialAdviceId: string): Promise<AxiosResponse<FinancialAdvice>> {
    return axios.get(`${api}/${financialAdviceId}`);
  },
  getByProductId(productId: string): Promise<AxiosResponse<FinancialAdvice>> {
    return axios.get(`${api}/product/${productId}`);
  },
  cancelDraft(financialAdviceId: string, financialOfferId: string): Promise<AxiosResponse<FinancialAdviceOffer>> {
    return axios.delete(`${api}/${financialAdviceId}/financial-offers/${financialOfferId}/draft`);
  },
};
