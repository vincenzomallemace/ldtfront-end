import axios, { AxiosResponse } from "axios";
import { getApiContext } from "commons/Configuration";
import { Party } from "customers/models/Party";
import { FinancialOfferList } from "models/FinancialOffer";

const api = `${getApiContext()}/v1/financial-advices`;

interface ContextData {
  policyholder: Party;
}

export const financialOffersService = {
  create(contextData: ContextData): Promise<AxiosResponse<FinancialOfferList>> {
    return axios.post(`${api}`, contextData);
  },
  get(
    financialOfferListId: string
  ): Promise<AxiosResponse<FinancialOfferList>> {
    return axios.get(`${api}/${financialOfferListId}`);
  },
};
