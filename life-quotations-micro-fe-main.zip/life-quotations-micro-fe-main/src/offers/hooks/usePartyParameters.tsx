import { useEffect, useState } from "react";
import { YogaParam } from "commons/models/YogaParam";
import { partyService } from "commons/services/PartyService";
import { KeyValue } from "commons/models/YogaModels";
import { RoleType } from "contracts/enums/RoleType";

const usePartyParameters = (
  role: RoleType,
  productCode?: string,
  productId?: string
) => {
  const [params, setParams] = useState<YogaParam[] | undefined>(undefined);

  useEffect(() => {
    const fetchData = async () => {
      // If there are no params, it is fine and I will have an empty list
      try {
        const res = await partyService.getParametersByRole(
          role,
          productCode,
          productId
        );
        setParams(res.data as YogaParam[]);
      } catch (e) {
        setParams([]);
        // @ts-ignore
        const res = e?.response;
        if (res.status < 200 && res.status > 300 && res.status != 404) {
          console.error(res);
          throw new Error("An error occurred while fetching the data.");
        }
      }
    };

    if (role) {
      fetchData();
    }
  }, [role]);

  const updateParams = async (
    partyId: string,
    newVals: KeyValue<YogaParam>,
    productId?: string
  ): Promise<YogaParam[]> => {
    let updatedParams: YogaParam[] = [];
    try {
      const res = await partyService.updateParametersWithParty(
        role,
        partyId,
        newVals ? Object.values(newVals) : [],
        productId
      );
      updatedParams = res.data;
      setParams(updatedParams);
    } catch (e) {
      console.error(e);
    }
    return updatedParams;
  };

  const resetParams = async () => {
    try {
      const res = await partyService.getParametersByRole(role);
      setParams(res.data as YogaParam[]);
    } catch (e) {
      setParams([]);
    }
  };

  return { params, updateParams, resetParams };
};

export default usePartyParameters;
