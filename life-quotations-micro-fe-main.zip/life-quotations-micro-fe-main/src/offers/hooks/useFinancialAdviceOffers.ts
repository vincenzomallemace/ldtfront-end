import { FinancialAdviceOffer } from "commons/services/LifeProductService";
import { FinancialAdvice } from "models/FinancialAdvice";
import { useEffect, useState } from "react";

export default function useFinancialAdviceOffers(
  financialAdvice: FinancialAdvice
) {
  const [financialAdviceOffers, setFinancialAdviceOffers] =
    useState<FinancialAdviceOffer[]>(undefined);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setLoading(true);
    const fetchData = async () => {
      if (financialAdvice) {
        const offers: FinancialAdviceOffer[] =
          financialAdvice.financialOffers.map((financialOffer) => {
            return {
              financialAdviceId: financialAdvice.financialAdviceId,
              financialOfferId: financialOffer.financialOfferId,
              product: financialOffer.product,
              investmentLines: financialOffer.investmentLines,
              operationValue: financialOffer.operationValue,
              appliedDiscount: financialOffer.appliedDiscount,
            };
          });
        setFinancialAdviceOffers(offers);
        setLoading(false);
      }
    };
    fetchData().catch((e) => {
      console.error(e);
    });
  }, [financialAdvice]);

  return {
    loading,
    financialAdviceOffers,
  };
}
