import { useContext, useEffect, useState } from "react";
import { FinancialAdvice } from "models/FinancialAdvice";
import { financialAdvicesService } from "offers/services/FinancialAdvicesService";
import { Context } from "commons/contexts/Context";

export default function useFinancialAdvice(id: string, fromQuotation: boolean = false, loader: boolean = true) {
  const [financialAdvice, setFinancialAdvice] = useState<FinancialAdvice>(undefined);
  const { changeLoading } = useContext(Context);
  const [financialAdviceError, setFinancialAdviceError] = useState<Error | undefined>();

  useEffect(() => {
    if (id) {
      loader && changeLoading(1);
      const fetchData = async () => {
        let result;
        if (fromQuotation) {
          result = await financialAdvicesService.getByProductId(id);
        } else {
          result = await financialAdvicesService.get(id);
        }
        const financialAdvice = result.data;
        setFinancialAdvice(financialAdvice);
      };
      fetchData()
        .catch((e) => {
          console.error(e);
          setFinancialAdviceError(e);
        })
        .finally(() => {
          loader && changeLoading(-1);
        });
    }
  }, [id]);

  return {
    financialAdvice,
    financialAdviceError,
  };
}
