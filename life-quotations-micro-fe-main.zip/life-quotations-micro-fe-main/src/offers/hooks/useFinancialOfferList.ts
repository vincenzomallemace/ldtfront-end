import { FinancialOfferList } from "models/FinancialOffer";
import { financialOffersService } from "offers/services/FinancialOffersService";
import { useEffect, useState } from "react";

export default function useFinancialOfferList(financialOfferListId: string) {
  const [financialOfferList, setFinancialOfferList] =
    useState<FinancialOfferList>(undefined);

  useEffect(() => {
    if (financialOfferListId) {
      const fetchData = async () => {
        const result = await financialOffersService.get(financialOfferListId);
        const financialOfferList = result.data as FinancialOfferList;
        setFinancialOfferList(financialOfferList);
      };
      fetchData().catch((e) => {
        console.error(e);
      });
    }
  }, [financialOfferListId]);

  return {
    financialOfferList,
  };
}
