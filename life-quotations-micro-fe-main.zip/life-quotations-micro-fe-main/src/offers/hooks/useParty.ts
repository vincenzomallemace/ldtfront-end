import { useEffect, useState } from "react";
import { partyService } from "commons/services/PartyService";
import { Party } from "customers/models/Party";
import {} from "commons/contexts/Context";

export default function useParty(excludeNode?: boolean) {
  const [partyId, setPartyId] = useState<string>(undefined);
  const [party, setParty] = useState<Party>(undefined);
  const [partyError, setPartyError] = useState<Error | undefined>();

  useEffect(() => {
    const fetchData = async () => {
      if (partyId) {
        const result = await partyService.get(partyId, excludeNode);
        const party = result.data;
        setParty(party);
      }
    };

    if (partyId) {
      fetchData().catch((e) => {
        setPartyError(e);
      });
    }
  }, [partyId]);

  return {
    party,
    partyError,
    setPartyId,
  };
}
