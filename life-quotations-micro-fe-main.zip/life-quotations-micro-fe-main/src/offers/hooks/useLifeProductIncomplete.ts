import { Context } from "commons/contexts/Context";
import { useContext, useEffect, useMemo, useState } from "react";
import { areProductErrors, Product } from "offers/models/Product";
import { lifeProductService } from "commons/services/LifeProductService";
import { KeyValue } from "commons/models/YogaModels";
import { YogaParam } from "commons/models/YogaParam";
import { Asset } from "offers/models/Asset";

export default function useLifeProductIncomplete(productInstanceId?: string) {
  const context = useContext(Context);

  const [productError, setProductError] = useState<string>(undefined);
  const [product, setProduct] = useState<Product>(undefined);

  const hasErrorMessages = useMemo(() => {
    if (product) {
      const productLevelErrors = product.messages?.["errors"]?.length > 0;
      if (productLevelErrors) {
        return true;
      }
      const assetLevelErrors = Object.values(product.assets)
        .reduce((selectedAssets: Asset[], currentAssetType) => {
          selectedAssets.concat(Object.values(currentAssetType).filter((a) => a.selected));
          return selectedAssets;
        }, [])
        .some((a) => a.messages["errors"]?.length > 0 || a.messagesBefore["errors"]?.length > 0);

      return assetLevelErrors;
    }
    return true;
  }, [product]);

  useEffect(() => {
    const fetchData = async () => {
      context.changeLoading(1);
      let res;
      if (productInstanceId) {
        res = await lifeProductService.getIncompleteLifeProduct(productInstanceId);
        let product = res.data;
        if (product) {
          if (
            // product.status === "PURCHASED" ||
            product.status === "EXPIRED"
          ) {
            setProductError("No available");
          } else {
            setProduct(product);
          }
        }
      }
    };
    fetchData()
      .catch((e: any) => {
        setProductError(e.response?.data?.message);
      })
      .finally(() => {
        context.changeLoading(-1);
      });
  }, [productInstanceId]);

  function updateProductParameters(parameters: KeyValue<YogaParam>, partitionOption = undefined) {
    context.changeLoading(1);
    return lifeProductService
      .updateProductParameters(product.productId, parameters)
      .then((response) => {
        if (response.data) {
          let updatedProduct: Product = response.data;
          if (partitionOption) {
            Object.assign(updatedProduct, { partitionOption: partitionOption });
          }
          setProduct(updatedProduct);
        }
      })
      .finally(() => context.changeLoading(-1));
  }

  function updateProduct(productToUpdate: Product, quote: boolean = false): Promise<boolean> {
    return new Promise((resolve, reject) => {
      if (productToUpdate.productId === product.productId) {
        context.changeLoading(1);
        if (quote) {
          lifeProductService
            .updateAndQuoteIncompleteProduct(productToUpdate.productId, productToUpdate, {
              policyholder: product.policyHolder,
            })
            .then((response) => {
              setProduct(response.data);
              resolve(areProductErrors(response.data));
            })
            .finally(() => context.changeLoading(-1))
            .catch((e) => reject(e));
        } else {
          lifeProductService
            .updateProductIncomplete(productToUpdate.productId, productToUpdate, {
              policyholder: product.policyHolder,
            })
            .then((response) => {
              setProduct(response.data);
              resolve(areProductErrors(response.data));
            })
            .finally(() => context.changeLoading(-1))
            .catch((e) => reject(e));
        }
      } else {
        resolve(true);
      }
    });
  }

  return {
    productError,
    product,
    setProduct,

    // utility flags
    hasErrorMessages,

    // utility functions
    updateProductParameters,
    updateProduct,
  };
}
