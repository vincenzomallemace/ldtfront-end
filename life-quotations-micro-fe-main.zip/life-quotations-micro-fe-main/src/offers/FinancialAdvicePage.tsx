import { StickyBar } from "commons/components/StickyBar";
import { YogaButton } from "commons/components/YogaButton";
import { YogaMessage } from "commons/components/YogaMessage";
//import { ProductCategoryIcon } from "offers/components/ProductCategoryIcon";
import { FormattedMessage, FormattedNumber } from "react-intl";
import { useContext, useEffect, useMemo, useState } from "react";
import { ConfirmModal } from "commons/modals/ConfirmModal";
import { useNavigate, useParams } from "react-router-dom";
import useFinancialAdvice from "offers/hooks/useFinancialAdvice";
import { CurrencyEuroIcon, TrashIcon } from "@heroicons/react/solid";
import useParty from "offers/hooks/useParty";
import { PlayIcon, ArrowCircleRightIcon, SearchIcon } from "@heroicons/react/solid";
import { FinancialAdviceOffer, lifeProductService } from "commons/services/LifeProductService";
import { financialAdvicesService } from "offers/services/FinancialAdvicesService";
import { CTX } from "commons/Configuration";
import { Context } from "commons/contexts/Context";
import useFinancialAdviceOffers from "./hooks/useFinancialAdviceOffers";
import YogaSkeleton from "commons/components/YogaSkeleton";
import OfferStatusChip from "./components/OfferStatusChip";

export default function FinancialAdvicePage() {
  const { changeLoading } = useContext(Context);
  const navigate = useNavigate();

  const { financialAdviceId } = useParams<string>();
  const { financialAdvice, financialAdviceError } = useFinancialAdvice(financialAdviceId, false, false);
  const { party, setPartyId } = useParty();
  const { financialAdviceOffers, loading: offersLoading } = useFinancialAdviceOffers(financialAdvice);
  const [openCancelDraftModal, setOpenCancelDraftModal] = useState<boolean>(false);
  const [draftToCancelIndex, setDraftToCancelIndex] = useState<number>();
  const [error, setError] = useState<Error | undefined>();

  useEffect(() => {
    if (financialAdvice && financialAdvice.contractHolder && financialAdvice.contractHolder.partyId) {
      setPartyId(financialAdvice.contractHolder.partyId);
    }
  }, [financialAdvice]);

  useEffect(() => {
    onError(financialAdviceError);
  }, [financialAdviceError]);

  async function createLifeProduct(offerSelected: any) {
    changeLoading(1);
    hideError();
    try {
      await lifeProductService
        .createLifeProduct({
          policyholder: party,
          financialAdviceOffer: offerSelected,
        })
        .then((lifeProduct) => navigate(`${CTX}/offers/${lifeProduct.data.productId}/additionalData`))
        .catch((e) => onError(e));
    } finally {
      changeLoading(-1);
    }
  }

  async function resumeOffer(offerSelected: FinancialAdviceOffer) {
    navigate(`${CTX}/offers/${offerSelected.product.productId}/additionalData`);
  }

  async function gotoDossier(offerSelected: FinancialAdviceOffer) {
    navigate(`${CTX}/offers/${offerSelected.product.contractId}/confirm`);
  }

  const detailStatus = ["VALID_PROPOSAL", "COMPLETED_PROPOSAL", "PROPOSAL_TO_SIGN"];

  const cancellableStates = ["DRAFT"];

  const hasOffersDetails = useMemo(() => {
    if (financialAdviceOffers) return financialAdviceOffers.some((offer) => detailStatus.includes(offer.product.status));
  }, [financialAdviceOffers]);

  function goToDetail(contractId: string) {
    navigate(`${CTX}/offers/${contractId}/detail`);
  }

  async function onConfirmCancelDraft() {
    const financialAdviceOffer = getDraftToCancel();
    changeLoading(1);
    hideError();
    await financialAdvicesService
      .cancelDraft(financialAdviceOffer.financialAdviceId, financialAdviceOffer.financialOfferId)
      .then((response) => setDraftToCancel(response.data))
      .catch((e) => onError(e))
      .finally(() => changeLoading(-1));
  }

  function onError(error) {
    console.log(error);
    setError(error);
  }

  function hideError() {
    setError(undefined);
  }

  const getDraftToCancel = () => financialAdviceOffers?.[draftToCancelIndex];

  function getDraftToCancelDescription() {
    const draft = getDraftToCancel();

    return draft && `${draft.product?.description} - ${draft.investmentLines && Object.values(draft.investmentLines)[0].description}`;
  }

  const setDraftToCancel = (financialAdviceOffer: FinancialAdviceOffer) => (financialAdviceOffers[draftToCancelIndex] = financialAdviceOffer);

  const canCancelDraft = (status: string) => cancellableStates.includes(status);

  const CancelDraftButton = (index: number, offer: FinancialAdviceOffer) =>
    canCancelDraft(offer.product.status) && (
      <YogaButton
        data-qa={`cancel-draft-financial-offer-${offer.product.code}-${index}`}
        action={() => {
          setDraftToCancelIndex(index);
          setOpenCancelDraftModal(true);
        }}
        className="border-none px-0 py-0 self-end w-8 h-8"
        type="button"
        outline
      >
        <TrashIcon className="text-error" />
      </YogaButton>
    );

  function getActionForOffer(offer: FinancialAdviceOffer, index?: number) {
    switch (offer.product.status) {
      case "DRAFT":
        return (
          <YogaButton
            type="button"
            kind="default"
            position="inner"
            className="items-center gap-x-2"
            data-qa={`financial-offer-resume-${offer.product.productId}`}
            action={() => resumeOffer(offer)}
          >
            <ArrowCircleRightIcon className="w-6 h-6" />
            <FormattedMessage id="resumeFinancialOffer" />
          </YogaButton>
        );
      case "VALID_PROPOSAL":
        return <></>;
      case "COMPLETED_PROPOSAL":
      case "PROPOSAL_TO_SIGN":
        return (
          <YogaButton
            type="button"
            kind="default"
            position="inner"
            className="items-center gap-x-2"
            data-qa={`financial-offer-create-${offer.product.code}-${index}`}
            action={() => gotoDossier(offer)}
          >
            <ArrowCircleRightIcon className="w-6 h-6" />
            {offer.product.status === "COMPLETED_PROPOSAL" ? <FormattedMessage id="waitingDocuments" /> : <FormattedMessage id="waitingSign" />}
          </YogaButton>
        );
      default:
        return (
          <YogaButton
            type="button"
            kind="default"
            position="inner"
            className="items-center gap-x-2"
            data-qa={`financial-offer-create-${offer.product.code}-${index}`}
            action={() => createLifeProduct(offer)}
          >
            <PlayIcon className="w-6 h-6" />
            <FormattedMessage id="createFinancialOffer" />
          </YogaButton>
        );
    }
  }

  return (
    <>
      <StickyBar
        hasBackButton={false}
        breadcrumb={
          <div className="flex flex-col truncate">
            <div data-qa="financial-offer-list-page-title" className="truncate">
              <FormattedMessage id="financialOfferListPageTitle" />
            </div>
            <div className="text-base font-normal truncate">
              <span>{party?.surnameOrCompanyName}</span>&nbsp;
              <span>{party?.name}</span>
            </div>
          </div>
        }
      />
      <div data-qa="messages-container" className="p-3">
        {error && (
          <YogaMessage type="error" position="inner" id="page-error">
            <p data-qa="pageError">
              <code>{error.message}</code>
            </p>
          </YogaMessage>
        )}
      </div>
      <div className="px-3">
        <table className="-mt-4 relative table-auto border-separate border-spacing-y-4 w-full">
          <thead className="hidden lg:table-header-group">
            <tr className="text-left font-bold text-xs uppercase text-body-text">
              <th className="px-2"></th>
              <th className="px-2">
                <FormattedMessage id="financialOfferProductColumn" />
              </th>
              <th className="px-2">
                <FormattedMessage id="financialOfferInvestmentLineColumn" />
              </th>
              <th className="px-2 text-right">
                <FormattedMessage id="financialOfferAmountColumn" />
              </th>
              <th className="px-2 text-right min-w-20">
                <FormattedMessage id="financialOfferProductStatusColumn" />
              </th>
              {hasOffersDetails && <th className="px-2"></th>}
            </tr>
          </thead>
          <tbody className="relative top-0 lg:-top-2" data-qa="financial-offer-list">
            {offersLoading ? (
              <>
                <tr>
                  <td colSpan={6}>
                    <YogaSkeleton position="outer" className="h-[84px] lg:h-[76px] rounded-2xl" />
                  </td>
                </tr>
                <tr>
                  <td colSpan={6}>
                    <YogaSkeleton position="outer" className="h-[84px] lg:h-[76px] rounded-2xl" />
                  </td>
                </tr>
                <tr>
                  <td colSpan={6}>
                    <YogaSkeleton position="outer" className="h-[84px] lg:h-[76px] rounded-2xl" />
                  </td>
                </tr>
              </>
            ) : (
              financialAdviceOffers?.map((offer, index) => (
                <tr
                  key={`financial-offer-${offer.product.code}-${index}`}
                  data-qa="financial-offer-row"
                  className="shadow-lg rounded-2xl lg:shadow-none"
                >
                  <td className="py-4 pl-4 pr-2 rounded-l-2xl w-[1%] whitespace-nowrap bg-box-background">
                    <CurrencyEuroIcon /*category={offer.product.category}*/ className="w-10 h-10 stroke-thin" /*style="round"*/ />
                  </td>
                  <td className="py-4 px-2 bg-box-background" data-qa="financial-offer-product">
                    <div className="flex flex-col h-full items-stretch justify-between gap-y-1">
                      <div className="text-title-text font-bold text-xl">{offer.product.description}</div>
                      <div className="flex flex-row gap-x-1 lg:hidden">
                        {offer.investmentLines && Object.values(offer.investmentLines) && (
                          <span data-qa="financial-offer-investment-line" className="text-title-text font-bold text-base">
                            {Object.values(offer.investmentLines)[0].description ?? Object.values(offer.investmentLines)[0].code}
                          </span>
                        )}
                        {offer.operationValue && (
                          <span className="text-title-text font-bold text-base">
                            <FormattedNumber value={offer.operationValue.amount} currency={offer.operationValue.currency || "EUR"} style="currency" />
                          </span>
                        )}
                      </div>
                    </div>
                  </td>
                  <td className="hidden lg:table-cell py-4 px-2 bg-box-background" data-qa="financial-offer-investment-line">
                    {offer.investmentLines && Object.values(offer.investmentLines) && (
                      <span className="text-title-text font-bold text-base">
                        {Object.values(offer.investmentLines)[0].description ?? Object.values(offer.investmentLines)[0].code}
                      </span>
                    )}
                  </td>
                  <td
                    className="hidden lg:table-cell py-4 px-2 w-[1%] whitespace-nowrap text-right bg-box-background"
                    data-qa="financial-offer-amount"
                  >
                    {offer.operationValue && (
                      <span className="text-title-text font-bold text-base">
                        <FormattedNumber value={offer.operationValue.amount} currency={offer.operationValue.currency || "EUR"} style="currency" />
                      </span>
                    )}
                  </td>
                  <td className="hidden lg:table-cell py-4 px-4 w-[1%] whitespace-nowrap bg-box-background">
                    <div className="float-right">
                      <OfferStatusChip offer={offer} />
                    </div>
                  </td>
                  <td className="hidden lg:table-cell py-4 ps-4 w-[1%] whitespace-nowrap bg-box-background">
                    <div className="float-right">{CancelDraftButton(index, offer)}</div>
                  </td>
                  <td className="text-right pl-6 pr-4 py-4 rounded-r-2xl w-[1%] h-full whitespace-nowrap bg-box-background">
                    <div className="flex flex-col justify-between gap-y-1">
                      <OfferStatusChip offer={offer} className="self-end lg:hidden" />
                      <div className="text-right min-h-[44px]">
                        <div className="flex items-center gap-x-2 justify-end">
                          <div className="lg:hidden">{CancelDraftButton(index, offer)}</div>
                          {getActionForOffer(offer, index)}
                          {detailStatus.includes(offer.product.status) && (
                            <span
                              data-qa="go-to-detail-button"
                              className="lg:hidden px-4 py-2 border-primary border-2 rounded-lg cursor-pointer"
                              onClick={() => goToDetail(offer.product.contractId)}
                            >
                              <SearchIcon className="w-6 h-6 shrink-0 text-primary" />
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  </td>
                  {hasOffersDetails && (
                    <td className="hidden lg:table-cell w-[1%] h-auto">
                      <div className="ml-4 hidden lg:flex gap-4 items-center justify-center ">
                        {detailStatus.includes(offer.product.status) && (
                          <div
                            data-qa={`financial-offer-${offer.product.code}-${index}-detail-button`}
                            className="bg-box-background h-[76px] w-[76px] cursor-pointer rounded-2xl hidden lg:flex items-center justify-center shadow-lg"
                            onClick={() => navigate(`${CTX}/offers/${offer.product.contractId}/detail`)}
                          >
                            <div data-qa="go-to-detail-button" className="border-2 border-primary p-1.5 rounded-lg">
                              <SearchIcon className="w-6 h-6 text-primary" />
                            </div>
                          </div>
                        )}
                      </div>
                    </td>
                  )}
                </tr>
              ))
            )}
          </tbody>
        </table>
        <ConfirmModal
          isOpen={openCancelDraftModal}
          onClose={() => {
            setOpenCancelDraftModal(false);
          }}
          onConfirm={() => {
            onConfirmCancelDraft();
            setDraftToCancelIndex(undefined);
            setOpenCancelDraftModal(false);
          }}
          title="cancelFinancialOfferDraft"
          dataQa="cancel-financialoffer-draft-modal"
        >
          <div>
            <FormattedMessage id="cancelFinancialOfferDraftMessage" values={{ draft: getDraftToCancelDescription() }} />
          </div>
        </ConfirmModal>
      </div>
    </>
  );
}
