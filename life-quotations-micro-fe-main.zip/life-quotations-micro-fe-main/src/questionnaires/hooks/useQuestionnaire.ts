import { AxiosError } from "axios";
import { getErrorMessageFromReason } from "commons/Utils";
import { Context } from "commons/contexts/Context";
import { CustomerContext } from "commons/contexts/CustomerContext";
import { KeyValue } from "commons/models/YogaModels";
import { YogaParamValueType } from "commons/models/YogaParam";
import { questionnaireService } from "commons/services/QuestionnaireService";
import { Product } from "offers/models/Product";
import { QuestionnaireModel } from "questionnaires/models/QuestionnaireModel";
import { useContext, useEffect, useMemo, useState } from "react";

interface PartialUpdateParams {
  entityId: string;
  entityType: string;
  values: KeyValue<YogaParamValueType>;
  updateQuestionnaireOnChange: boolean;
  product?: Product;
  questionnaireCompleted?: boolean;
}

interface UseQuestionnaireReturn {
  questionnaire: QuestionnaireModel | undefined;
  setQuestionnaire: (q: QuestionnaireModel) => void;
  updateQuestionnaire: (entityId: string, entityType: string, values: KeyValue<YogaParamValueType>) => void;
  partialUpdateQuestionnaire: ({
    entityId,
    entityType,
    values,
    updateQuestionnaireOnChange,
    product,
    questionnaireCompleted,
  }: PartialUpdateParams) => Promise<QuestionnaireModel>;
  partialUpdateContractQuestionnaire: (
    contractId: string,
    values: KeyValue<YogaParamValueType>,
    updateQuestionnaireOnChange: boolean,
    contextData: Object,
    questionnaireCompleted: boolean
  ) => Promise<QuestionnaireModel>;
  error?: boolean;
}

export default function useQuestionnaire(questId: string): UseQuestionnaireReturn {
  const context = useContext(Context);

  const [questionnaire, setQuestionnaire] = useState<QuestionnaireModel | undefined>(undefined);
  const [error, setError] = useState(false);
  const [changedValues, setChangedValues] = useState<KeyValue<YogaParamValueType>>({});

  const { selectedCustomers } = useContext(CustomerContext);

  const customer = useMemo(() => {
    return selectedCustomers[0];
  }, [selectedCustomers]);

  useEffect(() => {
    const fetchData = async () => {
      const result = await questionnaireService.get(questId);
      if (!result.data) {
        setError(true);
      } else {
        setQuestionnaire(result.data);
        setChangedValues({});
      }
    };
    fetchData().catch(() => setError(true));
  }, [questId]);

  const updateQuestionnaire = async (entityId: string, entityType: string, values: KeyValue<YogaParamValueType>) => {
    if (questionnaire) {
      setError(undefined);
      context.changeLoading(1);
      try {
        customer.questionnaire = questionnaire;
        Object.entries(customer.questionnaire.questions).forEach(([key, q]) => {
          q.answer.value = values[key] ?? q.answer.value;
        });
        const result = await questionnaireService.update(
          questionnaire.questionnaireId,
          {
            answers: values,
            party: customer,
          },
          entityId,
          entityType,
          true,
          true
        );
        setQuestionnaire(result.data);
        context.changeLoading(-1);
      } catch (e: any) {
        setError(e.response?.data?.message);
        context.changeLoading(-1);
      }
    }
  };

  const partialUpdateQuestionnaire = ({
    entityId,
    entityType,
    values,
    updateQuestionnaireOnChange,
    product,
    questionnaireCompleted,
  }: PartialUpdateParams): Promise<QuestionnaireModel> => {
    return new Promise((resolve, reject) => {
      const newChangedValues = { ...changedValues, ...values };
      // Keep track of every new value
      setChangedValues(newChangedValues);
      setError(undefined);
      if (updateQuestionnaireOnChange && questionnaire) {
        context.changeLoading(1);
        questionnaireService
          .partialUpdate(
            questionnaire.questionnaireId,
            {
              answers: newChangedValues,
              party: customer,
              product: product,
            },
            entityId,
            entityType,
            questionnaireCompleted
          )
          .then((result) => {
            const updatedQuestionnaire = result.data as QuestionnaireModel;
            let updatedAnswers = Object.values(updatedQuestionnaire.questions).reduce((acc, curr) => {
              acc[curr.code] = curr.answer.values;
              return acc;
            }, {});

            // Updates any answer values modified by the rules, such as value flushes
            Object.entries(newChangedValues).forEach(([k]) => {
              if (k in updatedAnswers) {
                if (updatedAnswers[k]) {
                  newChangedValues[k] = updatedAnswers[k].at(-1);
                } else {
                  newChangedValues[k] = "";
                }
              }
            });

            setChangedValues(newChangedValues);
            setQuestionnaire(updatedQuestionnaire);
            context.changeLoading(-1);
            resolve(updatedQuestionnaire);
          })
          .catch((e: AxiosError) => {
            const errorMessage = getErrorMessageFromReason(e);
            setError(errorMessage.trim() !== "");
            context.changeLoading(-1);
            reject(errorMessage);
          });
      } else {
        reject("Condition not verified");
      }
    });
  };

  const partialUpdateContractQuestionnaire = (
    entityId,
    values,
    updateQuestionnaireOnChange,
    contextData = {},
    questionnaireCompleted
  ): Promise<QuestionnaireModel> => {
    return new Promise((resolve, reject) => {
      const newChangedValues = { ...changedValues, ...values };
      setChangedValues(newChangedValues);
      setError(undefined);
      if (updateQuestionnaireOnChange && questionnaire) {
        context.changeLoading(1);
        questionnaireService
          .partialUpdate(
            questionnaire.questionnaireId,
            Object.assign(contextData, { answers: newChangedValues }),
            entityId,
            "contract",
            questionnaireCompleted
          )
          .then((result) => {
            const updatedQuestionnaire = result.data as QuestionnaireModel;
            setQuestionnaire(updatedQuestionnaire);
            context.changeLoading(-1);
            resolve(updatedQuestionnaire);
          })
          .catch((e: AxiosError) => {
            const errorMessage = getErrorMessageFromReason(e);
            setError(errorMessage.trim() !== "");
            context.changeLoading(-1);
            reject(errorMessage);
          });
      } else {
        reject("Condition not verified");
      }
    });
  };

  return {
    questionnaire,
    setQuestionnaire,
    updateQuestionnaire,
    partialUpdateQuestionnaire,
    partialUpdateContractQuestionnaire,
    error,
  };
}
