import { questionnaireService } from "commons/services/QuestionnaireService";
import { Contract, STATUS } from "contracts/models/Contract";
import { Party } from "customers/models/Party";
import { Product } from "offers/models/Product";
import {
  QuestionnaireModel,
  QUESTIONNAIRE_TYPE,
} from "questionnaires/models/QuestionnaireModel";

const useQuestionnaireHelper = () => {
  enum Entities {
    CONTRACT = "contract",
  }

  const getQuestionnaire = async (id: string) => {
    return (await questionnaireService.get(id)).data;
  };

  const hasQuestionnaire = (contract: Contract, type: QUESTIONNAIRE_TYPE) => {
    return contract.questionnaires && contract.questionnaires[type];
  };

  const checkHasDueDiligence = async (
    party: Party,
    product: Product,
    contract: Contract
  ): Promise<boolean> => {
    if (contract.contractStatus === STATUS.AUTHORIZED) {
      return false;
    }

    if (hasQuestionnaire(contract, QUESTIONNAIRE_TYPE.DUE_DILIGENCE)) {
      // if questionnaire already exists, use that
      const questionnaire = await getQuestionnaire(
        contract.questionnaires[QUESTIONNAIRE_TYPE.DUE_DILIGENCE]
      );
      return Object.values(questionnaire.questions).some(
        (quest) => quest.visible
      );
    }
    try {
      const questionnaire = (
        await questionnaireService.createType(
          QUESTIONNAIRE_TYPE.DUE_DILIGENCE,
          {
            party: party,
            product: product,
          },
          contract.contractId,
          Entities.CONTRACT,
          contract.productCode
        )
      ).data as QuestionnaireModel;
      return Object.values(questionnaire.questions).some(
        (quest) => quest.visible
      );
    } catch (e) {
      return false;
    }
  };

  const createDueDiligence = async (
    party: Party,
    product: Product,
    contract: Contract
  ) => {
    if (hasQuestionnaire(contract, QUESTIONNAIRE_TYPE.DUE_DILIGENCE)) {
      // if questionnaire already exists, use that
      return await getQuestionnaire(
        contract.questionnaires[QUESTIONNAIRE_TYPE.DUE_DILIGENCE]
      );
    }
    const result = await questionnaireService.createType(
      QUESTIONNAIRE_TYPE.DUE_DILIGENCE,
      {
        party: party,
        product: product,
      },
      contract.contractId,
      Entities.CONTRACT,
      contract.productCode
    );
    return result.data as QuestionnaireModel;
  };

  return {
    checkHasDueDiligence,
    createDueDiligence,
  };
};

export default useQuestionnaireHelper;
