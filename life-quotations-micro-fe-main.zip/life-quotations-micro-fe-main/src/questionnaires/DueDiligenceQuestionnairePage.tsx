import { ArrowCircleRightIcon, SaveIcon } from "@heroicons/react/outline";
import { config, CTX } from "commons/Configuration";
import ErrorPage from "commons/components/ErrorPage";
import Messages from "commons/components/Messages";
import { StickyBar } from "commons/components/StickyBar";
import { YogaButton } from "commons/components/YogaButton";
import { YogaMessage } from "commons/components/YogaMessage";
import { Context } from "commons/contexts/Context";
import { KeyValue } from "commons/models/YogaModels";
import { YogaParamValueType } from "commons/models/YogaParam";
import { contractService } from "commons/services/ContractService";
import useContract from "contracts/hooks/useContract";
import { Contract } from "contracts/models/Contract";
import { FormikHelpers, FormikProps } from "formik";
import { Product } from "offers/models/Product";
import useLifeProductIncompleteOnly from "payments/hooks/useLifeProductIncompleteOnly";
import { useContext, useEffect, useRef, useState } from "react";
import { FormattedMessage } from "react-intl";
import { useNavigate, useParams } from "react-router-dom";
import QuestionnaireForm from "./components/QuestionnaireForm";
import useQuestionnaire from "./hooks/useQuestionnaire";
import { areQuestionnaireOrQuestionErrors } from "questionnaires/models/QuestionnaireModel";

export default function DueDiligenceQuestionnairePage() {
  const { contractId, questId } = useParams();
  const { contract, contractError, policyholder, saveDraft } = useContract(contractId);
  const { questionnaire, partialUpdateQuestionnaire, error } = useQuestionnaire(questId);
  const { product, setProductId } = useLifeProductIncompleteOnly(null);
  const [submitError, setSubmitError] = useState(false);

  const { changeLoading } = useContext(Context);
  const navigate = useNavigate();
  const formRef = useRef<FormikProps<any>>(null);

  const onSubmit = async (values: KeyValue<YogaParamValueType>, { setSubmitting }: FormikHelpers<KeyValue<YogaParamValueType>>) => {
    setSubmitError(false);
    setSubmitting(false);
    changeLoading(1);

    if (product && contract) {
      let updatedContract = await confirmQuestionnaire(values, product, contract);
      if (updatedContract && updatedContract.contractId) {
        navigate(`${CTX}/offers/${updatedContract.contractId}/summary`);
      }
    } else {
      setSubmitError(true);
    }
    changeLoading(-1);
  };

  const confirmQuestionnaire: (values: KeyValue<YogaParamValueType>, product: Product, contract: Contract) => Promise<Contract> = async (
    values: KeyValue<YogaParamValueType>,
    product: Product,
    contract: Contract
  ) => {
    const updatedQuestionnaire = await partialUpdateQuestionnaire({
      entityId: contract.contractId,
      entityType: "contract",
      values: values,
      updateQuestionnaireOnChange: true,
      product: product,
      questionnaireCompleted: true,
    });
    if (!areQuestionnaireOrQuestionErrors(updatedQuestionnaire)) {
      const res = await contractService.addQuestionnaire(contract.contractId, updatedQuestionnaire);
      return res.data as Contract;
    }
  };

  async function onPartialUpdate(values: KeyValue<YogaParamValueType>, updateQuestionnaireOnChange: boolean) {
    setSubmitError(false);
    await partialUpdateQuestionnaire({
      entityId: contract.contractId,
      entityType: "contract",
      values,
      updateQuestionnaireOnChange,
      product,
    });
  }

  useEffect(() => {
    setProductId(contract?.quotationId);
  }, [contract]);

  async function confirmQuestionnaireAndSaveDraft(values: KeyValue<YogaParamValueType>) {
    changeLoading(1);
    await confirmQuestionnaire(values, product, contract).finally(() => changeLoading(-1));
    saveDraft(contract);
  }

  return (
    <>
      {contractError || error ? (
        <ErrorPage></ErrorPage>
      ) : (
        <>
          {contract && policyholder && questionnaire && (
            <>
              <StickyBar
                //backFunction={() => saveDraft(formRef.current.values)}
                breadcrumb={
                  <div className="flex flex-col">
                    <div data-qa="due-diligence-page-title" className="truncate">
                      <FormattedMessage id="dueDiligenceQuestionnaire" />
                    </div>
                    <div className="inline-flex flex-wrap gap-x-4 items-center" data-qa="extra-info">
                      {/*contract.quotationNumber && (
                        <span className="text-base font-normal truncate" data-qa="product-quotationNumber">
                          N. {contract.quotationNumber}
                        </span>
                      )*/}
                      <span className="text-base font-normal truncate" data-qa="policyholder-title">
                        {policyholder?.surnameOrCompanyName}&nbsp;
                        {policyholder?.name}
                      </span>
                      <span className="text-base font-normal truncate" data-qa="product-description">
                        {contract.contractProductName}
                      </span>
                    </div>
                  </div>
                }
              >
                <div className="self-end text-right flex-1 flex gap-x-4">
                  {config.SAVE_DRAFT_LIFE_PROPOSAL && (
                    <YogaButton
                      kind="default"
                      type="button"
                      outline
                      className="flex gap-2 items-center"
                      data-qa="save-draft-button"
                      action={() => confirmQuestionnaireAndSaveDraft(formRef.current.values)}
                    >
                      <SaveIcon className="w-5 -ml-1 shrink-0" />
                      <FormattedMessage id="saveDraft" />
                    </YogaButton>
                  )}
                  <YogaButton
                    kind="default"
                    data-qa="continue-button"
                    type="submit"
                    form="questionnaire-form"
                    className="flex items-center gap-x-2"
                    disabled={areQuestionnaireOrQuestionErrors(questionnaire)}
                    //action={() => saveDraft(formRef.current.values)}
                  >
                    <ArrowCircleRightIcon className="w-5 h-5" />
                    <div className="hidden lg:block">
                      <FormattedMessage id="continue" />
                    </div>
                  </YogaButton>
                </div>
              </StickyBar>
              <div className="px-3">
                {submitError && (
                  <YogaMessage type="error" position="outer" data-qa="submit-error" className="mb-4">
                    <FormattedMessage id="submitIssueError" />
                  </YogaMessage>
                )}
                <Messages messages={contract.messages} entity="contract" />
                <QuestionnaireForm formRef={formRef} questionnaire={questionnaire} onSubmit={onSubmit} onPartialUpdate={onPartialUpdate} />
              </div>
            </>
          )}
        </>
      )}
    </>
  );
}
