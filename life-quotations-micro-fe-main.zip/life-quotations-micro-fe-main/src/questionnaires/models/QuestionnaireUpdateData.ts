import { Party } from "customers/models/Party";
import { KeyValue } from "commons/models/YogaModels";
import { YogaParamValueType } from "commons/models/YogaParam";
import ContractAsset from "contracts/models/ContractAsset";
import { Contract } from "contracts/models/Contract";
import { Product } from "offers/models/Product";

export interface QuestionnaireUpdateData {
  answers: KeyValue<YogaParamValueType>;
  party?: Party;
  product?: Product;
  contract?: Contract;
  asset?: ContractAsset;
}
