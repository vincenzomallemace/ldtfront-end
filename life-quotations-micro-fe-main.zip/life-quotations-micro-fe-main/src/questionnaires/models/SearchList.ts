export interface SearchList {
  attribute: string;
  stringToDisplay: string;
}
