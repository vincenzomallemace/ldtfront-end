import { Question } from "./Question";
import { KeyValue } from "commons/models/YogaModels";

interface QuestionnaireResults {
  riskAnalysis?: KeyValue<number>;
  coveredRisks?: string[];
  hiddenRisks?: string[];
}

export interface QuestionnaireModel {
  description: string;
  questionnaireCode: string;
  questionnaireId: string;
  questions: KeyValue<Question>;
  results: QuestionnaireResults;
  messages: KeyValue<string[]>;
  messagesBefore: KeyValue<string[]>;
}

export enum QUESTIONNAIRE_TYPE {
  DUE_DILIGENCE = "Due Diligence",
}

export const areQuestionnaireErrors = (questionnaire?: QuestionnaireModel) =>
  questionnaire &&
  questionnaire.messages &&
  (("failures" in questionnaire.messages && questionnaire.messages["failures"].length > 0) ||
    ("errors" in questionnaire.messages && questionnaire.messages["errors"].length > 0));

export const areQuestionErrors = (questionnaire?: QuestionnaireModel) =>
  questionnaire &&
  questionnaire.questions &&
  Object.values(questionnaire.questions).some(
    (question) =>
      question.visible &&
      questionnaire.messagesBefore &&
      questionnaire.messagesBefore["errors"] &&
      questionnaire.messagesBefore["errors"][question.code] &&
      questionnaire.messagesBefore["errors"][question.code].length > 0
  );

export const areQuestionnaireOrQuestionErrors = (questionnaire?: QuestionnaireModel) =>
  areQuestionnaireErrors(questionnaire) || areQuestionErrors(questionnaire);
