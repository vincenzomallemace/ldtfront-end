import { Answer } from "./Answer";
import { OrderedEntity } from "commons/models/YogaModels";

export interface Question extends OrderedEntity {
  code: string;
  label: string;
  description?: string;
  questionId: string;
  answer: Answer;
  visible: boolean;
  tags: string[];
  updateQuestionnaireOnChange: boolean;
}
