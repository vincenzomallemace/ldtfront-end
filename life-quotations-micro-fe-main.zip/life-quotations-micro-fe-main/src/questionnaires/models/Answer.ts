import { SearchList } from "./SearchList";

type AnswerType =
  | "STRING"
  | "NUMBER"
  | "LIST"
  | "BOOLEAN"
  | "DATE"
  | "AMOUNT"
  | "SEARCHLIST"
  | "MULTIPLE_CHOICE";

type AnswerValueType = string | boolean | number | Date | undefined;

export interface Answer {
  answerId: string;
  availableValues: string[];
  defaultValue: AnswerValueType;
  mandatory: boolean;
  validations: AnswerValidations;
  disabled: boolean;
  type: AnswerType;
  value: AnswerValueType;
  values: string[];
  searchList?: SearchList;
}

interface AnswerValidations {
  minSelected: number;
  maxSelected: number;
}
