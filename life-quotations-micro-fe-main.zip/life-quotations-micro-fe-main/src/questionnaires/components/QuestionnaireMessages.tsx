import { EMPTY } from "commons/Utils";
import { YogaMessage } from "commons/components/YogaMessage";
import { FormattedMessage } from "react-intl";

interface QuestionnaireMessagesProps {
  messagesError: string[];
  messagesWarning: string[];
  messagesInfo: string[];
  prefixMessages: string;
  position: "inner" | "outer";
}

export default function QuestionnaireMessages({
  messagesError,
  messagesWarning,
  messagesInfo,
  prefixMessages,
  position,
}: QuestionnaireMessagesProps) {
  return (
    <>
      {messagesError.length > 0 &&
        messagesError.map((it, index) => (
          <YogaMessage
            type="error"
            position={position}
            className="text-left font-normal"
            key={prefixMessages + "_error_" + index}
            prefix={prefixMessages}
          >
            <p data-qa={prefixMessages + "_error"}>
              <FormattedMessage id={it || EMPTY} />
            </p>
          </YogaMessage>
        ))}
      {messagesWarning.length > 0 &&
        messagesWarning.map((it, index) => (
          <YogaMessage
            type="warning"
            position={position}
            className="text-left font-normal"
            key={prefixMessages + "_warning_" + index}
            prefix={prefixMessages}
          >
            <p data-qa={prefixMessages + "_warning"}>
              <FormattedMessage id={it || EMPTY} />
            </p>
          </YogaMessage>
        ))}
      {messagesInfo.length > 0 &&
        messagesInfo.map((it, index) => (
          <YogaMessage
            type="info"
            position={position}
            className="text-left font-normal"
            key={prefixMessages + "_info_" + index}
            prefix={prefixMessages}
          >
            <p data-qa={prefixMessages + "_info"}>
              <FormattedMessage id={it || EMPTY} />
            </p>
          </YogaMessage>
        ))}
    </>
  );
}
