import {
  questionairesByTag,
  questionsToInputParams,
  toYupFieldsByName,
  valuesOf,
} from "commons/FormUtils";
import { orderedMapToArray } from "commons/Utils";
import YogaCard from "commons/components/YogaCard";
import { YogaScrollToFieldError } from "commons/components/YogaScrollToFieldError";
import { FormikInput } from "commons/formik/FormikInput";
import { FormInputParam } from "commons/models/YogaParam";
import { Field, Form, Formik } from "formik";
import { QuestionnaireModel } from "questionnaires/models/QuestionnaireModel";
import React, { useEffect, useState } from "react";
import { FormattedMessage, useIntl } from "react-intl";
import * as yup from "yup";
import QuestionnaireMessages from "./QuestionnaireMessages";
import { Accordion } from "commons/components/Accordion";

export interface QuestionnaireFormProps {
  questionnaire: QuestionnaireModel;
  onSubmit?;
  onPartialUpdate?;
  title?: JSX.Element;
  formRef?: any;
}

export default function QuestionnaireForm({
  questionnaire,
  onSubmit,
  onPartialUpdate,
  title,
  formRef,
}: QuestionnaireFormProps) {
  const [initialValues, setInitialValues] = useState({});
  const [validationSchema, setValidationSchema] = useState({});
  const [formParams, setFormParams] = useState<{
    [tag: string]: FormInputParam[];
  }>({});
  const intl = useIntl();

  useEffect(() => {
    if (questionnaire) {
      const newFormParams = questionsToInputParams(
        orderedMapToArray(questionnaire.questions).filter(
          (question) => question.visible
        )
      );
      setFormParams(questionairesByTag(newFormParams));

      const newInitialValues = valuesOf(
        questionsToInputParams(orderedMapToArray(questionnaire.questions))
      );
      setInitialValues(newInitialValues);

      setValidationSchema(
        yup
          .object()
          .shape(
            toYupFieldsByName(
              questionsToInputParams(
                orderedMapToArray(questionnaire.questions)
              ),
              intl
            )
          )
      );
    }
  }, [questionnaire]);

  const getInput = (param: FormInputParam) => (
    <React.Fragment>
      <QuestionnaireMessages
        messagesError={
          questionnaire.messagesBefore &&
          questionnaire.messagesBefore["errors"] != null &&
          questionnaire.messagesBefore["errors"][param.code]
            ? questionnaire.messagesBefore["errors"][param.code]
            : []
        }
        messagesWarning={
          questionnaire.messagesBefore &&
          questionnaire.messagesBefore["warnings"] != null &&
          questionnaire.messagesBefore["warnings"][param.code]
            ? questionnaire.messagesBefore["warnings"][param.code]
            : []
        }
        messagesInfo={
          questionnaire.messagesBefore &&
          questionnaire.messagesBefore["info"] != null &&
          questionnaire.messagesBefore["info"][param.code]
            ? questionnaire.messagesBefore["info"][param.code]
            : []
        }
        prefixMessages={questionnaire.questionnaireId + "_" + param.code}
        key={questionnaire.questionnaireId + "_" + param.code + "_messages"}
        position="inner"
      />

      <Field
        key={param.name}
        name={param.name}
        component={FormikInput}
        content={param}
        onPartialUpdate={onPartialUpdate}
        fieldName={param.name}
        disabled={param.disabled}
        dataQa={"section-" + (param.tag || "noTag")}
        questionnaireForm
      />
    </React.Fragment>
  );

  return (
    <>
      {formParams &&
        validationSchema &&
        Object.keys(validationSchema).length > 0 && (
          <>
            {questionnaire.messages &&
              Object.keys(questionnaire.messages).length > 0 && (
                <div className="flex flex-col gap-4 mb-4">
                  <QuestionnaireMessages
                    messagesError={
                      questionnaire.messages &&
                      questionnaire.messages["errors"] != null
                        ? questionnaire.messages["errors"]
                        : []
                    }
                    messagesWarning={
                      questionnaire.messages &&
                      questionnaire.messages["warnings"] != null
                        ? questionnaire.messages["warnings"]
                        : []
                    }
                    messagesInfo={
                      questionnaire.messages &&
                      questionnaire.messages["info"] != null
                        ? questionnaire.messages["info"]
                        : []
                    }
                    prefixMessages={questionnaire.questionnaireId}
                    key={questionnaire.questionnaireId + "_messages"}
                    position="outer"
                  />
                </div>
              )}

            <YogaCard uniformPadding>
              <Formik
                validationSchema={validationSchema}
                onSubmit={onSubmit}
                innerRef={formRef}
                initialValues={initialValues}
                enableReinitialize
                validateOnMount
                validateOnChange
                validateOnBlur
              >
                <Form id="questionnaire-form">
                  <fieldset disabled={false}>
                    {title}
                    <div className="flex flex-col gap-y-4">
                      {Object.entries(formParams).map(
                        ([tag, params]: [string, FormInputParam[]], index) =>
                          tag === "noTags" ? (
                            <div key={`${tag}-section`}>
                              <div
                                className="flex flex-col gap-x-8 gap-y-4"
                                data-qa={`${tag}-values-form`}
                              >
                                {params.map((param) => getInput(param))}
                              </div>
                            </div>
                          ) : (
                            <Accordion
                              name={`${tag}-section`}
                              open={true}
                              withStatus
                              withDivider={index > 0}
                              className="flex flex-col gap-2"
                              titleContainerClasses=""
                              accordionTitle={
                                <div className="inline-flex items-center w-full">
                                  <h4 className="text-title-text font-light whitespace-nowrap">
                                    <FormattedMessage id={tag} />
                                  </h4>
                                  {/* <span className="middle-border-accordion"></span> */}
                                </div>
                              }
                              key={`${tag}-section`}
                            >
                              <div
                                className="border-b-2 last:border-b-0 border-background"
                                key={`${tag}-section`}
                              >
                                <div
                                  className="flex flex-col gap-x-8 gap-y-4"
                                  data-qa={`${tag}-values-form`}
                                >
                                  {params.map((param) => getInput(param))}
                                </div>
                              </div>
                            </Accordion>
                          )
                      )}
                    </div>
                  </fieldset>

                  <YogaScrollToFieldError />
                </Form>
              </Formik>
            </YogaCard>
          </>
        )}
    </>
  );
}
