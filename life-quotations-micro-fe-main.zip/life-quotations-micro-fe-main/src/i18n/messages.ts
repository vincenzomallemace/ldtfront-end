import { EMPTY } from "commons/Utils";
import { englishMessages } from "i18n/en";
import { italianMessages } from "i18n/it";

const feMessages: Record<string, Record<string, string>> = {
  en: englishMessages,
  it: italianMessages,
};
// add empty messages as defaults
Object.values(feMessages).forEach((r) => (r[EMPTY] = ""));

export { feMessages };
