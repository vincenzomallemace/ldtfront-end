import { useEffect, useState } from "react";
import { Consent, ConsentType } from "customers/models/Consent";
import { partyService } from "commons/services/PartyService";

export default function useConsentsListNew(consentType?: ConsentType) {
  const [defaultConsents, setDefaultConsents] = useState<Consent[]>(undefined);

  useEffect(() => {
    const fetchData = async () => {
      const result = await partyService.getConsents(consentType);
      const consents = result.data;
      // Fix null values of extraData
      consents.forEach((consent) => {
        if (consent.extraData) {
          Object.keys(consent.extraData).forEach((key) => {
            if (consent.extraData[key]?.value == null) {
              consent.extraData[key].value = "";
            }
          });
        }
      });
      setDefaultConsents(consents);
    };
    fetchData().catch((e) => {
      setDefaultConsents([]);
      console.error(e);
    });
  }, []);

  return {
    defaultConsents,
  };
}
