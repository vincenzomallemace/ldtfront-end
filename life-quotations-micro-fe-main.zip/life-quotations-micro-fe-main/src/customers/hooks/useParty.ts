import { useContext, useEffect, useState } from "react";
import { partyService } from "commons/services/PartyService";
import { Party } from "customers/models/Party";
import { Context } from "commons/contexts/Context";

export default function useParty(partyId: string, excludeNode?: boolean) {
  const [party, setParty] = useState<Party>(undefined);
  const [partyError, setPartyError] = useState<Error | undefined>();
  const { changeLoading } = useContext(Context);

  useEffect(() => {
    const fetchData = async () => {
      changeLoading(1);
      if (partyId) {
        const result = await partyService.get(partyId, excludeNode);
        const party = result.data;
        setParty(party);
      }
    };

    fetchData()
      .catch((e) => {
        setPartyError(e);
      })
      .finally(() => {
        changeLoading(-1);
      });
  }, []);

  return {
    party,
    partyError,
  };
}
