import { useContext, useEffect, useState } from "react";
import { YogaParam } from "commons/models/YogaParam";
import { partyService } from "commons/services/PartyService";
import { KeyValue } from "commons/models/YogaModels";
import { RoleType } from "contracts/enums/RoleType";
import { Context } from "commons/contexts/Context";

const usePartyParameters = (role: RoleType, productCode?: string, productId?: string, productType?: string) => {
  const [paramsById, setParamsById] = useState<KeyValue<YogaParam[]>>({});
  const [defaultParams, setDefaultParams] = useState<YogaParam[] | undefined>(undefined);
  const { changeLoading } = useContext(Context);

  useEffect(() => {
    const fetchData = async () => {
      // If there are no params, it is fine and I will have an empty list
      try {
        const res = await partyService.getParametersByRole(role, productCode, productId, productType);
        setDefaultParams(JSON.parse(JSON.stringify(res.data as YogaParam[])));
      } catch (e) {
        // @ts-ignore
        const res = e?.response;
        setDefaultParams([]);
        if (res.status < 200 && res.status > 300 && res.status != 404) {
          console.error(res);
          throw new Error("An error occurred while fetching the data.");
        }
      }
    };

    if (role) {
      changeLoading(1);
      fetchData().finally(() => changeLoading(-1));
    }
  }, [role, productCode]);

  const updateParams = async (partyId: string, newVals: KeyValue<YogaParam>): Promise<YogaParam[]> => {
    if (partyId == undefined || partyId.length == 0) {
      return [];
    }
    let updatedParams: YogaParam[] = [];
    changeLoading(1);
    try {
      const res = await partyService.updateParametersWithParty(
        role,
        partyId,
        newVals ? Object.values(newVals) : [],
        productId,
        productType,
        productCode
      );
      updatedParams = res.data;
      setParamsById({ ...paramsById, [partyId]: updatedParams });
    } catch (e) {
      console.error(e);
    }
    changeLoading(-1);
    return updatedParams;
  };

  return { updateParams, defaultParams };
};

export default usePartyParameters;
