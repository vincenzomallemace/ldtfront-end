import { Context } from "commons/contexts/Context";
import { KeyValue } from "commons/models/YogaModels";
import { partyService } from "commons/services/PartyService";
import {
  Consent,
  ConsentExtraData,
  ConsentType,
} from "customers/models/Consent";
import { useContext, useEffect, useState } from "react";

export default function useConsentsList(
  partyConsents?: Consent[],
  consentType?: ConsentType,
  waitPartyConsents: boolean = false
) {
  const [currentPartyConsents, setCurrentPartyConsents] =
    useState<Consent[]>(partyConsents);
  const [error, setError] = useState<Error | undefined>(undefined);
  const [consents, setConsents] = useState<KeyValue<Consent>>();
  const { changeLoading } = useContext(Context);

  useEffect(() => {
    if (waitPartyConsents && currentPartyConsents == null) return;

    const fetchData = async () => {
      changeLoading(1);
      const result = await partyService.getConsents(consentType);
      let mergedConsents = mergePartyConsents(
        result.data,
        currentPartyConsents ?? []
      );
      setConsents(mergedConsents);
    };
    fetchData()
      .catch((e) => {
        setError(e);
        changeLoading(-1);
      })
      .then(() => {
        changeLoading(-1);
      });
  }, [currentPartyConsents]);

  const mergePartyConsents = (
    consents: Consent[],
    partyConsents: Consent[]
  ): KeyValue<Consent> => {
    //Put customer consents in an object
    const customerConsents = partyConsents
      ? partyConsents?.reduce((a, v) => ({ ...a, [v.name]: v }), {})
      : {};

    //Take customer consents if present, otherwise take default from configuration
    return consents?.reduce(
      (a, v) => ({
        ...a,
        [v.name]: {
          ...v,
          value: getConsentValue(v, customerConsents[v.name]),
          extraData: getConsentExtraData(v, customerConsents[v.name]),
        },
      }),
      {}
    );
  };

  const getConsentValue = (
    consentModel: Consent,
    partyConsent?: Consent
  ): boolean => {
    let result = consentModel.default;
    if (partyConsent) {
      result = partyConsent.value;
    }
    return result;
  };

  const getConsentExtraData = (
    consentModel: Consent,
    partyConsent?: Consent
  ): ConsentExtraData => {
    let result = consentModel.extraData;
    if (partyConsent) {
      result = partyConsent.extraData;
    }
    return result;
  };

  return {
    consents,
    setConsents,
    error,
    setCurrentPartyConsents,
  };
}
