import classnames from "classnames";
import { Field, FieldProps } from "formik";
import { FormattedMessage } from "react-intl";
import { Consent, needExtraData } from "customers/models/Consent";
import { FormikInput } from "commons/formik/FormikInput";

interface FormikConsentFormProps extends FieldProps<Consent> {
  consent: Consent;
  disabled?: boolean;
}

export default function FormikConsentForm({
                                            consent,
                                            disabled = false,
                                            field: { name, value },
                                            form,
                                          }: FormikConsentFormProps) {
  const meta = form.getFieldMeta(name);

  const hasError = form.submitCount > 0 && meta?.error;

  return (
    value && (
      <div
        data-qa="consent"
        className="w-full p-2 border-t-2 first:border-t-0 border-background border-collapse"
      >
        <div
          data-qa="consent"
          className="inline-flex items-center w-full justify-between"
        >
          <label
            htmlFor={`toggle-consent-${consent.consentId}`}
            className={classnames("flex items-center w-full")}
            data-qa="consent-label"
          >
            <div className="mr-4 w-full" data-qa="consent-text">
              <FormattedMessage id={consent.text}></FormattedMessage>
            </div>
            <div className="relative inline-block w-40">
              {consent.mandatory ? (
                <div
                  id={`${name}.value`}
                  data-qa={`${name}-select-buttons`}
                  className="flex w-full"
                >
                  <div key="yes" data-tip data-for="yes" className="ml-auto">
                    <button
                      title="yes"
                      data-qa="yes"
                      type="button"
                      onClick={() => {
                        !disabled && form.setFieldValue(`${name}.value`, true);
                      }}
                      className={classnames(
                        "border-2 rounded-lg ml-auto grow-0 w-14 px-4 py-2",
                        disabled ? "cursor-not-allowed" : "cursor-pointer",
                        !disabled && {
                          "bg-primary border-primary text-button-text":
                            value.value === true,
                          "border-body-text text-body-text":
                            !hasError && value.value !== true,
                          "border-error bg-box-background text-primary":
                            hasError && value.value !== true,
                        },
                        disabled && {
                          "bg-action-disabled border-action-disabled text-white":
                            value.value === true,
                          "bg-background-disabled border-action-disabled text-action-disabled":
                            !hasError && value.value !== true,
                          "border-error bg-background-disabled text-action-disabled":
                            hasError && value.value !== true,
                        }
                      )}
                    >
                      <FormattedMessage id="yes" />
                    </button>
                  </div>
                </div>
              ) : (
                <div
                  id={`${name}.value`}
                  data-qa={`${name}-select-buttons`}
                  className="flex justify-end"
                >
                  <div key="no" data-tip data-for="no">
                    <button
                      title="no"
                      data-qa="no"
                      type="button"
                      onClick={() => {
                        !disabled && form.setFieldValue(`${name}.value`, false);
                      }}
                      className={classnames(
                        "border-2 rounded-lg rounded-r-none grow-0 w-14 px-4 py-2",
                        disabled ? "cursor-not-allowed" : "cursor-pointer",
                        !disabled && {
                          "bg-primary border-primary text-button-text":
                            value.value === false,
                          "border-body-text text-body-text":
                            !hasError && value.value === null,
                          "border-error bg-box-background text-primary":
                            hasError && value.value === null,
                          "border-r-primary border-body-text text-body-text":
                            value.value === true,
                        },
                        disabled && {
                          "bg-action-disabled border-action-disabled text-white":
                            value.value === false,
                          "border-action-disabled bg-background-disabled text-action-disabled":
                            !hasError && value.value === null,
                          "border-error bg-background-disabled text-action-disabled":
                            hasError && value.value === null,
                          "border-action-disabled text-action-disabled":
                            value.value === true,
                        }
                      )}
                    >
                      <FormattedMessage id="no" />
                    </button>
                  </div>
                  <div key="yes" data-tip data-for="yes">
                    <button
                      title="yes"
                      data-qa="yes"
                      type="button"
                      onClick={() => {
                        !disabled && form.setFieldValue(`${name}.value`, true);
                      }}
                      className={classnames(
                        "border-2 border-l-0 rounded-lg rounded-l-none grow-0 w-14 px-4 py-2",
                        disabled ? "cursor-not-allowed" : "cursor-pointer",
                        !disabled && {
                          "bg-primary border-primary text-button-text":
                            value.value === true,
                          "border-body-text text-body-text":
                            !hasError && value.value === null,
                          "border-error bg-box-background text-primary":
                            hasError && value.value === null,
                          "border-r-primary border-body-text text-body-text":
                            value.value === false,
                        },
                        disabled && {
                          "bg-action-disabled border-action-disabled text-white":
                            value.value === true,
                          "border-action-disabled bg-background-disabled text-action-disabled":
                            !hasError && value.value === null,
                          "border-error bg-background-disabled text-action-disabled":
                            hasError && value.value === null,
                          "border-action-disabled text-action-disabled":
                            value.value === false,
                        }
                      )}
                    >
                      <FormattedMessage id="yes" />
                    </button>
                  </div>
                </div>
              )}
              {hasError &&
                (value.value === null ||
                  (consent.mandatory && value.value != true)) && (
                  <div
                    className={classnames(
                      "text-base text-error w-full whitespace-nowrap text-right"
                    )}
                  >
                    <FormattedMessage id="required" />
                  </div>
                )}
            </div>
          </label>
        </div>
        {value.value && needExtraData(consent) && (
          <div className="grid grid-cols-3 gap-8">
            {consent?.extraData?.email?.type != "HIDDEN" && (
              <Field
                name={`${name}.extraData.email.value`}
                component={FormikInput}
                content={{
                  name: `${name}.extraData.email.value`,
                  label: "extraData.email_label",
                  type: "STRING",
                  mandatory:
                    consent?.extraData.email?.type == "VISIBLE_AND_REQUIRED",
                }}
              />
            )}
            {consent?.extraData?.phone?.type != "HIDDEN" && (
              <Field
                name={`${name}.extraData.phone.value`}
                component={FormikInput}
                content={{
                  name: `${name}.extraData.phone.value`,
                  label: "extraData.phone_label",
                  type: "PHONE",
                  mandatory:
                    consent?.extraData.phone?.type == "VISIBLE_AND_REQUIRED",
                }}
              />
            )}
          </div>
        )}
      </div>
    )
  );
}
