import { FormInputParam } from "commons/models/YogaParam";
import { config } from "commons/Configuration";
import { AVAILABLE_COMPANY_TYPES } from "customers/models/AvailableCompanyTypes";

const newLegalPolicyholderFormInternal: FormInputParam[] = [
  {
    availableValues: ["physical", "legal"],
    name: "legalEntity",
    value: "legal",
    mandatory: true,
    label: "policyholderType",
    type: "LIST",
    updatePartially: true,
  },
  {
    name: "vatNumber",
    value: "",
    mandatory: true,
    label: "vatNumber",
    type: "STRING",
    updatePartially: true,
  },
  {
    availableValues: AVAILABLE_COMPANY_TYPES,
    name: "companyType",
    value: "",
    mandatory: true,
    label: "companyType",
    type: "LIST",
  },
  {
    name: "taxId",
    value: "",
    mandatory: true,
    label: "taxCode",
    type: "STRING",
    updatePartially: true,
  },
  {
    name: "surnameOrCompanyName",
    value: "",
    mandatory: true,
    label: "companyName",
    type: "STRING",
  },
  {
    name: "email",
    value: "",
    mandatory: true,
    label: "email",
    type: "STRING",
  },
  {
    name: "mobilePhoneNumber",
    value: null,
    mandatory: true,
    label: "mobilePhoneNumber",
    type: "PHONE",
  },
  {
    name: "atecoCode",
    value: "",
    mandatory: true,
    label: "atecoCode",
    type: "STRING",
  },
  {
    name: "employeesNumber",
    value: "",
    mandatory: true,
    label: "employeesNumber",
    type: "NUMBER",
  },
  {
    name: "revenue",
    value: "",
    mandatory: true,
    label: "revenue",
    type: "AMOUNT",
  },
];

export const newLegalPolicyholderForm: FormInputParam[] =
  config.DISPLAY_PARTY_IBAN !== "disabled"
    ? newLegalPolicyholderFormInternal.concat([
        {
          name: "iban",
          value: "",
          mandatory: false,
          label: "iban",
          type: "STRING",
        },
      ])
    : newLegalPolicyholderFormInternal;

export const newPhysicalPolicyholderFormInternal: FormInputParam[] = [
  {
    availableValues: ["physical", "legal"],
    name: "legalEntity",
    value: "physical",
    mandatory: true,
    label: "policyholderType",
    type: "LIST",
    updatePartially: true,
  },
  {
    name: "taxId",
    value: "",
    mandatory: true,
    label: "taxCode",
    type: "STRING",
    updatePartially: true,
  },
  {
    name: "surnameOrCompanyName",
    value: "",
    mandatory: true,
    label: "surnameOrCompanyName",
    type: "STRING",
  },
  {
    name: "name",
    value: "",
    mandatory: true,
    label: "name",
    type: "STRING",
  },
  {
    name: "birthDate",
    value: "",
    mandatory: true,
    label: "birthDate",
    type: "DATE",
  },
  {
    name: "birthCountry",
    value: "",
    mandatory: true,
    label: "birthCountry",
    type: "COUNTRY",
  },
  {
    name: "birthPlace",
    value: "",
    mandatory: true,
    label: "birthPlace",
    type: "CITY",
  },
  {
    availableValues: ["male", "female"],
    name: "gender",
    value: "",
    mandatory: true,
    label: "gender",
    type: "LIST",
  },
  {
    name: "email",
    value: "",
    mandatory: true,
    label: "email",
    type: "STRING",
  },
  {
    name: "mobilePhoneNumber",
    value: null,
    mandatory: true,
    label: "mobilePhoneNumber",
    type: "PHONE",
  },
];

export const newPhysicalPolicyholderForm: FormInputParam[] =
  config.DISPLAY_PARTY_IBAN !== "disabled"
    ? newPhysicalPolicyholderFormInternal.concat([
        {
          name: "iban",
          value: "",
          mandatory: false,
          label: "iban",
          type: "STRING",
        },
      ])
    : newPhysicalPolicyholderFormInternal;
