import { FormikInput } from "commons/formik/FormikInput";
import { YogaParam } from "commons/models/YogaParam";
import { Field, FieldProps } from "formik";
import { useMemo } from "react";
import { FormattedMessage } from "react-intl";
import { fromYogaParamToFormParam, paramsToMap } from "commons/FormUtils";
import { Accordion } from "commons/components/Accordion";
import { PARTY_PARAM } from "commons/formik/FormikDynamicSelect";

interface PartyParametersFormProps extends FieldProps<YogaParam[]>, React.HTMLAttributes<HTMLDivElement> {
  partyParameters: YogaParam[];
  updateParameters: (values: any) => any;
  disabled?: boolean;
}

export function PartyParametersForm({
  partyParameters,
  updateParameters,
  field: { name },
  form,
  disabled = false,
  className,
}: PartyParametersFormProps) {
  const parametersByTag = useMemo(() => {
    const params = partyParameters
      .filter((p) => p.visible)
      .sort((a, b) => (a.tags[0] > b.tags[0] ? 1 : -1))
      .sort((a, b) => a.order - b.order);

    return params.reduce((previous: { [tag: string]: YogaParam[] }, current: YogaParam) => {
      let tag = "noTags";
      if (current.tags && current.tags.length) {
        tag = current.tags[0];
      }
      if (!previous[tag]) {
        previous[tag] = [];
      }
      previous[tag] = previous[tag].concat(current);
      return previous;
    }, {});
  }, [partyParameters]);

  const parameters = useMemo(() => {
    return paramsToMap(partyParameters);
  }, [partyParameters]);

  const getInput = (param: YogaParam) => {
    return (
      <Field
        key={`${name}.${param.code}`}
        name={`${name}.${param.code}.value`}
        data-qa={`${name}.${param.code}`}
        component={FormikInput}
        content={{
          ...fromYogaParamToFormParam(param),
          name: `${name}.${param.code}.value`,
        }}
        fieldName={`${param.code}`}
        disabled={param.disabled || disabled}
        onUpdate={(values) => {
          updateParameters(values);
        }}
        onPartialUpdate={(args: any) => {
          form.setFieldValue(
            `${name}.${param.code}`,
            {
              ...param,
              value: args[param.code],
            },
            false
          );
          form.setFieldTouched(`${name}.${param.code}.value`, true, false);
        }}
        values={form.values}
        slider={param.slider}
        parameters={parameters}
        paramType={PARTY_PARAM}
        {...(param.type == "LIST" && { isParameterForm: true })}
      />
    );
  };

  return (
    parametersByTag &&
    Object.keys(parametersByTag).length > 0 && (
      <div className={className} data-qa="party-parameters-form">
        {Object.entries(parametersByTag).map(([tag, params]) =>
          tag === "noTags" ? (
            <div key={`${tag}-section`}>
              <div className="grid grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-4" data-qa={`${tag}-values-form`}>
                {params.map((param) => getInput(param))}
              </div>
            </div>
          ) : (
            <Accordion
              name={`${tag}-section`}
              open={false}
              withStatus
              className="flex flex-col gap-2"
              titleContainerClasses=""
              accordionTitle={
                <div className="inline-flex items-center w-full">
                  <h4 className="text-title-text font-light whitespace-nowrap">
                    <FormattedMessage id={tag} />
                  </h4>
                  {/* <span className="middle-border-accordion"></span> */}
                </div>
              }
              key={`${tag}-section`}
            >
              <div className="border-b-2 last:border-b-0 border-background" key={`${tag}-section`}>
                <div className="grid grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-4" data-qa={`${tag}-values-form`}>
                  {params.map((param) => getInput(param))}
                </div>
              </div>
            </Accordion>
          )
        )}
      </div>
    )
  );
}
