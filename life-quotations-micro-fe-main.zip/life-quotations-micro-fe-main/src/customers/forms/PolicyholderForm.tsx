import { YogaMessage } from "commons/components/YogaMessage";
import { CustomerContext } from "commons/contexts/CustomerContext";
import { KeyValue } from "commons/models/YogaModels";
import {
  FormInputParam,
  YogaParam,
  YogaParamValueType,
} from "commons/models/YogaParam";
import { partyService } from "commons/services/PartyService";
import { Consent, mergePartyConsents } from "customers/models/Consent";
import { Party } from "customers/models/Party";
import { Field, FieldProps } from "formik";
import { useContext, useEffect, useState } from "react";
import { FormattedMessage } from "react-intl";
import { Accordion } from "commons/components/Accordion";
import { ManagementNode } from "commons/models/nodes/ManagementNode";
import YogaLoader from "commons/components/Loader";
import PartyFromAnotherNodeModal from "customers/components/PartyFromAnotherNodeModal";
import { FormikInput } from "commons/formik/FormikInput";
import { PolicyholderLocationForm } from "./PolicyholderLocationForm";
import { PolicyholderDomicileForm } from "./PolicyholderDomicileForm";
import { getDate } from "commons/formik/Utils";

interface PolicyholderFormProps extends FieldProps<any> {
  parameters?: YogaParam[];
  defaultConsents?: Consent[];
  managementNodes: ManagementNode[];
}

export function PolicyholderForm({
  parameters = [],
  defaultConsents = null,
  managementNodes,
  field: { value },
  form,
  ...props
}: PolicyholderFormProps) {
  const mustResetSessionStorage = (props as any)
    .mustResetSessionStorage as boolean;
  const resetTaxIdInconsistent = (props as any)
    .resetTaxIdInconsistent as () => any;
  const setIsAnUpdate = (props as any).setIsAnUpdate as (value: boolean) => any;
  const isAnUpdate = (props as any).isAnUpdate as Boolean;

  const updateConsents = (props as any).updateConsents as (
    value: Consent[]
  ) => any;

  const physicalParams = (props as any).physicalParams as FormInputParam[];
  const legalParams = (props as any).legalParams as FormInputParam[];
  const policyholderTemplate = (props as any)
    .policyholderTemplate as FormInputParam[];

  const [isRetrievingInsured, setIsRetrievingInsured] = useState(false);
  const [partyToRetrieve, setPartyToRetrieve] = useState(null);
  const [notVisibleNodeModal, setNotVisibleNodeModal] = useState(false);
  const [canRetrieve, setCanRetrieve] = useState(true);
  const [domicileOpen, setDomicileOpen] = useState(false);

  const {
    setSelectedCustomers,
    policyholderAnonymous,
    setPolicyholderAnonymous,
  } = useContext(CustomerContext);

  useEffect(() => {
    // If there are initial values, it retrieves the party
    if (
      value?.taxId &&
      value?.taxId?.length === 16 &&
      value.legalEntity === "physical"
    ) {
      if (canRetrieve) {
        retrieveInsured(value?.taxId, false);
      } else {
        setCanRetrieve(true);
      }
    } else if (
      value?.vatNumber &&
      value?.vatNumber?.length === 11 &&
      value.legalEntity === "legal"
    ) {
      retrieveInsured(value?.vatNumber, true);
    }
  }, []);

  function onPartialUpdate(
    values: KeyValue<YogaParamValueType>,
    updateOnChange: boolean
  ) {
    if (updateOnChange) {
      let field = Object.keys(values).length ? Object.keys(values)[0] : "";
      if (
        (field == "taxId" || field == "legalEntity") &&
        value?.taxId &&
        value?.taxId?.length === 16 &&
        value.legalEntity === "physical"
      ) {
        if (canRetrieve) {
          retrieveInsured(value?.taxId, false);
        } else {
          setCanRetrieve(true);
        }
      } else if (
        (field == "vatNumber" || field == "legalEntity") &&
        value?.vatNumber &&
        value?.vatNumber?.length === 11 &&
        value.legalEntity === "legal"
      ) {
        retrieveInsured(value?.vatNumber, true);
      } else if (field == "legalEntity") {
        value.taxId = "";
        value.vatNumber = "";
        resetTaxIdInconsistent();
        setIsAnUpdate(false);
        if (updateConsents) {
          updateConsents([]);
        }
        setFormValues();
      }

      if (field == "taxId" && !value?.taxId) {
        resetFormValues();
      }
      if (field == "vatNumber" && !value?.vatNumber) {
        resetFormValues();
      }
    }
  }

  useEffect(() => {
    if (
      value?.vatNumber &&
      value?.vatNumber?.length === 11 &&
      value?.companyType !== "" &&
      value?.companyType !== "Ditta Individuale" &&
      value?.companyType !== "Impresa familiare" &&
      value?.taxId === "" &&
      form.dirty
    ) {
      value.taxId = value?.vatNumber;
    }
  }, [value?.vatNumber, value?.companyType]);

  useEffect(() => {
    const policyholder = Object.assign({}, policyholderAnonymous);
    if (value.legalEntity === "legal") {
      policyholder.legalEntity = "legal";
    } else if (value.legalEntity === "physical") {
      policyholder.legalEntity = "physical";
    }
    setPolicyholderAnonymous(policyholder);
  }, [value?.legalEntity]);

  function setFormValues(party?: Party) {
    if (party) {
      value.legalEntity = party.legalEntity ? "legal" : "physical";
      updateFormValues(party);
    } else {
      resetFormValues();
    }
  }

  async function updateFormValues(party?: Party) {
    if (party) {
      if (
        value.taxId.toUpperCase() === party.taxId.toUpperCase() &&
        value.taxId !== party.taxId
      ) {
        setCanRetrieve(false);
      }
      value.taxId = party.taxId;
      value.name = party.name;
      value.surnameOrCompanyName = party.surnameOrCompanyName;
      value.gender = party.gender ?? "";
      value.birthDate = party.birthDate ?? "";
      value.birthPlace = party.birthPlace
        ? party.birthCountyCode
          ? `${party.birthPlace} (${party.birthCountyCode})`
          : party.birthPlace
        : "";
      value.birthPlaceComplete = {
        geoId: "",
        name: party.birthPlace ?? "",
        countyCode: party.birthCountyCode ?? "",
      };
      value.birthCountryCode = party.birthCountryCode ?? "";
      value.birthCountry = party.birthCountry ?? "";
      value.email = party.email ?? "";
      value.mobilePhoneNumber = party.mobilePhoneNumber
        ? party.mobilePhoneNumberPrefix
          ? party.mobilePhoneNumberPrefix.replace("00", "+") +
            party.mobilePhoneNumber
          : "+39" + party.mobilePhoneNumber
        : null;
      value.location = party.location;
      value.domicileIsNotResidence = party.domicileIsNotResidence ?? false;
      if (party.domicileIsNotResidence === true) {
        setDomicileOpen(party.domicileIsNotResidence);
      }
      value.domicile =
        party.domicile?.label != party.location?.label ? party.domicile : "";
      if (
        policyholderTemplate &&
        !policyholderTemplate["companyType.disabled"]
      ) {
        if (
          !policyholderTemplate["companyType.availableValues"] ||
          (
            policyholderTemplate["companyType.availableValues"] as string[]
          ).indexOf(party.companyType) > -1
        )
          value.companyType = party.companyType ?? "";
      } else {
        value.companyType = party.companyType ?? "";
      }
      value.customerReference = party.customerReference;
      value.managementNodes = party.managementNodes;
      value.partyId = party.partyId;
      value.questionnaireCode = party.questionnaireCode;
      value.questionnaire = party.questionnaire;
      value.tags = party.tags;
      value.vatNumber = party.vatNumber ?? "";
      value.legacyData = party.legacyData;
      if (policyholderTemplate && policyholderTemplate["atecoCode.value"]) {
        value.atecoCode =
          party.atecoCode || policyholderTemplate["atecoCode.value"];
      } else {
        value.atecoCode = party.atecoCode ?? "";
      }
      value.rae = party.rae ?? "";
      value.sae = party.sae ?? "";
      if (
        policyholderTemplate &&
        policyholderTemplate["employeesNumber.value"]
      ) {
        value.employeesNumber =
          party.employeesNumber ??
          policyholderTemplate["employeesNumber.value"];
      } else {
        value.employeesNumber = party.employeesNumber ?? "";
      }
      if (policyholderTemplate && policyholderTemplate["revenue.value"]) {
        value.revenue =
          party.revenue?.amount.toString() ||
          policyholderTemplate["revenue.value"];
      } else {
        value.revenue = party.revenue?.amount.toString() || "";
      }
      value.consents = mergePartyConsents(defaultConsents, party.consents);
      value.lastConsentsUpdateInstant = party.lastConsentsUpdateInstant;
      value.otpSignatureEnabled = party.otpSignatureEnabled;
      value.linkedParties = party.linkedParties;
      value.registrationDate = party.registrationDate;
      value.iban = party.iban ?? "";
      value.bankAccounts = party.bankAccounts ?? [];
      value.parameters = Object.assign(
        parameters.reduce((acc, current) => {
          acc[current.code] = current;
          return acc;
        }, {}),
        party.parameters
      );
      value.profile = party.profile;
      await form.validateForm();
    } else {
      resetFormValues();
    }
  }

  function resetFormValues() {
    value.taxId = value.legalEntity === "physical" ? value.taxId : "";
    value.name = "";
    value.surnameOrCompanyName = "";
    value.birthDate = "";
    value.birthPlace = "";
    value.birthCountyCode = null;
    value.birthCountryCode = "";
    value.birthCountry = "";
    value.gender = "";
    value.email = "";
    value.mobilePhoneNumber = null;
    value.location = null;
    value.domicile = null;
    value.domicileIsNotResidence = false;
    value.profile = null;
    if (policyholderTemplate && policyholderTemplate["companyType.value"]) {
      value.companyType = policyholderTemplate["companyType.value"];
    } else {
      value.companyType = "";
    }
    if (policyholderTemplate && policyholderTemplate["atecoCode.value"]) {
      value.atecoCode = policyholderTemplate["atecoCode.value"];
    } else {
      value.atecoCode = "";
    }
    if (policyholderTemplate && policyholderTemplate["employeesNumber.value"]) {
      value.employeesNumber = policyholderTemplate["employeesNumber.value"];
    } else {
      value.employeesNumber = "";
    }
    if (policyholderTemplate && policyholderTemplate["revenue.value"]) {
      value.revenue = policyholderTemplate["revenue.value"];
    } else {
      value.revenue = "";
    }
    value.rae = "";
    value.sae = "";
    value.iban = "";
    value.bankAccounts = [];
    value.parameters = parameters.reduce((acc, current) => {
      acc[current.code] = current;
      return acc;
    }, {});
    value.customerReference = null;
    value.managementNodes = null;
    value.partyId =
      value.legalEntity === "physical" ? value.taxId : value.vatNumber;
    value.questionnaireCode = null;
    value.questionnaire = null;
    value.tags = null;
    value.vatNumber = value.legalEntity === "physical" ? "" : value.vatNumber;
    value.legacyData = null;
    value.lastConsentsUpdateInstant = "";
    value.otpSignatureEnabled = false;
    value.linkedParties = null;
    value.registrationDate = null;
    value.consents = defaultConsents;
    setIsAnUpdate(false);
  }

  function confirmRetrievedPartyPhysical(party: any) {
    updateFormValues(party);
    resetTaxIdInconsistent();
    setIsAnUpdate(!!party.surnameOrCompanyName);
    if (updateConsents) {
      updateConsents(party.consents ?? []);
    }
    party.legalEntity = party.legalEntity ? "legal" : "physical";
    if (mustResetSessionStorage === false) {
      return;
    }
    setPolicyholderAnonymous(party);
    setSelectedCustomers([]);
  }

  async function confirmRetrievedPartyLegal(party: any) {
    let isAnUpdate: boolean = false;
    await partyService
      .get(party.vatNumber, true)
      .then(() => {
        isAnUpdate = true;
        if (updateConsents) {
          updateConsents(party.consents ?? []);
        }
      })
      .catch(() => {
        if (party?.legacyData["PASS"]) {
          isAnUpdate = true;
        }
      });
    updateFormValues(party);
    resetTaxIdInconsistent();
    setIsAnUpdate(isAnUpdate);
    party.legalEntity = party.legalEntity ? "legal" : "physical";

    if (mustResetSessionStorage === false) {
      return;
    }
    setPolicyholderAnonymous(party);
    setSelectedCustomers([]);
  }

  async function retrieveInsured(id: string, legalEntity: boolean) {
    if (isRetrievingInsured) {
      return;
    }
    setIsRetrievingInsured(true);
    resetTaxIdInconsistent();
    setIsAnUpdate(false);
    if (updateConsents) {
      updateConsents([]);
    }

    if (legalEntity) {
      await partyService
        .getPartyByVatNumber(id)
        .then(async (result) => {
          const party: any = result.data;
          const notVisible = result.headers["x-not-visible-on-node"];
          if (notVisible === "true") {
            setPartyToRetrieve(party);
            setNotVisibleNodeModal(true);
          } else {
            confirmRetrievedPartyLegal(party);
          }
        })
        .catch(() => {
          const policyholderAnonymousWithoutConsents = Object.assign(
            {},
            policyholderAnonymous
          );
          policyholderAnonymousWithoutConsents.consents = [];
          setPolicyholderAnonymous(policyholderAnonymousWithoutConsents);

          updateFormValues();
          resetTaxIdInconsistent();
          setIsAnUpdate(false);
          if (updateConsents) {
            updateConsents([]);
          }
        })
        .finally(() => {
          setIsRetrievingInsured(false);
        });
    } else {
      await partyService
        .getPartyByTaxId(id, false)
        .then((result) => {
          const party: any = result.data;
          const notVisible = result.headers["x-not-visible-on-node"];
          if (notVisible === "true") {
            setPartyToRetrieve(party);
            setNotVisibleNodeModal(true);
          } else {
            confirmRetrievedPartyPhysical(party);
          }
        })
        .catch(() => {
          const policyholderAnonymousWithoutConsents = Object.assign(
            {},
            policyholderAnonymous
          );
          policyholderAnonymousWithoutConsents.consents = [];
          setPolicyholderAnonymous(policyholderAnonymousWithoutConsents);
          updateFormValues();
          resetTaxIdInconsistent();
          setIsAnUpdate(false);
          if (updateConsents) {
            updateConsents([]);
          }
        })
        .finally(() => {
          setIsRetrievingInsured(false);
        });
    }
  }

  useEffect(() => {
    if (!value.domicileIsNotResidence) {
      value.domicile = null;
    }
  }, [value.domicileIsNotResidence]);

  return (
    <>
      <YogaLoader loading={isRetrievingInsured} />
      <div
        id="policyholder-insertData"
        data-qa="policyholder-insert-data-message"
      >
        <YogaMessage type="info" position="inner" className="mb-4">
          <p>
            <FormattedMessage id="insertDataMessage" />
          </p>
        </YogaMessage>
      </div>
      {isAnUpdate && (
        <div
          id="policyholder-updatePartyMessage"
          data-qa="policyholder-update-party-message"
        >
          <YogaMessage type="warning" position="inner" className="mb-4">
            <p>
              <FormattedMessage id="updatePartyMessage" />
            </p>
          </YogaMessage>
        </div>
      )}
      <div
        className="grid grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-4"
        data-qa="policyholder-form-container"
      >
        {value.legalEntity === "legal" ? (
          <>
            {legalParams &&
              legalParams.map((p) => (
                <Field
                  key={p.name}
                  name={p.name}
                  component={FormikInput}
                  content={p}
                  values={form.values}
                  currency={policyholderAnonymous?.revenue?.currency || "EUR"}
                  disabled={
                    (p.name !== "vatNumber" &&
                      p.name !== "legalEntity" &&
                      value?.vatNumber?.length !== 11) ||
                    isRetrievingInsured == true ||
                    p.disabled ||
                    (p.name === "email" && value?.profile)
                  }
                  maxLength={
                    p.name === "vatNumber" ||
                    (p.name === "taxId" &&
                      value.companyType !== "Ditta Individuale" &&
                      value.companyType !== "Impresa familiare")
                      ? 11
                      : p.name === "taxId"
                      ? 16
                      : undefined
                  }
                  onPartialUpdate={onPartialUpdate}
                  noValidate={p.name === "vatNumber"}
                  fieldName={p.name}
                  noDelayOnUpdate={true}
                />
              ))}

            <Field
              name="location"
              key="location"
              component={PolicyholderLocationForm}
              disabled={
                value?.vatNumber?.length !== 11 || isRetrievingInsured == true
              }
            />
          </>
        ) : (
          <>
            {physicalParams &&
              physicalParams.map((p) => {
                return (
                  <Field
                    key={p.name}
                    name={p.name}
                    component={FormikInput}
                    content={getDate(p, value?.birthDate)}
                    values={form.values}
                    maxLength={p.name === "taxId" ? 16 : undefined}
                    hidden={
                      (p.name === "birthCountry" &&
                        value?.taxId?.charAt(11).toUpperCase() !== "Z") ||
                      (p.name === "birthPlace" &&
                        value?.taxId?.charAt(11).toUpperCase() === "Z")
                    }
                    disabled={
                      (p.name !== "taxId" &&
                        p.name !== "legalEntity" &&
                        value?.taxId?.length !== 16) ||
                      isRetrievingInsured == true ||
                      p.disabled ||
                      (p.name === "email" && value?.profile)
                    }
                    onPartialUpdate={onPartialUpdate}
                    noValidate={p.name === "taxId"}
                    fieldName={p.name}
                    noDelayOnUpdate={true}
                  />
                );
              })}

            <Field
              name="location"
              key="location"
              component={PolicyholderLocationForm}
              disabled={
                value?.taxId?.length !== 16 || isRetrievingInsured == true
              }
            />
          </>
        )}
      </div>

      <div className="w-full">
        <Accordion
          name="domicile-data"
          open={domicileOpen}
          className="flex flex-col mt-4 gap-2 w-full"
          titleContainerClasses=""
          accordionTitle={
            <div className="inline-flex items-center w-full">
              <h4 className="text-title-text whitespace-nowrap">
                <FormattedMessage id="domicileData" />
              </h4>
              <span className="middle-border-accordion"></span>
            </div>
          }
          key="domicile-section"
        >
          <div className="grid grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-4">
            <div data-qa={`domicile-values-form`}>
              <Field
                key="domicileIsNotResidence"
                name="domicileIsNotResidence"
                component={FormikInput}
                label="domicileDataLabel"
                content={{
                  name: "domicileIsNotResidence",
                  label:
                    value.legalEntity === "legal"
                      ? "domicileDataLabelLegal"
                      : "domicileDataLabelPhysical",
                  type: "BOOLEAN",
                }}
              />
            </div>
            {value.domicileIsNotResidence && (
              <div className="w-full col-span-2">
                <Field
                  name="domicile"
                  key="domicile"
                  component={PolicyholderDomicileForm}
                  disabled={
                    value?.taxId?.length === 16
                      ? false
                      : value?.taxId?.length === 11
                      ? false
                      : isRetrievingInsured
                      ? false
                      : true
                  }
                  content={{
                    label:
                      value.legalEntity === "legal"
                        ? "domicileDataLabelLegal"
                        : "domicileDataLabelPhysical",
                  }}
                />
              </div>
            )}
          </div>
        </Accordion>
      </div>

      <PartyFromAnotherNodeModal
        isOpen={notVisibleNodeModal}
        onClose={() => {
          value.taxId = "";
          value.vatNumber = "";
          resetTaxIdInconsistent();
          setIsAnUpdate(false);
          if (updateConsents) {
            updateConsents([]);
          }
          setFormValues();
          setNotVisibleNodeModal(false);
        }}
        onConfirm={() => {
          if (partyToRetrieve.legalEntity) {
            confirmRetrievedPartyLegal(partyToRetrieve);
          } else {
            confirmRetrievedPartyPhysical(partyToRetrieve);
          }
          setNotVisibleNodeModal(false);
        }}
        partyToRetrieve={partyToRetrieve}
        newManagementNodes={managementNodes}
      />
    </>
  );
}
