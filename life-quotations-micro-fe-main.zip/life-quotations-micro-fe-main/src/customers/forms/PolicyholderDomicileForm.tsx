import { config } from "commons/Configuration";
import { LocationAutocomplete } from "commons/components/LocationAutocomplete";
import { LocationSplitted } from "commons/components/LocationSplitted";
//import { FormikInput } from "commons/formik/FormikInput";
import {
  Suggestion,
  mandatoryLocationParams,
  suggestionToLocation,
} from "commons/models/Suggestion";
//import { FormInputParam } from "commons/models/YogaParam";
//import { Field, FieldProps } from "formik";
import { FieldProps } from "formik";

export function PolicyholderDomicileForm({ form, ...props }: FieldProps) {
  const disabled = (props as any).disabled as boolean;
  /*  const param: FormInputParam = {
    name: "domicile",
    type: "STRING",
    label: "domicile",
    mandatory: false,
  };*/
  function setLocation(suggestion?: Suggestion) {
    if (suggestion) {
      let domicile = suggestionToLocation(suggestion);
      form.setFieldValue(`domicile`, domicile);
    } else {
      form.setFieldValue(`domicile`, null);
    }
  }

  return (
    <>
      {config.GEOLOCATION == "disabled" ? (
        /*<Field
          key="location"
          name="location.label"
          component={FormikInput}
          content={param}
          values={form.values}
          />*/
        <LocationSplitted
          name="domicile"
          label={
            form.values?.legalEntity === "legal" ? "fiscalDomicile" : "domicile"
          }
          startLocation={form.getFieldProps("domicile").value}
          form={form}
          error={
            form.getFieldMeta("domicile").touched
              ? form.getFieldMeta("domicile").error
              : undefined
          }
          disabled={disabled}
        />
      ) : (
        <LocationAutocomplete
          id="domicile"
          label={
            form.values?.legalEntity === "legal" ? "fiscalDomicile" : "domicile"
          }
          onSelectLocation={setLocation}
          startLocation={form.getFieldProps("domicile").value}
          error={
            form.getFieldMeta("domicile").touched
              ? form.getFieldMeta("domicile").error
              : undefined
          }
          disabled={disabled}
          mandatoryLocationParams={mandatoryLocationParams}
        />
      )}
    </>
  );
}
