import { config } from "commons/Configuration";
import { FormInputParam } from "commons/models/YogaParam";

export const newLegalRepresentativeFormInternal: FormInputParam[] = [
  {
    name: "taxId",
    label: "taxCode",
    type: "STRING",
  },
  {
    name: "surnameOrCompanyName",
    label: "surnameOrCompanyName",
    type: "STRING",
  },
  {
    name: "name",
    label: "name",
    type: "STRING",
  },
  {
    name: "birthDate",
    label: "birthDate",
    type: "DATE",
  },
  {
    name: "birthCountry",
    label: "birthCountry",
    type: "COUNTRY",
  },
  {
    name: "birthPlace",
    label: "birthPlace",
    type: "CITY",
  },
  {
    availableValues: ["male", "female"],
    name: "gender",
    label: "gender",
    type: "LIST",
  },
  {
    name: "email",
    label: "email",
    type: "STRING",
  },
  {
    name: "mobilePhoneNumber",
    label: "mobilePhoneNumberSignature",
    type: "PHONE",
    value: null,
  },
];

export const newLegalRepresentativeForm: FormInputParam[] =
  config.DISPLAY_PARTY_IBAN !== "disabled"
    ? newLegalRepresentativeFormInternal.concat([
        {
          name: "iban",
          value: "",
          mandatory: false,
          label: "iban",
          type: "STRING",
        },
      ])
    : newLegalRepresentativeFormInternal;

export const newReferentFormInternal: FormInputParam[] = [
  {
    name: "taxId",
    label: "taxCode",
    type: "STRING",
  },
  {
    name: "surnameOrCompanyName",
    label: "surnameOrCompanyName",
    type: "STRING",
  },
  {
    name: "name",
    label: "name",
    type: "STRING",
  },
  {
    name: "birthDate",
    label: "birthDate",
    type: "DATE",
  },
  {
    name: "birthCountry",
    label: "birthCountry",
    type: "STRING",
  },
  {
    name: "birthPlace",
    label: "birthPlace",
    type: "STRING",
  },
  {
    availableValues: ["male", "female"],
    name: "gender",
    label: "gender",
    type: "LIST",
  },
  {
    name: "email",
    label: "email",
    type: "STRING",
  },
  {
    name: "mobilePhoneNumber",
    label: "mobilePhoneNumber",
    type: "PHONE",
    value: null,
  },
];

export const newReferentForm: FormInputParam[] =
  config.DISPLAY_PARTY_IBAN !== "disabled"
    ? newReferentFormInternal.concat([
        {
          name: "iban",
          value: "",
          mandatory: false,
          label: "iban",
          type: "STRING",
        },
      ])
    : newReferentFormInternal;

export const newOtpForm: FormInputParam[] = [
  {
    name: "mobilePhoneNumber",
    label: "mobilePhoneNumberSignature",
    type: "PHONE",
    value: null,
  },
  {
    name: "email",
    label: "email",
    type: "STRING",
  },
];
