import { config } from "commons/Configuration";
import { LocationAutocomplete } from "commons/components/LocationAutocomplete";
import { LocationSplitted } from "commons/components/LocationSplitted";
//import { FormikInput } from "commons/formik/FormikInput";
import {
  Suggestion,
  mandatoryLocationParams,
  suggestionToLocation,
} from "commons/models/Suggestion";
//import { FormInputParam } from "commons/models/YogaParam";
//import { Field, FieldProps } from "formik";
import { FieldProps } from "formik";

export function PolicyholderLocationForm({ form, ...props }: FieldProps) {
  const disabled = (props as any).disabled as boolean;
  /*  const param: FormInputParam = {
    name: "location",
    type: "STRING",
    label: "residentialAddressOrRegisteredAddress",
    mandatory: true,
  };
  */
  function setLocation(suggestion?: Suggestion) {
    if (suggestion) {
      let location = suggestionToLocation(suggestion);
      form.setFieldValue(`location`, location);
    } else {
      form.setFieldValue(`location`, null);
    }
  }

  return (
    <>
      {config.GEOLOCATION == "disabled" ? (
        /*<Field
          key="location"
          name="location.label"
          component={FormikInput}
          content={param}
          values={form.values}
          />*/
        <LocationSplitted
          name="location"
          label={
            form.values?.legalEntity === "legal"
              ? "registeredOffice"
              : "residentialAddressOrRegisteredAddress"
          }
          startLocation={form.getFieldProps("location").value}
          form={form}
          error={
            form.getFieldMeta("location").touched
              ? form.getFieldMeta("location").error
              : undefined
          }
          disabled={disabled}
        />
      ) : (
        <div className="col-span-2 w-full">
          <LocationAutocomplete
            id="location"
            label={
              form.values?.legalEntity === "legal"
                ? "registeredOffice"
                : "residentialAddressOrRegisteredAddress"
            }
            onSelectLocation={setLocation}
            startLocation={form.getFieldProps("location").value}
            error={
              form.getFieldMeta("location").touched
                ? form.getFieldMeta("location").error
                : undefined
            }
            disabled={disabled}
            mandatoryLocationParams={mandatoryLocationParams}
          />
        </div>
      )}
    </>
  );
}
