import { Location } from "commons/models/Location";
import { BankAccount } from "./BankAccount";

export interface LinkedParty {
  partyId: string;
  taxId: string;
  legalEntity?: boolean;
  name: string;
  surnameOrCompanyName: string;
  birthCountry?: string;
  birthDate?: Date;
  birthPlace?: string;
  gender?: string;
  mobilePhoneNumber?: string;
  mobilePhoneNumberPrefix?: string;
  email?: string;
  location?: Location;
  legacyData?: Map<string, any>;
  bankAccounts?: BankAccount[];
}
