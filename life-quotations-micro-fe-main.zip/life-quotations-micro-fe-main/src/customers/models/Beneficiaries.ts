import { CodeAndDescription } from "commons/models/CodeAndDescription";
import { Location } from "commons/models/Location";
import { FormInputParam, YogaParam } from "commons/models/YogaParam";
import { AVAILABLE_COMPANY_TYPES } from "./AvailableCompanyTypes";
import { config } from "commons/Configuration";
import { KeyValue, Money } from "commons/models/YogaModels";
import { Geo } from "commons/models/Geo";
import { ManagementNode } from "commons/models/nodes/ManagementNode";

export interface Beneficiaries extends Partial<CodeAndDescription> {
  partyData?: BeneficiaryPartyData[];
  thirdReferent?: ThirdReferentData;
}

export interface BeneficiaryPartyData {
  legalEntity: boolean;
  name?: string;
  surnameOrCompanyName: string;
  birthDate?: Date;
  birthCountry?: string;
  birthCountryCode?: string;
  birthCountyCode?: string;
  birthPlace?: string;
  birthPlaceCode?: string;
  parentalRelationship?: CodeAndDescription;
  unverified: boolean;
  irrevocable?: boolean;
  percentage?: number;
  partyId: string;
  taxId: string;
  vatNumber?: string;
  companyType?: string;
  gender?: string;
  mobilePhoneNumber?: string;
  mobilePhoneNumberPrefix?: string;
  email?: string;
  location?: Location;
  employeesNumber?: number;
  revenue?: Money;
  atecoCode?: string;
  iban?: string;
  parameters?: KeyValue<YogaParam>;
}

export interface ThirdReferentData {
  domicileIsNotResidence?: boolean;
  name?: string;
  surnameOrCompanyName: string;
  birthDate?: Date;
  birthPlace?: string;
  birthPlaceCode?: string;
  birthPlaceComplete?: Geo;
  birthCountry?: string;
  birthCountryCode?: string;
  birthCountyCode?: string;
  contactAddress?: Location;
  mobilePhoneNumberPrefix?: string;
  mobilePhoneNumber?: string;
  unverified: boolean;

  partyId: string;
  taxId: string;
  gender?: string;
  email?: string;
  location?: Location;
  iban?: string;
  parameters?: KeyValue<YogaParam>;
  foreign?: boolean;

  managementNodes?: ManagementNode[];
  legacyData?: Map<string, any>;
}

const beneficiaryNaturalPartyDataFormParamsInternal: FormInputParam[] = [
  {
    name: "taxId",
    label: "taxCode",
    type: "STRING",
    updatePartially: true,
    max: 16,
    mandatory: true,
  },
  {
    name: "surnameOrCompanyName",
    label: "surnameOrCompanyName",
    type: "STRING",
    mandatory: true,
  },
  {
    name: "name",
    label: "name",
    type: "STRING",
    className: "lg:pt-0.5",
    mandatory: true,
  },
  {
    name: "birthDate",
    label: "birthDate",
    type: "DATE",
    className: "pt-0.5",
    mandatory: true,
  },
  {
    name: "birthPlace",
    type: "BIRTHPLACE",
    mandatory: true,
  },
  {
    name: "gender",
    label: "gender",
    type: "LIST",
    availableValues: ["male", "female"],
    mandatory: true,
  },
  /*{
    name: "email",
    label: "email",
    type: "STRING",
  },*/
  {
    name: "mobilePhoneNumber",
    label: "mobilePhoneNumber",
    type: "PHONE",
  },
  {
    name: "location",
    label: "residentialAddressOrRegisteredAddress",
    type: "LOCATION",
    className: "order-last col-span-2",
    mandatory: true,
  },
];

export const beneficiaryNaturalPartyDataFormParams =
  config.DISPLAY_PARTY_IBAN !== "disabled"
    ? beneficiaryNaturalPartyDataFormParamsInternal.concat([
        {
          name: "iban",
          value: "",
          mandatory: false,
          label: "iban",
          type: "STRING",
          className: "order-10",
        },
      ])
    : beneficiaryNaturalPartyDataFormParamsInternal;

export const beneficiaryNaturalUnverifiedPartyDataFormParams: FormInputParam[] =
  [
    {
      name: "surnameOrCompanyName",
      label: "surnameOrCompanyName",
      type: "STRING",
      mandatory: true,
    },
    {
      name: "name",
      label: "name",
      type: "STRING",
      className: "lg:pt-0.5",
      mandatory: true,
    },
    {
      name: "birthDate",
      label: "birthDate",
      type: "DATE",
      className: "lg:pt-0.5",
      mandatory: true,
    },
    {
      name: "birthPlace",
      type: "BIRTHPLACE",
      className: "col-span-2 lg:col-span-1",
      mandatory: true,
    },
  ];

const beneficiaryLegalPartyDataFormParamsInternal: FormInputParam[] = [
  {
    name: "vatNumber",
    value: "",
    mandatory: true,
    label: "vatNumber",
    type: "STRING",
    updatePartially: true,
  },
  {
    availableValues: AVAILABLE_COMPANY_TYPES,
    name: "companyType",
    value: "",
    mandatory: true,
    label: "companyType",
    type: "LIST",
  },
  {
    name: "taxId",
    value: "",
    mandatory: true,
    label: "taxCode",
    type: "STRING",
    updatePartially: true,
  },
  {
    name: "surnameOrCompanyName",
    value: "",
    mandatory: true,
    label: "companyName",
    type: "STRING",
  },
  {
    name: "email",
    value: "",
    mandatory: true,
    label: "email",
    type: "STRING",
  },
  {
    name: "mobilePhoneNumber",
    value: null,
    label: "mobilePhoneNumber",
    type: "PHONE",
  },
  {
    name: "atecoCode",
    value: "",
    mandatory: true,
    label: "atecoCode",
    type: "STRING",
  },
  {
    name: "employeesNumber",
    value: "",
    mandatory: true,
    label: "employeesNumber",
    type: "NUMBER",
  },
  {
    name: "revenue.amount",
    value: "",
    mandatory: true,
    label: "revenue",
    type: "AMOUNT",
  },
  {
    name: "location",
    mandatory: true,
    label: "registeredOffice",
    type: "LOCATION",
    className: "order-last col-span-2",
  },
];

export const beneficiaryLegalPartyDataFormParams: FormInputParam[] =
  config.DISPLAY_PARTY_IBAN !== "disabled"
    ? beneficiaryLegalPartyDataFormParamsInternal.concat([
        {
          name: "iban",
          value: "",
          mandatory: false,
          label: "iban",
          type: "STRING",
        },
      ])
    : beneficiaryLegalPartyDataFormParamsInternal;

export const beneficiaryLegalUnverifiedPartyDataFormParams: FormInputParam[] = [
  {
    name: "surnameOrCompanyName",
    value: "",
    mandatory: true,
    label: "companyName",
    type: "STRING",
  },
];

const thirdReferentFormParamsInternal: FormInputParam[] = [
  {
    name: "taxId",
    label: "taxCode",
    type: "STRING",
    className: "order-first",
    updatePartially: true,
    max: 16,
    mandatory: true,
  },
  {
    name: "surnameOrCompanyName",
    label: "surnameOrCompanyName",
    type: "STRING",
    mandatory: true,
  },
  {
    name: "name",
    label: "name",
    type: "STRING",
    mandatory: true,
  },
  {
    name: "birthDate",
    label: "birthDate",
    type: "DATE",
    className: "lg:pt-0.5",
    mandatory: true,
  },
  {
    name: "birthPlace",
    type: "BIRTHPLACE",
    mandatory: true,
  },
  {
    name: "gender",
    label: "gender",
    type: "LIST",
    availableValues: ["male", "female"],
    className: "pt-0.5",
    mandatory: true,
  },
  /*{
    name: "email",
    label: "email",
    type: "STRING",
  },*/
  {
    name: "mobilePhoneNumber",
    label: "mobilePhoneNumber",
    type: "STRING",
  },
  {
    name: "location",
    label: "residentialAddressOrRegisteredAddress",
    type: "LOCATION",
    className: "order-last col-span-2",
  },
];

export const thirdReferentFormParams =
  config.DISPLAY_PARTY_IBAN !== "disabled"
    ? thirdReferentFormParamsInternal.concat([
        {
          name: "iban",
          value: "",
          mandatory: false,
          label: "iban",
          type: "STRING",
        },
      ])
    : thirdReferentFormParamsInternal;

export const unverifiedThirdReferentFormParams: FormInputParam[] = [
  {
    name: "surnameOrCompanyName",
    label: "surnameOrCompanyName",
    type: "STRING",
  },
  {
    name: "name",
    label: "name",
    type: "STRING",
  },
  {
    name: "mobilePhoneNumber",
    label: "mobilePhoneNumber",
    type: "PHONE",
    mandatory: false,
  },
  {
    name: "contactAddress",
    label: "domicile",
    type: "LOCATION",
    className: "col-span-2",
  },
];
