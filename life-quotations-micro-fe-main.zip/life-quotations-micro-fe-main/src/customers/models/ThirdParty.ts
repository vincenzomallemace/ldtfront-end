import { config } from "commons/Configuration";
import { geoValidationError } from "commons/FormUtils";
import { getLocationSchema } from "commons/models/Location";
import { FormInputParam } from "commons/models/YogaParam";
import { ThirdPartyPresence } from "contracts/form/ThirdPartyForm";
import { isValidIBAN } from "ibantools";
import { IntlShape } from "react-intl";
import { isValidPhoneNumber } from "react-phone-number-input";
import * as Yup from "yup";

export const thirdReferentFormParamsInternal: FormInputParam[] = [
  {
    name: "taxId",
    label: "taxCode",
    type: "STRING",
    updatePartially: true,
  },
  {
    name: "surnameOrCompanyName",
    label: "surnameOrCompanyName",
    type: "STRING",
    mandatory: true,
  },
  {
    name: "name",
    label: "name",
    type: "STRING",
    mandatory: true,
  },
  {
    name: "birthDate",
    label: "birthDate",
    type: "DATE",
    mandatory: true,
  },
  {
    name: "birthCountry",
    label: "birthCountry",
    type: "COUNTRY",
    mandatory: true,
  },
  {
    name: "birthPlace",
    label: "birthPlace",
    type: "CITY",
    mandatory: true,
  },
  {
    availableValues: ["male", "female"],
    name: "gender",
    label: "gender",
    type: "LIST",
    mandatory: true,
  },
  /*{
    name: "email",
    label: "email",
    type: "STRING",
  },*/
  {
    name: "mobilePhoneNumber",
    label: "mobilePhoneNumber",
    type: "PHONE",
  },
  {
    name: "location",
    label: "residentialAddressOrRegisteredAddress",
    type: "LOCATION",
    className: "col-span-2 order-last",
  },
];

export const thirdPartyFormFields =
  config.DISPLAY_PARTY_IBAN !== "disabled"
    ? thirdReferentFormParamsInternal.concat([
        {
          name: "iban",
          value: "",
          mandatory: false,
          label: "iban",
          type: "STRING",
        },
      ])
    : thirdReferentFormParamsInternal;

export const getThirdPartyValidationSchema = (policyholderTaxId: string, intl: IntlShape) => {
  const requiredMessage = intl.formatMessage({ id: "required" });
  const requiredGeo = geoValidationError(intl);
  const taxCodeLengthMessage = intl.formatMessage({ id: "lengthError" }, { number: "16" });
  //const selectLocationMessage = intl.formatMessage({ id: "selectLocation" });
  const invalidPhoneMessage = intl.formatMessage({
    id: "invalidPhoneNumber",
  });
  const invalidThirdParty = intl.formatMessage({ id: "invalidThirdParty" });

  return Yup.object({
    taxId: Yup.string().when("presence", {
      is: ThirdPartyPresence.PRESENT,
      then: Yup.string()
        .test("len16", taxCodeLengthMessage, (val) => val?.length === 16)
        .test("policyholderTaxId", invalidThirdParty, (val) => val?.length === 16 && val.toUpperCase() !== policyholderTaxId.toUpperCase()),
    }),
    name: Yup.string().when("presence", {
      is: ThirdPartyPresence.PRESENT,
      then: Yup.string().ensure().required(requiredMessage),
    }),
    surnameOrCompanyName: Yup.string().when("presence", {
      is: ThirdPartyPresence.PRESENT,
      then: Yup.string().ensure().required(requiredMessage),
    }),
    mobilePhoneNumber: Yup.string().when("presence", {
      is: ThirdPartyPresence.PRESENT,
      then: Yup.string()
        .nullable()
        .test("phoneValid", invalidPhoneMessage, (val) => val == null || val == "" || isValidPhoneNumber(val ?? ""))
        .ensure(),
    }),
    birthDate: Yup.string().when("presence", {
      is: ThirdPartyPresence.PRESENT,
      then: Yup.string().required(requiredMessage),
    }),

    birthCountry: Yup.string().when(["presence", "taxId"], {
      is: (presence: string, taxId: string = "") =>
        presence == ThirdPartyPresence.PRESENT && (!taxId || taxId?.length < 12 || (taxId?.length >= 12 && taxId.charAt(11).toUpperCase() === "Z")),
      then: Yup.string().required(requiredGeo),
    }),
    birthPlace: Yup.string().when(["presence", "taxId"], {
      is: (presence: string, taxId: string = "") =>
        presence == ThirdPartyPresence.PRESENT && (!taxId || taxId?.length < 12 || (taxId?.length >= 12 && taxId.charAt(11).toUpperCase() !== "Z")),
      then: Yup.string().required(requiredGeo),
    }),
    gender: Yup.string().when("presence", {
      is: ThirdPartyPresence.PRESENT,
      then: Yup.string().required(requiredMessage),
    }),
    location: Yup.object().when("presence", {
      is: ThirdPartyPresence.PRESENT,
      then: getLocationSchema(intl),
    }),
    domicile: Yup.object().when(["presence", "domicileIsNotResidence"], {
      is: (presence, domicileIsNotResidence) => presence == ThirdPartyPresence.PRESENT && domicileIsNotResidence,
      then: getLocationSchema(intl),
    }),
    email: Yup.string()
      .nullable()
      .email(intl.formatMessage({ id: "invalidEmail" })),
    iban: Yup.string().when("presence", {
      is: ThirdPartyPresence.PRESENT,
      then: Yup.string()
        .nullable()
        .test("iban", intl.formatMessage({ id: "ibanFormatError" }), (v) => !v || isValidIBAN(v)),
    }),
  });
};
