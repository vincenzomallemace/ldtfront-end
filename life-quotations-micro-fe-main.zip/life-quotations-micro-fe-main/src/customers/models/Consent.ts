import * as Yup from "yup";
import { isValidPhoneNumber } from "react-phone-number-input";
import { IntlShape } from "react-intl";

export interface Consent {
  value: boolean;
  consentId: string;
  name: string;
  text: string;
  mandatory: boolean;
  default: boolean;
  types: ConsentType[];
  extraData?: ConsentExtraData;
}

export class ConsentExtraData {
  email?: ConsentExtraDataValue = new ConsentExtraDataValue();
  phone?: ConsentExtraDataValue = new ConsentExtraDataValue();
}

export class ConsentExtraDataValue {
  type: ConsentExtraDataType = "HIDDEN";
  value?: string;
}

export type ConsentExtraDataType =
  | "HIDDEN"
  | "VISIBLE_AND_OPTIONAL"
  | "VISIBLE_AND_REQUIRED";

export enum ConsentType {
  POLICYHOLDER_IN_ISSUE = "POLICYHOLDER_IN_ISSUE",
  APPLICANT_IN_FNOL = "APPLICANT_IN_FNOL",
  INSURED_IN_FNOL = "INSURED_IN_FNOL",
  INSURED_IN_ISSUE = "INSURED_IN_ISSUE",
}

export const CONSENT_TYPES = Object.values(ConsentType);

export function needExtraData(consent: Consent): boolean {
  if (consent && consent.extraData) {
    return Object.keys(consent.extraData).some(
      (key) =>
        (consent.extraData[key] as ConsentExtraDataValue).type ==
        "VISIBLE_AND_OPTIONAL" ||
        (consent.extraData[key] as ConsentExtraDataValue).type ==
        "VISIBLE_AND_REQUIRED"
    );
  }
  return false;
}

export function hasMandatoryExtraData(consent: Consent): boolean {
  if (consent && consent.extraData) {
    return (
      consent.value &&
      Object.keys(consent.extraData).some(
        (key) =>
          (consent.extraData[key] as ConsentExtraDataValue).type ==
          "VISIBLE_AND_REQUIRED" &&
          !(consent.extraData[key] as ConsentExtraDataValue).value
      )
    );
  }
  return false;
}

export const mergePartyConsents = (
  consents: Consent[] = [],
  partyConsents: Consent[] = []
): Consent[] => {
  //Take customer consents if present, otherwise take default from configuration
  return consents?.map((c) => {
    const partyConsent = partyConsents?.find(
      (pc) => pc.consentId === c.consentId
    );
    return partyConsent
      ? Object.assign({}, c, {
        value: getConsentValue(c, partyConsent),
        extraData: getConsentExtraData(c, partyConsent),
      })
      : Object.assign({}, c, {
        value: getConsentValue(c),
        extraData: getConsentExtraData(c),
      });
  });
};

const getConsentValue = (
  consentModel: Consent,
  partyConsent?: Consent
): boolean => {
  let result = consentModel.default;
  if (partyConsent) {
    result = partyConsent.value;
  }
  return result;
};

const getConsentExtraData = (
  consentModel: Consent,
  partyConsent?: Consent
): ConsentExtraData => {
  let result = consentModel.extraData || new ConsentExtraData();
  if (consentModel.extraData && partyConsent && partyConsent.extraData) {
    result = {
      email: {
        type: consentModel.extraData.email?.type,
        value: partyConsent.extraData.email?.value ?? "",
      },
      phone: {
        type: consentModel.extraData.phone?.type,
        value: partyConsent.extraData.phone?.value ?? "",
      },
    };
  }
  return result;
};

export const getConsentSchema = (intl: IntlShape) => {
  return Yup.object().shape({
    value: Yup.boolean().when("mandatory", {
      is: (mandatory: boolean) => mandatory,
      then: Yup.boolean().oneOf([true], intl.formatMessage({ id: "required" })),
      otherwise: Yup.boolean(),
    }),
    extraData: Yup.object()
      .nullable()
      .when("value", {
        is: true,
        then: Yup.object()
          .nullable()
          .shape({
            email: Yup.object().shape({
              value: Yup.string()
                .email(intl.formatMessage({ id: "invalidEmail" }))
                .when("type", {
                  is: (type: string) => type === "VISIBLE_AND_REQUIRED",
                  then: Yup.string()
                    .ensure()
                    .required(intl.formatMessage({ id: "required" })),
                  otherwise: Yup.string().nullable(),
                }),
            }),
            phone: Yup.object().shape({
              value: Yup.string()
                .test(
                  "phoneValid",
                  intl.formatMessage({ id: "invalidPhoneNumber" }),
                  (val) => !val || isValidPhoneNumber(val ?? "")
                )
                .when("type", {
                  is: (type: string) => type === "VISIBLE_AND_REQUIRED",
                  then: Yup.string()
                    .ensure()
                    .required(intl.formatMessage({ id: "required" })),
                  otherwise: Yup.string().nullable(),
                }),
            }),
          }),
        otherwise: Yup.object().nullable(),
      }),
  });
};

export const getConsentsSchema = (intl: IntlShape) => {
  const requiredMessage = intl.formatMessage({ id: "required" });
  return Yup.array().of(getConsentSchema(intl)).required(requiredMessage);
};
