import { Consent, getConsentsSchema } from "customers/models/Consent";
import { KeyValue, Money } from "commons/models/YogaModels";
import { ManagementNode } from "commons/models/nodes/ManagementNode";
import { QuestionnaireModel } from "questionnaires/models/QuestionnaireModel";
import { LinkedParty } from "./LinkedParty";
import { Location, getLocationSchema } from "commons/models/Location";
import { BankAccount } from "./BankAccount";
import * as Yup from "yup";
import { isValidPhoneNumber } from "react-phone-number-input";
import { isValidIBAN } from "ibantools";
import { IntlShape } from "react-intl";
import { YogaParam } from "commons/models/YogaParam";
import { geoValidationError, toYupObjectByCode } from "commons/FormUtils";
import { Profile } from "./Profile";

type BirthDataParams =
  | "taxId"
  | "birthCountryCode"
  | "birthCountyCode"
  | "birthCountry"
  | "birthDate"
  | "birthPlaceCode"
  | "birthPlace";

export interface EntityWithBirthData extends Pick<Party, BirthDataParams> {}

export interface Party {
  partyId: string;
  taxId: string;
  legalEntity?: boolean;
  vatNumber?: string;
  companyType?: string;
  name: string;
  surnameOrCompanyName: string;
  birthCountryCode?: string;
  birthCountyCode?: string;
  birthCountry?: string;
  birthDate?: Date;
  birthPlaceCode?: string;
  birthPlace?: string;
  gender?: string;
  mobilePhoneNumber?: string;
  mobilePhoneNumberPrefix?: string;
  customerReference?: string;
  profile?: Profile;
  tags?: string[];
  email?: string;
  location?: Location;
  domicile?: Location;
  domicileIsNotResidence?: boolean;
  managementNodes?: ManagementNode[];
  questionnaireCode?: string;
  questionnaire?: QuestionnaireModel;
  consents?: Consent[];
  lastConsentsUpdateInstant?: Date;
  hidden?: boolean;
  legacyData?: Map<string, any>;
  registrationDate?: Date;
  employeesNumber?: number;
  revenue?: Money;
  atecoCode?: string;
  rae?: string;
  sae?: string;
  iban?: string;
  bankAccounts?: BankAccount[];
  dataEnrichmentComplete?: boolean;
  otpSignatureEnabled?: boolean;
  linkedParties?: { [role: string]: LinkedParty[] };
  parameters?: KeyValue<YogaParam>;
}

export const getPolicyholderSchema = (
  intl: IntlShape,
  partyParams: YogaParam[] = []
) => {
  const requiredMessage = intl.formatMessage({ id: "required" });
  const requiredGeo = geoValidationError(intl);
  const vatNumberLengthMessage = intl.formatMessage(
    { id: "lengthError" },
    { number: "11" }
  );
  const taxCodeLengthMessage = intl.formatMessage(
    { id: "lengthError" },
    { number: "16" }
  );
  //const selectLocationMessage = intl.formatMessage({ id: "selectLocation" });
  const invalidPhoneMessage = intl.formatMessage({
    id: "invalidPhoneNumber",
  });

  return {
    legalEntity: Yup.string().required(requiredMessage),
    taxId: Yup.string().when(["legalEntity", "companyType"], {
      is: (legalEntity: string, companyType: string) =>
        legalEntity === "legal" &&
        companyType !== "Ditta Individuale" &&
        companyType !== "Impresa familiare",
      then: Yup.string().test(
        "len11",
        vatNumberLengthMessage,
        (val) => val?.length === 11
      ),
      otherwise: Yup.string().test(
        "len16",
        taxCodeLengthMessage,
        (val) => val?.length === 16
      ),
    }),
    companyType: Yup.string().when("legalEntity", {
      is: "legal",
      then: Yup.string().required(requiredMessage),
      otherwise: Yup.string().nullable(),
    }),
    vatNumber: Yup.string().when("legalEntity", {
      is: "legal",
      then: Yup.string().test(
        "len11",
        vatNumberLengthMessage,
        (val) => val?.length === 11
      ),
      otherwise: Yup.string().nullable(),
    }),
    surnameOrCompanyName: Yup.string().required(requiredMessage),
    name: Yup.string().when("legalEntity", {
      is: "legal",
      then: Yup.string().nullable(),
      otherwise: Yup.string().required(requiredMessage),
    }),
    birthDate: Yup.string().when("legalEntity", {
      is: "legal",
      then: Yup.string().nullable(),
      otherwise: Yup.string().required(requiredMessage),
    }),
    birthCountry: Yup.string().when(["legalEntity", "taxId"], {
      is: (legalEntity: string, taxId: string) =>
        legalEntity !== "legal" &&
        (!taxId ||
          taxId?.length < 12 ||
          (taxId?.length >= 12 && taxId.charAt(11).toUpperCase() === "Z")),
      then: Yup.string().required(requiredGeo),
      otherwise: Yup.string().nullable(),
    }),
    birthPlace: Yup.string().when(["legalEntity", "taxId"], {
      is: (legalEntity: string, taxId: string) =>
        legalEntity !== "legal" &&
        (!taxId ||
          taxId?.length < 12 ||
          (taxId?.length >= 12 && taxId.charAt(11).toUpperCase() !== "Z")),
      then: Yup.string().required(requiredGeo),
      otherwise: Yup.string().nullable(),
    }),
    gender: Yup.string().when("legalEntity", {
      is: "legal",
      then: Yup.string().nullable(),
      otherwise: Yup.string().required(requiredMessage),
    }),
    email: Yup.string()
      .nullable()
      .email(intl.formatMessage({ id: "invalidEmail" })),
    mobilePhoneNumber: Yup.string()
      .nullable()
      .test(
        "phoneValid",
        invalidPhoneMessage,
        (val) => val == null || val == "" || isValidPhoneNumber(val ?? "")
      ),
    location: getLocationSchema(intl),
    domicile: Yup.object({
      label: Yup.string().ensure().nullable(),
    }).when("domicileIsNotResidence", {
      is: true,
      then: getLocationSchema(intl),
      otherwise: Yup.object().nullable(),
    }),
    domicileIsNotResidence: Yup.boolean().default(false).nullable(),
    iban: Yup.string()
      .nullable()
      .test(
        "iban",
        intl.formatMessage({ id: "ibanFormatError" }),
        (v) => !v || isValidIBAN(v)
      ),
    consents: getConsentsSchema(intl),
    parameters: getPartyParamsSchema(intl, partyParams),
  };
};

export const getPartyParamsSchema = (
  intl: IntlShape,
  partyParams: YogaParam[] = []
) =>
  Yup.object(
    toYupObjectByCode(
      partyParams.filter((p) => p.visible && !p.disabled),
      intl
    )
  );

export const isForeign = (party: EntityWithBirthData) => {
  if (party.birthCountry || party.birthCountryCode) {
    return !(
      party.birthCountryCode === "ITA" || party.birthCountry === "ITALIA"
    );
  } else if (party.taxId) {
    return party.taxId.charAt(11).toUpperCase() === "Z";
  }
};
