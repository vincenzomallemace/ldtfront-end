export interface BankAccount {
  iban: string;
  description: string;
}
