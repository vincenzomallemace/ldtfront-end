import { Party } from "./Party";

export interface ProductParty extends Party {
  policyholderIsInsuredPerson?: boolean;
}
