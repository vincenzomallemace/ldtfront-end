export interface Profile {
  profileId?: string;
  profileType?: string;
  email: string;
  userName?: string;
  tags?: string[];
  authenticatorProfileId?: string;
  communicationsType?: string;
  lastAccessInstant?: Date;
}
