import { Context } from "commons/contexts/Context";
import { ConfirmModal } from "commons/modals/ConfirmModal";
import { ManagementNode } from "commons/models/nodes/ManagementNode";
import { partyService } from "commons/services/PartyService";
import { useContext } from "react";
import { FormattedMessage } from "react-intl";

interface PartyFromAnotherNodeModalProps {
  isOpen: boolean;
  onClose: any;
  onConfirm: any;
  partyToRetrieve: any;
  newManagementNodes: ManagementNode[];
}

export default function PartyFromAnotherNodeModal({
  isOpen,
  onClose,
  onConfirm,
  partyToRetrieve,
  newManagementNodes,
}: PartyFromAnotherNodeModalProps) {
  const context = useContext(Context);
  function onConfimIntercept() {
    context.changeLoading(1);
    Promise.all(
      newManagementNodes.map((node) =>
        partyService.addManagementNode(partyToRetrieve.partyId, node)
      )
    )
      .then(() => {
        if (onConfirm) {
          onConfirm();
        }
      })
      .finally(() => {
        context.changeLoading(-1);
      });
  }

  return (
    <ConfirmModal
      isOpen={isOpen}
      onClose={onClose}
      onConfirm={onConfimIntercept}
      title={"partyOnAnotherNode"}
      closeClickOutside={false}
      dataQa="confirm-retrieve-party-modal"
    >
      {partyToRetrieve && (
        <>
          {partyToRetrieve.legalEntity ? (
            <FormattedMessage
              id="retrievePartyLegalOnAnotherNode"
              values={{
                vatNumber: partyToRetrieve.vatNumber,
              }}
            />
          ) : (
            <FormattedMessage
              id="retrievePartyOnAnotherNode"
              values={{
                taxCode: partyToRetrieve.taxId,
              }}
            />
          )}
        </>
      )}
    </ConfirmModal>
  );
}
