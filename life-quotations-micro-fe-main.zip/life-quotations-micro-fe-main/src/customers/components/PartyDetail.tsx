import { config } from "commons/Configuration";
//import { Accordion } from "commons/components/Accordion";
import { DateComponent } from "commons/components/DateComponent";
import { DlElement } from "commons/components/DlElement";
import { FormikInput } from "commons/formik/FormikInput";
import { Party } from "customers/models/Party";
import { Field, FieldProps } from "formik";
import { useEffect } from "react";
import { FormattedMessage } from "react-intl";

interface PartyDetailParams {
  party: Party;
}

export function PartyMainDetails({ party }: PartyDetailParams) {
  return (
    <>
      {party.legalEntity ? (
        <div className="grid grid-cols-2 lg:grid-cols-3 gap-y-3 gap-x-8" data-qa="legal-policyholder-output-data">
          <dl data-qa="companyType">
            <DlElement title="companyType" bordered={false}>
              {party.companyType ? <FormattedMessage id={party.companyType} /> : <>{"-"}</>}
            </DlElement>
          </dl>
          <dl data-qa="vatNumber">
            <DlElement title="vatNumber" bordered={false}>
              {party.vatNumber || "-"}
            </DlElement>
          </dl>
          <dl data-qa="taxCode">
            <DlElement title="taxCode" bordered={false}>
              {party.taxId || "-"}
            </DlElement>
          </dl>
          <dl data-qa="companyName">
            <DlElement title="companyName" bordered={false}>
              {party.surnameOrCompanyName || "-"}
            </DlElement>
          </dl>
        </div>
      ) : (
        <div className="grid grid-cols-2 lg:grid-cols-3 gap-y-3 gap-x-8" data-qa="physical-policyholder-output-data">
          <dl data-qa="taxCode">
            <DlElement title="taxCode" bordered={false}>
              {party.taxId || "-"}
            </DlElement>
          </dl>
          <dl data-qa="surnameOrCompanyName">
            <DlElement title="surnameOrCompanyName" bordered={false}>
              {party.surnameOrCompanyName || "-"}
            </DlElement>
          </dl>
          <dl data-qa="name">
            <DlElement title="name" bordered={false}>
              {party.name || "-"}
            </DlElement>
          </dl>

          <dl data-qa="birthDate">
            <DlElement title="birthDate" bordered={false}>
              {party.birthDate ? <DateComponent date={party.birthDate} /> : <>{"-"}</>}
            </DlElement>
          </dl>

          {party.taxId.charAt(11).toUpperCase() !== "Z" ? (
            <dl data-qa="birthPlace">
              <DlElement title="birthPlace" bordered={false}>
                {party.birthPlace ? (party.birthCountyCode ? `${party.birthPlace} (${party.birthCountyCode})` : party.birthPlace) : "-"}
              </DlElement>
            </dl>
          ) : (
            <dl data-qa="birthCountry">
              <DlElement title="birthCountry" bordered={false}>
                {party.birthCountry || "-"}
              </DlElement>
            </dl>
          )}

          <dl data-qa="gender">
            <DlElement title="gender" bordered={false}>
              {party.gender ? <FormattedMessage id={party.gender} /> : <>{"-"}</>}
            </DlElement>
          </dl>
        </div>
      )}
    </>
  );
}

interface AdditionalPartyDetailsProps extends FieldProps<Party> {
  policyholder: Party;
}

export function AdditionalPartyDetailsForm({ field: { value }, policyholder }: AdditionalPartyDetailsProps) {
  useEffect(() => {
    if (!value.domicileIsNotResidence) value.domicile = { label: "" };
  }, [value.domicileIsNotResidence]);

  return (
    <>
      <div className="grid grid-cols-2 lg:grid-cols-3 gap-y-4 gap-x-8 items-start pt-4" data-qa="policyholder-form-container">
        {/*<Field
          name="email"
          component={FormikInput}
          content={{
            name: "email",
            label: "email",
            type: "STRING",
          }}
        />*/}
        <Field
          name="mobilePhoneNumber"
          component={FormikInput}
          content={{
            name: "mobilePhoneNumber",
            label: "mobilePhoneNumber",
            type: "PHONE",
          }}
        />
        {policyholder.legalEntity && (
          <>
            <Field
              name="atecoCode"
              component={FormikInput}
              content={{
                name: "atecoCode",
                label: "atecoCode",
                type: "STRING",
              }}
            />
            <Field
              name="employeesNumber"
              component={FormikInput}
              content={{
                name: "employeesNumber",
                label: "employeesNumber",
                type: "NUMBER",
              }}
            />
            <Field
              name="revenue"
              component={FormikInput}
              content={{
                name: "revenue",
                label: "revenue",
                type: "AMOUNT",
              }}
              currency={policyholder.revenue?.currency}
            />
          </>
        )}

        {config.DISPLAY_PARTY_IBAN !== "disabled" && (
          <Field
            name="iban"
            component={FormikInput}
            content={{
              name: "iban",
              label: "iban",
              type: "STRING",
            }}
          />
        )}
        <div className="col-span-2">
          <Field
            name="location"
            component={FormikInput}
            content={{
              name: "location",
              label: policyholder.legalEntity ? "registeredOffice" : "residentialAddressOrRegisteredAddress",
              type: "LOCATION",
            }}
          />
        </div>
        {/*</div>

      <Accordion
        name="domicile-data"
        open={policyholder.domicileIsNotResidence}
        className="flex flex-col gap-2 w-full py-4"
        titleContainerClasses=""
        accordionTitle={
          <div className="inline-flex items-center w-full">
            <h4 className="text-title-text whitespace-nowrap">
              <FormattedMessage id="domicileData" />
            </h4>
            <span className="middle-border-accordion"></span>
          </div>
        }
        key="domicile-section"
      >*/}
        <div className="col-span-2 lg:col-span-3 grid grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-4">
          <div>
            <Field
              name="domicileIsNotResidence"
              component={FormikInput}
              label="domicileDataLabel"
              content={{
                name: "domicileIsNotResidence",
                label: policyholder.legalEntity ? "domicileDataLabelLegal" : "domicileDataLabelPhysical",
                type: "BOOLEAN",
              }}
            />
          </div>
          {value.domicileIsNotResidence && (
            <div className="col-span-2">
              <Field
                name="domicile"
                component={FormikInput}
                content={{
                  name: "domicile",
                  type: "LOCATION",
                  label: "domicile",
                }}
              />
            </div>
          )}
        </div>
        {/*</Accordion>*/}
      </div>
    </>
  );
}
