import { default as classNames, default as classnames } from "classnames";
import { FormattedMessage } from "react-intl";

interface ConsentSelectProps {
  id: string;
  checked?: boolean;
  onChange?: (v) => void;
  //used when toggle is used inside formik
  name?: string;
  mandatory?: boolean;
  error?: boolean;
}

export default function ConsentSelect({
  checked,
  onChange = () => {},
  name,
  mandatory = false,
  error = false,
}: ConsentSelectProps) {
  return (
    <span className={classNames("relative inline-block w-40")}>
      {mandatory ? (
        <div
          id={name}
          data-qa={`${name}-select-buttons`}
          className="flex w-full"
        >
          <div key="yes" data-tip data-for="yes" className="ml-auto">
            <button
              title="yes"
              data-qa="yes"
              type="button"
              onClick={() => {
                onChange(true);
              }}
              className={classnames(
                "cursor-pointer border-2 rounded-lg ml-auto grow-0 w-14 text-body-text px-4 py-2",
                {
                  "bg-primary border-primary text-button-text": checked == true,
                  "border-body-text": !error && checked != true,
                  "border-error bg-box-background text-primary":
                    error && checked != true,
                }
              )}
            >
              <FormattedMessage id="yes" />
            </button>
          </div>
        </div>
      ) : (
        <div
          id={name}
          data-qa={`${name}-select-buttons`}
          className="flex justify-end"
        >
          <div key="no" data-tip data-for="no">
            <button
              title="no"
              data-qa="no"
              type="button"
              onClick={() => {
                onChange(false);
              }}
              className={classnames(
                "cursor-pointer border-2 rounded-lg rounded-r-none grow-0 w-14 text-body-text px-4 py-2",
                {
                  "bg-primary border-primary text-button-text":
                    checked == false,
                  "border-body-text": checked == null,
                  "border-error bg-box-background text-primary":
                    error && checked == null,
                  "border-r-primary border-body-text": checked == true,
                }
              )}
            >
              <FormattedMessage id="no" />
            </button>
          </div>
          <div key="yes" data-tip data-for="yes">
            <button
              title="yes"
              data-qa="yes"
              type="button"
              onClick={() => {
                onChange(true);
              }}
              className={classnames(
                "cursor-pointer border-2 border-l-0 rounded-lg rounded-l-none grow-0 w-14 text-body-text px-4 py-2",
                {
                  "bg-primary border-primary text-button-text": checked == true,
                  "border-body-text": checked == null || checked == false,
                  "border-error bg-box-background text-primary":
                    error && checked == null,
                }
              )}
            >
              <FormattedMessage id="yes" />
            </button>
          </div>
        </div>
      )}
      {error && (checked == null || (mandatory && checked != true)) && (
        <div
          className={classnames(
            "text-base text-error w-full whitespace-nowrap text-right"
          )}
        >
          <FormattedMessage id="required" />
        </div>
      )}
    </span>
  );
}
