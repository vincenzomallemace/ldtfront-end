import { withAuthenticator } from "@aws-amplify/ui-react";
import Logout from "Logout";
import { Amplify, Auth } from "aws-amplify";
import axios from "axios";
import { AUTH, config } from "commons/Configuration";
import { AppContexts } from "commons/contexts/AppContexts";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { routes } from "routes";
import "./index.css";
import "./root.css";

Amplify.configure({
  region: AUTH.region,
  userPoolId: AUTH.userPoolId,
  userPoolWebClientId: AUTH.userPoolWebClientId,
  authenticationFlowType: "USER_SRP_AUTH",
});

axios.interceptors.request.use(
  async (request) => {
    if (
      !config.SKIP_SSO ||
      (config.SKIP_SSO && config.SKIP_SSO === "disabled")
    ) {
      const authenticatedUser = await Auth.currentAuthenticatedUser();
      const jwtToken = authenticatedUser?.signInUserSession?.idToken?.jwtToken;
      if (jwtToken) {
        request.headers["x-jwt-assertion"] = "Bearer " + jwtToken; // atm we`re using Authorization for Basic auth
      }
    }
    request.headers["yoga-channel"] =
      import.meta.env.VITE_YOGA_CHANNEL ?? "b2b";
    return request;
  },
  (error) => Promise.reject(error)
);

function App() {
  return (
    <div id="App">
      <div className="text-body-text bg-background" id="life-quotation-mfe">
        <AppContexts>
          <BrowserRouter basename={import.meta.env.BASE_URL}>
            <Routes>
              {routes.map((e) => (
                <Route
                  key={e.path}
                  path={`${e.path}`}
                  element={<e.component />}
                ></Route>
              ))}
              <Route path="/logout" element={<Logout />}></Route>
            </Routes>
          </BrowserRouter>
        </AppContexts>
      </div>
    </div>
  );
}

export default !import.meta.env.DEV ||
(config.SKIP_SSO && config.SKIP_SSO === "enabled")
  ? App
  : withAuthenticator(App);
