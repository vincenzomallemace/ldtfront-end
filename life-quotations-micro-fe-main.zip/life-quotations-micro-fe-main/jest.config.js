// Sync object
/** @type {import('@jest/types').Config.InitialOptions} */
const config = {
  silent: true,
  bail: false,
  clearMocks: true,
  collectCoverage: false,
  coverageDirectory: "coverage",
  maxWorkers: 6,
  coveragePathIgnorePatterns: [
    "<rootDir>/node_modules/",
    "<rootDir>/src/index.tsx",
    "<rootDir>/src/.styleguide",
    "<rootDir>/src/themes",
  ],
  fakeTimers: {
    enableGlobally: true,
  },
  haste: {
    computeSha1: true,
    forceNodeFilesystemAPI: true,
  },
  collectCoverageFrom: [
    "src/**/*.tsx",
    "src/**/*.ts",
    "!<rootDir>/src/reportWebVitals.*",
    "!<rootDir>/src/index.tsx",
    "!src/**/*.d.ts",
    "!src/**/__mocks__/*.ts",
    "!src/**/models/*.ts"
  ],
  coverageThreshold: {
    global: {
      statements: 0,
      branches: 0,
      functions: 0,
      lines: 0,
    },
  },
  coverageReporters: ["lcov", "text"],
  moduleDirectories: ["src", "node_modules"],
  transformIgnorePatterns: ["/node_modules/(?!(uuid)/)"],
  setupFilesAfterEnv: ["<rootDir>/src/setupTests.tsx"],
  testEnvironment: "jest-environment-jsdom",
  testMatch: ["<rootDir>/src/__tests__/*.{ts,tsx}"],
  watchPlugins: [
    "jest-watch-typeahead/filename",
    "jest-watch-typeahead/testname",
  ],
  moduleNameMapper: {
    "\\.(jpg|ico|jpeg|png|gif|eot|otf|webp|ttf|woff|woff2|mp4|webm|wav|mp3|m4a|aac|oga)$":
      "<rootDir>/fileMock.js",
    "\\.(css|less)$": "<rootDir>/fileMock.js",
    "\\.svg": "<rootDir>/svgMock.js",
    "^uuid$": require.resolve("uuid"),
  },
};

module.exports = config;
