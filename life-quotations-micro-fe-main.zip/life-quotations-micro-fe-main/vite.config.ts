import federation from "@originjs/vite-plugin-federation";
import react from "@vitejs/plugin-react";
import path from "path";
import { defineConfig } from "vite";
import svgr from "vite-plugin-svgr";
import tsconfigPaths from "vite-tsconfig-paths";

// https://vitejs.dev/config/
export default defineConfig(({ command }) => {
  return {
    build: {
      target: "esnext",
      outDir: "build",
      sourcemap: command == "serve",
      minify: command != "serve",
    },
    plugins: [
      tsconfigPaths(),
      react(),
      svgr(),
      federation({
        name: "life_quotations_app",
        filename: "remoteEntry.js",
        shared: ["react", "react-dom", "react-router-dom", "axios"],
        exposes: {
          "./Federation": "./src/Federation.tsx",
        },
      }),
    ],
    server: {
      proxy: {
        "/api": "https://zurich-dev.dock.aws.d4x.it",
      },
      port: 3000,
    },
    resolve: {
      alias: {
        "~/": `${path.resolve(__dirname, "src")}/`,
        "./runtimeConfig": "./runtimeConfig.browser",
        "ag-grid-react": `${path.resolve(
          __dirname,
          "./node_modules/ag-grid-react/bundles/ag-grid-react.min.js"
        )}/`,
      },
    },
  };
});
