#!/bin/bash

version=$(git rev-list --count HEAD)

sed -i "s/1.0.*/1.0.$(echo $version)/" chart/Chart.yaml

sed -i "s/1.0.*/1.0.$(echo $version)/" chart/templates/*-deployment.yaml

sed -i "s/1.0.*/1.0.$(echo $version)/" cicd/version
