#!/bin/bash

NAMESPACE=$1
DEPLOYMENT=$2

if [ -z $1 ]
then
    echo "Please insert namespace"
    exit 0
fi

if [ -z $2 ]
then
    echo "Please insert deployment"
    exit 0
fi


old_pod=$(kubectl get po -n $NAMESPACE | grep $DEPLOYMENT | awk '{print $1}')

echo "old pod that is about to die "
echo $old_pod

kubectl rollout restart deployment $DEPLOYMENT -n $NAMESPACE

while [[ $(kubectl get pods -n $NAMESPACE | grep -c $DEPLOYMENT ) != "2" ]]; 
do    
    sleep 1; 
    done

new_pods=$(kubectl get po -n $NAMESPACE | grep $DEPLOYMENT | awk '{print $1}')


echo "waiting for new pod spawn"
while [[ $(kubectl get pods -n $NAMESPACE | grep -c $DEPLOYMENT ) != "1" ]]; 
do    
    sleep 1; 
    done

new_pod=$(echo ${new_pods//$old_pod/})

echo "waiting for new pod to be up and running..."
echo $new_pod

time=0
while [[ $(kubectl get pods $new_pod -n $NAMESPACE -o 'jsonpath={..status.conditions[?(@.type=="Ready")].status}') != "True" ]]; 
do
    sleep 1
    time = time + 1
    if [time>300]
    then
        echo "Deploy timeout"
        exit 0
    fi
    done

exit 0
