module.exports = {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
    "postcss-prefix-selector": {
      prefix: ".life-quotation-mfe",
      exclude: [":root", RegExp("(^\\.custom-select)\\w")],
    },
  },
};
